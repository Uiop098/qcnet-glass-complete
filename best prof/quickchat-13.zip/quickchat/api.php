<?php
// api.php — chat backend: fetch messages, send text messages, and
// clear a room (host/super only). All requests require a valid
// session token issued by auth.php.

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

function require_valid_session($room, $token) {
    $session = get_session($token);
    if (!$session || $session['room'] !== safe_room_name($room)) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Session expired or invalid. Please rejoin.']);
        exit;
    }
    return $session;
}

if ($method === 'GET') {
    $room = isset($_GET['room']) ? $_GET['room'] : 'default';
    $token = isset($_GET['token']) ? $_GET['token'] : '';
    $since = isset($_GET['since']) ? intval($_GET['since']) : 0;

    $session = require_valid_session($room, $token);

    $config = read_config($room);
    if (!$config) $config = default_config();

    if ($session['role'] === 'member' && is_banned($config, $session['user'])) {
        remove_sessions_for_user($room, $session['user']);
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'banned', 'message' => 'You have been removed from this chat by the host.']);
        exit;
    }

    touch_presence($config, $session['user'], $session['role']);
    write_config($room, $config);

    $messages = read_messages($room);
    if ($since > 0) {
        $messages = array_values(array_filter($messages, function ($m) use ($since) {
            return isset($m['id']) && $m['id'] > $since;
        }));
    }

    $isAdmin = in_array($session['role'], ['host', 'super'], true);
    $mutedRemaining = mute_remaining_ms($config, $session['user']);

    $response = [
        'ok' => true,
        'messages' => $messages,
        'title' => $config['title'],
        'presence' => $isAdmin ? active_presence($config) : null,
        'bannedUsers' => $isAdmin ? $config['bannedUsers'] : null,
        'mutedUsers' => $isAdmin ? $config['mutedUsers'] : null,
        'you' => [
            'user' => $session['user'],
            'role' => $session['role'],
            'mutedRemainingMs' => $mutedRemaining,
        ],
    ];

    echo json_encode($response);
    exit;
}

if ($method === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true);
    $room = isset($body['room']) ? $body['room'] : '';
    $token = isset($body['token']) ? $body['token'] : '';
    $text = isset($body['text']) ? trim($body['text']) : '';

    $session = require_valid_session($room, $token);

    $config = read_config($room);
    if (!$config) $config = default_config();

    if ($session['role'] === 'member' && is_banned($config, $session['user'])) {
        remove_sessions_for_user($room, $session['user']);
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'banned', 'message' => 'You have been removed from this chat by the host.']);
        exit;
    }

    if ($session['role'] !== 'super') {
        $remaining = mute_remaining_ms($config, $session['user']);
        if ($remaining > 0) {
            http_response_code(403);
            echo json_encode([
                'ok' => false,
                'error' => 'muted',
                'message' => 'You are muted for ' . ceil($remaining / 1000) . ' more second(s).',
                'mutedRemainingMs' => $remaining,
            ]);
            exit;
        }
    }

    $text = trim($text);
    if ($text === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Empty message']);
        exit;
    }
    if (mb_strlen($text) > 20000) {
        $text = mb_substr($text, 0, 20000);
    }

    $newMsg = append_message($room, [
        'type' => 'text',
        'user' => $session['user'],
        'role' => $session['role'],
        'text' => $text,
    ]);

    echo json_encode(['ok' => true, 'message' => $newMsg]);
    exit;
}

if ($method === 'DELETE') {
    $room = isset($_GET['room']) ? $_GET['room'] : '';
    $token = isset($_GET['token']) ? $_GET['token'] : '';

    $session = require_valid_session($room, $token);

    if (!in_array($session['role'], ['host', 'super'], true)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Only the host or a super user can clear this chat.']);
        exit;
    }

    write_messages($room, []);
    $dir = room_files_dir($room);
    foreach (glob($dir . '/*') as $f) {
        if (is_file($f)) @unlink($f);
    }

    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
