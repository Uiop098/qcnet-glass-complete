<?php
// admin.php — small admin actions bundled together:
//   action=set_title            : host or super — rename the room (emoji ok)
//   action=reset_host_password  : super only — clears the host password
//                                  so the next host login sets a new one,
//                                  and kicks any current host session
//   action=unban                : host or super — lift a ban

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
$token = isset($body['token']) ? $body['token'] : '';
$action = isset($body['action']) ? $body['action'] : '';

$session = get_session($token);
if (!$session) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Session expired or invalid. Please rejoin.']);
    exit;
}

$room = $session['room'];
$config = read_config($room);
if (!$config) $config = default_config();

if ($action === 'set_title') {
    if (!in_array($session['role'], ['host', 'super'], true)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Only the host or a super user can rename this room.']);
        exit;
    }
    $title = isset($body['title']) ? (string)$body['title'] : '';
    // Strip control characters/tags but keep emoji (multi-byte unicode is fine).
    $title = trim($title);
    $title = preg_replace('/[\x00-\x1F\x7F]/u', '', $title);
    $title = mb_substr($title, 0, 60);
    $config['title'] = $title;
    write_config($room, $config);
    echo json_encode(['ok' => true, 'title' => $title]);
    exit;
}

if ($action === 'reset_host_password') {
    if ($session['role'] !== 'super') {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Only a super user can reset the host password.']);
        exit;
    }
    $config['hostPasswordHash'] = null;
    write_config($room, $config);
    remove_host_sessions($room);
    echo json_encode(['ok' => true, 'message' => 'Host password cleared. The next person to log in as host will set a new one.']);
    exit;
}

if ($action === 'unban') {
    if (!in_array($session['role'], ['host', 'super'], true)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Only the host or a super user can unban people.']);
        exit;
    }
    $targetUser = trim((string)($body['targetUser'] ?? ''));
    if ($targetUser === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'No user specified.']);
        exit;
    }
    unban_user($config, $targetUser);
    write_config($room, $config);
    echo json_encode(['ok' => true, 'unbanned' => $targetUser]);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'Unknown action.']);
