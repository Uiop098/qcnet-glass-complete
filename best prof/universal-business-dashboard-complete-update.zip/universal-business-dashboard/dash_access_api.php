<?php
// dash_access_api.php — role policies and per-user access overrides.
// All writes use the existing encrypted JSON table helpers.

require_once __DIR__ . '/dash_firewall.php';
require_once __DIR__ . '/dash_access.php';
require_once __DIR__ . '/dash_audit.php';

header('Content-Type: application/json');

$identity = dash_access_current_user();
if (!$identity) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'error' => 'Unauthorized access.']);
    exit;
}

$dir = dash_access_dir();
if (!is_dir($dir)) @mkdir($dir, 0755, true);
$action = $_GET['action'] ?? '';
$catalog = dash_access_permission_catalog();

function dash_access_post_bool($value) {
    return in_array(strtolower((string)$value), ['1', 'true', 'on', 'yes'], true);
}

function dash_access_valid_role($role) {
    return array_key_exists(strtolower((string)$role), dash_access_default_roles());
}

switch ($action) {
    case 'get_access':
        $store = dash_access_store($dir);
        $effective = dash_access_effective_permissions($dir, $identity['username'], $identity['is_admin']);
        $can_manage = $identity['is_admin'] && !empty($effective['permissions']['system_manage']);
        $response = [
            'status' => 'success',
            'actor' => ['username' => $identity['username'], 'role' => $effective['role'], 'is_admin' => $identity['is_admin'], 'can_manage' => $can_manage, 'permissions' => $effective['permissions']],
            'permissions' => $catalog,
            'roles' => $store['roles'],
            'users' => $can_manage ? dash_access_dashboard_users($dir) : [],
        ];
        echo json_encode($response);
        break;

    case 'save_role_permission':
        if (!$identity['is_admin']) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'error' => 'Only an administrator can edit role policies.']);
            break;
        }
        $role = strtolower(trim((string)($_POST['role'] ?? '')));
        $permission = trim((string)($_POST['permission'] ?? ''));
        if (!dash_access_valid_role($role) || !isset($catalog[$permission])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'error' => 'Invalid role or permission.']);
            break;
        }
        if ($role === 'owner') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'error' => 'Owner access cannot be restricted.']);
            break;
        }
        $store = dash_access_store($dir);
        $store['roles'][$role]['permissions'][$permission] = dash_access_post_bool($_POST['allowed'] ?? false);
        $store = dash_access_save($dir, $store);
        log_activity($dir, $identity['username'], 'role_permission_updated', 'Updated ' . $role . ' access for ' . $permission . '.');
        echo json_encode(['status' => 'success', 'role' => $role, 'permission' => $permission, 'allowed' => !empty($store['roles'][$role]['permissions'][$permission])]);
        break;

    case 'assign_user_role':
        if (!$identity['is_admin']) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'error' => 'Only an administrator can assign roles.']);
            break;
        }
        $username = trim((string)($_POST['username'] ?? ''));
        $role = strtolower(trim((string)($_POST['role'] ?? '')));
        $users = get_secure_table($dir . '/users.json');
        if ($username === '' || !isset($users[$username]) || !dash_access_valid_role($role) || $role === 'owner') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'error' => 'Choose an existing user and a valid non-owner role.']);
            break;
        }
        $store = dash_access_store($dir);
        $store['users'][$username]['role'] = $role;
        if (!isset($store['users'][$username]['overrides']) || !is_array($store['users'][$username]['overrides'])) $store['users'][$username]['overrides'] = [];
        $store = dash_access_save($dir, $store);
        log_activity($dir, $identity['username'], 'user_role_assigned', 'Assigned ' . $role . ' to ' . $username . '.');
        echo json_encode(['status' => 'success', 'username' => $username, 'role' => $role]);
        break;

    case 'save_user_override':
        if (!$identity['is_admin']) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'error' => 'Only an administrator can edit user overrides.']);
            break;
        }
        $username = trim((string)($_POST['username'] ?? ''));
        $permission = trim((string)($_POST['permission'] ?? ''));
        $users = get_secure_table($dir . '/users.json');
        if ($username === '' || !isset($users[$username]) || !isset($catalog[$permission])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'error' => 'Invalid user or permission.']);
            break;
        }
        $store = dash_access_store($dir);
        $store['users'][$username]['overrides'][$permission] = dash_access_post_bool($_POST['allowed'] ?? false);
        $store = dash_access_save($dir, $store);
        log_activity($dir, $identity['username'], 'user_permission_override', 'Updated ' . $permission . ' for ' . $username . '.');
        echo json_encode(['status' => 'success', 'username' => $username, 'permission' => $permission, 'allowed' => !empty($store['users'][$username]['overrides'][$permission])]);
        break;

    case 'clear_user_overrides':
        if (!$identity['is_admin']) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'error' => 'Only an administrator can clear user overrides.']);
            break;
        }
        $username = trim((string)($_POST['username'] ?? ''));
        $users = get_secure_table($dir . '/users.json');
        if ($username === '' || !isset($users[$username])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'error' => 'User not found.']);
            break;
        }
        $store = dash_access_store($dir);
        $store['users'][$username]['overrides'] = [];
        dash_access_save($dir, $store);
        log_activity($dir, $identity['username'], 'user_permission_reset', 'Reset individual access overrides for ' . $username . '.');
        echo json_encode(['status' => 'success', 'username' => $username]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['status' => 'error', 'error' => 'Unknown access action.']);
        break;
}
?>