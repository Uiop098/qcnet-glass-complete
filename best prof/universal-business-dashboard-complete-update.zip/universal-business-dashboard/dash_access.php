<?php
// dash_access.php — shared role and permission helpers for the dashboard.
//
// Access policy is stored in the same tenant-scoped encrypted JSON format as
// every other dashboard table. This file deliberately delegates all crypto to
// dash_crypto.php; it never introduces a second storage or encryption format.

require_once __DIR__ . '/dash_crypto.php';

function dash_access_permission_catalog() {
    return [
        'overview_view' => ['label' => 'View overview', 'description' => 'See workspace health, activity, and summary metrics.', 'group' => 'Workspace'],
        'operations_view' => ['label' => 'View operations', 'description' => 'Review the action queue and operational status.', 'group' => 'Workspace'],
        'operations_manage' => ['label' => 'Manage operations', 'description' => 'Create, complete, and prioritize action items.', 'group' => 'Workspace'],
        'businesses_view' => ['label' => 'View businesses', 'description' => 'See the active business profile and workspace information.', 'group' => 'Workspace'],
        'businesses_manage' => ['label' => 'Manage businesses', 'description' => 'Edit business details and manage workspace configuration.', 'group' => 'Workspace'],
        'people_view' => ['label' => 'View people', 'description' => 'Review people and account status in this workspace.', 'group' => 'People'],
        'people_manage' => ['label' => 'Manage people', 'description' => 'Invite, assign roles, edit, and remove people.', 'group' => 'People'],
        'payments_view' => ['label' => 'View payments', 'description' => 'Read payments, balances, and payment health.', 'group' => 'Finance'],
        'payments_manage' => ['label' => 'Manage payments', 'description' => 'Record payments, issue changes, and export finance data.', 'group' => 'Finance'],
        'reports_view' => ['label' => 'View reports', 'description' => 'Review report tables, totals, and visual trends.', 'group' => 'Insights'],
        'reports_manage' => ['label' => 'Manage reports', 'description' => 'Create report data, edit rows, and export insights.', 'group' => 'Insights'],
        'profile_manage' => ['label' => 'Manage own profile', 'description' => 'Update personal profile and account preferences.', 'group' => 'Account'],
        'settings_manage' => ['label' => 'Manage settings', 'description' => 'Change business, notification, and payment settings.', 'group' => 'Administration'],
        'themes_manage' => ['label' => 'Manage themes', 'description' => 'Choose and update dashboard themes.', 'group' => 'Administration'],
        'system_manage' => ['label' => 'Manage system access', 'description' => 'Edit role policies and individual user overrides.', 'group' => 'Administration'],
    ];
}

function dash_access_default_roles() {
    $all = array_fill_keys(array_keys(dash_access_permission_catalog()), true);
    $only = static function ($keys) {
        return array_fill_keys($keys, true);
    };
    return [
        'owner' => ['name' => 'Owner', 'description' => 'Full workspace and access control authority.', 'permissions' => $all],
        'admin' => ['name' => 'Admin', 'description' => 'Full business operations access.', 'permissions' => $all],
        'manager' => ['name' => 'Manager', 'description' => 'Day-to-day operations and reporting access.', 'permissions' => $only(['overview_view', 'operations_view', 'operations_manage', 'businesses_view', 'people_view', 'payments_view', 'reports_view', 'reports_manage', 'profile_manage'])],
        'member' => ['name' => 'Member', 'description' => 'Standard team access to assigned workspace information.', 'permissions' => $only(['overview_view', 'operations_view', 'businesses_view', 'people_view', 'payments_view', 'reports_view', 'profile_manage'])],
        'viewer' => ['name' => 'Viewer', 'description' => 'Read-only workspace access.', 'permissions' => $only(['overview_view', 'businesses_view', 'people_view', 'payments_view', 'reports_view', 'profile_manage'])],
    ];
}

function dash_access_dir() {
    $tenant_id = $_SESSION['dash_tenant'] ?? 'main';
    $safe_tenant = preg_replace('/[^a-zA-Z0-9_\-]/', '', $tenant_id);
    return ($tenant_id === 'main') ? __DIR__ . '/data_dash' : __DIR__ . '/data_dash/' . $safe_tenant;
}

function dash_access_file($dir) {
    return rtrim($dir, DIRECTORY_SEPARATOR) . '/access.json';
}

function dash_access_normalize($store) {
    if (!is_array($store)) $store = [];
    $defaults = dash_access_default_roles();
    $roles = isset($store['roles']) && is_array($store['roles']) ? $store['roles'] : [];
    foreach ($defaults as $role_id => $role) {
        if (!isset($roles[$role_id]) || !is_array($roles[$role_id])) $roles[$role_id] = $role;
        $roles[$role_id]['name'] = $role['name'];
        $roles[$role_id]['description'] = $role['description'];
        $existing_permissions = isset($roles[$role_id]['permissions']) && is_array($roles[$role_id]['permissions']) ? $roles[$role_id]['permissions'] : [];
        $roles[$role_id]['permissions'] = array_merge($role['permissions'], $existing_permissions);
    }
    $users = isset($store['users']) && is_array($store['users']) ? $store['users'] : [];
    foreach ($users as $username => &$user) {
        if (!is_array($user)) $user = [];
        $user_role = strtolower((string)($user['role'] ?? 'member'));
        if (!isset($roles[$user_role])) $user_role = 'member';
        $user['role'] = $user_role;
        $user['overrides'] = isset($user['overrides']) && is_array($user['overrides']) ? $user['overrides'] : [];
    }
    unset($user);
    return ['version' => 1, 'roles' => $roles, 'users' => $users, 'updated_at' => $store['updated_at'] ?? null];
}

function dash_access_store($dir) {
    $file = dash_access_file($dir);
    if (!file_exists($file)) {
        $store = dash_access_normalize([]);
        save_secure_table($file, $store);
        return $store;
    }
    return dash_access_normalize(get_secure_table($file));
}

function dash_access_save($dir, $store) {
    $store = dash_access_normalize($store);
    $store['updated_at'] = time();
    save_secure_table(dash_access_file($dir), $store);
    return $store;
}

function dash_access_current_user() {
    if (isset($_SESSION['dash_admin'])) return ['username' => $_SESSION['dash_admin'], 'session_role' => 'admin', 'is_admin' => true];
    if (isset($_SESSION['dash_user'])) return ['username' => $_SESSION['dash_user'], 'session_role' => 'user', 'is_admin' => false];
    return null;
}

function dash_access_actor_role($dir, $username, $is_admin) {
    if ($is_admin) {
        return (($_SESSION['dash_tenant'] ?? 'main') === 'main') ? 'owner' : 'admin';
    }
    $store = dash_access_store($dir);
    $role = strtolower((string)($store['users'][$username]['role'] ?? 'member'));
    return isset($store['roles'][$role]) ? $role : 'member';
}

function dash_access_effective_permissions($dir, $username, $is_admin) {
    $store = dash_access_store($dir);
    $role_id = dash_access_actor_role($dir, $username, $is_admin);
    $permissions = $store['roles'][$role_id]['permissions'] ?? [];
    if (!$is_admin && isset($store['users'][$username]['overrides']) && is_array($store['users'][$username]['overrides'])) {
        $permissions = array_merge($permissions, $store['users'][$username]['overrides']);
    }
    foreach (dash_access_permission_catalog() as $permission_id => $_meta) {
        $permissions[$permission_id] = !empty($permissions[$permission_id]);
    }
    return ['role' => $role_id, 'permissions' => $permissions];
}

function dash_access_can($permission_id) {
    $identity = dash_access_current_user();
    if (!$identity) return false;
    $effective = dash_access_effective_permissions(dash_access_dir(), $identity['username'], $identity['is_admin']);
    return !empty($effective['permissions'][$permission_id]);
}

function dash_access_require($permission_id) {
    if (!dash_access_can($permission_id)) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'error' => 'You do not have permission to perform this action.']);
        exit;
    }
}

function dash_access_dashboard_users($dir) {
    $users = get_secure_table($dir . '/users.json');
    $store = dash_access_store($dir);
    $result = [];
    foreach ($users as $username => $account) {
        if (!is_array($account)) $account = [];
        $role = strtolower((string)($store['users'][$username]['role'] ?? 'member'));
        if (!isset($store['roles'][$role])) $role = 'member';
        $overrides = $store['users'][$username]['overrides'] ?? [];
        $permissions = $store['roles'][$role]['permissions'];
        $permissions = array_merge($permissions, is_array($overrides) ? $overrides : []);
        foreach (dash_access_permission_catalog() as $permission_id => $_meta) $permissions[$permission_id] = !empty($permissions[$permission_id]);
        $result[$username] = [
            'username' => $username,
            'name' => $account['name'] ?? $username,
            'email' => $account['email'] ?? '',
            'role' => $role,
            'status' => $account['status'] ?? 'active',
            'created_at' => $account['created_at'] ?? null,
            'overrides' => is_array($overrides) ? $overrides : [],
            'permissions' => $permissions,
        ];
    }
    return $result;
}
?>