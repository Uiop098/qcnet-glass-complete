<?php
require_once 'dash_firewall.php';
require_once 'dash_crypto.php';
require_once 'dash_access.php';
header('Content-Type: application/json');

if (!isset($_SESSION['dash_admin']) && !isset($_SESSION['dash_user'])) die(json_encode(["error" => "Unauthorized access."]));

$is_admin = isset($_SESSION['dash_admin']);
$action = $_GET['action'] ?? '';
$tenant_id = $_SESSION['dash_tenant'] ?? 'main';
$dir = ($tenant_id === 'main') ? __DIR__ . '/data_dash' : __DIR__ . '/data_dash/' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $tenant_id);
if (!is_dir($dir)) @mkdir($dir, 0755, true);

$db_files = [
    'users' => $dir . '/users.json', 'payments' => $dir . '/payments.json', 
    'reminders' => $dir . '/reminders.json', 'links' => $dir . '/links.json',
    'products' => $dir . '/products.json', 'settings' => $dir . '/settings.json'
];
foreach ($db_files as $file) { if (!file_exists($file)) save_secure_table($file, []); }

switch ($action) {
    case 'get_dashboard_data':
        $users = get_secure_table($db_files['users']);
        $payments = get_secure_table($db_files['payments']);
        $products = get_secure_table($db_files['products']);
        $identity = dash_access_current_user();
        $effective = dash_access_effective_permissions($dir, $identity['username'], $identity['is_admin']);
        $permissions = $effective['permissions'];
        $data = [
            "status" => "success",
            "links" => !empty($permissions['businesses_view']) ? get_secure_table($db_files['links']) : [],
            "reminders" => !empty($permissions['operations_view']) ? get_secure_table($db_files['reminders']) : [],
            "products" => !empty($permissions['businesses_view']) ? $products : []
        ];
        
        if ($is_admin) {
            $data["users"] = $users; $data["payments"] = $payments;
            $data["settings"] = get_secure_table($db_files['settings']);
            
            $total_users = count($users);
            $total_revenue = 0;
            foreach ($payments as $p) { if (($p['status'] ?? '') === 'Received') $total_revenue += floatval($p['amount'] ?? 0); }
            $data["stats"] = [ "total_users" => $total_users, "total_revenue" => $total_revenue ];
        } else {
            $user_id = $_SESSION['dash_user']; 
            $my_payments = array_filter($payments, function($p) use ($user_id) { return ($p['client'] ?? '') === $user_id; });
            $data["payments"] = array_values($my_payments); 
            $data["my_profile"] = $users[$user_id] ?? [];
        }
        $data["access"] = ["role" => $effective["role"], "permissions" => $permissions];
        echo json_encode($data); break;
        
    case 'add_record':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $table = $_POST['table'] ?? ''; if (!array_key_exists($table, $db_files)) die(json_encode(["error" => "Invalid table."]));
            $table_permissions = [
                'payments' => 'payments_manage',
                'reminders' => 'operations_manage',
                'links' => 'businesses_manage',
                'products' => 'businesses_manage',
                'settings' => 'settings_manage',
            ];
            if (!isset($table_permissions[$table]) || !dash_access_can($table_permissions[$table])) {
                http_response_code(403);
                die(json_encode(["status" => "error", "error" => "You do not have permission to add records here."]));
            }
            // users.json is a keyed object ({username: {...}}), not a flat
            // array like payments/reminders/links/products — appending a
            // record here with $data[] would corrupt that structure, and
            // this path never hashes a password anyway. Adding a user goes
            // through dash_auth.php's create_pending invite-token flow instead.
            if ($table === 'users') die(json_encode(["error" => "Use the invite-token flow to add a user, not this endpoint."]));
            $data = get_secure_table($db_files[$table]); $new_record = ["id" => uniqid(), "created_at" => time()];
            foreach ($_POST as $key => $value) if ($key !== 'table') $new_record[$key] = $value;
            $data[] = $new_record; save_secure_table($db_files[$table], $data); echo json_encode(["status" => "success"]);
        }
        break;

    case 'update_record':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $table = $_POST['table'] ?? '';
            $table_permissions = [
                'payments' => ['payments_manage', 'reports_manage'],
                'reminders' => ['operations_manage'],
                'links' => ['businesses_manage'],
                'products' => ['businesses_manage'],
            ];
            $allowed = false;
            foreach ($table_permissions[$table] ?? [] as $permission) {
                if (dash_access_can($permission)) { $allowed = true; break; }
            }
            if (!$allowed) {
                http_response_code(403);
                die(json_encode(["status" => "error", "error" => "You do not have permission to edit this record."]));
            }
            $record_id = trim((string)($_POST['id'] ?? ''));
            if ($record_id === '' || !isset($db_files[$table])) {
                http_response_code(400);
                die(json_encode(["status" => "error", "error" => "Invalid record."]));
            }
            $field_allowlist = [
                'payments' => ['client', 'amount', 'status', 'description', 'notes'],
                'reminders' => ['task', 'priority', 'due', 'notes'],
                'links' => ['title', 'url'],
                'products' => ['name', 'price', 'desc'],
            ];
            $records = get_secure_table($db_files[$table]);
            $updated = false;
            foreach ($records as &$record) {
                if (!is_array($record) || (string)($record['id'] ?? '') !== $record_id) continue;
                foreach ($field_allowlist[$table] as $field) {
                    if (array_key_exists($field, $_POST)) $record[$field] = $_POST[$field];
                }
                $record['updated_at'] = time();
                $updated = true;
                break;
            }
            unset($record);
            if (!$updated) {
                http_response_code(404);
                die(json_encode(["status" => "error", "error" => "Record not found."]));
            }
            save_secure_table($db_files[$table], $records);
            echo json_encode(["status" => "success"]);
        }
        break;
        
    case 'save_settings':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && dash_access_can('settings_manage')) {
            // Previously this expected the client to have sent real AES
            // ciphertext (it hadn't — see dash_script.js's saveSettings()) and
            // tried to decrypt it with a fixed, key-derived IV, which is itself
            // a weak construction (a static IV reused across every save, taken
            // from the encryption key's own bytes, leaks patterns and is bad
            // practice even where a static IV is otherwise tolerable). This
            // always failed. Settings now arrive as plain POST fields over
            // HTTPS and get the same AES-256-CBC-with-random-IV at-rest
            // encryption as every other table, via save_secure_table().
            $settings_data = [
                "payment_mode" => $_POST['payment_mode'] ?? 'server',
                "cf_app_id" => $_POST['cf_app_id'] ?? '',
                "cf_env" => $_POST['cf_env'] ?? 'SANDBOX'
            ];
            // Keep the previously-saved secret key if the admin left the
            // password-style field blank (don't overwrite it with an empty string).
            $existing = get_secure_table($db_files['settings']);
            $new_secret = $_POST['cf_secret_key'] ?? '';
            $settings_data['cf_secret_key'] = $new_secret !== '' ? $new_secret : ($existing['cf_secret_key'] ?? '');

            save_secure_table($db_files['settings'], $settings_data);
            echo json_encode(["status" => "success"]);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            http_response_code(403); echo json_encode(["status" => "error", "error" => "You do not have permission to change settings."]);
        }
        break;
        
    case 'update_user':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && dash_access_can('people_manage')) {
            $username = $_POST['username'] ?? ''; $users = get_secure_table($db_files['users']);
            if (isset($users[$username])) {
                $users[$username]['name'] = $_POST['name'] ?? $users[$username]['name']; $users[$username]['mobile'] = $_POST['mobile'] ?? '';
                $users[$username]['email'] = $_POST['email'] ?? ''; $users[$username]['address'] = $_POST['address'] ?? '';
                $users[$username]['tags'] = $_POST['tags'] ?? ''; $users[$username]['notes'] = $_POST['notes'] ?? ''; $users[$username]['admin_message'] = $_POST['admin_message'] ?? '';
                save_secure_table($db_files['users'], $users); echo json_encode(["status" => "success"]);
            } else echo json_encode(["error" => "User not found"]);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            http_response_code(403); echo json_encode(["status" => "error", "error" => "You do not have permission to manage people."]);
        }
        break;
        
    case 'update_my_profile':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_admin && dash_access_can('profile_manage')) {
            $user_id = $_SESSION['dash_user']; $users = get_secure_table($db_files['users']);
            if (isset($users[$user_id])) {
                $users[$user_id]['mobile'] = $_POST['mobile'] ?? ''; $users[$user_id]['email'] = $_POST['email'] ?? '';
                $users[$user_id]['address'] = $_POST['address'] ?? ''; save_secure_table($db_files['users'], $users); echo json_encode(["status" => "success"]);
            } else echo json_encode(["error" => "User not found"]);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            http_response_code(403); echo json_encode(["status" => "error", "error" => "You do not have permission to update this profile."]);
        }
        break;
        
    case 'delete_user':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && dash_access_can('people_manage')) {
            $username = $_POST['username'] ?? ''; $users = get_secure_table($db_files['users']);
            if (isset($users[$username])) {
                unset($users[$username]);
                save_secure_table($db_files['users'], $users);
                $access_store = dash_access_store($dir);
                unset($access_store['users'][$username]);
                dash_access_save($dir, $access_store);
                echo json_encode(["status" => "success"]);
            } 
            else echo json_encode(["error" => "User not found"]);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            http_response_code(403); echo json_encode(["status" => "error", "error" => "You do not have permission to remove people."]);
        }
        break;
}
?>