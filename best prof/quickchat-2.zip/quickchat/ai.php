<?php
// ai.php — sends a prompt to Pollinations' free, keyless text API and
// posts the reply back into the room as a message from "AI Assistant".
//
// No API key required for casual/light use. If Pollinations changes
// their free-tier policy or rate-limits you, this is the only file
// you'd need to update (see call_pollinations() below).

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

if (!$body || empty($body['room']) || !isset($body['prompt']) || trim($body['prompt']) === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing room or prompt']);
    exit;
}

$room = $body['room'];
$prompt = trim(strip_tags($body['prompt']));
if (mb_strlen($prompt) > 2000) {
    $prompt = mb_substr($prompt, 0, 2000);
}

// Give the AI a little context: the last few messages in the room.
$history = read_messages($room);
$recent = array_slice($history, -8); // last 8 messages for context

$chatMessages = [
    ['role' => 'system', 'content' => 'You are a helpful assistant participating in a casual group chat. Keep replies concise and friendly.'],
];
foreach ($recent as $m) {
    if ($m['type'] === 'text' && !empty($m['text'])) {
        $role = ($m['user'] === 'AI Assistant') ? 'assistant' : 'user';
        $content = ($role === 'user') ? ($m['user'] . ': ' . $m['text']) : $m['text'];
        $chatMessages[] = ['role' => $role, 'content' => $content];
    }
}
$chatMessages[] = ['role' => 'user', 'content' => $prompt];

function call_pollinations($messages) {
    $url = 'https://text.pollinations.ai/openai';
    $payload = json_encode([
        'model' => 'openai',
        'messages' => $messages,
        'seed' => random_int(1, 999999999),
        'stream' => false,
        'private' => true,
    ]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 25);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($response === false || $httpCode >= 400) {
        return ['ok' => false, 'error' => 'Pollinations request failed (HTTP ' . $httpCode . '): ' . $curlErr];
    }

    // Try to parse as OpenAI-style JSON first
    $decoded = json_decode($response, true);
    if (is_array($decoded) && isset($decoded['choices'][0]['message']['content'])) {
        return ['ok' => true, 'text' => trim($decoded['choices'][0]['message']['content'])];
    }

    // Fallback: some Pollinations endpoints return plain text directly
    if (is_string($response) && trim($response) !== '') {
        return ['ok' => true, 'text' => trim($response)];
    }

    return ['ok' => false, 'error' => 'Unexpected response from Pollinations'];
}

$result = call_pollinations($chatMessages);

if (!$result['ok']) {
    http_response_code(502);
    echo json_encode(['ok' => false, 'error' => $result['error']]);
    exit;
}

$newMsg = append_message($room, [
    'type' => 'text',
    'user' => 'AI Assistant',
    'text' => $result['text'],
]);

echo json_encode(['ok' => true, 'message' => $newMsg]);
