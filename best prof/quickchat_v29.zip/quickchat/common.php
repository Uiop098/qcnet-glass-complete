<?php
// common.php — shared helpers: message storage, room config (PIN, host
// password, bans, mutes, presence, theme, title), and session/token
// management (including the super-user "master" session used to browse
// rooms before joining one).

$GLOBALS['dataDir'] = __DIR__ . '/data';
$GLOBALS['filesDir'] = __DIR__ . '/files';
$GLOBALS['maxMessages'] = 300;
$GLOBALS['messageExpirySeconds'] = 24 * 60 * 60; // 24 hours
$GLOBALS['sessionTtlSeconds'] = 6 * 60 * 60; // 6 hours, sliding
$GLOBALS['presenceWindowMs'] = 10000; // "online" = seen in last 10s
$GLOBALS['MASTER_ROOM'] = '__super_master__'; // sentinel room for super pre-join sessions
$GLOBALS['linkPreviewCacheSeconds'] = 6 * 60 * 60; // 6 hours
$GLOBALS['messageEditWindowSeconds'] = null; // null = editable any time (owner-only)

// SUPER_MASTER_SECRET — used ONLY to let a verified super-user session
// recover a room's encryption passphrase automatically (no manual key
// entry). CHANGE THIS to your own long random string before deploying.
// Anyone who has this string (i.e. server file access) can recover every
// room's encryption passphrase, same as any super user can — this is an
// intentional bypass, not a bug. If you don't want this bypass to exist
// at all, don't use the "auto-recover for super" feature (see README).
if (!defined('SUPER_MASTER_SECRET')) {
    define('SUPER_MASTER_SECRET', 'CHANGE-ME-a8f3k2m9x7q1w5e0r4t6y8u2i0o3p9-CHANGE-ME');
}

// ---------------------------------------------------------------------
// Firewall — application-level IP blocklist + rate limiting. Required
// here (rather than in each file individually) so every entry point
// that already does `require_once common.php` gets the blocklist check
// for free. See FIREWALL_HOW_IT_WORKS.txt for the full explanation.
// ---------------------------------------------------------------------
require_once __DIR__ . '/firewall.php';

if (is_ip_blocked(get_client_ip())) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'blocked', 'message' => 'Your connection has been blocked from this site.']);
    exit;
}

if (!is_dir($GLOBALS['dataDir'])) {
    mkdir($GLOBALS['dataDir'], 0755, true);
}
if (!is_dir($GLOBALS['filesDir'])) {
    mkdir($GLOBALS['filesDir'], 0755, true);
}

$dataHtaccess = $GLOBALS['dataDir'] . '/.htaccess';
if (!file_exists($dataHtaccess)) {
    @file_put_contents($dataHtaccess, "Require all denied\n");
}
$filesHtaccess = $GLOBALS['filesDir'] . '/.htaccess';
if (!file_exists($filesHtaccess)) {
    @file_put_contents($filesHtaccess, "Options -Indexes\n");
}

function now_ms() {
    return round(microtime(true) * 1000);
}

// ---------------------------------------------------------------------
// Basic helpers
// ---------------------------------------------------------------------

function safe_room_name($room) {
    $room = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$room);
    return substr($room, 0, 64) ?: 'default';
}

function room_file($room) {
    return $GLOBALS['dataDir'] . '/room_' . safe_room_name($room) . '.json';
}

function room_config_file($room) {
    return $GLOBALS['dataDir'] . '/config_' . safe_room_name($room) . '.json';
}

function sessions_file() {
    return $GLOBALS['dataDir'] . '/sessions.json';
}

function remember_tokens_file() {
    return $GLOBALS['dataDir'] . '/remember_tokens.json';
}

function room_files_dir($room) {
    $dir = $GLOBALS['filesDir'] . '/' . safe_room_name($room);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    return $dir;
}

function room_wallpapers_dir($room) {
    $dir = room_files_dir($room) . '/wallpapers';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    return $dir;
}

function read_json_file($path) {
    if (!file_exists($path)) return null;
    $fp = fopen($path, 'r');
    if (!$fp) return null;
    flock($fp, LOCK_SH);
    $content = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return json_decode($content, true);
}

function write_json_file($path, $data) {
    $fp = fopen($path, 'c+');
    if (!$fp) return false;
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return true;
}

// ---------------------------------------------------------------------
// Room config: PIN, host password, bans, mutes, presence, theme, title
// ---------------------------------------------------------------------

function default_config() {
    return [
        'pinHash' => null,
        'hostPasswordHash' => null,
        'bannedUsers' => [],   // [{user: lowercase, ts: ms}]
        'mutedUsers' => [],    // usernameLower => muteUntilMs
        'presence' => [],      // usernameLower => {name, role, ts, typingUntil}
        'title' => '',
        'createdAt' => null,
        'lastActivity' => null,
        'roomTheme' => ['background' => '', 'glowColor' => '', 'uiSkin' => ''], // super-controlled, room-wide
        'pinnedMessageId' => null,
        'encEnabled' => false, // client-side end-to-end encryption toggle
        'encSalt' => null,     // random, non-secret — used to derive the key from the room's encryption passphrase (never stored here)
        'encSuperRecovery' => null, // passphrase, recoverable ONLY for verified super sessions — see SUPER_MASTER_SECRET below
    ];
}

function read_config($room) {
    $data = read_json_file(room_config_file($room));
    if (!is_array($data)) return null;
    return array_merge(default_config(), $data);
}

function write_config($room, $config) {
    return write_json_file(room_config_file($room), $config);
}

// Encrypts a room's encryption passphrase so it can be recovered later
// ONLY by code that knows SUPER_MASTER_SECRET (i.e. this server, for a
// verified super session). Uses AES-256-CBC with a random IV per call.
function super_encrypt_passphrase($plaintext) {
    $key = hash('sha256', SUPER_MASTER_SECRET, true); // 32 raw bytes
    $iv = openssl_random_pseudo_bytes(16);
    $ciphertext = openssl_encrypt($plaintext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    if ($ciphertext === false) return null;
    return base64_encode($iv . $ciphertext);
}

function super_decrypt_passphrase($blob) {
    if (!$blob) return null;
    $raw = base64_decode($blob, true);
    if ($raw === false || strlen($raw) < 17) return null;
    $iv = substr($raw, 0, 16);
    $ciphertext = substr($raw, 16);
    $key = hash('sha256', SUPER_MASTER_SECRET, true);
    $plaintext = openssl_decrypt($ciphertext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $plaintext === false ? null : $plaintext;
}

// End-to-end encryption toggle. The server stores a random, non-secret
// salt plus (optionally) a copy of the passphrase that only a verified
// super session can ever recover — see super_encrypt_passphrase() above.
// Enabling (or rotating) always issues a fresh salt, since a new key means
// old ciphertext can no longer be derived-and-checked against it anyway.
function enable_encryption(&$config, $passphraseForSuperRecovery = null) {
    $config['encEnabled'] = true;
    $config['encSalt'] = base64_encode(random_bytes(16));
    $config['encSuperRecovery'] = $passphraseForSuperRecovery !== null
        ? super_encrypt_passphrase($passphraseForSuperRecovery)
        : null;
}

function disable_encryption(&$config) {
    $config['encEnabled'] = false;
    $config['encSalt'] = null;
    $config['encSuperRecovery'] = null;
}

function is_banned($config, $username) {
    $uname = strtolower(trim($username));
    foreach ($config['bannedUsers'] as $b) {
        if (isset($b['user']) && $b['user'] === $uname) return true;
    }
    return false;
}

function ban_user(&$config, $username) {
    $uname = strtolower(trim($username));
    if ($uname === '') return;
    foreach ($config['bannedUsers'] as $b) {
        if (isset($b['user']) && $b['user'] === $uname) return;
    }
    $config['bannedUsers'][] = ['user' => $uname, 'ts' => now_ms()];
}

function unban_user(&$config, $username) {
    $uname = strtolower(trim($username));
    $config['bannedUsers'] = array_values(array_filter($config['bannedUsers'], function ($b) use ($uname) {
        return !(isset($b['user']) && $b['user'] === $uname);
    }));
}

// Returns remaining mute milliseconds (>0) if currently muted, else 0.
function mute_remaining_ms($config, $username) {
    $uname = strtolower(trim($username));
    if (!isset($config['mutedUsers'][$uname])) return 0;
    $remaining = $config['mutedUsers'][$uname] - now_ms();
    return $remaining > 0 ? $remaining : 0;
}

function mute_user(&$config, $username, $minutes) {
    $uname = strtolower(trim($username));
    if ($uname === '') return;
    if ($minutes <= 0) {
        unset($config['mutedUsers'][$uname]);
    } else {
        $config['mutedUsers'][$uname] = now_ms() + ($minutes * 60 * 1000);
    }
}

function touch_presence(&$config, $username, $role) {
    $existing = isset($config['presence'][strtolower($username)]) ? $config['presence'][strtolower($username)] : [];
    $config['presence'][strtolower($username)] = [
        'name' => $username,
        'role' => $role,
        'ts' => now_ms(),
        'typingUntil' => isset($existing['typingUntil']) ? $existing['typingUntil'] : 0,
        'ip' => function_exists('get_client_ip') ? get_client_ip() : ($existing['ip'] ?? null),
    ];
}

function set_typing(&$config, $username, $role) {
    touch_presence($config, $username, $role);
    $config['presence'][strtolower($username)]['typingUntil'] = now_ms() + 4000;
}

// Names currently typing, excluding $exceptUser, visible to everyone (not admin-only).
function typing_users($config, $exceptUser) {
    $now = now_ms();
    $exceptLower = strtolower($exceptUser);
    $out = [];
    foreach ($config['presence'] as $key => $p) {
        if ($key === $exceptLower) continue;
        if (!empty($p['typingUntil']) && $p['typingUntil'] > $now) {
            $out[] = $p['name'];
        }
    }
    return $out;
}

function active_presence($config) {
    $now = now_ms();
    $out = [];
    foreach ($config['presence'] as $p) {
        if (($now - $p['ts']) <= $GLOBALS['presenceWindowMs']) {
            $out[] = $p;
        }
    }
    return $out;
}

// List every room that has a config file, with summary info for the
// super-user room browser (no room-name typing needed).
function list_rooms() {
    $rooms = [];
    $pattern = $GLOBALS['dataDir'] . '/config_*.json';
    foreach (glob($pattern) as $path) {
        $base = basename($path, '.json');
        $slug = substr($base, strlen('config_'));
        if ($slug === '') continue;
        $config = read_config($slug);
        if (!$config) continue;

        $msgs = read_json_file(room_file($slug));
        $msgCount = is_array($msgs) ? count($msgs) : 0;

        $rooms[] = [
            'room' => $slug,
            'title' => $config['title'] !== '' ? $config['title'] : $slug,
            'createdAt' => $config['createdAt'],
            'lastActivity' => $config['lastActivity'],
            'hostSet' => !empty($config['hostPasswordHash']),
            'pinSet' => !empty($config['pinHash']),
            'encEnabled' => !empty($config['encEnabled']),
            'activeUsers' => active_presence($config),
            'messageCount' => $msgCount,
        ];
    }
    usort($rooms, function ($a, $b) {
        $at = $a['lastActivity'] ?? $a['createdAt'] ?? 0;
        $bt = $b['lastActivity'] ?? $b['createdAt'] ?? 0;
        return $bt <=> $at;
    });
    return $rooms;
}

// ---------------------------------------------------------------------
// Sessions / tokens
// ---------------------------------------------------------------------

function read_sessions() {
    $data = read_json_file(sessions_file());
    return is_array($data) ? $data : [];
}

function write_sessions($sessions) {
    write_json_file(sessions_file(), $sessions);
}

function create_session($room, $user, $role) {
    $sessions = read_sessions();
    $now = time();
    foreach ($sessions as $t => $s) {
        if (!isset($s['expires']) || $s['expires'] < $now) unset($sessions[$t]);
    }
    $token = bin2hex(random_bytes(16));
    $roomSlug = ($room === $GLOBALS['MASTER_ROOM']) ? $GLOBALS['MASTER_ROOM'] : safe_room_name($room);
    $sessions[$token] = [
        'room' => $roomSlug,
        'user' => $user,
        'role' => $role,
        'expires' => $now + $GLOBALS['sessionTtlSeconds'],
    ];
    write_sessions($sessions);
    return $token;
}

function get_session($token) {
    if (!$token) return null;
    $sessions = read_sessions();
    if (!isset($sessions[$token])) return null;
    $s = $sessions[$token];
    if (!isset($s['expires']) || $s['expires'] < time()) {
        unset($sessions[$token]);
        write_sessions($sessions);
        return null;
    }
    $sessions[$token]['expires'] = time() + $GLOBALS['sessionTtlSeconds'];
    write_sessions($sessions);
    return $sessions[$token];
}

function remove_sessions_for_user($room, $username) {
    $sessions = read_sessions();
    $room = safe_room_name($room);
    $uname = strtolower(trim($username));
    $changed = false;
    foreach ($sessions as $t => $s) {
        if ($s['room'] === $room && strtolower($s['user']) === $uname) {
            unset($sessions[$t]);
            $changed = true;
        }
    }
    if ($changed) write_sessions($sessions);
}

function remove_host_sessions($room) {
    $sessions = read_sessions();
    $room = safe_room_name($room);
    $changed = false;
    foreach ($sessions as $t => $s) {
        if ($s['room'] === $room && $s['role'] === 'host') {
            unset($sessions[$t]);
            $changed = true;
        }
    }
    if ($changed) write_sessions($sessions);
}

// ---------------------------------------------------------------------
// Remember-me tokens (long-lived auto-login, separate from short-lived
// session tokens above). Uses a selector/validator split so the raw
// token is never stored — only a hash of the validator half — same
// principle as the session tokens but with a much longer TTL and its
// own file, so clearing sessions.json (e.g. on server restart) doesn't
// silently log everyone's "remember me" out too, and vice versa.
// ---------------------------------------------------------------------

$GLOBALS['rememberTtlSeconds'] = 30 * 24 * 60 * 60; // 30 days

function read_remember_tokens() {
    $data = read_json_file(remember_tokens_file());
    return is_array($data) ? $data : [];
}

function write_remember_tokens($tokens) {
    write_json_file(remember_tokens_file(), $tokens);
}

// Creates a remember-me token for a given room/user/role. Returns the
// string to hand to the client (selector:validator) — this exact
// string is never stored server-side, only its hash.
function create_remember_token($room, $user, $role) {
    $tokens = read_remember_tokens();
    $now = time();
    foreach ($tokens as $sel => $t) {
        if (!isset($t['expires']) || $t['expires'] < $now) unset($tokens[$sel]);
    }

    $selector = bin2hex(random_bytes(9));
    $validator = bin2hex(random_bytes(33));
    $roomSlug = ($room === $GLOBALS['MASTER_ROOM']) ? $GLOBALS['MASTER_ROOM'] : safe_room_name($room);

    $tokens[$selector] = [
        'hash' => hash('sha256', $validator),
        'room' => $roomSlug,
        'user' => $user,
        'role' => $role,
        'expires' => $now + $GLOBALS['rememberTtlSeconds'],
    ];
    write_remember_tokens($tokens);
    return $selector . ':' . $validator;
}

// Validates a "selector:validator" string. On success, rotates the
// token (issues a new selector/validator pair and invalidates the old
// one) so a stolen-but-unused cookie/localStorage value only works
// once before rotating out from under an attacker, and returns
// ['room' => ..., 'user' => ..., 'role' => ..., 'newToken' => 'selector:validator'].
// Returns null on any failure (bad format, unknown selector, expired,
// or validator mismatch).
function consume_remember_token($raw) {
    if (!is_string($raw) || strpos($raw, ':') === false) return null;
    [$selector, $validator] = explode(':', $raw, 2);

    $tokens = read_remember_tokens();
    if (!isset($tokens[$selector])) return null;
    $t = $tokens[$selector];

    if (!isset($t['expires']) || $t['expires'] < time()) {
        unset($tokens[$selector]);
        write_remember_tokens($tokens);
        return null;
    }

    // Constant-time comparison — avoids leaking timing info about the hash.
    if (!hash_equals($t['hash'], hash('sha256', $validator))) {
        return null;
    }

    unset($tokens[$selector]);
    $newRaw = create_remember_token($t['room'], $t['user'], $t['role']); // re-reads/writes the file
    return [
        'room' => $t['room'],
        'user' => $t['user'],
        'role' => $t['role'],
        'newToken' => $newRaw,
    ];
}

// Revokes a single remember-me token (used on explicit logout).
function revoke_remember_token($raw) {
    if (!is_string($raw) || strpos($raw, ':') === false) return;
    [$selector] = explode(':', $raw, 2);
    $tokens = read_remember_tokens();
    if (isset($tokens[$selector])) {
        unset($tokens[$selector]);
        write_remember_tokens($tokens);
    }
}

// Mirrors remove_sessions_for_user() — call this alongside it whenever
// a user is kicked/banned, so a stale remember-me token can't silently
// let them back in.
function remove_remember_tokens_for_user($room, $username) {
    $tokens = read_remember_tokens();
    $room = safe_room_name($room);
    $uname = strtolower(trim($username));
    $changed = false;
    foreach ($tokens as $sel => $t) {
        if ($t['room'] === $room && strtolower($t['user']) === $uname) {
            unset($tokens[$sel]);
            $changed = true;
        }
    }
    if ($changed) write_remember_tokens($tokens);
}

// Mirrors remove_host_sessions() — call this alongside it whenever a
// room's host password is reset, so old "remember me as Host" tokens
// die with the old password instead of granting host access forever.
function remove_host_remember_tokens($room) {
    $tokens = read_remember_tokens();
    $room = safe_room_name($room);
    $changed = false;
    foreach ($tokens as $sel => $t) {
        if ($t['room'] === $room && $t['role'] === 'host') {
            unset($tokens[$sel]);
            $changed = true;
        }
    }
    if ($changed) write_remember_tokens($tokens);
}

// ---------------------------------------------------------------------
// Messages (with 24h auto-expiry)
// ---------------------------------------------------------------------

function purge_expired($room, $messages) {
    $expiryMs = $GLOBALS['messageExpirySeconds'] * 1000;
    $nowMs = now_ms();
    $changed = false;
    $kept = [];

    foreach ($messages as $m) {
        $age = $nowMs - (isset($m['ts']) ? $m['ts'] : 0);
        if ($age > $expiryMs) {
            $changed = true;
            if (isset($m['type']) && $m['type'] === 'file' && !empty($m['fileUrl'])) {
                $path = __DIR__ . '/' . ltrim($m['fileUrl'], '/');
                if (is_file($path)) @unlink($path);
            }
        } else {
            $kept[] = $m;
        }
    }

    if ($changed) {
        write_messages($room, $kept);
    }

    return $kept;
}

function read_messages($room) {
    $data = read_json_file(room_file($room));
    $messages = is_array($data) ? $data : [];
    return purge_expired($room, $messages);
}

function write_messages($room, $messages) {
    if (count($messages) > $GLOBALS['maxMessages']) {
        $messages = array_slice($messages, -1 * $GLOBALS['maxMessages']);
    }
    return write_json_file(room_file($room), $messages);
}

function find_message($room, $id) {
    $messages = read_messages($room);
    foreach ($messages as $m) {
        if (isset($m['id']) && $m['id'] == $id) return $m;
    }
    return null;
}

// Builds a short quoted snippet of a message for use as a reply-to preview.
function build_reply_snippet($msg) {
    if (!$msg) return null;
    $text = isset($msg['text']) ? $msg['text'] : '';
    if ($text === '' && isset($msg['type']) && $msg['type'] === 'file') {
        $text = '📎 ' . (isset($msg['fileName']) ? $msg['fileName'] : 'file');
    }
    // Encrypted envelopes must stay intact — truncating a base64 ciphertext
    // blob makes it undecryptable client-side. Plain text still gets trimmed.
    if (strpos($text, 'encv1:') !== 0) {
        $text = mb_substr(str_replace("\n", ' ', $text), 0, 120);
    }
    return [
        'id' => $msg['id'],
        'user' => $msg['user'],
        'text' => $text,
    ];
}

// Toggles $username's reaction with $emoji on a message. A user can only
// have one active reaction per message — picking a new emoji replaces
// their old one on that message.
function toggle_reaction($room, $messageId, $username, $emoji) {
    $messages = read_messages($room);
    $found = false;
    $userLower = strtolower($username);
    foreach ($messages as &$m) {
        if (!isset($m['id']) || $m['id'] != $messageId) continue;
        $found = true;
        if (!isset($m['reactions']) || !is_array($m['reactions'])) $m['reactions'] = [];

        $hadThisEmoji = isset($m['reactions'][$emoji]) && in_array($username, $m['reactions'][$emoji], true);

        // Remove this user from every emoji bucket first.
        foreach ($m['reactions'] as $e => $users) {
            $m['reactions'][$e] = array_values(array_filter($users, function ($u) use ($username) {
                return strtolower($u) !== $userLower;
            }));
            if (empty($m['reactions'][$e])) unset($m['reactions'][$e]);
        }

        // Re-add only if they weren't already reacting with this same emoji (i.e. toggle off).
        if (!$hadThisEmoji) {
            if (!isset($m['reactions'][$emoji])) $m['reactions'][$emoji] = [];
            $m['reactions'][$emoji][] = $username;
        }
        break;
    }
    unset($m);
    if ($found) write_messages($room, $messages);
    return $found ? find_message($room, $messageId) : null;
}

function next_message_id($messages) {
    $nextId = 1;
    foreach ($messages as $m) {
        if (isset($m['id']) && $m['id'] >= $nextId) {
            $nextId = $m['id'] + 1;
        }
    }
    return $nextId;
}

function append_message($room, $msg) {
    $messages = read_messages($room);
    $msg['id'] = next_message_id($messages);
    $msg['ts'] = now_ms();
    $messages[] = $msg;
    write_messages($room, $messages);

    // bump last-activity on the room config too
    $config = read_config($room);
    if ($config) {
        $config['lastActivity'] = $msg['ts'];
        write_config($room, $config);
    }

    return $msg;
}

// ---------------------------------------------------------------------
// Message editing
// ---------------------------------------------------------------------

// Edits a message's text in place, but only if $username is the original
// sender (case-insensitive) — host/super do NOT get a bypass here, this
// is purely "edit your own message" like Discord/Slack. Returns the
// updated message on success, or null if not found / not the owner.
function edit_message($room, $id, $username, $newText) {
    $messages = read_messages($room);
    $updated = null;
    foreach ($messages as &$m) {
        if (!isset($m['id']) || $m['id'] != $id) continue;
        if (!isset($m['user']) || strtolower($m['user']) !== strtolower($username)) {
            return null; // not the owner — stop, don't leak which id existed
        }
        if (isset($m['type']) && $m['type'] !== 'text') {
            return null; // only plain text messages are editable, not files
        }
        $m['text'] = $newText;
        $m['edited'] = true;
        $m['editedAt'] = now_ms();
        $updated = $m;
        break;
    }
    unset($m);
    if ($updated) write_messages($room, $messages);
    return $updated;
}

// ---------------------------------------------------------------------
// Read receipts — piggybacks on the existing presence heartbeat, just
// stores the highest message id each person has seen.
// ---------------------------------------------------------------------

function mark_read(&$config, $username, $role, $messageId) {
    touch_presence($config, $username, $role); // keeps ts/typingUntil semantics intact
    $key = strtolower($username);
    $current = isset($config['presence'][$key]['lastReadId']) ? $config['presence'][$key]['lastReadId'] : 0;
    if ($messageId > $current) {
        $config['presence'][$key]['lastReadId'] = $messageId;
    }
}

// Read receipts visible to everyone (not just admins) — every active
// user's name + their highest read message id, excluding $exceptUser.
function read_receipts($config, $exceptUser) {
    $now = now_ms();
    $exceptLower = strtolower($exceptUser);
    $out = [];
    foreach ($config['presence'] as $key => $p) {
        if ($key === $exceptLower) continue;
        if (($now - $p['ts']) > $GLOBALS['presenceWindowMs']) continue; // only "online" people
        $out[] = ['user' => $p['name'], 'lastReadId' => isset($p['lastReadId']) ? $p['lastReadId'] : 0];
    }
    return $out;
}

// ---------------------------------------------------------------------
// Link previews — server-side fetch (browsers can't read cross-origin
// pages directly) with SSRF protections: only http/https, only ports
// 80/443, and every resolved IP for the host must be a public address
// (no loopback/private/link-local/reserved ranges). Results are cached
// to disk for a while so repeated views of the same link are cheap and
// so we don't hammer other people's servers.
// ---------------------------------------------------------------------

function link_preview_cache_file($url) {
    return $GLOBALS['dataDir'] . '/linkpreview_' . hash('sha256', $url) . '.json';
}

function is_public_ip($ip) {
    // Rejects loopback, private, link-local, reserved, and multicast
    // ranges for both IPv4 and IPv6.
    return filter_var(
        $ip,
        FILTER_VALIDATE_IP,
        FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
    ) !== false;
}

function url_is_safe_to_fetch($url) {
    $parts = parse_url($url);
    if (!$parts || empty($parts['host'])) return false;
    $scheme = strtolower($parts['scheme'] ?? '');
    if (!in_array($scheme, ['http', 'https'], true)) return false;
    $port = $parts['port'] ?? ($scheme === 'https' ? 443 : 80);
    if (!in_array((int)$port, [80, 443], true)) return false;

    $host = $parts['host'];
    // If the host is already a literal IP, check it directly; otherwise
    // resolve it and check every A/AAAA record (DNS can return multiple,
    // and an attacker-controlled domain could point at an internal IP).
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        return is_public_ip($host);
    }
    $records = @dns_get_record($host, DNS_A + DNS_AAAA);
    if (!$records) return false;
    foreach ($records as $r) {
        $ip = $r['ip'] ?? ($r['ipv6'] ?? null);
        if ($ip && !is_public_ip($ip)) return false;
    }
    return true;
}

// Fetches a URL and extracts a small preview (title, description, image,
// site name). Returns null on any failure. Caches successes (and
// failures, briefly) to disk.
function fetch_link_preview($url) {
    $cacheFile = link_preview_cache_file($url);
    $cached = read_json_file($cacheFile);
    if (is_array($cached) && isset($cached['fetchedAt']) && (now_ms() - $cached['fetchedAt']) < ($GLOBALS['linkPreviewCacheSeconds'] * 1000)) {
        return $cached['preview']; // may itself be null (cached "failed to preview")
    }

    $preview = null;
    if (url_is_safe_to_fetch($url)) {
        $ctx = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 4,
                'follow_location' => 0, // no redirects — a redirect could point at an internal address
                'header' => "User-Agent: QuickChatLinkPreview/1.0\r\n",
            ],
            'https' => [
                'timeout' => 4,
                'follow_location' => 0,
            ],
        ]);
        $html = @file_get_contents($url, false, $ctx, 0, 300000); // cap read size
        if ($html !== false && $html !== '') {
            $preview = parse_preview_html($html, $url);
        }
    }

    write_json_file($cacheFile, ['fetchedAt' => now_ms(), 'preview' => $preview]);
    return $preview;
}

function parse_preview_html($html, $url) {
    $title = null; $description = null; $image = null; $siteName = null;

    if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $m)) {
        $title = trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES));
    }
    $meta = function ($property) use ($html) {
        if (preg_match('/<meta[^>]+(?:property|name)=["\']' . preg_quote($property, '/') . '["\'][^>]+content=["\']([^"\']*)["\']/is', $html, $m)) {
            return trim(html_entity_decode($m[1], ENT_QUOTES));
        }
        return null;
    };
    $ogTitle = $meta('og:title');
    if ($ogTitle) $title = $ogTitle;
    $description = $meta('og:description') ?: $meta('description');
    $image = $meta('og:image');
    $siteName = $meta('og:site_name') ?: parse_url($url, PHP_URL_HOST);

    if ($title) $title = mb_substr($title, 0, 200);
    if ($description) $description = mb_substr($description, 0, 300);

    if (!$title && !$description && !$image) return null;

    // Resolve a relative og:image against the page URL, if needed.
    if ($image && !preg_match('#^https?://#i', $image)) {
        $base = parse_url($url);
        $image = ($base['scheme'] ?? 'https') . '://' . ($base['host'] ?? '') . '/' . ltrim($image, '/');
    }
    // Only allow the preview image to be embedded if it's itself a safe,
    // public http(s) URL — same SSRF reasoning as the page fetch above.
    if ($image && !url_is_safe_to_fetch($image)) $image = null;

    return [
        'title' => $title,
        'description' => $description,
        'image' => $image,
        'siteName' => $siteName,
        'url' => $url,
    ];
}

// Finds the first http(s) URL in a plain-text message, if any.
function first_url_in_text($text) {
    if (!is_string($text)) return null;
    if (preg_match('#https?://[^\s<>"]+#i', $text, $m)) {
        return rtrim($m[0], '.,)]!?');
    }
    return null;
}
