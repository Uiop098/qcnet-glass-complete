<?php
// config.php — every value in here MUST be changed before you go live.
// This file is blocked from direct browser access by .htaccess, but it
// still sits in plain text on the server, so keep server access (FTP/
// control panel login) private, same as you would for any other host.

// ---------------------------------------------------------------------
// 1) MySQL — create a database in your InfinityFree control panel
//    (Control Panel -> MySQL Databases), then paste its details here.
//    InfinityFree DB hostnames are usually NOT "localhost" — copy the
//    exact hostname shown next to your database (something like
//    sqlXXX.infinityfree.com).
// ---------------------------------------------------------------------
define('DB_HOST', 'sqlXXX.infinityfree.com');
define('DB_NAME', 'if0_XXXXXXXX_quickchat_pay');
define('DB_USER', 'if0_XXXXXXXX');
define('DB_PASS', 'REPLACE_WITH_YOUR_DB_PASSWORD');

// ---------------------------------------------------------------------
// 2) Razorpay — from https://dashboard.razorpay.com -> Settings -> API Keys.
//    Use TEST keys (rzp_test_...) while you're setting this up, switch
//    to LIVE keys (rzp_live_...) only once a real test payment has
//    worked end-to-end. Never put the key SECRET in any file the
//    browser can load directly — only server-side files here use it.
// ---------------------------------------------------------------------
define('RAZORPAY_KEY_ID', 'rzp_test_XXXXXXXXXXXXXX');
define('RAZORPAY_KEY_SECRET', 'REPLACE_WITH_YOUR_KEY_SECRET');

// Settings -> Webhooks -> Add New Webhook on the Razorpay dashboard.
//   Webhook URL: https://yourpaymentsite.example/webhook.php
//   Active events: payment.captured
// Razorpay gives you a separate "Webhook Secret" when you create it —
// paste that (NOT the API key secret) here.
define('RAZORPAY_WEBHOOK_SECRET', 'REPLACE_WITH_YOUR_WEBHOOK_SECRET');

// ---------------------------------------------------------------------
// 3) Shared secret with the main QuickChat app. Generate a long random
//    string (e.g. run  php -r "echo bin2hex(random_bytes(32));"  once,
//    anywhere PHP is available) and paste the SAME value here and in
//    the main app's common.php (PAYMENT_GATEWAY_SECRET). This is what
//    stops a random visitor from calling verify_token.php directly.
// ---------------------------------------------------------------------
define('APP_SHARED_SECRET', 'd9ccf35d43118ce84fe75b354e2fb5bdc9cc1e571c6b2ab715d61c20724e50a');

// ---------------------------------------------------------------------
// 4) The offer. Amount is in PAISE (Razorpay's smallest unit for INR),
//    so 100 = ₹1.00. This is deliberately a test/promo price — change
//    it once you're ready for a real price.
// ---------------------------------------------------------------------
define('OFFER_AMOUNT_PAISE', 100);       // ₹1
define('OFFER_CURRENCY', 'INR');
define('OFFER_DURATION_DAYS', 10);
define('OFFER_LABEL', 'QuickChat Super Access — 10 days');

// How long a "Buy Super Access" link stays valid before someone has to
// go back to QuickChat and click the button again. Keep this short —
// it's meant to be used within a minute or two of clicking Buy, not
// bookmarked.
define('ACCESS_LINK_TTL_MINUTES', 20);

// ---------------------------------------------------------------------
// Everything below this line is plumbing, not configuration.
// ---------------------------------------------------------------------
$GLOBALS['dataDir'] = __DIR__ . '/data'; // used by firewall.php for rate-limit/IP-block storage
require_once __DIR__ . '/firewall.php';
require_once __DIR__ . '/db.php';
