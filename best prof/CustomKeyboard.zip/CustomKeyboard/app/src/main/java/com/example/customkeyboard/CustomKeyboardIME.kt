package com.example.customkeyboard

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.GridView

class CustomKeyboardIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    companion object {
        /** Set by MainActivity when the user picks/resets a custom sound, so the
         *  running keyboard service knows to reload it next time it's shown. */
        var soundNeedsReload = false

        // Custom key codes - all negative so they can never collide with a
        // real character code (letters/digits/punctuation are all >= 0).
        private const val CODE_EMOJI = -2
        private const val CODE_SYMBOLS = -3
        private const val CODE_ENTER = -4
        private const val CODE_ABC = -6
    }

    private lateinit var keyboardView: KeyboardView
    private lateinit var qwertyKeyboard: Keyboard
    private lateinit var symbolsKeyboard: Keyboard
    private lateinit var emojiGrid: GridView
    private lateinit var soundManager: SoundManager
    private var vibrator: Vibrator? = null
    private var capsOn = false

    override fun onCreate() {
        super.onCreate()
        // Preload happens exactly ONCE here, while the keyboard is starting up
        // and before the user has touched a single key. This is what removes
        // the delay - by the time onKey() ever fires, the sound is already
        // sitting decoded in memory. See SoundManager for details.
        soundManager = SoundManager(this)

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
    }

    override fun onCreateInputView(): View {
        val container = layoutInflater.inflate(R.layout.keyboard_container, null) as FrameLayout

        qwertyKeyboard = Keyboard(this, R.xml.keyboard_qwerty)
        symbolsKeyboard = Keyboard(this, R.xml.keyboard_symbols)

        keyboardView = container.findViewById(R.id.keyboard_view)
        keyboardView.keyboard = qwertyKeyboard
        keyboardView.setOnKeyboardActionListener(this)
        keyboardView.isPreviewEnabled = Prefs.animationEnabled(this)

        emojiGrid = container.findViewById(R.id.emoji_grid)
        val adapter = object : ArrayAdapter<String>(this, R.layout.item_emoji, EmojiData.EMOJIS) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                view.setOnClickListener {
                    triggerFeedback()
                    currentInputConnection?.commitText(EmojiData.EMOJIS[position], 1)
                }
                return view
            }
        }
        emojiGrid.adapter = adapter

        return container
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // Cheap settings refresh every time the keyboard becomes visible -
        // picks up toggle changes made in MainActivity without restarting
        // the whole service.
        keyboardView.isPreviewEnabled = Prefs.animationEnabled(this)
        if (soundNeedsReload) {
            soundManager.loadActiveSound()
            soundNeedsReload = false
        }
        showLetters()
    }

    // ---- Feedback: fires on PRESS (finger-down), not on release. This is
    // what makes it feel instant - we don't wait for the tap gesture to
    // fully resolve into a committed character before playing sound/haptics.
    private fun triggerFeedback() {
        soundManager.playClick()
        if (Prefs.vibrationEnabled(this)) {
            vibrateShort()
        }
    }

    private fun vibrateShort() {
        val v = vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(12)
        }
    }

    private fun showLetters() {
        keyboardView.keyboard = qwertyKeyboard
        keyboardView.visibility = View.VISIBLE
        emojiGrid.visibility = View.GONE
    }

    private fun showSymbols() {
        keyboardView.keyboard = symbolsKeyboard
        keyboardView.visibility = View.VISIBLE
        emojiGrid.visibility = View.GONE
    }

    private fun showEmoji() {
        keyboardView.visibility = View.GONE
        emojiGrid.visibility = View.VISIBLE
    }

    // ---- OnKeyboardActionListener ----

    override fun onPress(primaryCode: Int) {
        triggerFeedback()
        // The instant background-color swap (the "press animation") is handled
        // automatically by KeyboardView + key_background.xml's state_pressed -
        // it happens on the same touch event, so it's already in sync with
        // the sound/vibration triggered here.
    }

    override fun onRelease(primaryCode: Int) {}

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic = currentInputConnection ?: return

        when (primaryCode) {
            Keyboard.KEYCODE_SHIFT -> {
                capsOn = !capsOn
                qwertyKeyboard.isShifted = capsOn
                keyboardView.invalidateAllKeys()
            }
            Keyboard.KEYCODE_DELETE -> {
                val selected = ic.getSelectedText(0)
                if (selected.isNullOrEmpty()) {
                    ic.deleteSurroundingText(1, 0)
                } else {
                    ic.commitText("", 1)
                }
            }
            CODE_SYMBOLS -> showSymbols()
            CODE_ABC -> showLetters()
            CODE_EMOJI -> showEmoji()
            CODE_ENTER -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                    ic.performEditorAction(action)
                } else {
                    ic.commitText("\n", 1)
                }
            }
            else -> {
                var code = primaryCode.toChar()
                if (capsOn && code.isLetter()) {
                    code = code.uppercaseChar()
                }
                ic.commitText(code.toString(), 1)
            }
        }
    }

    override fun onText(text: CharSequence?) {
        currentInputConnection?.commitText(text, 1)
    }

    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}

    override fun onDestroy() {
        super.onDestroy()
        soundManager.release()
    }
}
