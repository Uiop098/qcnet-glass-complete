package com.example.customkeyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import java.io.File

class MainActivity : AppCompatActivity() {

    private val pickAudioLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri == null) return@registerForActivityResult
            try {
                val input = contentResolver.openInputStream(uri) ?: return@registerForActivityResult
                val outFile = File(filesDir, Prefs.CUSTOM_SOUND_FILENAME)
                input.use { inStream ->
                    outFile.outputStream().use { outStream ->
                        inStream.copyTo(outStream)
                    }
                }
                Prefs.setHasCustomSound(this, true)
                CustomKeyboardIME.soundNeedsReload = true
                findViewById<android.widget.TextView>(R.id.txt_sound_status).text =
                    getString(R.string.custom_sound_set)
            } catch (e: Exception) {
                // Copy failed (bad file, no permission, etc.) - keep using
                // whichever sound was already active rather than crashing.
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.widget.Button>(R.id.btn_enable).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        findViewById<android.widget.Button>(R.id.btn_switch).setOnClickListener {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        val soundSwitch = findViewById<SwitchMaterial>(R.id.switch_sound)
        soundSwitch.isChecked = Prefs.soundEnabled(this)
        soundSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setSoundEnabled(this, checked)
        }

        val vibrationSwitch = findViewById<SwitchMaterial>(R.id.switch_vibration)
        vibrationSwitch.isChecked = Prefs.vibrationEnabled(this)
        vibrationSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setVibrationEnabled(this, checked)
        }

        val animationSwitch = findViewById<SwitchMaterial>(R.id.switch_animation)
        animationSwitch.isChecked = Prefs.animationEnabled(this)
        animationSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setAnimationEnabled(this, checked)
        }

        findViewById<android.widget.Button>(R.id.btn_pick_sound).setOnClickListener {
            pickAudioLauncher.launch("audio/*")
        }

        findViewById<android.widget.Button>(R.id.btn_reset_sound).setOnClickListener {
            File(filesDir, Prefs.CUSTOM_SOUND_FILENAME).delete()
            Prefs.setHasCustomSound(this, false)
            CustomKeyboardIME.soundNeedsReload = true
            findViewById<android.widget.TextView>(R.id.txt_sound_status).text = ""
        }

        if (Prefs.hasCustomSound(this)) {
            findViewById<android.widget.TextView>(R.id.txt_sound_status).text =
                getString(R.string.custom_sound_set)
        }
    }
}
