package com.example.customkeyboard

import android.content.Context

/**
 * Tiny wrapper around SharedPreferences. Reading these is cheap (in-memory
 * XML backed map after first load) so it is safe to call from onKey()
 * without introducing any noticeable per-tap latency.
 */
object Prefs {
    private const val FILE = "keyboard_prefs"
    private const val KEY_SOUND = "sound_enabled"
    private const val KEY_VIBRATION = "vibration_enabled"
    private const val KEY_ANIMATION = "animation_enabled"
    private const val KEY_HAS_CUSTOM_SOUND = "has_custom_sound"

    const val CUSTOM_SOUND_FILENAME = "custom_click.wav"

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun soundEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SOUND, true)

    fun setSoundEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_SOUND, enabled).apply()
    }

    fun vibrationEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_VIBRATION, true)

    fun setVibrationEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_VIBRATION, enabled).apply()
    }

    fun animationEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_ANIMATION, true)

    fun setAnimationEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ANIMATION, enabled).apply()
    }

    fun hasCustomSound(context: Context): Boolean =
        prefs(context).getBoolean(KEY_HAS_CUSTOM_SOUND, false)

    fun setHasCustomSound(context: Context, has: Boolean) {
        prefs(context).edit().putBoolean(KEY_HAS_CUSTOM_SOUND, has).apply()
    }
}
