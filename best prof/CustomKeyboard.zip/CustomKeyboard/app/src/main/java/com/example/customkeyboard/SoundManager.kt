package com.example.customkeyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File

/**
 * THIS IS THE FIX FOR THE ORIGINAL "delayed click sound" BUG.
 *
 * The classic mistake (and almost certainly what was happening in the app
 * you uploaded) is calling something like:
 *
 *     val id = soundPool.load(context, R.raw.click, 1)
 *     soundPool.play(id, 1f, 1f, 0, 0, 1f)   // <-- called immediately after load()
 *
 * SoundPool.load() is ASYNCHRONOUS - it kicks off a decode on a background
 * thread and returns right away, before the sound is actually ready. If you
 * call play() before the load finishes, one of two things happens:
 *   1. Nothing plays (the id isn't ready yet), or
 *   2. It plays late, whenever decoding happens to finish - which is exactly
 *      the "delay" you're describing, and it's often worse on the very first
 *      few key taps after the keyboard opens.
 *
 * The correct pattern is to preload every sound ONCE, up front (in the IME's
 * onCreate, long before the user starts typing), wait for
 * setOnLoadCompleteListener to confirm it's ready, and then every later
 * play() call is just handing an already-decoded buffer to the audio driver
 * - effectively zero latency.
 */
class SoundManager(private val context: Context) {

    private var soundPool: SoundPool? = null
    private var soundId: Int = 0
    private var loaded = false
    private var pendingPlayRequested = false

    init {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val pool = SoundPool.Builder()
            .setMaxStreams(4) // allow overlapping taps (fast typing) without cutting sounds off
            .setAudioAttributes(attributes)
            .build()

        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0 && sampleId == soundId) {
                loaded = true
                if (pendingPlayRequested) {
                    pendingPlayRequested = false
                    playInternal()
                }
            }
        }

        soundPool = pool
        loadActiveSound()
    }

    /** Load either the user's custom sound file, or the bundled default. Call again after the user picks a new custom sound. */
    fun loadActiveSound() {
        val pool = soundPool ?: return
        loaded = false

        val customFile = File(context.filesDir, Prefs.CUSTOM_SOUND_FILENAME)
        soundId = if (Prefs.hasCustomSound(context) && customFile.exists()) {
            pool.load(customFile.absolutePath, 1)
        } else {
            pool.load(context, R.raw.key_click, 1)
        }
    }

    /** Called on every key tap. Safe to call even before loading finishes - it will queue exactly one play once ready, instead of dropping or lagging. */
    fun playClick() {
        if (!Prefs.soundEnabled(context)) return
        if (loaded) {
            playInternal()
        } else {
            // Only happens in the first fraction of a second after the IME
            // starts up, before the async load callback fires.
            pendingPlayRequested = true
        }
    }

    private fun playInternal() {
        soundPool?.play(soundId, 1f, 1f, 1, 0, 1f)
    }

    fun release() {
        soundPool?.release()
        soundPool = null
    }
}
