# Custom Keyboard (Android)

A lightweight custom Android keyboard (IME) built on the classic
`android.inputmethodservice.Keyboard` / `KeyboardView` framework APIs — the
same low-overhead approach used by well-known open-source keyboards like
[rkkr/simple-keyboard](https://github.com/rkkr/simple-keyboard). No heavy
custom rendering engine, no bundled dictionary/ML models — just letters,
numbers, symbols, and emoji, with instant sound + haptic + visual feedback
on every key tap.

## Why the original click-sound delay happened (and how this fixes it)

The most common cause of a delayed keyboard click sound is loading the sound
effect *at the moment the key is tapped*:

```kotlin
// BAD - causes the exact delay you were seeing
val id = soundPool.load(context, R.raw.click, 1)
soundPool.play(id, 1f, 1f, 0, 0, 1f)   // called before load() finishes decoding
```

`SoundPool.load()` is asynchronous. It returns immediately but the actual
audio decode happens on a background thread. If you call `play()` right
after `load()`, the sound either doesn't play at all or plays late once
decoding catches up — worse on the first few taps.

This project fixes it in `SoundManager.kt`:
- The sound is decoded **once**, in the IME's `onCreate()`, before the user
  ever touches a key.
- A `setOnLoadCompleteListener` flips a `loaded` flag once it's actually
  ready.
- `playClick()` on every tap just hands the already-decoded buffer to the
  audio driver — no decode-on-demand, no delay.
- Feedback (`onPress`) fires on **finger-down**, not after the full tap
  gesture resolves, so it feels instant rather than trailing the visual
  press.

## Features

- Full QWERTY layout with number row, `?123` symbols page, and an emoji
  panel (tap 😀 to open it)
- Shift/caps
- **Sound** on tap — bundled default click (generated, no license
  concerns) or your own custom sound file, picked from the Settings screen
- **Vibration** on tap (`VibrationEffect`, ~12ms — short enough not to feel
  laggy)
- **Key press animation** — the tapped key's background flips instantly via
  an Android state-list drawable (`key_background.xml`), synchronized with
  the touch event itself, plus the standard key-preview popup (toggle via
  Settings)
- All three feedback types can be toggled independently in the app's
  Settings screen

## Project structure

```
app/src/main/java/com/example/customkeyboard/
  CustomKeyboardIME.kt   - the keyboard service itself (onKey, feedback)
  SoundManager.kt        - preloaded SoundPool (the delay fix)
  MainActivity.kt        - setup screen: enable, switch, toggles, custom sound
  Prefs.kt               - tiny SharedPreferences wrapper
  EmojiData.kt           - emoji list for the emoji panel

app/src/main/res/xml/
  keyboard_qwerty.xml    - letters + numbers layout
  keyboard_symbols.xml   - symbols layout

app/src/main/res/raw/key_click.wav  - generated default click sound
```

## Building it

This is a standard Gradle-based Android Studio project, but it was
assembled outside of Android Studio, so the Gradle wrapper isn't included.

1. Open the `CustomKeyboard/` folder in **Android Studio** (Hedgehog or
   newer).
2. Let Android Studio generate the Gradle wrapper and sync (it will prompt
   automatically, or use *File → Sync Project with Gradle Files*).
3. Run on a device/emulator (API 23+).
4. In the app, tap **"Enable in System Settings"**, turn the keyboard on,
   then tap **"Switch to Custom Keyboard"** (or switch keyboards from any
   text field's keyboard-switch icon).

> I built and wrote every file in this project, but I don't have an Android
> SDK/emulator available in this environment, so I haven't been able to
> compile or run it myself. Please flag anything that doesn't build cleanly
> and I'll fix it directly.

## Customizing the click sound

In the app's Settings screen, tap **"Choose custom click sound…"** and pick
any audio file (short `.wav`/`.mp3` clips work best — under ~200ms feels
most like a real key click). It's copied into the app's private storage and
loaded through the same preloaded-`SoundPool` path as the default sound, so
custom sounds get the same zero-delay behavior.
