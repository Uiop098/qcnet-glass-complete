QUICK CHAT — SELF-HOSTED, NO DEPENDENCIES
==========================================

WHAT'S INSIDE
  index.html       - frontend (HTML/CSS/JS, no external libraries)
  api.php          - fetch/send messages, clear chat (host/super only)
  auth.php         - login: member join, host login, super login/join
  upload.php       - file uploads (restricted for members, open for super)
  kick.php         - removes a user from a room (host/super only)
  mute.php         - temporary "spammer timer" mute (host/super only)
  admin.php        - room title, host password reset, unban, pin/unpin
  theme.php        - room wallpaper + glow color (super only, room-wide)
  wallpaper_upload.php - uploads a wallpaper image to the server (super only)
  typing.php       - marks a user as "currently typing"
  react.php        - toggles an emoji reaction on a message
  rooms.php        - lists all rooms for the super-user room browser
  common.php       - shared storage/session/config helpers
  super_users.php  - hardcoded super user accounts (see below)
  data/            - JSON files: messages, PINs, host passwords, bans,
                     mutes, presence, room titles/timestamps, theme
                     (.htaccess blocks direct browser access)
  files/           - uploaded files, organized by room, including a
                     wallpapers/ subfolder per room
                     (.htaccess blocks folder listing, direct links work)

REQUIREMENTS
  Any PHP host works (PHP 7+). No database needed.

HOW TO DEPLOY
  Upload the whole "quickchat" folder (all files, plus the data/ and
  files/ subfolders) to your site via FTP or your host's File
  Manager. Example: htdocs/quickchat/  or  public_html/quickchat/
  Make sure "data" and "files" are writable by PHP (755/775 if you
  hit errors). Then visit https://yourdomain.com/quickchat/

ROLES
  MEMBER — joins with room name + PIN + username. Sends messages,
  uploads common file types. Can be muted or kicked by a host/super.

  HOST — one per room, password-protected. The FIRST login for a new
  room sets that password (write it down — no recovery except via
  server access, or a super user resetting it, see below). Can clear
  chat, mute, and kick. The optional PIN field on the host login
  screen sets/changes the room PIN members need to join.

  SUPER USER — global accounts from super_users.php. Logs in with
  username + password only (no room name needed) and then browses
  EVERY room that exists — running or past — in a list showing:
  whether a host password is set, whether a PIN is set, who's
  currently active, when the room was created, and when it was last
  active. From there, join any room either as a visible Super User
  (crown icon, animated glowing message border) or "as Host
  (anonymously)" — entering with full host powers under the plain
  "Host" identity, indistinguishable from a real host login. Can also
  create brand-new rooms from the same screen.

  Super users can:
    - Upload any file type (except a small blocklist of
      server-executable extensions like .php/.exe, kept for safety)
    - Clear chat, mute, kick — like a host, in ANY room
    - Rename the room (emoji titles supported, e.g. "🎮 Game Night")
    - Reset a room's host password (kicks the current host session;
      whoever logs in as host next sets a new password)
    - Unban previously kicked users

  ADDING MORE SUPER USERS
    Open super_users.php and add a line following the existing
    format — commented examples are right there.
    Currently configured: username "xbot", password "#123xbot",
    default display name "09".

SPAM TIMER (MUTE)
  Both hosts and super users can mute anyone in the room via the
  "Manage" panel — pick a duration in minutes (0 unmutes early). A
  muted person sees a banner and can't send messages or upload files
  until it expires.

THEME & WALLPAPER — LOCAL TO EACH PERSON, NOT SHARED
  Every user has a 🌓 button to toggle dark/light mode.
  Super users additionally get a 🎨 Theme panel to set a background
  color, paste an image URL, upload an image from their device, or
  pick from built-in presets.
  IMPORTANT: none of this is sent to the server or shown to anyone
  else — it's saved only in that person's own browser (localStorage),
  so a super user's wallpaper choice never changes what other people
  see. The only thing that's visible to everyone is the animated
  rotating glow border automatically shown around every Super User's
  chat messages — that's fixed and not configurable, it's just how
  super identity is indicated to the room.
  Note: wallpapers uploaded from a device only last for that browser
  tab/session (they're not saved as a file anywhere) — pick a preset
  or paste a URL for something that persists across visits.

AUTOMATIC CLEANUP (24-HOUR EXPIRY)
  Messages and their uploaded files are automatically deleted once
  they're older than 24 hours — checked whenever the chat is loaded
  or polled, no cron job needed. Edit $messageExpirySeconds in
  common.php to change this.

ROOM WALLPAPER & MESSAGE GLOW (SUPER-CONTROLLED, ROOM-WIDE)
  Only a super user can change a room's wallpaper — from the 🎨 Theme
  button, they can pick a color, paste an image URL, upload an image
  from their device (stored on the server so it persists), or use a
  built-in preset. Whatever they set applies to EVERYONE currently in
  that room and anyone who joins later — nobody else can override it,
  and it's not something a regular member or host can change.
  Super users can also set their own glow color for the animated
  border around their messages (default is a rotating rainbow if left
  unset) — this is visible to everyone as an identity indicator.
  Everyone still gets a personal, purely local 🌓 dark/light toggle
  for basic contrast — that one stays private per-browser and doesn't
  touch the server at all.

MESSAGE REACTIONS
  Tap "😊 React" under any message to pick from six quick emoji
  (👍❤️😂😮😢🔥). One active reaction per person per message — picking
  a different emoji swaps your old one out. Reaction counts sync to
  everyone in the room, including on older messages.

REPLY / QUOTE
  Tap ↩️ next to any message to reply to it — a preview bar appears
  above the input showing what you're replying to (with a ✕ to cancel).
  The message you send shows a small quoted snippet of the original
  above it.

TYPING INDICATOR
  While someone has text in the message box, others see "X is
  typing…" above the message list. Clears automatically a few seconds
  after they stop.

SOUND + TAB NOTIFICATION
  If the browser tab isn't focused when a new message arrives, you'll
  hear a short beep (generated in-browser, no audio file needed) and
  the tab title updates to show an unread count, e.g. "(3) Quick
  Chat" — clears automatically when you switch back to the tab.

PIN MESSAGE (SUPER — PREMIUM)
  Super users can tap 📌 on any message to pin it — it shows in a gold
  bar at the top of the chat for everyone, with an "Unpin" button
  (super-only) to remove it.

MESSAGE COMPOSER, CODE BLOCKS & COPY
  The message box is a multi-line textarea. Enter always just adds a
  new line — it never sends by itself anymore (this was the bug where
  writing/pasting code with line breaks could accidentally send
  mid-way through). Tap "Send" to send, or use Ctrl+Enter (Cmd+Enter
  on Mac) as a keyboard shortcut.

  Any message containing a line break is automatically shown in a
  proper code box: monospace font, horizontal scrolling for long
  lines (nothing gets cut off or wrapped awkwardly), and its own
  "📋 Copy" button in the corner that copies the exact text, line
  breaks included. Plain single-line messages get a small copy button
  next to the sender's name instead.

  The per-message length limit is 20,000 characters — plenty for
  pasted code.

FILE SHARING
  Members: images, audio, video, docs (pdf/doc/xls/ppt/txt/csv/rtf),
  archives (zip/rar/7z) — shown inline where possible, download card
  otherwise.
  Super users: everything above PLUS any other file type, except the
  small server-safety blocklist.
  Default max size: 25 MB (members) / 200 MB (super) — your host's
  own PHP upload_max_filesize/post_max_size may cap this lower.

SECURITY NOTES (read this)
  - Passwords in super_users.php are plain text — anyone with server
    file access could read them. Don't reuse these passwords elsewhere.
  - PINs and host passwords ARE hashed (SHA-256) before storage.
  - This is casual/personal-use security, not hardened against a
    determined attacker with server access.
  - Traffic is only encrypted if your host serves the site over
    HTTPS — check your host's control panel for free SSL if unsure.
  - Sessions last 6 hours of activity (sliding) then expire.

CUSTOMIZING
  - POLL_INTERVAL_MS in index.html — how often the chat checks updates
  - $maxMessages in common.php — how much history is kept
  - $sessionTtlSeconds in common.php — how long logins stay valid
  - $memberAllowedExtensions / $dangerousExtensions in upload.php
  - THEME_PRESETS / WALLPAPER_PRESETS in index.html — the quick-pick
    swatches in the super user's theme panel
