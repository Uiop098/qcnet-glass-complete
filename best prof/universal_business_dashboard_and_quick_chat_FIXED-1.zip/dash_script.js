let businessData = { users: {}, payments: [], reminders: [], links: [], products: [], stats: {}, settings: {} };
let currentUserRole = 'user';
let currentUsername = '';

async function checkAuth() {
    const response = await fetch('dash_auth.php?action=check_auth'); const data = await response.json();
    if (data.status === 'success') {
        currentUserRole = data.role; currentUsername = data.user;
        if (window.location.href.includes('dash_login.html')) { window.location.href = data.role === 'admin' ? 'dash_admin.html' : 'dash_user.html'; }
        else fetchDashboardData();
    } else {
        if (!window.location.href.includes('dash_login.html') && !window.location.href.includes('pay.html')) window.location.href = 'dash_login.html';
    }
}

async function fetchDashboardData() {
    const response = await fetch('dash_api.php?action=get_dashboard_data'); const data = await response.json();
    if (data.status === 'success') {
        businessData = data;
        renderTopBar();
        if(currentUserRole === 'admin') renderUI('dashboard_home');
        if(currentUserRole === 'user') renderUserUI('profile');
    }
}

function renderTopBar() {
    const tb = document.getElementById('top-bar');
    if(!tb) return;
    const userCount = Object.keys(businessData.users || {}).length;
    tb.innerHTML = `
        <div class="user-info">Welcome, <span>${businessData.my_profile?.name || currentUsername}</span> | Role: ${currentUserRole.toUpperCase()}</div>
        ${currentUserRole === 'admin' ? `<div class="stats-badge">👥 ${userCount} Users Registered</div>` : ''}
    `;
}

function renderUI(module) {
    const area = document.getElementById('content-area'); document.getElementById('module-title').innerText = module.toUpperCase().replace('_', ' ');
    
    if (module === 'dashboard_home') {
        area.innerHTML = `
            <div class="stats-grid fade-in">
                <div class="stat-card"><h3>Total Users</h3><div class="val">${businessData.stats?.total_users || 0}</div></div>
                <div class="stat-card"><h3>Total Revenue</h3><div class="val">₹${businessData.stats?.total_revenue || 0}</div></div>
                <div class="stat-card"><h3>Products</h3><div class="val">${businessData.products.length}</div></div>
            </div>
            <p style="color:#a89bc2;">Use the sidebar to manage your Business Chat Portal.</p>
        `;
        return;
    }
    
    if (module === 'settings') {
        let s = businessData.settings || {};
        area.innerHTML = `
            <div class="glass-panel fade-in" style="padding:25px; max-width:500px; display:flex; flex-direction:column; gap:5px;">
                <h3 style="margin:0 0 10px 0;">Payment API Settings</h3>
                <label>Payment Gateway Mode</label>
                <select id="set-mode"><option value="server" ${s.payment_mode==='server'?'selected':''}>Default Server Keys</option><option value="self" ${s.payment_mode==='self'?'selected':''}>Self (My Own Cashfree Keys)</option></select>
                <label>Cashfree App ID</label><input type="text" id="set-appid" value="${s.cf_app_id||''}">
                <label>Cashfree Secret Key</label><input type="password" id="set-secret" placeholder="••••••••">
                <label>Environment</label>
                <select id="set-env"><option value="SANDBOX" ${s.cf_env==='SANDBOX'?'selected':''}>Sandbox (Testing)</option><option value="PROD" ${s.cf_env==='PROD'?'selected':''}>Production</option></select>
                <button onclick="saveSettings()" class="primary-btn" style="margin-top:10px;">🔒 Save Settings</button>
            </div>`;
        return;
    }
    
    if (module === 'products') {
        area.innerHTML = `<div style="margin-bottom:15px;"><button onclick="showAddForm('products')" class="primary-btn">+ Add Membership/Product</button></div>
        <div class="table-container fade-in"><table><tr><th>Product Name</th><th>Price (₹)</th><th>Desc</th></tr>
        ${businessData.products.map(p => `<tr><td><b>${p.name}</b></td><td>₹${p.price}</td><td>${p.desc||'--'}</td></tr>`).join('')}
        </table></div>`;
        return;
    }

    let html = `<div style="margin-bottom:15px;"><button onclick="showAddForm('${module}')" class="primary-btn">${module === 'users' ? '+ Invite New User' : '+ Add Record'}</button></div>`;
    html += `<div class="table-container fade-in"><table>`;
    if (module === 'users') {
        html += `<tr><th>User</th><th>Tags</th><th>Actions</th></tr>`;
        Object.keys(businessData.users).forEach(u => {
            html += `<tr><td><b>${businessData.users[u].name||'--'}</b><br><span style="font-size:11px;color:#aaa;">@${u}</span></td>
            <td><span style="background:rgba(74,222,128,0.2); padding:3px 8px; border-radius:12px; font-size:11px; color:#4ade80;">${businessData.users[u].tags||'None'}</span></td>
            <td><button onclick="deleteUser('${u}')" style="font-size:11px; padding:5px 8px; background:rgba(255,107,107,0.3); color:#ff6b6b;">Del</button></td></tr>`;
        });
    } else if (module === 'payments') {
        html += `<tr><th>Client Username</th><th>Amount</th><th>Status</th></tr>`;
        businessData.payments.forEach(p => html += `<tr><td>@${p.client||'--'}</td><td>₹${p.amount||'0'}</td><td>${p.status||'--'}</td></tr>`);
    } else if (module === 'reminders') {
        html += `<tr><th>Task</th><th>Priority</th><th>Due Date</th></tr>`;
        businessData.reminders.forEach(r => html += `<tr><td>${r.task||'--'}</td><td>${r.priority||'--'}</td><td>${r.due||'--'}</td></tr>`);
    } else if (module === 'links') {
        html += `<tr><th>Title</th><th>URL</th></tr>`;
        businessData.links.forEach(l => html += `<tr><td>${l.title||'--'}</td><td><a href="${l.url}" target="_blank" style="color:#4ade80">${l.url}</a></td></tr>`);
    }
    area.innerHTML = html + `</table></div>`;
}

function showAddForm(module) {
    const area = document.getElementById('content-area');
    let formHtml = `<div id="add-form" class="glass-panel fade-in" style="padding:25px; max-width:400px; display:flex; flex-direction:column; gap:5px;">`;
    if (module === 'users') {
        // Users aren't created directly here — usernames/passwords need
        // server-side hashing, uniqueness checks, and users.json is a keyed
        // object ({username: {...}}), not the flat array the generic
        // add_record/submitForm path assumes for payments/reminders/links.
        // Instead this generates a short-lived invite token (the same
        // create_pending flow QuickChat itself already uses for invites),
        // which the new user redeems at setup_account.html to set their own
        // username & password.
        formHtml += `<label>Contact Name</label><input type="text" name="name" placeholder="Full name" required><label>Date of Birth</label><input type="date" name="dob" required>`;
        formHtml += `<div style="display:flex; gap:10px; margin-top:10px;"><button onclick="createPendingUser()" class="primary-btn" style="flex:1;">Generate Invite Token</button></div></div>`;
        area.innerHTML = formHtml;
        return;
    }
    if (module === 'payments') { 
        let userOpts = Object.keys(businessData.users).map(u => `<option value="${u}">@${u} - ${businessData.users[u].name}</option>`).join('');
        formHtml += `<label>Select Client</label><select name="client">${userOpts}</select><label>Amount</label><input type="number" name="amount" placeholder="0.00"><label>Status</label><select name="status"><option>Pending</option><option>Received</option></select>`; 
    } 
    else if (module === 'products') { formHtml += `<label>Product Name</label><input type="text" name="name" required><label>Price (INR)</label><input type="number" name="price" required><label>Description</label><input type="text" name="desc">`; }
    else if (module === 'reminders') { formHtml += `<label>Task Description</label><input type="text" name="task" placeholder="..."><label>Priority</label><select name="priority"><option>High</option><option>Normal</option></select><label>Due Date</label><input type="date" name="due">`; } 
    else if (module === 'links') { formHtml += `<label>Link Title</label><input type="text" name="title" placeholder="..."><label>URL</label><input type="url" name="url" placeholder="https://...">`; }
    formHtml += `<div style="display:flex; gap:10px; margin-top:10px;"><button onclick="submitForm('${module}')" class="primary-btn" style="flex:1;">Save</button></div></div>`;
    area.innerHTML = formHtml;
}

async function createPendingUser() {
    const nameInput = document.querySelector('#add-form input[name="name"]');
    const dobInput = document.querySelector('#add-form input[name="dob"]');
    if (!nameInput.value.trim() || !dobInput.value) { alert("Name and date of birth are required."); return; }
    const form = new URLSearchParams(); form.append('name', nameInput.value.trim()); form.append('dob', dobInput.value);
    const res = await fetch('dash_auth.php?action=create_pending', { method: 'POST', body: form });
    const data = await res.json();
    if (data.status !== 'success') { alert(data.error || "Failed to generate invite."); return; }
    document.getElementById('content-area').innerHTML = `<div class="glass-panel fade-in" style="padding:25px; max-width:400px;">
        <h3 style="margin-top:0;">✅ Invite Token Created</h3>
        <p style="color:#aaa; font-size:13px;">Share this token with <b>${nameInput.value.trim()}</b>. It expires in 10 minutes and can only be used once, at the account setup page.</p>
        <div style="font-size:24px; letter-spacing:3px; text-align:center; background:rgba(0,0,0,0.2); border-radius:8px; padding:15px 0; margin:15px 0; font-weight:700;">${data.token}</div>
        <div style="display:flex; gap:10px;">
            <button onclick="navigator.clipboard.writeText('${data.token}'); this.innerText='Copied!';" class="primary-btn" style="flex:1;">📋 Copy Token</button>
            <button onclick="renderUI('users')" style="flex:1;">Done</button>
        </div>
    </div>`;
}

async function saveSettings() {
    // Previously this ran the payload through e2ee_encrypt() (just btoa() —
    // not encryption at all) and the server tried to AES-decrypt it as if it
    // were real ciphertext, using an IV derived from the server's own secret
    // key. That mismatch meant this call failed every time ("E2EE Decryption
    // Failed"), and even if it had "worked" it wasn't providing the claimed
    // protection — a client can't meaningfully encrypt something only the
    // server can read without either sharing a secret (which defeats the
    // purpose) or the server exposing its at-rest key to the browser (which
    // would be far worse, since that same key protects every tenant's data).
    // The real protection here is HTTPS in transit plus the server's existing
    // AES-256-CBC encryption at rest (save_secure_table), which already
    // applies correctly to every settings save.
    const form = new URLSearchParams();
    form.append('payment_mode', document.getElementById('set-mode').value);
    form.append('cf_app_id', document.getElementById('set-appid').value);
    form.append('cf_secret_key', document.getElementById('set-secret').value);
    form.append('cf_env', document.getElementById('set-env').value);
    const res = await fetch('dash_api.php?action=save_settings', { method: 'POST', body: form });
    const data = await res.json();
    if (data.status === 'success') { alert("Settings saved."); fetchDashboardData(); } else alert(data.error || "Failed to save settings.");
}

async function submitForm(table) {
    const inputs = document.querySelectorAll('#add-form input, #add-form select'); const formData = new URLSearchParams(); formData.append('table', table);
    inputs.forEach(input => formData.append(input.name, input.value));
    await fetch('dash_api.php?action=add_record', { method: 'POST', body: formData }); fetchDashboardData();
}

async function deleteUser(username) {
    if(confirm(`WARNING: Are you sure you want to permanently delete user @${username}?`)) {
        const form = new URLSearchParams(); form.append('username', username);
        await fetch('dash_api.php?action=delete_user', { method: 'POST', body: form }); fetchDashboardData();
    }
}

function renderUserUI(module) {
    const area = document.getElementById('content-area'); document.getElementById('module-title').innerText = module.toUpperCase().replace('_', ' ');
    if (module === 'products') {
        let html = `<div class="stats-grid fade-in">`;
        businessData.products.forEach(p => {
            html += `<div class="stat-card" style="text-align:left;">
                <h3 style="color:#fff; font-size:18px;">${p.name}</h3><p style="color:#aaa; font-size:12px;">${p.desc||''}</p>
                <div class="val" style="margin-bottom:10px;">₹${p.price}</div>
                <button onclick="buyProduct('${p.id}')" class="primary-btn" style="width:100%;">Buy Now via Cashfree</button>
            </div>`;
        });
        area.innerHTML = html + `</div>`; return;
    }
    if (module === 'profile') { area.innerHTML = `<div class="glass-panel fade-in" style="padding:20px; max-width:400px;"><h3>Profile Details</h3><p><b>Name:</b> ${businessData.my_profile?.name||'--'}</p></div>`; return; }
    if (module === 'my_payments') {
        let html = `<div class="table-container fade-in"><table><tr><th>Amount</th><th>Status</th></tr>`;
        businessData.payments.forEach(p => html += `<tr><td>₹${p.amount||'0'}</td><td>${p.status||'--'}</td></tr>`);
        area.innerHTML = html + `</table></div>`; return;
    }
    
    let html = `<div class="table-container fade-in"><table>`;
    if (module === 'reminders') {
        html += `<tr><th>Task</th><th>Priority</th><th>Due Date</th></tr>`;
        businessData.reminders.forEach(r => html += `<tr><td>${r.task||'--'}</td><td>${r.priority||'--'}</td><td>${r.due||'--'}</td></tr>`);
    } else if (module === 'links') {
        html += `<tr><th>Title</th><th>URL</th></tr>`;
        businessData.links.forEach(l => html += `<tr><td>${l.title||'--'}</td><td><a href="${l.url}" target="_blank" style="color:#4ade80">${l.url}</a></td></tr>`);
    }
    area.innerHTML = html + `</table></div>`;
}

async function buyProduct(pid) {
    const form = new URLSearchParams(); form.append('product_id', pid);
    const res = await fetch('tenant_payment_api.php?action=buy_product', { method: 'POST', body: form });
    const data = await res.json();
    if(data.status === 'success') {
        const cashfree = Cashfree({ mode: "production" });
        cashfree.checkout({ paymentSessionId: data.payment_session_id, redirectTarget: "_self" });
    } else alert(data.error);
}

function showForgotModal() { document.getElementById('forgotModal').classList.add('active'); }
function hideForgotModal() { document.getElementById('forgotModal').classList.remove('active'); }

async function sendOTP() {
    const email = document.getElementById('f-email').value; const dob = document.getElementById('f-dob').value;
    const form = new URLSearchParams(); form.append('email', email); form.append('dob', dob);
    const res = await fetch('dash_auth.php?action=forgot_password_step1', { method: 'POST', body: form });
    const data = await res.json();
    if(data.status === 'success') {
        alert(data.message);
        document.getElementById('step1').style.display='none'; document.getElementById('step2').style.display='flex';
    } else alert(data.error);
}

async function verifyOTP() {
    const email = document.getElementById('f-email').value; const code = document.getElementById('f-code').value;
    const form = new URLSearchParams(); form.append('email', email); form.append('code', code);
    const res = await fetch('dash_auth.php?action=forgot_password_step2', { method: 'POST', body: form });
    const data = await res.json();
    if(data.status === 'success') {
        const sel = document.getElementById('f-user-sel'); sel.innerHTML = data.accounts.map(u => `<option value="${u}">@${u}</option>`).join('');
        document.getElementById('step2').style.display='none'; document.getElementById('step3').style.display='flex';
    } else alert(data.error);
}

async function resetPass() {
    const email = document.getElementById('f-email').value; const code = document.getElementById('f-code').value;
    const user = document.getElementById('f-user-sel').value; const pass = document.getElementById('f-newpass').value;
    const form = new URLSearchParams(); form.append('email', email); form.append('code', code); form.append('username', user); form.append('new_password', pass);
    const res = await fetch('dash_auth.php?action=forgot_password_step3', { method: 'POST', body: form });
    const data = await res.json();
    if(data.status === 'success') { alert(data.message); window.location.reload(); } else alert(data.error);
}

async function submitLogin() {
    const role = document.getElementById('login-role').value; const user = document.getElementById('login-user').value;
    const pass = document.getElementById('login-pass').value; const msg = document.getElementById('login-msg');
    const form = new URLSearchParams(); form.append('username', user); form.append('password', pass);
    const endpoint = role === 'admin' ? 'admin_login' : 'user_login';
    try {
        const res = await fetch('dash_auth.php?action=' + endpoint, { method: 'POST', body: form }); const data = await res.json();
        if (data.status === 'success') { window.location.href = role === 'admin' ? 'dash_admin.html' : 'dash_user.html'; } 
        else { msg.style.color = '#ff6b6b'; msg.innerText = data.error; }
    } catch (e) { msg.innerText = 'Connection error.'; }
}
async function logout() { await fetch('dash_auth.php?action=logout'); window.location.href = 'dash_login.html'; }
async function generateToken() {
    const name = prompt("Enter User's Name:"); if (!name) return; const dob = prompt("Enter User's Date of Birth (YYYY-MM-DD):"); if (!dob) return;
    const form = new URLSearchParams(); form.append('name', name); form.append('dob', dob);
    try {
        const res = await fetch('dash_auth.php?action=create_pending', { method: 'POST', body: form }); const data = await res.json();
        if (data.status === 'success') {
            try { await navigator.clipboard.writeText(data.token); alert(`Token Generated & Copied! Token: ${data.token} Expires in: 10 mins`); } 
            catch(err) { prompt("Copy your token (Expires in 10 mins):", data.token); }
        } else alert(data.error);
    } catch(e) { alert("Error generating token."); }
}

const wallpapers = [ 'none', 'url("assets/dark-abstract.jpg")' ];
let currentBg = 0;
function changeTheme() { currentBg = (currentBg + 1) % wallpapers.length; document.documentElement.style.setProperty('--bg-image', wallpapers[currentBg]); }

if (!window.location.href.includes("gateway.html") && !window.location.href.includes("welcome.html") && !window.location.href.includes("pay.html")) { checkAuth(); }
