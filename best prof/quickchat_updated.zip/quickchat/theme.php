<?php
// theme.php — lets a super user set the room's background theme and the
// glow color used for their own messages. Super-user only.

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
$token = isset($body['token']) ? $body['token'] : '';

$session = get_session($token);
if (!$session) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Session expired or invalid. Please rejoin.']);
    exit;
}
if ($session['role'] !== 'super') {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Only a super user can change the theme.']);
    exit;
}

$room = $session['room'];
$config = read_config($room);
if (!$config) $config = default_config();

// Basic sanitization: allow CSS color/gradient-ish strings, block anything
// that looks like it's trying to break out of a CSS value (e.g. via url()
// with javascript: or closing braces).
function clean_css_value($val) {
    $val = trim((string)$val);
    $val = str_ireplace(['javascript:', '<', '>', '{', '}', ';'], '', $val);
    return mb_substr($val, 0, 300);
}

if (isset($body['background'])) {
    $config['theme']['background'] = clean_css_value($body['background']);
}
if (isset($body['glow'])) {
    $config['theme']['glow'] = clean_css_value($body['glow']);
}
if (isset($body['glowOff'])) {
    $config['theme']['glowOff'] = !empty($body['glowOff']);
}

write_config($room, $config);

echo json_encode(['ok' => true, 'theme' => $config['theme']]);
