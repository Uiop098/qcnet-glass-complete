<?php
// mute.php — temporarily blocks a user from sending messages/files
// ("spammer timer") without kicking them out of the room. Pass
// durationSeconds=0 to unmute early. Only callable by a host or super user.

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
$token = isset($body['token']) ? $body['token'] : '';
$targetUser = trim((string)($body['targetUser'] ?? ''));
$durationSeconds = isset($body['durationSeconds']) ? (int)$body['durationSeconds'] : 0;

$session = get_session($token);
if (!$session) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Session expired or invalid. Please rejoin.']);
    exit;
}
if (!in_array($session['role'], ['host', 'super'], true)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Only the host or a super user can mute people.']);
    exit;
}
if ($targetUser === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'No user specified.']);
    exit;
}
if (strtolower($targetUser) === strtolower($session['user'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'You can\'t mute yourself.']);
    exit;
}
if ($durationSeconds < 0 || $durationSeconds > 86400) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Duration must be between 0 (unmute) and 86400 seconds (24h).']);
    exit;
}

$room = $session['room'];
$config = read_config($room);
if (!$config) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Room not found.']);
    exit;
}

mute_user($config, $targetUser, $durationSeconds);
write_config($room, $config);

echo json_encode([
    'ok' => true,
    'user' => $targetUser,
    'mutedForSeconds' => $durationSeconds,
    'remaining' => mute_remaining_seconds($config, $targetUser),
]);
