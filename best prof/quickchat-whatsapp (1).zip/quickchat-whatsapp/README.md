# QuickChat — WhatsApp (iOS)-style Web Chat

A self-hosted, no-database chat app styled after the iOS WhatsApp UI: chat
list with avatars/unread badges, green/white message bubbles, a bottom
composer with attach/mic/send, typing indicators, read receipts, replies,
voice notes, and dark mode. Built with plain HTML/CSS/JS on the frontend and
plain PHP + JSON files on the backend — no build step, no database, no
external libraries.

This was built using an earlier "Quick Chat" project as a structural
reference (JSON-file storage, session auth, polling API), redesigned from
scratch with a WhatsApp-style interface and a per-user/per-chat data model
instead of a single shared room.

## What's inside

```
index.html          - app shell (login screen + chat list + chat screen + settings)
css/style.css        - WhatsApp iOS visual theme (light + dark mode)
js/app.js             - all frontend logic (polling, rendering, uploads, recording)
api/
  common.php          - shared config, JSON storage helpers, session bootstrap
  auth.php            - login (display name only, no password) / logout
  chats.php           - list chats, list contacts, start a direct or group chat
  messages.php        - fetch/send/delete messages (polling-based)
  upload.php          - image/video/audio/file uploads
  typing.php           - "is typing…" presence flag
  read.php             - read-receipt tracking (drives unread badges)
data/                - JSON storage: users, chats, messages, read state, typing
                        (.htaccess blocks direct browser access)
uploads/             - uploaded files/images/voice notes
                        (.htaccess blocks script execution, allows direct file access)
.htaccess             - basic security response headers (Apache only)
```

## Requirements

Any PHP host works (PHP 7.4+). No database needed — everything is stored as
JSON files under `data/`. Voice notes use the browser's MediaRecorder API
(requires HTTPS in most browsers, except on localhost).

## How to deploy

1. Upload the whole `quickchat-whatsapp` folder to your PHP host (FTP or
   File Manager) — e.g. `public_html/chat/`.
2. Make sure `data/` and `uploads/` are writable by PHP (755/775 if you hit
   permission errors).
3. Visit `https://yourdomain.com/chat/` and enter a display name to join.
4. Open the same URL in another browser (or incognito window) with a
   different name to test messaging between two people.

No signup, no password, no configuration required to get started — the app
creates a user record the first time a display name is used, and matches it
again (case-insensitively) the next time that name logs in.

## How it works

- **Storage**: everything lives in flat JSON files under `data/` —
  `users.json`, `chats.json`, one `messages/<chatId>.json` per conversation,
  and one `read/<chatId>.json` per conversation for read-receipt state.
  Reads/writes use file locks (`flock`) to avoid corrupting data under
  concurrent requests.
- **Auth**: logging in with a name creates or reuses a user record and
  starts a PHP session (12-hour sliding expiry). There's no password — this
  is meant as a lightweight personal/demo deployment, not a hardened
  multi-tenant service (see Security notes below).
- **Sync**: the frontend polls `messages.php` every 2 seconds for the open
  chat and `chats.php` every 4 seconds for the chat list, so new messages,
  typing indicators, and read receipts show up without a page reload. This
  keeps the stack dependency-free (no WebSocket server needed) at the cost
  of near-real-time rather than truly instant delivery.
- **Chats**: two people get one shared direct chat (created lazily the
  first time you tap their name); `chats.php` also supports creating named
  group chats with multiple members, though the UI currently only exposes
  starting direct chats from the "New Chat" screen.

## Features

- **Chat list** — avatars (colored initials), last message preview with
  delivery ticks, timestamp, unread badge, search.
- **Conversation screen** — WhatsApp-style bubbles (pale green = sent,
  white = received), grouped consecutive messages, date separators,
  auto-linkified URLs.
- **Composer** — auto-growing text box, Enter-to-send, attach button
  (images/video/audio/docs), and a mic button that becomes a send button as
  soon as you start typing.
- **Voice messages** — tap the mic to record in-browser (MediaRecorder),
  see a live timer, then "Stop & send" or "Cancel".
- **Typing indicator** — "typing…" appears in the other person's header,
  and an animated dot bubble appears in the thread, while you're composing.
- **Read receipts** — double gray ticks show "delivered"; the chat list's
  unread badge and per-message read tracking are driven by each person's
  last-read message id.
- **Reply / quote** — tap ↩️ on any message to reply; the sent message
  shows a small quoted snippet of the original above it.
- **Delete for everyone** — tap 🗑️ on your own message to remove it
  (replaced with a "This message was deleted" placeholder).
- **Dark mode** — toggle in Settings; saved per-browser in localStorage.
- **File sharing** — images/video render inline, audio gets a playable
  player, other file types show a download card with name + size.

## Customizing

- `POLL_LIST_MS` / `POLL_MSG_MS` in `js/app.js` — how often the chat list
  and open conversation poll for updates.
- `SESSION_TTL_SECONDS`, `MAX_MESSAGE_LENGTH`, `MAX_UPLOAD_BYTES`,
  `ALLOWED_UPLOAD_EXT` in `api/common.php` — session length, message length
  cap, upload size cap, and which file extensions are accepted.
- `--wa-green`, `--bubble-sent`, etc. custom properties at the top of
  `css/style.css` — the WhatsApp color palette, easy to retheme.

## Security notes (read this)

- There is **no password** on logins — anyone who knows (or guesses) a
  display name can "become" that user. This is intentional for a quick
  personal/demo deployment, not meant for sensitive conversations between
  strangers on the open internet. Add a shared PIN or real auth in
  `auth.php` before using this for anything sensitive.
- Uploaded files are served directly from `uploads/`; the `.htaccess` there
  blocks PHP/CGI execution but doesn't scan file contents — don't disable
  that block.
- `data/.htaccess` blocks direct browser access to the JSON storage; if
  your host isn't Apache (nginx, etc.), add an equivalent rule in your
  server config, since `.htaccess` only works under Apache with
  `mod_rewrite`/`mod_authz_core` enabled.
- Traffic is only encrypted if your host serves the site over HTTPS —
  check your host's control panel for free SSL if unsure.
- This has no rate limiting or IP blocking (unlike more hardened chat
  setups) — fine for a small trusted group, not for a public-internet
  deployment exposed to abuse.
