<?php
require __DIR__ . '/common.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // action=me — return current session user (if any), used on page load
    if (!empty($_SESSION['user_id'])) {
        $user = find_user($_SESSION['user_id']);
        if ($user) json_out(['ok' => true, 'user' => $user]);
    }
    json_out(['ok' => true, 'user' => null]);
}

if ($method === 'POST') {
    $body = body_json();
    $action = $body['action'] ?? 'login';

    if ($action === 'login') {
        $name = trim((string)($body['name'] ?? ''));
        if ($name === '') fail('name_required');
        if (mb_strlen($name) > 40) fail('name_too_long');

        // Match an existing user case-insensitively so people can "log back in"
        // by typing the same display name; otherwise create a new one.
        $existing = null;
        foreach (all_users() as $u) {
            if (mb_strtolower($u['name']) === mb_strtolower($name)) { $existing = $u; break; }
        }

        if ($existing) {
            $user = $existing;
            $user['online'] = true;
            $user['lastSeen'] = time();
        } else {
            $user = [
                'id' => new_id('u_'),
                'name' => $name,
                'initials' => initials($name),
                'color' => avatar_color($name),
                'createdAt' => time(),
                'online' => true,
                'lastSeen' => time(),
            ];
        }
        save_user($user);
        $_SESSION['user_id'] = $user['id'];
        json_out(['ok' => true, 'user' => $user]);
    }

    if ($action === 'logout') {
        if (!empty($_SESSION['user_id'])) {
            $user = find_user($_SESSION['user_id']);
            if ($user) {
                $user['online'] = false;
                $user['lastSeen'] = time();
                save_user($user);
            }
        }
        session_unset();
        session_destroy();
        json_out(['ok' => true]);
    }

    fail('unknown_action');
}

fail('method_not_allowed', 405);
