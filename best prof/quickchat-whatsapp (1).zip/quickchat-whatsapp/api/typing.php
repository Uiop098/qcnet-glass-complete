<?php
require __DIR__ . '/common.php';

$user = require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('method_not_allowed', 405);

$body = body_json();
$chatId = trim((string)($body['chatId'] ?? ''));
if ($chatId === '') fail('chatId_required');
$chat = find_chat($chatId);
if (!$chat) fail('chat_not_found', 404);
require_chat_membership($chat, $user);

$isTyping = !empty($body['isTyping']);
$map = read_json(typing_path(), []);
$key = $chatId . '::' . $user['id'];

if ($isTyping) {
    $map[$key] = time();
} else {
    unset($map[$key]);
}

// Housekeeping: drop stale entries so the file doesn't grow forever
$now = time();
foreach ($map as $k => $ts) {
    if (($now - $ts) > TYPING_TTL_SECONDS) unset($map[$k]);
}

write_json(typing_path(), $map);
json_out(['ok' => true]);
