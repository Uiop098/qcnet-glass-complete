<?php
require __DIR__ . '/common.php';

$user = require_login();
$method = $_SERVER['REQUEST_METHOD'];

/** Build the lightweight chat-list summary the frontend needs: last message + unread count. */
function chat_summary(array $chat, array $me): array {
    $messages = read_json(messages_path($chat['id']), []);
    $last = count($messages) ? $messages[count($messages) - 1] : null;

    $readState = read_json(read_state_path($chat['id']), []);
    $myLastRead = $readState[$me['id']]['lastReadId'] ?? null;

    $unread = 0;
    if ($messages) {
        $counting = $myLastRead === null;
        foreach ($messages as $m) {
            if ($counting && $m['senderId'] !== $me['id']) $unread++;
            if (!$counting && $m['id'] === $myLastRead) $counting = true;
        }
    }

    $otherId = null;
    if ($chat['type'] === 'direct') {
        foreach ($chat['members'] as $m) if ($m !== $me['id']) { $otherId = $m; break; }
    }
    $otherUser = $otherId ? find_user($otherId) : null;

    $title = $chat['type'] === 'group' ? $chat['name'] : ($otherUser['name'] ?? 'Unknown');
    $initials = $chat['type'] === 'group' ? initials($chat['name']) : ($otherUser['initials'] ?? '?');
    $color = $chat['type'] === 'group' ? avatar_color($chat['name']) : ($otherUser['color'] ?? '#999');
    $online = $chat['type'] === 'direct' ? (bool)($otherUser['online'] ?? false) : false;
    $lastSeen = $otherUser['lastSeen'] ?? null;

    return [
        'id' => $chat['id'],
        'type' => $chat['type'],
        'title' => $title,
        'initials' => $initials,
        'color' => $color,
        'online' => $online,
        'lastSeen' => $lastSeen,
        'otherUserId' => $otherId,
        'lastMessage' => $last,
        'unreadCount' => $unread,
        'updatedAt' => $last['createdAt'] ?? $chat['createdAt'],
    ];
}

if ($method === 'GET') {
    $action = $_GET['action'] ?? 'list';

    if ($action === 'list') {
        $chats = array_filter(all_chats(), fn($c) => in_array($user['id'], $c['members'], true));
        $summaries = array_map(fn($c) => chat_summary($c, $user), $chats);
        usort($summaries, fn($a, $b) => $b['updatedAt'] <=> $a['updatedAt']);
        json_out(['ok' => true, 'chats' => array_values($summaries)]);
    }

    if ($action === 'contacts') {
        // Everyone except me, for the "start new chat" screen
        $contacts = array_values(array_filter(all_users(), fn($u) => $u['id'] !== $user['id']));
        usort($contacts, fn($a, $b) => strcasecmp($a['name'], $b['name']));
        json_out(['ok' => true, 'contacts' => $contacts]);
    }

    fail('unknown_action');
}

if ($method === 'POST') {
    $body = body_json();
    $action = $body['action'] ?? 'create_direct';

    if ($action === 'create_direct') {
        $otherId = trim((string)($body['userId'] ?? ''));
        if ($otherId === '') fail('userId_required');
        $other = find_user($otherId);
        if (!$other) fail('user_not_found', 404);
        if ($otherId === $user['id']) fail('cannot_chat_with_self');

        // Reuse existing direct chat if one already exists between these two
        foreach (all_chats() as $c) {
            if ($c['type'] === 'direct' && count($c['members']) === 2
                && in_array($user['id'], $c['members'], true) && in_array($otherId, $c['members'], true)) {
                json_out(['ok' => true, 'chat' => chat_summary($c, $user)]);
            }
        }

        $chat = [
            'id' => new_id('c_'),
            'type' => 'direct',
            'members' => [$user['id'], $otherId],
            'createdAt' => time(),
        ];
        save_chat($chat);
        json_out(['ok' => true, 'chat' => chat_summary($chat, $user)]);
    }

    if ($action === 'create_group') {
        $name = trim((string)($body['name'] ?? ''));
        $memberIds = $body['memberIds'] ?? [];
        if ($name === '') fail('name_required');
        if (!is_array($memberIds)) $memberIds = [];
        $members = array_values(array_unique(array_merge([$user['id']], $memberIds)));
        if (count($members) < 2) fail('need_at_least_one_other_member');

        $chat = [
            'id' => new_id('c_'),
            'type' => 'group',
            'name' => $name,
            'members' => $members,
            'createdAt' => time(),
        ];
        save_chat($chat);
        json_out(['ok' => true, 'chat' => chat_summary($chat, $user)]);
    }

    fail('unknown_action');
}

fail('method_not_allowed', 405);
