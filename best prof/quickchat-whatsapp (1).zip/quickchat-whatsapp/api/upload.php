<?php
require __DIR__ . '/common.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('method_not_allowed', 405);
if (empty($_FILES['file'])) fail('file_required');

$file = $_FILES['file'];
if ($file['error'] !== UPLOAD_ERR_OK) fail('upload_error');
if ($file['size'] > MAX_UPLOAD_BYTES) fail('file_too_large');

$origName = $file['name'];
$ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));

// Voice notes recorded via MediaRecorder often arrive as webm/ogg with a generic
// name — still route them through the same audio pipeline.
$kind = ALLOWED_UPLOAD_EXT[$ext] ?? null;
if (!$kind) fail('file_type_not_allowed');

$safeBase = new_id('f_');
$storedName = $safeBase . '.' . $ext;
$dest = UPLOAD_DIR . '/' . $storedName;

if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0775, true);
if (!move_uploaded_file($file['tmp_name'], $dest)) fail('save_failed', 500);

json_out([
    'ok' => true,
    'attachment' => [
        'url' => UPLOAD_URL_BASE . '/' . $storedName,
        'name' => $origName,
        'kind' => $kind, // image | video | audio | file
        'size' => $file['size'],
    ],
]);
