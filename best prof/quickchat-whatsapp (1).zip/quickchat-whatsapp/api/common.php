<?php
/**
 * common.php — shared config, JSON storage helpers, and session bootstrap.
 * Every api/*.php file requires this first.
 */

// ---- Config -----------------------------------------------------------
define('DATA_DIR', __DIR__ . '/../data');
define('MSG_DIR', DATA_DIR . '/messages');
define('READ_DIR', DATA_DIR . '/read');
define('UPLOAD_DIR', __DIR__ . '/../uploads');
define('UPLOAD_URL_BASE', '../uploads'); // relative to index.html

define('SESSION_TTL_SECONDS', 60 * 60 * 12); // 12h sliding session
define('TYPING_TTL_SECONDS', 6);             // how long a "typing" flag stays valid
define('MAX_MESSAGE_LENGTH', 8000);
define('MAX_UPLOAD_BYTES', 15 * 1024 * 1024); // 15 MB

// Allowed upload extensions -> broad category used by the frontend to decide rendering
define('ALLOWED_UPLOAD_EXT', [
    'jpg' => 'image', 'jpeg' => 'image', 'png' => 'image', 'gif' => 'image', 'webp' => 'image',
    'mp4' => 'video', 'mov' => 'video', 'webm' => 'video',
    'mp3' => 'audio', 'wav' => 'audio', 'ogg' => 'audio', 'm4a' => 'audio', 'weba' => 'audio',
    'pdf' => 'file', 'doc' => 'file', 'docx' => 'file', 'xls' => 'file', 'xlsx' => 'file',
    'ppt' => 'file', 'pptx' => 'file', 'txt' => 'file', 'csv' => 'file', 'zip' => 'file',
]);

header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params(SESSION_TTL_SECONDS);
session_start();

// Sliding session expiry
if (isset($_SESSION['user_id']) && isset($_SESSION['last_active'])) {
    if (time() - $_SESSION['last_active'] > SESSION_TTL_SECONDS) {
        session_unset();
        session_destroy();
    }
}
$_SESSION['last_active'] = time();

// ---- Small utilities ----------------------------------------------------

function json_out($data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function fail(string $error, int $status = 400): void {
    json_out(['ok' => false, 'error' => $error], $status);
}

function require_login(): array {
    if (empty($_SESSION['user_id'])) {
        fail('not_authenticated', 401);
    }
    $user = find_user($_SESSION['user_id']);
    if (!$user) {
        fail('not_authenticated', 401);
    }
    return $user;
}

function body_json(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/** Read a JSON file safely, with a simple exclusive-lock-friendly retry. */
function read_json(string $path, $default = []) {
    if (!file_exists($path)) return $default;
    $fp = fopen($path, 'r');
    if (!$fp) return $default;
    flock($fp, LOCK_SH);
    $content = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    $data = json_decode($content, true);
    return $data === null ? $default : $data;
}

/** Write a JSON file atomically-ish with an exclusive lock. */
function write_json(string $path, $data): void {
    $dir = dirname($path);
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    $fp = fopen($path, 'c+');
    if (!$fp) return;
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
}

function users_path(): string { return DATA_DIR . '/users.json'; }
function chats_path(): string { return DATA_DIR . '/chats.json'; }
function typing_path(): string { return DATA_DIR . '/typing.json'; }
function messages_path(string $chatId): string { return MSG_DIR . '/' . preg_replace('/[^a-zA-Z0-9_-]/', '', $chatId) . '.json'; }
function read_state_path(string $chatId): string { return READ_DIR . '/' . preg_replace('/[^a-zA-Z0-9_-]/', '', $chatId) . '.json'; }

function all_users(): array { return read_json(users_path(), []); }
function find_user(string $id): ?array {
    foreach (all_users() as $u) if ($u['id'] === $id) return $u;
    return null;
}
function save_user(array $user): void {
    $users = all_users();
    $found = false;
    foreach ($users as &$u) {
        if ($u['id'] === $user['id']) { $u = $user; $found = true; break; }
    }
    unset($u);
    if (!$found) $users[] = $user;
    write_json(users_path(), $users);
}

function all_chats(): array { return read_json(chats_path(), []); }
function find_chat(string $id): ?array {
    foreach (all_chats() as $c) if ($c['id'] === $id) return $c;
    return null;
}
function save_chat(array $chat): void {
    $chats = all_chats();
    $found = false;
    foreach ($chats as &$c) {
        if ($c['id'] === $chat['id']) { $c = $chat; $found = true; break; }
    }
    unset($c);
    if (!$found) $chats[] = $chat;
    write_json(chats_path(), $chats);
}

/** Confirm the current session user is a member of the given chat, or fail(). */
function require_chat_membership(array $chat, array $user): void {
    if (!in_array($user['id'], $chat['members'], true)) {
        fail('forbidden', 403);
    }
}

function new_id(string $prefix = ''): string {
    return $prefix . bin2hex(random_bytes(8));
}

function initials(string $name): string {
    $parts = preg_split('/\s+/', trim($name));
    $out = '';
    foreach (array_slice($parts, 0, 2) as $p) {
        if ($p !== '') $out .= mb_strtoupper(mb_substr($p, 0, 1));
    }
    return $out === '' ? '?' : $out;
}

// A small fixed palette so avatar colors are stable-looking, keyed by name hash.
function avatar_color(string $seed): string {
    $palette = ['#25D366', '#128C7E', '#34B7F1', '#ED7A5D', '#9B59B6', '#F0932B', '#EB4D4B', '#22A6B3', '#6AB04C', '#EE5A6F'];
    $idx = abs(crc32($seed)) % count($palette);
    return $palette[$idx];
}
