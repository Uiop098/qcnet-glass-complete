<?php
require __DIR__ . '/common.php';

$user = require_login();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $chatId = trim((string)($_GET['chatId'] ?? ''));
    if ($chatId === '') fail('chatId_required');
    $chat = find_chat($chatId);
    if (!$chat) fail('chat_not_found', 404);
    require_chat_membership($chat, $user);

    $since = isset($_GET['since']) ? (int)$_GET['since'] : 0; // unix seconds; 0 = all
    $messages = read_json(messages_path($chatId), []);
    if ($since > 0) {
        $messages = array_values(array_filter($messages, fn($m) => $m['createdAt'] > $since));
    }

    // Who's currently typing in this chat (excluding me)
    $typingMap = read_json(typing_path(), []);
    $now = time();
    $typingUsers = [];
    foreach ($typingMap as $key => $ts) {
        if (strpos($key, $chatId . '::') === 0 && ($now - $ts) < TYPING_TTL_SECONDS) {
            $uid = substr($key, strlen($chatId) + 2);
            if ($uid !== $user['id']) {
                $u = find_user($uid);
                if ($u) $typingUsers[] = $u['name'];
            }
        }
    }

    json_out([
        'ok' => true,
        'messages' => $messages,
        'typing' => $typingUsers,
        'serverTime' => $now,
    ]);
}

if ($method === 'POST') {
    $body = body_json();
    $action = $body['action'] ?? 'send';
    $chatId = trim((string)($body['chatId'] ?? ''));
    if ($chatId === '') fail('chatId_required');
    $chat = find_chat($chatId);
    if (!$chat) fail('chat_not_found', 404);
    require_chat_membership($chat, $user);

    if ($action === 'send') {
        $type = $body['type'] ?? 'text';
        $text = trim((string)($body['text'] ?? ''));
        $attachment = $body['attachment'] ?? null; // {url, name, kind, size} from upload.php
        $replyTo = $body['replyTo'] ?? null; // message id being replied to

        if ($type === 'text' && $text === '') fail('text_required');
        if (mb_strlen($text) > MAX_MESSAGE_LENGTH) fail('text_too_long');

        $replySnippet = null;
        if ($replyTo) {
            foreach (read_json(messages_path($chatId), []) as $m) {
                if ($m['id'] === $replyTo) {
                    $replySnippet = [
                        'id' => $m['id'],
                        'senderName' => $m['senderName'],
                        'text' => $m['type'] === 'text' ? mb_substr($m['text'], 0, 120) : ('📎 ' . ($m['attachment']['name'] ?? 'Attachment')),
                    ];
                    break;
                }
            }
        }

        $message = [
            'id' => new_id('m_'),
            'chatId' => $chatId,
            'senderId' => $user['id'],
            'senderName' => $user['name'],
            'type' => $type, // text | image | video | audio | file
            'text' => $text,
            'attachment' => $attachment,
            'replyTo' => $replySnippet,
            'createdAt' => time(),
            'editedAt' => null,
        ];

        $messages = read_json(messages_path($chatId), []);
        $messages[] = $message;
        write_json(messages_path($chatId), $messages);

        // Clear the sender's own typing flag now that they've sent
        $typingMap = read_json(typing_path(), []);
        unset($typingMap[$chatId . '::' . $user['id']]);
        write_json(typing_path(), $typingMap);

        json_out(['ok' => true, 'message' => $message]);
    }

    if ($action === 'delete') {
        $messageId = trim((string)($body['messageId'] ?? ''));
        $messages = read_json(messages_path($chatId), []);
        $found = false;
        foreach ($messages as &$m) {
            if ($m['id'] === $messageId) {
                if ($m['senderId'] !== $user['id']) fail('forbidden', 403);
                $m['type'] = 'deleted';
                $m['text'] = '';
                $m['attachment'] = null;
                $found = true;
                break;
            }
        }
        unset($m);
        if (!$found) fail('message_not_found', 404);
        write_json(messages_path($chatId), $messages);
        json_out(['ok' => true]);
    }

    fail('unknown_action');
}

fail('method_not_allowed', 405);
