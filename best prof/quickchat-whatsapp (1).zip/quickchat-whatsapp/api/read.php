<?php
require __DIR__ . '/common.php';

$user = require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('method_not_allowed', 405);

$body = body_json();
$chatId = trim((string)($body['chatId'] ?? ''));
$lastReadId = trim((string)($body['lastReadId'] ?? ''));
if ($chatId === '' || $lastReadId === '') fail('chatId_and_lastReadId_required');

$chat = find_chat($chatId);
if (!$chat) fail('chat_not_found', 404);
require_chat_membership($chat, $user);

$state = read_json(read_state_path($chatId), []);
$state[$user['id']] = ['lastReadId' => $lastReadId, 'at' => time()];
write_json(read_state_path($chatId), $state);

json_out(['ok' => true]);
