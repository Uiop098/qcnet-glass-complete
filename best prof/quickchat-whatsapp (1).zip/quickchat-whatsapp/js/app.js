/* ===========================================================
   QuickChat — frontend application logic
   Polling-based sync against the PHP API in /api.
   =========================================================== */

const API = 'api';
const POLL_LIST_MS = 4000;
const POLL_MSG_MS = 2000;
const TYPING_DEBOUNCE_MS = 2500;

const state = {
  user: null,
  chats: [],
  currentChat: null,
  messages: [],
  contacts: [],
  replyTarget: null,
  lastPollAt: 0,
  typingTimer: null,
  iAmTyping: false,
  mediaRecorder: null,
  recordedChunks: [],
  recordStart: 0,
  recordTimerInterval: null,
};

// ---------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function show(el) { el.classList.remove('hidden'); }
function hide(el) { el.classList.add('hidden'); }

function toast(msg, ms = 2200) {
  const t = $('#toast');
  t.textContent = msg;
  show(t);
  clearTimeout(toast._h);
  toast._h = setTimeout(() => hide(t), ms);
}

function escapeHtml(str) {
  return (str || '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function linkify(text) {
  const escaped = escapeHtml(text);
  return escaped.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
}

function fmtTime(ts) {
  const d = new Date(ts * 1000);
  let h = d.getHours();
  const m = d.getMinutes().toString().padStart(2, '0');
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12; if (h === 0) h = 12;
  return `${h}:${m} ${ampm}`;
}

function fmtListTime(ts) {
  const d = new Date(ts * 1000);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  if (sameDay) return fmtTime(ts);
  const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  const diffDays = Math.floor((now - d) / 86400000);
  if (diffDays < 7) return d.toLocaleDateString(undefined, { weekday: 'short' });
  return d.toLocaleDateString(undefined, { month: 'numeric', day: 'numeric', year: '2-digit' });
}

function fmtDateSeparator(ts) {
  const d = new Date(ts * 1000);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today';
  const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' });
}

function fmtBytes(n) {
  if (!n) return '';
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(0) + ' KB';
  return (n / (1024 * 1024)).toFixed(1) + ' MB';
}

async function api(path, opts = {}) {
  const res = await fetch(`${API}/${path}`, {
    credentials: 'same-origin',
    headers: opts.body instanceof FormData ? {} : { 'Content-Type': 'application/json' },
    ...opts,
  });
  let data;
  try { data = await res.json(); } catch (e) { data = { ok: false, error: 'bad_response' }; }
  if (!res.ok && !data.error) data.error = 'request_failed';
  return data;
}

function apiGet(path) { return api(path, { method: 'GET' }); }
function apiPost(path, body) { return api(path, { method: 'POST', body: JSON.stringify(body) }); }

// ---------------------------------------------------------------
// Boot / auth
// ---------------------------------------------------------------
async function boot() {
  applyStoredDarkMode();
  const res = await apiGet('auth.php?action=me');
  if (res.ok && res.user) {
    state.user = res.user;
    enterApp();
  } else {
    show($('#loginScreen'));
  }
  bindEvents();
}

async function login(name) {
  const errEl = $('#loginError');
  errEl.textContent = '';
  const res = await apiPost('auth.php', { action: 'login', name });
  if (!res.ok) {
    errEl.textContent = res.error === 'name_required' ? 'Please enter a name.' : 'Something went wrong — try again.';
    return;
  }
  state.user = res.user;
  hide($('#loginScreen'));
  enterApp();
}

function enterApp() {
  show($('#app'));
  $('#myName').textContent = state.user.name;
  setAvatar($('#myAvatar'), state.user);
  goToChatList();
  refreshChatList();
  setInterval(refreshChatList, POLL_LIST_MS);
}

async function logout() {
  await apiPost('auth.php', { action: 'logout' });
  location.reload();
}

// ---------------------------------------------------------------
// Navigation between screens
// ---------------------------------------------------------------
function goToChatList() {
  hide($('#chatScreen')); hide($('#newChatScreen')); hide($('#settingsScreen'));
  show($('#chatListScreen'));
  state.currentChat = null;
}
function goToNewChat() {
  hide($('#chatListScreen'));
  show($('#newChatScreen'));
  loadContacts();
}
function goToSettings() {
  hide($('#chatListScreen'));
  show($('#settingsScreen'));
}
async function openChat(chatSummary) {
  state.currentChat = chatSummary;
  hide($('#chatListScreen')); hide($('#newChatScreen'));
  show($('#chatScreen'));
  renderChatHeader(chatSummary);
  state.messages = [];
  $('#messagesList').innerHTML = '';
  await loadMessages(true);
  scrollToBottom();
}

// ---------------------------------------------------------------
// Avatars
// ---------------------------------------------------------------
function setAvatar(el, entity) {
  el.style.background = entity.color || '#999';
  el.textContent = entity.initials || '?';
  el.classList.toggle('group', entity.type === 'group');
}

// ---------------------------------------------------------------
// Chat list
// ---------------------------------------------------------------
async function refreshChatList() {
  if (!state.user) return;
  const res = await apiGet('chats.php?action=list');
  if (!res.ok) return;
  state.chats = res.chats;
  renderChatList();
}

function renderChatList() {
  const listEl = $('#chatList');
  const query = ($('#chatSearch').value || '').toLowerCase().trim();
  const chats = state.chats.filter((c) => c.title.toLowerCase().includes(query));

  if (chats.length === 0) {
    listEl.innerHTML = '';
    show($('#chatListEmpty'));
    return;
  }
  hide($('#chatListEmpty'));

  listEl.innerHTML = chats.map((c) => {
    const preview = messagePreview(c.lastMessage);
    const isMine = c.lastMessage && c.lastMessage.senderId === state.user.id;
    const ticks = isMine ? ticksHtml(c.lastMessage, true) : '';
    return `
      <div class="chat-row" data-chat-id="${c.id}">
        <div class="chat-row-inner">
          <div class="avatar ${c.type === 'group' ? 'group' : ''}" style="background:${c.color}">${escapeHtml(c.initials)}</div>
          <div class="chat-row-main">
            <div class="chat-row-top">
              <span class="chat-row-name">${escapeHtml(c.title)}</span>
              <span class="chat-row-time">${c.lastMessage ? fmtListTime(c.lastMessage.createdAt) : ''}</span>
            </div>
            <div class="chat-row-bottom">
              <span class="chat-row-preview">${ticks}${escapeHtml(preview)}</span>
              ${c.unreadCount > 0 ? `<span class="unread-badge">${c.unreadCount > 99 ? '99+' : c.unreadCount}</span>` : ''}
            </div>
          </div>
        </div>
      </div>`;
  }).join('');

  $$('#chatList .chat-row').forEach((row) => {
    row.addEventListener('click', () => {
      const chat = state.chats.find((c) => c.id === row.dataset.chatId);
      if (chat) openChat(chat);
    });
  });
}

function messagePreview(msg) {
  if (!msg) return 'Say hello 👋';
  if (msg.type === 'text') return msg.text;
  if (msg.type === 'image') return '📷 Photo';
  if (msg.type === 'video') return '🎥 Video';
  if (msg.type === 'audio') return '🎤 Voice message';
  if (msg.type === 'deleted') return 'This message was deleted';
  return '📎 Attachment';
}

function ticksHtml(msg, wasRead) {
  if (!msg) return '';
  const cls = wasRead ? 'tick-read' : '';
  return `<span class="preview-ticks ${cls}">✓✓ </span>`;
}

// ---------------------------------------------------------------
// Contacts / new chat
// ---------------------------------------------------------------
async function loadContacts() {
  const res = await apiGet('chats.php?action=contacts');
  if (!res.ok) return;
  state.contacts = res.contacts;
  renderContacts();
}

function renderContacts() {
  const listEl = $('#contactList');
  const query = ($('#contactSearch').value || '').toLowerCase().trim();
  const contacts = state.contacts.filter((c) => c.name.toLowerCase().includes(query));

  if (contacts.length === 0) {
    listEl.innerHTML = '';
    show($('#contactListEmpty'));
    return;
  }
  hide($('#contactListEmpty'));

  listEl.innerHTML = contacts.map((c) => `
    <div class="contact-row" data-user-id="${c.id}">
      <div class="avatar" style="background:${c.color}">${escapeHtml(c.initials)}</div>
      <div class="contact-name">${escapeHtml(c.name)}</div>
    </div>`).join('');

  $$('#contactList .contact-row').forEach((row) => {
    row.addEventListener('click', async () => {
      const res = await apiPost('chats.php', { action: 'create_direct', userId: row.dataset.userId });
      if (!res.ok) { toast('Could not start chat'); return; }
      await refreshChatList();
      openChat(res.chat);
    });
  });
}

// ---------------------------------------------------------------
// Chat header
// ---------------------------------------------------------------
function renderChatHeader(chat) {
  $('#chatHeaderName').textContent = chat.title;
  setAvatar($('#chatAvatar'), chat);
  const statusEl = $('#chatHeaderStatus');
  if (chat.type === 'group') {
    statusEl.textContent = '';
  } else if (chat.online) {
    statusEl.textContent = 'online';
  } else if (chat.lastSeen) {
    statusEl.textContent = `last seen ${fmtListTime(chat.lastSeen)} ${fmtTime(chat.lastSeen)}`;
  } else {
    statusEl.textContent = '';
  }
}

// ---------------------------------------------------------------
// Messages: load, render, poll
// ---------------------------------------------------------------
async function loadMessages(initial = false) {
  if (!state.currentChat) return;
  const res = await apiGet(`messages.php?chatId=${encodeURIComponent(state.currentChat.id)}&since=0`);
  if (!res.ok) return;
  state.messages = res.messages;
  renderMessages();
  updateTypingRow(res.typing);
  markLatestAsRead();
}

async function pollMessages() {
  if (!state.currentChat) return;
  const chatId = state.currentChat.id;
  const res = await apiGet(`messages.php?chatId=${encodeURIComponent(chatId)}&since=0`);
  if (!res.ok || state.currentChat?.id !== chatId) return;

  const grew = res.messages.length !== state.messages.length;
  const lastChanged = JSON.stringify(res.messages[res.messages.length - 1]) !== JSON.stringify(state.messages[state.messages.length - 1]);
  state.messages = res.messages;
  if (grew || lastChanged) {
    const wasNearBottom = isNearBottom();
    renderMessages();
    if (wasNearBottom) scrollToBottom();
    markLatestAsRead();
  }
  updateTypingRow(res.typing);
}
setInterval(pollMessages, POLL_MSG_MS);

function isNearBottom() {
  const wrap = $('#messagesWrap');
  return wrap.scrollHeight - wrap.scrollTop - wrap.clientHeight < 150;
}
function scrollToBottom() {
  const wrap = $('#messagesWrap');
  wrap.scrollTop = wrap.scrollHeight;
}

function updateTypingRow(typingNames) {
  const row = $('#typingRow');
  const statusEl = $('#chatHeaderStatus');
  if (typingNames && typingNames.length > 0) {
    show(row);
    if (state.currentChat && state.currentChat.type === 'direct') {
      statusEl.textContent = 'typing…';
    }
    scrollIfNearBottom();
  } else {
    hide(row);
    if (state.currentChat) renderChatHeader(state.currentChat);
  }
}
function scrollIfNearBottom() { if (isNearBottom()) scrollToBottom(); }

function renderMessages() {
  const listEl = $('#messagesList');
  listEl.innerHTML = '';
  let lastDate = null;
  let lastSenderId = null;

  state.messages.forEach((m) => {
    const dateStr = fmtDateSeparator(m.createdAt);
    if (dateStr !== lastDate) {
      const sep = document.createElement('div');
      sep.className = 'date-sep';
      sep.textContent = dateStr;
      listEl.appendChild(sep);
      lastDate = dateStr;
      lastSenderId = null;
    }

    const isMine = m.senderId === state.user.id;
    const grouped = m.senderId === lastSenderId;
    lastSenderId = m.senderId;

    const row = document.createElement('div');
    row.className = `msg-row ${isMine ? 'sent' : 'received'} ${grouped ? 'grouped' : ''}`;
    row.dataset.messageId = m.id;

    const bubble = document.createElement('div');
    bubble.className = `bubble ${isMine ? 'bubble-sent' : 'bubble-received'}`;
    bubble.innerHTML = bubbleInnerHtml(m, isMine, grouped);
    row.appendChild(bubble);

    if (m.type !== 'deleted') {
      const actions = document.createElement('div');
      actions.className = 'msg-actions';
      actions.innerHTML = `<button data-act="reply" title="Reply">↩️</button>${isMine ? '<button data-act="delete" title="Delete">🗑️</button>' : ''}`;
      actions.querySelectorAll('button').forEach((btn) => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (btn.dataset.act === 'reply') startReply(m);
          if (btn.dataset.act === 'delete') deleteMessage(m.id);
        });
      });
      row.appendChild(actions);
    }

    listEl.appendChild(row);
  });
}

function bubbleInnerHtml(m, isMine, grouped) {
  let html = '';
  if (!isMine && state.currentChat?.type === 'group' && !grouped) {
    html += `<div class="bubble-sender">${escapeHtml(m.senderName)}</div>`;
  }
  if (m.replyTo) {
    html += `<div class="bubble-reply">
      <div class="bubble-reply-name">${escapeHtml(m.replyTo.senderName)}</div>
      <div class="bubble-reply-text">${escapeHtml(m.replyTo.text)}</div>
    </div>`;
  }

  if (m.type === 'deleted') {
    html += `<div class="bubble-deleted">🚫 This message was deleted</div>`;
    return html;
  }

  if (m.type === 'image' && m.attachment) {
    html += `<div class="bubble-media"><img src="${escapeHtml(m.attachment.url)}" alt="photo" loading="lazy"></div>`;
  } else if (m.type === 'video' && m.attachment) {
    html += `<div class="bubble-media"><video src="${escapeHtml(m.attachment.url)}" controls></video></div>`;
  } else if (m.type === 'audio' && m.attachment) {
    html += `<div class="bubble-audio">🎤<audio src="${escapeHtml(m.attachment.url)}" controls></audio></div>`;
  } else if (m.type === 'file' && m.attachment) {
    html += `<a class="bubble-file" href="${escapeHtml(m.attachment.url)}" download="${escapeHtml(m.attachment.name)}" target="_blank">
      <div class="bubble-file-icon">📄</div>
      <div>
        <div class="bubble-file-name">${escapeHtml(m.attachment.name)}</div>
        <div class="bubble-file-size">${fmtBytes(m.attachment.size)}</div>
      </div>
    </a>`;
  }

  if (m.text) {
    html += `<span class="bubble-text">${linkify(m.text)}</span>`;
  }

  html += `<span class="bubble-meta">${m.editedAt ? 'edited · ' : ''}${fmtTime(m.createdAt)}${isMine ? ` <span class="bubble-ticks">${messageTicks(m)}</span>` : ''}</span>`;
  return html;
}

function messageTicks() {
  // Simplified single/double-tick model: always shows delivered (double tick).
  // Blue read ticks are applied client-side once the peer's read state catches up
  // (see markLatestAsRead / refreshChatList unread counts for the underlying data).
  return '✓✓';
}

// ---------------------------------------------------------------
// Read receipts
// ---------------------------------------------------------------
async function markLatestAsRead() {
  if (!state.currentChat || state.messages.length === 0) return;
  const last = state.messages[state.messages.length - 1];
  await apiPost('read.php', { chatId: state.currentChat.id, lastReadId: last.id });
}

// ---------------------------------------------------------------
// Sending messages
// ---------------------------------------------------------------
async function sendText() {
  const input = $('#messageInput');
  const text = input.value.trim();
  if (!text || !state.currentChat) return;

  input.value = '';
  autoGrowTextarea(input);
  setTypingIndicatorSending(false);

  const body = { chatId: state.currentChat.id, type: 'text', text };
  if (state.replyTarget) body.replyTo = state.replyTarget.id;
  clearReply();

  const res = await apiPost('messages.php', body);
  if (!res.ok) { toast('Message failed to send'); return; }
  state.messages.push(res.message);
  renderMessages();
  scrollToBottom();
  refreshChatList();
}

async function sendAttachment(file, kindHint) {
  if (!state.currentChat) return;
  const fd = new FormData();
  fd.append('file', file, file.name);
  const upRes = await api('upload.php', { method: 'POST', body: fd });
  if (!upRes.ok) { toast(upRes.error === 'file_too_large' ? 'File is too large' : 'Upload failed'); return; }

  const type = kindHint || upRes.attachment.kind;
  const body = { chatId: state.currentChat.id, type, text: '', attachment: upRes.attachment };
  if (state.replyTarget) body.replyTo = state.replyTarget.id;
  clearReply();

  const res = await apiPost('messages.php', body);
  if (!res.ok) { toast('Message failed to send'); return; }
  state.messages.push(res.message);
  renderMessages();
  scrollToBottom();
  refreshChatList();
}

async function deleteMessage(messageId) {
  if (!state.currentChat) return;
  if (!confirm('Delete this message?')) return;
  const res = await apiPost('messages.php', { action: 'delete', chatId: state.currentChat.id, messageId });
  if (!res.ok) { toast('Could not delete'); return; }
  await loadMessages();
  refreshChatList();
}

// ---------------------------------------------------------------
// Reply UI
// ---------------------------------------------------------------
function startReply(message) {
  state.replyTarget = message;
  $('#replyBarName').textContent = message.senderId === state.user.id ? 'You' : message.senderName;
  $('#replyBarText').textContent = message.type === 'text' ? message.text : `📎 ${message.attachment?.name || 'Attachment'}`;
  show($('#replyBar'));
  $('#messageInput').focus();
}
function clearReply() {
  state.replyTarget = null;
  hide($('#replyBar'));
}

// ---------------------------------------------------------------
// Typing indicator (outgoing)
// ---------------------------------------------------------------
function setTypingIndicatorSending(isTyping) {
  if (!state.currentChat) return;
  if (isTyping === state.iAmTyping) {
    if (isTyping) scheduleTypingStop();
    return;
  }
  state.iAmTyping = isTyping;
  apiPost('typing.php', { chatId: state.currentChat.id, isTyping });
  if (isTyping) scheduleTypingStop();
}
function scheduleTypingStop() {
  clearTimeout(state.typingTimer);
  state.typingTimer = setTimeout(() => setTypingIndicatorSending(false), TYPING_DEBOUNCE_MS);
}

// ---------------------------------------------------------------
// Voice recording
// ---------------------------------------------------------------
async function startRecording() {
  if (!navigator.mediaDevices?.getUserMedia) { toast('Microphone not supported in this browser'); return; }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    state.recordedChunks = [];
    const mr = new MediaRecorder(stream);
    state.mediaRecorder = mr;
    mr.ondataavailable = (e) => { if (e.data.size > 0) state.recordedChunks.push(e.data); };
    mr.onstop = () => { stream.getTracks().forEach((t) => t.stop()); };
    mr.start();
    state.recordStart = Date.now();
    show($('#recordBar'));
    hide($('.composer'));
    $('.composer').style.display = 'none';
    state.recordTimerInterval = setInterval(updateRecordTimer, 250);
  } catch (e) {
    toast('Microphone permission denied');
  }
}
function updateRecordTimer() {
  const secs = Math.floor((Date.now() - state.recordStart) / 1000);
  const m = Math.floor(secs / 60);
  const s = (secs % 60).toString().padStart(2, '0');
  $('#recordTimer').textContent = `${m}:${s}`;
  if (secs >= 300) stopRecording(true); // 5 min safety cap
}
function stopRecording(send) {
  const mr = state.mediaRecorder;
  if (!mr) return;
  clearInterval(state.recordTimerInterval);
  hide($('#recordBar'));
  $('.composer').style.display = 'flex';

  mr.onstop = () => {
    mr.stream.getTracks().forEach((t) => t.stop());
    if (send && state.recordedChunks.length) {
      const blob = new Blob(state.recordedChunks, { type: mr.mimeType || 'audio/webm' });
      const ext = (mr.mimeType || '').includes('mp4') ? 'm4a' : 'webm';
      const file = new File([blob], `voice-message.${ext}`, { type: blob.type });
      sendAttachment(file, 'audio');
    }
  };
  mr.stop();
  state.mediaRecorder = null;
}

// ---------------------------------------------------------------
// Dark mode
// ---------------------------------------------------------------
function applyStoredDarkMode() {
  const on = localStorage.getItem('qc_dark') === '1';
  document.body.classList.toggle('dark', on);
  $('#darkSwitch')?.classList.toggle('on', on);
}
function toggleDarkMode() {
  const on = !document.body.classList.contains('dark');
  document.body.classList.toggle('dark', on);
  $('#darkSwitch').classList.toggle('on', on);
  localStorage.setItem('qc_dark', on ? '1' : '0');
}

// ---------------------------------------------------------------
// Textarea auto-grow
// ---------------------------------------------------------------
function autoGrowTextarea(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 100) + 'px';
}

// ---------------------------------------------------------------
// Event bindings
// ---------------------------------------------------------------
function bindEvents() {
  $('#loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = $('#loginName').value.trim();
    if (name) login(name);
  });

  // Chat list
  $('#newChatBtn').addEventListener('click', goToNewChat);
  $('#closeNewChat').addEventListener('click', goToChatList);
  $('#chatSearch').addEventListener('input', renderChatList);
  $('#contactSearch').addEventListener('input', renderContacts);
  $('#profileTabBtn').addEventListener('click', goToSettings);

  // Settings
  $('#darkModeToggle').addEventListener('click', toggleDarkMode);
  $('#logoutBtn').addEventListener('click', () => { if (confirm('Log out?')) logout(); });
  $$('.tab-bar .tab-item')[0].addEventListener('click', goToChatList);

  // Chat screen
  $('#backBtn').addEventListener('click', goToChatList);
  $('#cancelReply').addEventListener('click', clearReply);

  const input = $('#messageInput');
  input.addEventListener('input', () => {
    autoGrowTextarea(input);
    updateSendButtonMode();
    setTypingIndicatorSending(input.value.trim().length > 0);
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendText();
    }
  });

  $('#micBtn').addEventListener('click', () => {
    const input = $('#messageInput');
    if (input.value.trim()) {
      sendText();
    } else {
      startRecording();
    }
  });
  $('#stopRecord').addEventListener('click', () => stopRecording(true));
  $('#cancelRecord').addEventListener('click', () => stopRecording(false));

  $('#attachBtn').addEventListener('click', () => $('#fileInput').click());
  $('#fileInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) sendAttachment(file);
    e.target.value = '';
  });

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && state.currentChat) pollMessages();
  });
}

function updateSendButtonMode() {
  const hasText = $('#messageInput').value.trim().length > 0;
  const btn = $('#micBtn');
  btn.classList.toggle('send-mode', hasText);
  btn.classList.toggle('mic-mode', !hasText);
  btn.innerHTML = hasText
    ? '<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M3 20l18-8L3 4v6l12 2-12 2z"/></svg>'
    : '<svg viewBox="0 0 24 24" width="22" height="22"><path fill="currentColor" d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3Zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V21h2v-2.08A7 7 0 0 0 19 12Z"/></svg>';
}

boot();
