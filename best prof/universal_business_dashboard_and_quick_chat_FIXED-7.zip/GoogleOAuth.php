<?php
declare(strict_types=1);

/**
 * Raw Google OAuth 2.0 client -- no SDK, no Composer dependency, no JWT
 * library. Copy this single file into any PHP project (needs the curl
 * and json extensions, which ship with PHP by default).
 *
 * ---- Google Cloud Console setup (one-time) ----
 * 1. https://console.cloud.google.com/ -> APIs & Services -> Credentials
 * 2. Create Credentials -> OAuth client ID -> Application type: Web application
 * 3. Under "Authorized redirect URIs" add the exact callback URL you'll
 *    pass as $redirectUri below (e.g. https://yourdomain.com/google-callback.php)
 * 4. You may need to configure the "OAuth consent screen" first if this is
 *    the project's first OAuth client -- app name, support email, and
 *    (for testing) your own Google account under "Test users".
 * 5. Copy the generated Client ID and Client Secret.
 *
 * ---- Usage ----
 *
 *   $google = new GoogleOAuth($clientId, $clientSecret, $redirectUri);
 *
 *   // Step 1 -- redirect the user to Google:
 *   $state = bin2hex(random_bytes(16));
 *   $_SESSION['oauth_state'] = $state;
 *   header('Location: ' . $google->buildAuthUrl($state));
 *   exit;
 *
 *   // Step 2 -- on your callback page:
 *   if (($_GET['state'] ?? '') !== ($_SESSION['oauth_state'] ?? '')) {
 *       throw new RuntimeException('State mismatch -- possible CSRF.');
 *   }
 *   $profile = $google->handleCallback($_GET['code']);
 *   // $profile = ['sub' => '...', 'email' => '...', 'email_verified' => true,
 *   //             'name' => '...', 'picture' => '...']
 *   // $profile['sub'] is Google's permanent, unique user ID -- use this,
 *   // not the email, as your primary lookup key (emails can change).
 */
final class GoogleOAuth
{
    private string $clientId;
    private string $clientSecret;
    private string $redirectUri;

    public function __construct(string $clientId, string $clientSecret, string $redirectUri)
    {
        $this->clientId = $clientId;
        $this->clientSecret = $clientSecret;
        $this->redirectUri = $redirectUri;
    }

    /**
     * @param string[] $scopes
     */
    public function buildAuthUrl(string $state, array $scopes = ['openid', 'email', 'profile']): string
    {
        $params = [
            'client_id' => $this->clientId,
            'redirect_uri' => $this->redirectUri,
            'response_type' => 'code',
            'scope' => implode(' ', $scopes),
            'state' => $state,
            'access_type' => 'online',
            'prompt' => 'select_account',
        ];

        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params);
    }

    /**
     * Exchanges an authorization code for an access token, then fetches the
     * profile from Google's userinfo endpoint. This call happens server-to-
     * server over HTTPS using your client secret, so there's no need to
     * manually verify a JWT signature -- Google is authenticating the
     * request to itself.
     *
     * @return array{sub:string,email:string,email_verified:bool,name:string,picture:?string}
     * @throws RuntimeException on any failure -- always catch this at the call site.
     */
    public function handleCallback(string $code): array
    {
        $token = $this->postJson('https://oauth2.googleapis.com/token', [
            'code' => $code,
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'redirect_uri' => $this->redirectUri,
            'grant_type' => 'authorization_code',
        ]);

        if (empty($token['access_token'])) {
            throw new RuntimeException('Google did not return an access token.');
        }

        $profile = $this->getJson('https://www.googleapis.com/oauth2/v3/userinfo', (string) $token['access_token']);

        if (empty($profile['sub']) || empty($profile['email'])) {
            throw new RuntimeException('Google did not return a usable profile.');
        }

        return [
            'sub' => (string) $profile['sub'],
            'email' => (string) $profile['email'],
            'email_verified' => (bool) ($profile['email_verified'] ?? false),
            'name' => (string) ($profile['name'] ?? ''),
            'picture' => isset($profile['picture']) ? (string) $profile['picture'] : null,
        ];
    }

    /**
     * @param array<string,string> $fields
     * @return array<string,mixed>
     */
    private function postJson(string $url, array $fields): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        return $this->finish($ch);
    }

    /**
     * @return array<string,mixed>
     */
    private function getJson(string $url, string $bearerToken): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER => ['Accept: application/json', 'Authorization: Bearer ' . $bearerToken],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        return $this->finish($ch);
    }

    /**
     * @return array<string,mixed>
     */
    private function finish($ch): array
    {
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false) {
            throw new RuntimeException('Google request failed: ' . $error);
        }

        $data = json_decode((string) $response, true);

        if (!is_array($data) || $status >= 400) {
            throw new RuntimeException('Google returned an error response (HTTP ' . $status . ').');
        }

        return $data;
    }
}
