<?php
// dash_google_callback.php — handles Google's redirect back after
// dash_google_login.php. Looks up an EXISTING account by Google's unique
// subject ID (or, on first use, by a matching verified email) and logs
// them in. Deliberately does NOT create brand-new admin/tenant or client
// accounts on the fly — this project's account model only creates admin
// accounts via the paid portal purchase (payment_api.php) and client
// accounts via an admin-issued invite token (dash_auth.php's
// create_pending/complete_setup). Google sign-in is a login *method* for
// an account that already exists through one of those paths, not a third
// way to create one — otherwise anyone with a Google account could
// self-provision a business or client account for free.
require_once 'dash_firewall.php';
require_once 'dash_crypto.php';
require_once 'dash_audit.php';
require_once 'dash_login_helpers.php';
require_once 'google_config.php';
require_once 'GoogleOAuth.php';
require_once 'dash_2fa.php';

function google_fail($reason, $role) {
    error_log('[dash_google_callback] ' . $reason);
    header('Location: dash_login.html?google_error=1&role=' . urlencode($role));
    exit;
}

$state = $_GET['state'] ?? ''; $code = $_GET['code'] ?? '';
$role = $_SESSION['dash_oauth_role'] ?? 'user';

if (!rate_limit_allow('google_callback', get_client_ip(), 15, 600)) {
    http_response_code(429); google_fail('rate limited', $role);
}
if ($state === '' || $code === '' || $state !== ($_SESSION['dash_oauth_state'] ?? '')) {
    google_fail('state mismatch or missing code', $role);
}
unset($_SESSION['dash_oauth_state'], $_SESSION['dash_oauth_role']);

$google = new GoogleOAuth(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI);
try {
    $profile = $google->handleCallback($code);
} catch (Throwable $e) {
    google_fail('token exchange failed: ' . $e->getMessage(), $role);
}
if (!$profile['email_verified']) google_fail('Google email not verified for ' . $profile['email'], $role);

$email = strtolower(trim($profile['email']));

// Finds [$file, $store, $username, $dir, $tenant_id] for an existing
// account matching this Google sub or (failing that) this verified email,
// searching the given account type only.
function find_google_account($role, $sub, $email) {
    if ($role === 'admin') {
        $master_file = __DIR__ . '/data_dash/master.json';
        $masters = get_secure_table($master_file);
        foreach ($masters as $u => $acct) {
            if (($acct['google_sub'] ?? '') === $sub || strtolower($acct['email'] ?? '___') === $email) return [$master_file, $masters, $u, __DIR__ . '/data_dash', 'main'];
        }
        $tenants_file = __DIR__ . '/data_dash/tenants.json';
        $tenants = get_secure_table($tenants_file);
        foreach ($tenants as $u => $acct) {
            if (($acct['google_sub'] ?? '') === $sub || strtolower($acct['email'] ?? '___') === $email) {
                $tid = $acct['tenant_id']; $tdir = ($tid === 'main') ? __DIR__ . '/data_dash' : __DIR__ . '/data_dash/' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $tid);
                return [$tenants_file, $tenants, $u, $tdir, $tid];
            }
        }
        return null;
    }
    $all_dirs = array_merge([__DIR__ . '/data_dash'], glob(__DIR__ . '/data_dash/tenant_*', GLOB_ONLYDIR));
    foreach ($all_dirs as $dir) {
        $users_file = $dir . '/users.json'; $users = get_secure_table($users_file);
        foreach ($users as $u => $acct) {
            if (($acct['google_sub'] ?? '') === $sub || strtolower($acct['email'] ?? '___') === $email) {
                $tid = basename($dir); if ($tid === 'data_dash') $tid = 'main';
                return [$users_file, $users, $u, $dir, $tid];
            }
        }
    }
    return null;
}

$match = find_google_account($role, $profile['sub'], $email);

if (!$match) {
    // No existing account to log into. Point them at the right next step
    // instead of silently creating one for free.
    $hint = $role === 'admin' ? 'buy_portal' : 'need_invite';
    header('Location: dash_login.html?google_error=no_account&hint=' . $hint . '&role=' . urlencode($role));
    exit;
}

list($file, $store, $username, $dir, $tenant_id) = $match;
if (($store[$username]['status'] ?? 'active') === 'deactivated') google_fail('account deactivated: ' . $username, $role);

// Link (or refresh) Google identity + pull basic profile info (name,
// picture) for display — first successful Google login auto-links since
// Google has already verified the email address.
$wasLinked = !empty($store[$username]['google_sub']);
$store[$username]['google_sub'] = $profile['sub'];
$store[$username]['google_name'] = $profile['name'];
$store[$username]['google_picture'] = $profile['picture'];
if (empty($store[$username]['email'])) $store[$username]['email'] = $profile['email']; // fill in if it was blank
save_secure_table($file, $store);
if (!$wasLinked) log_activity($dir, $username, 'google_linked', 'Linked Google account (' . $profile['email'] . ').');

if (!empty($store[$username]['twofa_enabled'])) {
    $challenge = start_2fa_challenge($role, $username, $dir, $tenant_id, $store[$username]['twofa_secret'], $store[$username]['twofa_recovery_codes'] ?? []);
    header('Location: dash_login.html?google_2fa=1&pending_token=' . urlencode($challenge['pending_token']) . '&role=' . urlencode($role));
    exit;
}

finalize_dash_login($role, $username, $dir, $tenant_id);
header('Location: ' . ($role === 'admin' ? 'dash_admin.html' : 'dash_user.html'));
exit;
?>
