<?php
// dash_google_login.php — starts the "Sign in with Google" flow for either
// the admin or user login tab. Redirects to Google; dash_google_callback.php
// handles the return trip.
require_once 'dash_firewall.php';

$role = ($_GET['role'] ?? 'user') === 'admin' ? 'admin' : 'user';

if (!rate_limit_allow('google_login_start', get_client_ip(), 15, 600)) {
    http_response_code(429); die('Too many attempts. Please wait a few minutes and try again.');
}

if (!file_exists(__DIR__ . '/google_config.php')) { http_response_code(500); die('Google sign-in is not configured yet.'); }
require_once 'google_config.php';
require_once 'GoogleOAuth.php';

if (GOOGLE_CLIENT_ID === 'REPLACE_ME.apps.googleusercontent.com') {
    http_response_code(500);
    die('Google sign-in is not configured yet — set GOOGLE_CLIENT_ID/SECRET in google_config.php.');
}

$state = bin2hex(random_bytes(16));
$_SESSION['dash_oauth_state'] = $state;
$_SESSION['dash_oauth_role'] = $role;

$google = new GoogleOAuth(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI);
header('Location: ' . $google->buildAuthUrl($state));
exit;
?>
