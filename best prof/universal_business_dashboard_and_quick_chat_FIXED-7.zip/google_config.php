<?php
// google_config.php — from Google Cloud Console -> APIs & Services ->
// Credentials -> Create Credentials -> OAuth client ID -> Web application.
// Under "Authorized redirect URIs" add the exact URL below (your real
// domain + /dash_google_callback.php). You may need to configure the
// "OAuth consent screen" first if this is the project's first OAuth client.
define('GOOGLE_CLIENT_ID', 'REPLACE_ME.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', 'REPLACE_ME');
define('GOOGLE_REDIRECT_URI', 'https://REPLACE_ME.example.com/dash_google_callback.php');
?>
