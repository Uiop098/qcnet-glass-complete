// glass-app.js — shared logic for every page: session storage, API
// calls, and the client-side encryption helpers. Loaded alongside (not
// instead of) glass-theme.js on every page.

const API = {
  auth: 'auth.php', api: 'api.php', rooms: 'rooms.php', admin: 'admin.php',
  kick: 'kick.php', mute: 'mute.php', react: 'react.php', typing: 'typing.php',
  read: 'read.php', edit: 'edit.php', theme: 'theme.php', wallpaperUpload: 'wallpaper_upload.php',
  upload: 'upload.php', download: 'download.php', linkPreview: 'linkpreview.php',
  poll: 'poll.php', sticker: 'sticker.php', gif: 'gif.php', translate: 'translate.php',
  search: 'search.php', export: 'export.php', schedule: 'schedule.php', report: 'report.php',
  clearMine: 'clear_mine.php', dashboard: 'dashboard.php', backup: 'backup.php',
};

// ---------------- Session (per-tab, cleared on logout) ----------------
function getSession() {
  try { return JSON.parse(sessionStorage.getItem('qc_session')); } catch (e) { return null; }
}
function setSession(s) { sessionStorage.setItem('qc_session', JSON.stringify(s)); }
function clearSession() {
  const s = getSession();
  if (s && s.room) sessionStorage.removeItem('qc_enckey_' + s.room);
  sessionStorage.removeItem('qc_session');
}
function requireSession(redirectTo) {
  const s = getSession();
  if (!s || !s.token) { window.location.href = redirectTo || 'login.html'; return null; }
  return s;
}

// Super "master" token, held only between login.html -> rooms.html/create-room.html.
function getMasterToken() {
  return { token: sessionStorage.getItem('qc_master_token'), name: sessionStorage.getItem('qc_master_name') || '' };
}
function setMasterToken(token, defaultName) {
  sessionStorage.setItem('qc_master_token', token);
  sessionStorage.setItem('qc_master_name', defaultName || '');
}
function clearMasterToken() {
  sessionStorage.removeItem('qc_master_token');
  sessionStorage.removeItem('qc_master_name');
}

// "Remember me" — long-lived, survives browser restarts (localStorage).
function getRemember() {
  try { return JSON.parse(localStorage.getItem('qc_remember')); } catch (e) { return null; }
}
function setRemember(rememberToken) {
  if (!rememberToken) return;
  localStorage.setItem('qc_remember', JSON.stringify({ rememberToken }));
}
function clearRemember() { localStorage.removeItem('qc_remember'); }

// ---------------- Fetch helpers ----------------
async function apiPost(url, body) {
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  let data; try { data = await res.json(); } catch (e) { data = { ok: false, error: 'Bad response from server.' }; }
  return { res, data };
}
async function apiGet(url) {
  const res = await fetch(url);
  let data; try { data = await res.json(); } catch (e) { data = { ok: false, error: 'Bad response from server.' }; }
  return { res, data };
}

// Central place that decides what a failed response means for navigation.
// Returns true if it already handled the error (caller should stop).
function handleCommonErrors(res, data) {
  if (res.ok) return false;
  if (data.error === 'invalid_session') { clearSession(); window.location.href = 'login.html?msg=' + encodeURIComponent(data.message || 'Session expired. Please log in again.'); return true; }
  if (data.error === 'banned') { clearSession(); window.location.href = 'states.html?state=banned'; return true; }
  if (data.error === 'rate_limited') { showToast(data.message || 'Too many attempts — please wait a bit.', 'error'); return true; }
  return false;
}

// ---------------- Toasts ----------------
function showToast(message, kind) {
  let area = document.getElementById('toastArea');
  if (!area) {
    area = document.createElement('div');
    area.id = 'toastArea';
    area.className = 'toast-area';
    const phone = document.querySelector('.phone');
    (phone || document.body).prepend(area);
  }
  const el = document.createElement('div');
  el.className = 'toast ' + (kind || 'info');
  el.textContent = message;
  area.appendChild(el);
  setTimeout(() => el.remove(), 4500);
}

// ---------------- Formatting ----------------
function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str == null ? '' : String(str);
  return d.innerHTML;
}
function formatTime(ms) {
  if (!ms) return '';
  return new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function formatDate(ms) {
  if (!ms) return '—';
  const d = new Date(ms);
  return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function formatSize(bytes) {
  if (!bytes) return '0 B';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}

// ---------------- Encryption (AES-256-GCM, PBKDF2 from the room's passphrase) ----------------
// Envelope format the backend expects: "encv1:" + base64(iv[12 bytes] + ciphertext).
// The server treats everything after "encv1:" as opaque — it never sees the key or plaintext.
function bufToBase64(buf) {
  let binary = '';
  const bytes = new Uint8Array(buf);
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(binary);
}
function base64ToBuf(b64) {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}
async function deriveRoomKey(passphrase, saltB64) {
  const enc = new TextEncoder();
  const saltBytes = saltB64 ? base64ToBuf(saltB64) : enc.encode('quickchat-fallback-salt');
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(passphrase), { name: 'PBKDF2' }, false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: saltBytes, iterations: 100000, hash: 'SHA-256' },
    keyMaterial, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']
  );
}
async function encryptForRoom(key, plaintext) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const enc = new TextEncoder();
  const cipherBuf = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(plaintext));
  const combined = new Uint8Array(iv.length + cipherBuf.byteLength);
  combined.set(iv, 0); combined.set(new Uint8Array(cipherBuf), iv.length);
  return 'encv1:' + bufToBase64(combined);
}
async function decryptFromRoom(key, envelope) {
  if (!key || !envelope || envelope.indexOf('encv1:') !== 0) return null;
  try {
    const combined = base64ToBuf(envelope.slice(6));
    const iv = combined.slice(0, 12);
    const data = combined.slice(12);
    const dec = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, data);
    return new TextDecoder().decode(dec);
  } catch (e) { return null; }
}
function isEncryptedEnvelope(text) { return typeof text === 'string' && text.indexOf('encv1:') === 0; }

function cacheRoomPassphrase(room, passphrase) { sessionStorage.setItem('qc_enckey_' + room, passphrase); }
function getCachedRoomPassphrase(room) { return sessionStorage.getItem('qc_enckey_' + room); }

// PWA install support — registers once, on whichever page loads first.
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(() => {}); });
}

// ---------------- Customize preferences (compact mode, reduced motion,
// notification sound, desktop notifications) — set from the ☰ drawer on
// any page, applied on every page via body classes / a shared beep. ----
const PREFS_KEY = 'qc_prefs';
function getPrefs() {
  try { return Object.assign({ compact: false, reduceMotion: false, notifSound: false, desktopNotif: false }, JSON.parse(localStorage.getItem(PREFS_KEY)) || {}); }
  catch (e) { return { compact: false, reduceMotion: false, notifSound: false, desktopNotif: false }; }
}
function setPrefs(p) { localStorage.setItem(PREFS_KEY, JSON.stringify(p)); applyPrefs(); }
function applyPrefs() {
  const p = getPrefs();
  document.body.classList.toggle('compact-mode', !!p.compact);
  document.body.classList.toggle('reduce-motion', !!p.reduceMotion);
}
document.addEventListener('DOMContentLoaded', applyPrefs);

let __beepCtx = null;
function playNotifSound() {
  if (!getPrefs().notifSound) return;
  try {
    __beepCtx = __beepCtx || new (window.AudioContext || window.webkitAudioContext)();
    const osc = __beepCtx.createOscillator(); const gain = __beepCtx.createGain();
    osc.type = 'sine'; osc.frequency.value = 720;
    gain.gain.setValueAtTime(0.0001, __beepCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.12, __beepCtx.currentTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, __beepCtx.currentTime + 0.22);
    osc.connect(gain); gain.connect(__beepCtx.destination);
    osc.start(); osc.stop(__beepCtx.currentTime + 0.24);
  } catch (e) {}
}
function maybeNotifyDesktop(title, body) {
  if (!getPrefs().desktopNotif) return;
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  if (document.visibilityState === 'visible') return;
  try { new Notification(title, { body, icon: undefined }); } catch (e) {}
}
async function requestDesktopNotifPermission() {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  const perm = await Notification.requestPermission();
  return perm === 'granted';
}

// ---------------- Per-room draft autosave ----------------
function draftKey(room, user) { return 'qc_draft_' + room + '_' + user; }
function saveDraft(room, user, text) {
  const key = draftKey(room, user);
  if (text) localStorage.setItem(key, text); else localStorage.removeItem(key);
}
function loadDraft(room, user) { return localStorage.getItem(draftKey(room, user)) || ''; }

// ---------------- Offline send queue (per room) ----------------
function queueKey(room) { return 'qc_outbox_' + room; }
function getOutbox(room) { try { return JSON.parse(localStorage.getItem(queueKey(room))) || []; } catch (e) { return []; } }
function setOutbox(room, items) { localStorage.setItem(queueKey(room), JSON.stringify(items)); }
function pushOutbox(room, payload) { const items = getOutbox(room); items.push(payload); setOutbox(room, items); }
