<?php
require_once 'core_firewall.php';
require_once 'core_payment_config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$dir = __DIR__ . '/core_data';
if (!is_dir($dir)) @mkdir($dir, 0755, true);

$orders_file = $dir . '/orders.json';
$tenants_file = $dir . '/tenants.json';

foreach ([$orders_file, $tenants_file] as $f) {
    if (!file_exists($f)) file_put_contents($f, json_encode([]));
}

function get_json($path) { return json_decode(file_get_contents($path), true) ?: []; }
function save_json($path, $data) { file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT)); }

function setup_tenant_database($tenant_id) {
    $tenant_dir = __DIR__ . '/core_data/' . $tenant_id;
    if (!is_dir($tenant_dir)) @mkdir($tenant_dir, 0755, true);
    $tables = ['users.json', 'payments.json', 'reminders.json', 'links.json', 'pending_users.json', 'chat_rooms.json'];
    foreach ($tables as $tbl) {
        if (!file_exists("$tenant_dir/$tbl")) file_put_contents("$tenant_dir/$tbl", json_encode([]));
    }
    $tenant_files_dir = __DIR__ . '/core_files/' . $tenant_id;
    if (!is_dir($tenant_files_dir)) @mkdir($tenant_files_dir, 0755, true);
}

switch ($action) {
    case 'create_order':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? ''); $dob = trim($_POST['dob'] ?? '');
            if (!$name || !$email || !$phone || !$dob) die(json_encode(["error" => "All fields required."]));

            $order_id = 'order_' . uniqid() . '_' . time(); $customer_id = 'cust_' . substr(md5($email), 0, 10);
            $payload = [
                "order_id" => $order_id, "order_amount" => PANEL_PRICE_INR, "order_currency" => "INR",
                "customer_details" => ["customer_id" => $customer_id, "customer_name" => $name, "customer_email" => $email, "customer_phone" => $phone],
                "order_meta" => ["return_url" => "https://" . $_SERVER['HTTP_HOST'] . "/pay.html?order_id={order_id}"],
                "order_note" => "Custom Admin Panel"
            ];
            $ch = curl_init(cf_base_url() . '/orders');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'x-client-id: ' . CF_APP_ID, 'x-client-secret: ' . CF_SECRET_KEY, 'x-api-version: ' . CF_API_VERSION]);
            $response = curl_exec($ch); $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            
            $res_data = json_decode($response, true);
            if ($http_code === 200 && isset($res_data['payment_session_id'])) {
                $orders = get_json($orders_file);
                $orders[$order_id] = ["name" => $name, "email" => strtolower($email), "phone" => $phone, "dob" => $dob, "amount" => PANEL_PRICE_INR, "status" => "PENDING", "created_at" => time(), "registered" => false];
                save_json($orders_file, $orders);
                echo json_encode(["status" => "success", "payment_session_id" => $res_data['payment_session_id'], "order_id" => $order_id]);
            } else echo json_encode(["error" => "DEBUG: " . json_encode($res_data)]);
        }
        break;
    case 'verify_order':
        $order_id = $_GET['order_id'] ?? ''; $orders = get_json($orders_file);
        if (!isset($orders[$order_id])) die(json_encode(["error" => "Order not found."]));
        $ch = curl_init(cf_base_url() . '/orders/' . urlencode($order_id));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); curl_setopt($ch, CURLOPT_HTTPHEADER, ['x-client-id: ' . CF_APP_ID, 'x-client-secret: ' . CF_SECRET_KEY, 'x-api-version: ' . CF_API_VERSION]);
        $response = curl_exec($ch); curl_close($ch); $res_data = json_decode($response, true);
        if (isset($res_data['order_status']) && $res_data['order_status'] === 'PAID') {
            $orders[$order_id]['status'] = 'PAID'; save_json($orders_file, $orders);
            echo json_encode(["status" => "success", "message" => "Payment verified.", "email" => $orders[$order_id]['email'], "dob" => $orders[$order_id]['dob']]);
        } else echo json_encode(["error" => "Payment not completed yet."]);
        break;
    case 'resume_setup':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = strtolower(trim($_POST['email'] ?? '')); $dob = trim($_POST['dob'] ?? '');
            $orders = get_json($orders_file); $matched_order = null; $matched_order_id = null;
            foreach ($orders as $oid => $o) {
                if (strtolower($o['email']) === $email && $o['dob'] === $dob && $o['status'] === 'PAID') {
                    if ($o['registered']) die(json_encode(["error" => "This account is already registered."]));
                    $matched_order = $o; $matched_order_id = $oid; break;
                }
            }
            if ($matched_order) echo json_encode(["status" => "success", "order_id" => $matched_order_id, "name" => $matched_order['name'], "email" => $matched_order['email']]);
            else echo json_encode(["error" => "No pending paid order found for this Email and DOB."]);
        }
        break;
    case 'complete_admin_registration':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $order_id = trim($_POST['order_id'] ?? ''); $username = trim($_POST['username'] ?? ''); $password = trim($_POST['password'] ?? '');
            if (!preg_match('/^[a-zA-Z0-9]+$/', $username) || !preg_match('/^[a-zA-Z0-9]+$/', $password)) die(json_encode(["error" => "Username and Password must be alphanumeric."]));
            $orders = get_json($orders_file); $tenants = get_json($tenants_file);
            if (!isset($orders[$order_id])) die(json_encode(["error" => "Verification failed."]));
            if ($orders[$order_id]['registered']) die(json_encode(["error" => "Account already provisioned."]));
            if (isset($tenants[$username])) die(json_encode(["error" => "Username already taken."]));
            $tenant_id = 'tenant_' . substr(md5($username . time()), 0, 8); setup_tenant_database($tenant_id);
            $tenants[$username] = ["tenant_id" => $tenant_id, "name" => $orders[$order_id]['name'], "email" => $orders[$order_id]['email'], "phone" => $orders[$order_id]['phone'], "dob" => $orders[$order_id]['dob'], "password_hash" => password_hash($password, PASSWORD_DEFAULT), "created_at" => time()];
            save_json($tenants_file, $tenants);
            $orders[$order_id]['registered'] = true; $orders[$order_id]['tenant_id'] = $tenant_id; save_json($orders_file, $orders);
            echo json_encode(["status" => "success", "message" => "Admin Panel provisioned successfully!"]);
        }
        break;
    default: http_response_code(405); echo json_encode(["error" => "Direct access is not allowed."]); break;
}
?>