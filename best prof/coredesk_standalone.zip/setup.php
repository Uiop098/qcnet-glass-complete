<?php
$lock_file = __DIR__ . '/setup.lock';
if (file_exists($lock_file)) die("Setup is already completed and locked. Please delete setup.php.");
$folders = ['core_data', 'core_files'];
foreach ($folders as $folder) {
    if (!is_dir($folder)) { mkdir($folder, 0755, true); echo "<p>✅ Created <b>$folder</b></p>"; }
    file_put_contents("$folder/.htaccess", "Require all denied\nDeny from all\n");
}
$master_file = 'core_data/master.json';
if (!file_exists($master_file)) {
    file_put_contents($master_file, json_encode(["xbot" => [ "password_hash" => password_hash("#123xbot", PASSWORD_DEFAULT) ]], JSON_PRETTY_PRINT));
    echo "<p>🛡️ Independent Master Admin database provisioned.</p>";
}
if (!file_exists('core_data/chat_rooms.json')) file_put_contents('core_data/chat_rooms.json', json_encode([]));
if (!is_dir('core_files/main')) { mkdir('core_files/main', 0755, true); echo "<p>✅ Created <b>core_files/main</b> (chat file storage)</p>"; }
$root_htaccess = "DirectoryIndex login.html index.html index.php\nOptions -Indexes\n<FilesMatch \"\\.json$\">\n    Order Allow,Deny\n    Deny from all\n</FilesMatch>";
file_put_contents(".htaccess", $root_htaccess);
echo "<p>✅ Created main <b>.htaccess</b> protection.</p>";
file_put_contents($lock_file, "locked");
echo "<h3>🎉 Setup Complete! Go to your domain.</h3>";
?>