<?php
require_once 'core_firewall.php';
header('Content-Type: application/json');
if (!isset($_SESSION['core_admin']) && !isset($_SESSION['core_user'])) die(json_encode(["error" => "Unauthorized access. Please log in."]));

$is_admin = isset($_SESSION['core_admin']);
$my_username = $is_admin ? $_SESSION['core_admin'] : $_SESSION['core_user'];
$action = $_GET['action'] ?? '';
$tenant_id = $_SESSION['core_tenant'] ?? 'main';
$safe_tenant = preg_replace('/[^a-zA-Z0-9_\-]/', '', $tenant_id);
$dir = ($tenant_id === 'main') ? __DIR__ . '/core_data' : __DIR__ . '/core_data/' . $safe_tenant;
$files_dir = ($tenant_id === 'main') ? __DIR__ . '/core_files/main' : __DIR__ . '/core_files/' . $safe_tenant;
if (!is_dir($dir)) @mkdir($dir, 0755, true);
if (!is_dir($files_dir)) @mkdir($files_dir, 0755, true);

$rooms_file = $dir . '/chat_rooms.json';
if (!file_exists($rooms_file)) file_put_contents($rooms_file, json_encode([]));

function get_rooms($rooms_file) { return json_decode(file_get_contents($rooms_file), true) ?: []; }
function save_rooms($rooms_file, $data) { file_put_contents($rooms_file, json_encode($data, JSON_PRETTY_PRINT)); }
function msgs_path($dir, $room_id) { return $dir . '/chat_msgs_' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $room_id) . '.json'; }
function get_msgs($path) { return file_exists($path) ? (json_decode(file_get_contents($path), true) ?: []) : []; }
function save_msgs($path, $data) { file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT)); }

function room_visible($room, $username, $is_admin) {
    if ($is_admin) return true;
    if (in_array($username, $room['banned'] ?? [])) return false;
    if (empty($room['private'])) return true;
    return in_array($username, $room['members'] ?? []);
}

switch ($action) {

    case 'list_rooms':
        $rooms = get_rooms($rooms_file);
        $out = [];
        foreach ($rooms as $id => $r) {
            if (!room_visible($r, $my_username, $is_admin)) continue;
            $mfile = msgs_path($dir, $id); $msgs = get_msgs($mfile); $last = end($msgs);
            $out[] = [
                "id" => $id, "name" => $r['name'], "private" => !empty($r['private']),
                "slow_mode" => $r['slow_mode'] ?? 0, "owner" => $r['owner'],
                "member_count" => count($r['members'] ?? []), "last_message" => $last ? $last['text'] ?? '📎 File' : '',
                "is_member" => in_array($my_username, $r['members'] ?? []) || $is_admin,
                "invite_token" => $is_admin ? ($r['invite_token'] ?? null) : null
            ];
        }
        echo json_encode(["status" => "success", "rooms" => $out]);
        break;

    case 'create_room':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_admin) {
            $name = trim($_POST['name'] ?? ''); if ($name === '') die(json_encode(["error" => "Room name required."]));
            $private = ($_POST['private'] ?? '0') === '1';
            $room_id = 'room_' . substr(md5($name . microtime()), 0, 10);
            $rooms = get_rooms($rooms_file);
            $rooms[$room_id] = [
                "name" => $name, "owner" => $my_username, "private" => $private,
                "invite_token" => $private ? substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8) : null,
                "slow_mode" => 0, "members" => [$my_username], "banned" => [], "last_msg_time" => [], "created_at" => time()
            ];
            save_rooms($rooms_file, $rooms);
            save_msgs(msgs_path($dir, $room_id), []);
            echo json_encode(["status" => "success", "room_id" => $room_id, "invite_token" => $rooms[$room_id]['invite_token']]);
        }
        break;

    case 'delete_room':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_admin) {
            $room_id = $_POST['room_id'] ?? ''; $rooms = get_rooms($rooms_file);
            if (isset($rooms[$room_id])) {
                unset($rooms[$room_id]); save_rooms($rooms_file, $rooms);
                @unlink(msgs_path($dir, $room_id));
                echo json_encode(["status" => "success"]);
            } else echo json_encode(["error" => "Room not found."]);
        }
        break;

    case 'join_room':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $room_id = $_POST['room_id'] ?? ''; $token = strtoupper(trim($_POST['token'] ?? ''));
            $rooms = get_rooms($rooms_file);
            if (!isset($rooms[$room_id])) die(json_encode(["error" => "Room not found."]));
            $r = $rooms[$room_id];
            if (in_array($my_username, $r['banned'] ?? [])) die(json_encode(["error" => "You are banned from this room."]));
            if (!empty($r['private']) && !$is_admin) {
                if ($token === '' || $token !== ($r['invite_token'] ?? '')) die(json_encode(["error" => "Invalid invite token."]));
            }
            if (!in_array($my_username, $rooms[$room_id]['members'])) $rooms[$room_id]['members'][] = $my_username;
            save_rooms($rooms_file, $rooms); echo json_encode(["status" => "success"]);
        }
        break;

    case 'get_messages':
        $room_id = $_GET['room_id'] ?? ''; $rooms = get_rooms($rooms_file);
        if (!isset($rooms[$room_id]) || !room_visible($rooms[$room_id], $my_username, $is_admin)) die(json_encode(["error" => "Room not accessible."]));
        $since_id = $_GET['since'] ?? '';
        $msgs = get_msgs(msgs_path($dir, $room_id));
        if ($since_id !== '') {
            $idx = -1; foreach ($msgs as $i => $m) if ($m['id'] === $since_id) { $idx = $i; break; }
            if ($idx !== -1) $msgs = array_slice($msgs, $idx + 1);
        }
        // Hide un-approved files from everyone except the uploader and admin
        foreach ($msgs as &$m) {
            if (($m['type'] ?? 'text') === 'file' && $m['file_status'] === 'pending' && $m['user'] !== $my_username && !$is_admin) {
                $m['file_hidden'] = true; unset($m['file_name']);
            }
        }
        echo json_encode(["status" => "success", "messages" => $msgs, "slow_mode" => $rooms[$room_id]['slow_mode'] ?? 0]);
        break;

    case 'send_message':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $room_id = $_POST['room_id'] ?? ''; $text = trim($_POST['text'] ?? '');
            $rooms = get_rooms($rooms_file);
            if (!isset($rooms[$room_id])) die(json_encode(["error" => "Room not found."]));
            $r = &$rooms[$room_id];
            if (in_array($my_username, $r['banned'] ?? [])) die(json_encode(["error" => "You are banned from this room."]));
            if (empty($r['private']) && !in_array($my_username, $r['members'])) $r['members'][] = $my_username;
            if (!$is_admin && !in_array($my_username, $r['members'])) die(json_encode(["error" => "Join the room first."]));
            if ($text === '') die(json_encode(["error" => "Message cannot be empty."]));
            $slow = $r['slow_mode'] ?? 0;
            if ($slow > 0 && !$is_admin) {
                $last = $r['last_msg_time'][$my_username] ?? 0;
                $wait = $slow - (time() - $last);
                if ($wait > 0) die(json_encode(["error" => "Slow mode: wait {$wait}s before sending again."]));
            }
            $r['last_msg_time'][$my_username] = time();
            $mpath = msgs_path($dir, $room_id); $msgs = get_msgs($mpath);
            $msg = ["id" => uniqid('m_', true), "user" => $my_username, "role" => $is_admin ? 'admin' : 'user', "type" => "text", "text" => $text, "ts" => time()];
            $msgs[] = $msg; save_msgs($mpath, $msgs); save_rooms($rooms_file, $rooms);
            echo json_encode(["status" => "success", "message" => $msg]);
        }
        break;

    case 'upload_file':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $room_id = $_POST['room_id'] ?? ''; $rooms = get_rooms($rooms_file);
            if (!isset($rooms[$room_id])) die(json_encode(["error" => "Room not found."]));
            $r = &$rooms[$room_id];
            if (in_array($my_username, $r['banned'] ?? [])) die(json_encode(["error" => "You are banned from this room."]));
            if (empty($r['private']) && !in_array($my_username, $r['members'])) $r['members'][] = $my_username;
            if (empty($_FILES['file'])) die(json_encode(["error" => "No file received."]));
            if ($_FILES['file']['size'] > 8 * 1024 * 1024) die(json_encode(["error" => "File too large (max 8MB)."]));
            $room_files_dir = $files_dir . '/' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $room_id);
            if (!is_dir($room_files_dir)) @mkdir($room_files_dir, 0755, true);
            $orig_name = basename($_FILES['file']['name']);
            $safe_name = preg_replace('/[^a-zA-Z0-9_\-.]/', '_', $orig_name);
            $file_id = uniqid('f_', true);
            $stored_name = $file_id . '_' . $safe_name;
            if (!move_uploaded_file($_FILES['file']['tmp_name'], $room_files_dir . '/' . $stored_name)) die(json_encode(["error" => "Upload failed."]));
            $mpath = msgs_path($dir, $room_id); $msgs = get_msgs($mpath);
            $msg = ["id" => uniqid('m_', true), "user" => $my_username, "role" => $is_admin ? 'admin' : 'user', "type" => "file",
                "file_name" => $orig_name, "stored_name" => $stored_name, "file_status" => $is_admin ? 'approved' : 'pending', "ts" => time()];
            $msgs[] = $msg; save_msgs($mpath, $msgs); save_rooms($rooms_file, $rooms);
            echo json_encode(["status" => "success", "message" => $msg]);
        }
        break;

    case 'approve_file':
    case 'reject_file':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_admin) {
            $room_id = $_POST['room_id'] ?? ''; $msg_id = $_POST['msg_id'] ?? '';
            $mpath = msgs_path($dir, $room_id); $msgs = get_msgs($mpath); $found = false;
            foreach ($msgs as &$m) { if ($m['id'] === $msg_id) { $m['file_status'] = ($action === 'approve_file') ? 'approved' : 'rejected'; $found = true; break; } }
            if ($found) { save_msgs($mpath, $msgs); echo json_encode(["status" => "success"]); } else echo json_encode(["error" => "Message not found."]);
        }
        break;

    case 'kick_user':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_admin) {
            $room_id = $_POST['room_id'] ?? ''; $username = $_POST['username'] ?? ''; $rooms = get_rooms($rooms_file);
            if (isset($rooms[$room_id])) {
                $rooms[$room_id]['members'] = array_values(array_diff($rooms[$room_id]['members'], [$username]));
                save_rooms($rooms_file, $rooms); echo json_encode(["status" => "success"]);
            } else echo json_encode(["error" => "Room not found."]);
        }
        break;

    case 'ban_user':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_admin) {
            $room_id = $_POST['room_id'] ?? ''; $username = $_POST['username'] ?? ''; $rooms = get_rooms($rooms_file);
            if (isset($rooms[$room_id])) {
                $rooms[$room_id]['members'] = array_values(array_diff($rooms[$room_id]['members'], [$username]));
                if (!in_array($username, $rooms[$room_id]['banned'])) $rooms[$room_id]['banned'][] = $username;
                save_rooms($rooms_file, $rooms); echo json_encode(["status" => "success"]);
            } else echo json_encode(["error" => "Room not found."]);
        }
        break;

    case 'unban_user':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_admin) {
            $room_id = $_POST['room_id'] ?? ''; $username = $_POST['username'] ?? ''; $rooms = get_rooms($rooms_file);
            if (isset($rooms[$room_id])) {
                $rooms[$room_id]['banned'] = array_values(array_diff($rooms[$room_id]['banned'], [$username]));
                save_rooms($rooms_file, $rooms); echo json_encode(["status" => "success"]);
            } else echo json_encode(["error" => "Room not found."]);
        }
        break;

    case 'set_slow_mode':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_admin) {
            $room_id = $_POST['room_id'] ?? ''; $seconds = max(0, intval($_POST['seconds'] ?? 0)); $rooms = get_rooms($rooms_file);
            if (isset($rooms[$room_id])) { $rooms[$room_id]['slow_mode'] = $seconds; save_rooms($rooms_file, $rooms); echo json_encode(["status" => "success"]); }
            else echo json_encode(["error" => "Room not found."]);
        }
        break;

    case 'room_members':
        if ($is_admin) {
            $room_id = $_GET['room_id'] ?? ''; $rooms = get_rooms($rooms_file);
            if (isset($rooms[$room_id])) echo json_encode(["status" => "success", "members" => $rooms[$room_id]['members'], "banned" => $rooms[$room_id]['banned']]);
            else echo json_encode(["error" => "Room not found."]);
        }
        break;

    case 'download_file':
        $room_id = $_GET['room_id'] ?? ''; $msg_id = $_GET['msg_id'] ?? '';
        $rooms = get_rooms($rooms_file);
        if (!isset($rooms[$room_id]) || !room_visible($rooms[$room_id], $my_username, $is_admin)) die(json_encode(["error" => "Not accessible."]));
        $msgs = get_msgs(msgs_path($dir, $room_id)); $target = null;
        foreach ($msgs as $m) if ($m['id'] === $msg_id) { $target = $m; break; }
        if (!$target || ($target['type'] ?? '') !== 'file') die(json_encode(["error" => "File not found."]));
        $can_see = $is_admin || $target['user'] === $my_username || $target['file_status'] === 'approved';
        if (!$can_see) die(json_encode(["error" => "This file is awaiting admin approval."]));
        $full_path = $files_dir . '/' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $room_id) . '/' . $target['stored_name'];
        if (!file_exists($full_path)) die(json_encode(["error" => "File missing on server."]));
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($target['file_name']) . '"');
        header('Content-Length: ' . filesize($full_path));
        readfile($full_path); exit;

    default: http_response_code(405); echo json_encode(["error" => "Direct access is not allowed."]); break;
}
?>
