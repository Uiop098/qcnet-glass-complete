const THEMES = [
    { id: 'nocturne', label: 'Nocturne', color: '#8b5cf6' },
    { id: 'aurora',   label: 'Aurora',   color: '#22d3ee' },
    { id: 'ember',    label: 'Ember',    color: '#f97316' },
    { id: 'frost',    label: 'Frost',    color: '#60a5fa' }
];
function applyTheme(themeId) {
    document.documentElement.setAttribute('data-theme', themeId);
    try { localStorage.setItem('core_theme', themeId); } catch (e) {}
}
function initTheme() {
    let saved = 'nocturne'; try { saved = localStorage.getItem('core_theme') || 'nocturne'; } catch (e) {}
    applyTheme(saved);
    if (!document.querySelector('.blob-a')) {
        document.body.insertAdjacentHTML('afterbegin', '<div class="bg-blob blob-a"></div><div class="bg-blob blob-b"></div>');
    }
}
function changeTheme() {
    const existing = document.getElementById('theme-popover'); if (existing) { existing.remove(); return; }
    let html = `<div class="theme-popover fade-in" id="theme-popover">`;
    THEMES.forEach(t => { html += `<button onclick="applyTheme('${t.id}'); document.getElementById('theme-popover').remove();"><span class="theme-swatch" style="background:${t.color}"></span> ${t.label}</button>`; });
    html += `</div>`;
    document.querySelector('.sidebar').insertAdjacentHTML('beforeend', html);
}
let businessData = { users: [], payments: [], reminders: [], links: [] };
let currentUserRole = 'user'; let currentUsername = '';
let activeRoomId = null; let lastMsgId = ''; let chatPollTimer = null;
initTheme();

async function checkAuth() {
    try {
        const response = await fetch('core_auth.php?action=check_auth'); const data = await response.json();
        const isLoginPage = window.location.href.includes('login.html'); const isSetupPage = window.location.href.includes('setup_account.html');
        const isAdminPage = window.location.href.includes('admin.html'); const isUserPage = window.location.href.includes('user.html');
        
        if (data.status !== 'success') { if (!isLoginPage && !isSetupPage) window.location.href = 'login.html'; } 
        else {
            currentUserRole = data.role; currentUsername = data.user;
            if (isLoginPage || isSetupPage) { window.location.href = data.role === 'admin' ? 'admin.html' : 'user.html'; } 
            else if (data.role === 'user' && isAdminPage) { window.location.href = 'user.html'; } 
            else if (data.role === 'admin' && isUserPage) { window.location.href = 'admin.html'; } 
            else { fetchDashboardData(); }
        }
    } catch (e) { console.error("Auth check failed", e); }
}

async function submitLogin() {
    const role = document.getElementById('login-role').value; const user = document.getElementById('login-user').value;
    const pass = document.getElementById('login-pass').value; const msg = document.getElementById('login-msg');
    const form = new URLSearchParams(); form.append('username', user); form.append('password', pass);
    const endpoint = role === 'admin' ? 'admin_login' : 'user_login';
    try {
        const res = await fetch('core_auth.php?action=' + endpoint, { method: 'POST', body: form }); const data = await res.json();
        if (data.status === 'success') { window.location.href = role === 'admin' ? 'admin.html' : 'user.html'; } 
        else { msg.style.color = '#ff6b6b'; msg.innerText = data.error; }
    } catch (e) { msg.innerText = 'Connection error.'; }
}

async function logout() { await fetch('core_auth.php?action=logout'); window.location.href = 'login.html'; }

async function fetchDashboardData() {
    try {
        const response = await fetch('core_api.php?action=get_dashboard_data'); const data = await response.json();
        if (data.status === 'success') {
            businessData = data;
            if(document.title.includes("Admin")) renderUI('users');
            if(document.title.includes("Customer")) renderUserUI('profile');
        } else if (data.error === 'Unauthorized access. Please log in.') { window.location.href = 'login.html'; }
    } catch (e) { document.getElementById('content-area').innerHTML = "<p style='color:#ff6b6b'>Connection error.</p>"; }
}

async function generateToken() {
    const name = prompt("Enter User's Name:"); if (!name) return; const dob = prompt("Enter User's Date of Birth (YYYY-MM-DD):"); if (!dob) return;
    const form = new URLSearchParams(); form.append('name', name); form.append('dob', dob);
    try {
        const res = await fetch('core_auth.php?action=create_pending', { method: 'POST', body: form }); const data = await res.json();
        if (data.status === 'success') {
            try { await navigator.clipboard.writeText(data.token); alert(`Token Generated & Copied!

Token: ${data.token}
Expires in: 10 mins`); } 
            catch(err) { prompt("Copy your token (Expires in 10 mins):", data.token); }
        } else alert(data.error);
    } catch(e) { alert("Error generating token."); }
}

function renderUI(module) {
    if (module === 'chat') { document.getElementById('module-title').innerText = 'CHAT'; renderChatRoomList(true); return; }
    stopChatPolling();
    const area = document.getElementById('content-area'); document.getElementById('module-title').innerText = module.toUpperCase();
    let html = `<div class="action-bar" style="display:flex; gap:10px; margin-bottom:15px; flex-wrap:wrap;">`;
    if (module === 'users') {
        html += `<button onclick="generateToken()" class="primary-btn" style="background: rgba(139, 92, 246, 0.5);">🔑 Gen Token (Copy)</button>`;
        html += `<input type="text" id="search-bar" placeholder="Search contacts, tags, notes..." onkeyup="filterTable('.data-row')" style="flex:1; min-width:200px; margin:0;">`;
    } else {
        html += `<button onclick="showAddForm('${module}')" class="primary-btn">+ Add New Record</button> `;
        html += `<input type="text" id="search-bar" placeholder="Search..." onkeyup="filterTable('.data-row')" style="flex:1; min-width:200px; margin:0;">`;
    }
    html += `</div><div class="table-container"><table id="data-table"><tr>`;
    
    if (module === 'users') {
        html += `<th>User / Contact</th><th>Tags</th><th>Admin Notes</th><th>Actions</th></tr>`;
        Object.keys(businessData.users).forEach(username => {
            let u = businessData.users[username];
            html += `<tr class="data-row" data-search="${(u.name+' '+username+' '+u.tags+' '+u.notes).toLowerCase()}">
                <td><b>${u.name||'--'}</b><br><span style="font-size:11px; color:#aaa;">@${username}<br>${u.mobile||'No Phone'}<br>${u.email||'No Email'}</span></td>
                <td><span style="background:rgba(74,222,128,0.2); padding:3px 8px; border-radius:12px; font-size:11px; color:#4ade80;">${u.tags||'None'}</span></td>
                <td style="font-size:12px; max-width:150px; color:#ccc;">${u.notes||'--'}</td>
                <td><button onclick="editUser('${username}')" style="font-size:11px; padding:5px 8px;">Edit</button> <button onclick="deleteUser('${username}')" style="font-size:11px; padding:5px 8px; background:rgba(255,107,107,0.3); border-color:#ff6b6b; color:#ff6b6b;">Del</button></td></tr>`;
        });
    } else if (module === 'payments') {
        html += `<th>Client</th><th>Amount</th><th>Status</th><th>Date</th></tr>`;
        businessData.payments.forEach(p => html += `<tr class="data-row" data-search="${(p.client+' '+p.amount+' '+p.status+' '+p.date).toLowerCase()}"><td>${p.client||'--'}</td><td>$${p.amount||'--'}</td><td>${p.status||'--'}</td><td>${p.date||'--'}</td></tr>`);
    } else if (module === 'reminders') {
        html += `<th>Task</th><th>Priority</th><th>Due Date</th></tr>`;
        businessData.reminders.forEach(r => html += `<tr class="data-row" data-search="${(r.task+' '+r.priority+' '+r.due).toLowerCase()}"><td>${r.task||'--'}</td><td>${r.priority||'--'}</td><td>${r.due||'--'}</td></tr>`);
    } else if (module === 'links') {
        html += `<th>Title</th><th>URL</th></tr>`;
        businessData.links.forEach(l => html += `<tr class="data-row" data-search="${(l.title+' '+l.url).toLowerCase()}"><td>${l.title||'--'}</td><td><a href="${l.url}" target="_blank" style="color:#4ade80">${l.url}</a></td></tr>`);
    }
    area.innerHTML = html + `</table></div>`;
}

function filterTable(selector) {
    let filter = document.getElementById("search-bar").value.toLowerCase(); let rows = document.querySelectorAll(selector);
    rows.forEach(row => { row.style.display = row.getAttribute('data-search').includes(filter) ? "" : "none"; });
}

function editUser(username) {
    const u = businessData.users[username]; const area = document.getElementById('content-area');
    area.innerHTML = `<div class="glass-panel fade-in" style="padding:20px; max-width:400px; display:flex; flex-direction:column; gap:12px;">
        <h3 style="margin:0;">Manage Contact: @${username}</h3>
        <label>Full Name</label><input type="text" id="eu-name" value="${u.name||''}">
        <label>Mobile Number</label><input type="tel" id="eu-mob" value="${u.mobile||''}">
        <label>Email Address</label><input type="email" id="eu-em" value="${u.email||''}">
        <label>Physical Address</label><input type="text" id="eu-add" value="${u.address||''}">
        <label>Custom Tags (e.g. VIP, Unpaid)</label><input type="text" id="eu-tag" value="${u.tags||''}">
        <label>Private Admin Notes</label><textarea id="eu-note" placeholder="Visible only to admin...">${u.notes||''}</textarea>
        <label>Direct Message to User (Shows on their Dashboard)</label><textarea id="eu-msg" placeholder="Message they will see...">${u.admin_message||''}</textarea>
        <div style="display:flex; gap:10px; margin-top:10px;">
            <button onclick="saveUser('${username}')" class="primary-btn" style="flex:1;">Save User Data</button>
            <button onclick="renderUI('users')" style="flex:1; background:rgba(255,107,107,0.2); border-color:#ff6b6b; color:#ff6b6b;">Cancel</button>
        </div></div>`;
}

async function saveUser(username) {
    const form = new URLSearchParams(); form.append('username', username); form.append('name', document.getElementById('eu-name').value);
    form.append('mobile', document.getElementById('eu-mob').value); form.append('email', document.getElementById('eu-em').value);
    form.append('address', document.getElementById('eu-add').value); form.append('tags', document.getElementById('eu-tag').value);
    form.append('notes', document.getElementById('eu-note').value); form.append('admin_message', document.getElementById('eu-msg').value);
    await fetch('core_api.php?action=update_user', { method: 'POST', body: form }); fetchDashboardData();
}

async function deleteUser(username) {
    if(confirm(`WARNING: Are you sure you want to permanently delete user @${username}?`)) {
        const form = new URLSearchParams(); form.append('username', username);
        await fetch('core_api.php?action=delete_user', { method: 'POST', body: form }); fetchDashboardData();
    }
}

function renderUserUI(module) {
    if (module === 'chat') { document.getElementById('module-title').innerText = 'CHAT'; renderChatRoomList(false); return; }
    stopChatPolling();
    const area = document.getElementById('content-area'); document.getElementById('module-title').innerText = module.toUpperCase().replace('_', ' ');
    let html = '';
    if (businessData.my_profile && businessData.my_profile.admin_message && businessData.my_profile.admin_message.trim() !== '') {
        html += `<div class="admin-message-box fade-in" style="background:rgba(255,215,0,0.15); border:1px solid #facc15; color:#facc15; padding:15px; border-radius:8px; margin-bottom:20px; box-shadow: 0 4px 15px rgba(250, 204, 21, 0.1);">
            <h4 style="margin:0 0 5px 0;">🔔 Message from Administrator</h4><p style="margin:0; font-size:14px; color:#fff;">${businessData.my_profile.admin_message}</p></div>`;
    }
    if (module === 'profile') {
        let p = businessData.my_profile;
        html += `<div class="glass-panel fade-in" style="padding:25px; max-width:400px; display:flex; flex-direction:column; gap:12px;">
            <h3 style="margin:0; border-bottom:1px solid var(--glass-border); padding-bottom:10px;">My Profile</h3>
            <p style="margin:0;"><b>Name:</b> ${p.name||'--'}</p><p style="margin:0;"><b>DOB:</b> ${p.dob||'--'}</p>
            <label style="margin-top:10px; font-size:13px; color:#aaa;">Update Mobile Number:</label><input type="tel" id="my-mob" value="${p.mobile||''}" placeholder="Your Mobile">
            <label style="font-size:13px; color:#aaa;">Update Email Address:</label><input type="email" id="my-em" value="${p.email||''}" placeholder="Your Email">
            <label style="font-size:13px; color:#aaa;">Update Address:</label><input type="text" id="my-add" value="${p.address||''}" placeholder="Your Address">
            <button onclick="saveMyProfile()" class="primary-btn" style="margin-top:10px;">Save Profile Updates</button>
        </div>`;
        area.innerHTML = html; return;
    }
    html += `<div class="table-container fade-in"><table id="data-table"><tr>`;
    if (module === 'my_payments') {
        html += `<th>Amount</th><th>Status</th><th>Date</th></tr>`;
        businessData.payments.forEach(p => html += `<tr><td>$${p.amount||'--'}</td><td>${p.status||'--'}</td><td>${p.date||'--'}</td></tr>`);
    } else if (module === 'reminders') {
        html += `<th>Task</th><th>Priority</th><th>Due Date</th></tr>`;
        businessData.reminders.forEach(r => html += `<tr><td>${r.task||'--'}</td><td>${r.priority||'--'}</td><td>${r.due||'--'}</td></tr>`);
    } else if (module === 'links') {
        html += `<th>Title</th><th>URL</th></tr>`;
        businessData.links.forEach(l => html += `<tr><td>${l.title||'--'}</td><td><a href="${l.url}" target="_blank" style="color:#4ade80">${l.url}</a></td></tr>`);
    }
    area.innerHTML = html + `</table></div>`;
}

async function saveMyProfile() {
    const form = new URLSearchParams(); 
    form.append('mobile', document.getElementById('my-mob').value); form.append('email', document.getElementById('my-em').value); form.append('address', document.getElementById('my-add').value);
    await fetch('core_api.php?action=update_my_profile', { method: 'POST', body: form });
    alert("Profile Updated Successfully!"); fetchDashboardData();
}

async function submitForm(table) {
    const inputs = document.querySelectorAll('#add-form input, #add-form select'); const formData = new URLSearchParams(); formData.append('table', table);
    inputs.forEach(input => formData.append(input.name, input.value));
    await fetch('core_api.php?action=add_record', { method: 'POST', body: formData }); fetchDashboardData();
}

// ---------------- CHAT MODULE ----------------
function stopChatPolling() { if (chatPollTimer) { clearInterval(chatPollTimer); chatPollTimer = null; } activeRoomId = null; lastMsgId = ''; }

async function renderChatRoomList(isAdmin) {
    stopChatPolling();
    const area = document.getElementById('content-area');
    area.innerHTML = `<div class="chat-layout fade-in">
        <div class="room-list" id="room-list"><p style="font-size:12px;color:#aaa;">Loading rooms...</p></div>
        <div class="chat-window" id="chat-window"><div style="margin:auto;color:#aaa;font-size:13px;">Select a room to start chatting</div></div>
    </div>`;
    if (isAdmin) {
        document.getElementById('room-list').insertAdjacentHTML('beforebegin', `<div style="margin-bottom:10px;"><button onclick="createRoomPrompt()" class="primary-btn" style="width:100%;">+ New Room</button></div>`);
    }
    try {
        const res = await fetch('core_chat_api.php?action=list_rooms'); const data = await res.json();
        const list = document.getElementById('room-list');
        if (data.status !== 'success' || !data.rooms.length) { list.innerHTML = `<p style="font-size:12px;color:#aaa;">No rooms yet.</p>`; return; }
        list.innerHTML = '';
        data.rooms.forEach(r => {
            list.insertAdjacentHTML('beforeend', `<div class="room-item" onclick="openRoom('${r.id}', ${isAdmin}, ${!r.is_member})" id="room-${r.id}">
                <div class="rname">${r.private ? '🔒' : '#'} ${r.name}</div>
                <div class="rlast">${r.member_count} member(s) ${r.slow_mode ? '· 🐢' : ''}</div>
                <div class="rlast">${r.last_message ? r.last_message.substring(0,40) : 'No messages yet'}</div></div>`);
        });
    } catch (e) { document.getElementById('room-list').innerHTML = `<p style="color:#ff6b6b;font-size:12px;">Failed to load rooms.</p>`; }
}

async function createRoomPrompt() {
    const name = prompt("Room name:"); if (!name) return;
    const priv = confirm("Make this a PRIVATE room (invite token required to join)?\nOK = Private, Cancel = Public");
    const form = new URLSearchParams(); form.append('name', name); form.append('private', priv ? '1' : '0');
    const res = await fetch('core_chat_api.php?action=create_room', { method: 'POST', body: form }); const data = await res.json();
    if (data.status === 'success') {
        if (priv) alert(`Room created!\nInvite token: ${data.invite_token}`);
        renderChatRoomList(true);
    } else alert(data.error);
}

async function openRoom(roomId, isAdmin, needsJoin) {
    document.querySelectorAll('.room-item').forEach(el => el.classList.remove('active'));
    const el = document.getElementById('room-' + roomId); if (el) el.classList.add('active');
    if (needsJoin && !isAdmin) {
        const token = prompt("This is a private room. Enter invite token to join (leave blank if it's a public room):") || '';
        const form = new URLSearchParams(); form.append('room_id', roomId); form.append('token', token.toUpperCase());
        const res = await fetch('core_chat_api.php?action=join_room', { method: 'POST', body: form }); const data = await res.json();
        if (data.status !== 'success') { alert(data.error); return; }
    }
    stopChatPolling(); activeRoomId = roomId; lastMsgId = '';
    const win = document.getElementById('chat-window');
    win.innerHTML = `${isAdmin ? `<div class="mod-panel" id="mod-panel-${roomId}"></div>` : ''}
        <div class="chat-messages" id="chat-messages"></div>
        <div class="chat-input-bar">
            <input type="text" id="chat-text-input" placeholder="Type a message..." onkeydown="if(event.key==='Enter') sendChatMessage('${roomId}')">
            <button onclick="document.getElementById('chat-file-input').click()">📎</button>
            <input type="file" id="chat-file-input" style="display:none" onchange="uploadChatFile('${roomId}')">
            <button onclick="sendChatMessage('${roomId}')" class="primary-btn">Send</button>
        </div>`;
    if (isAdmin) renderModPanel(roomId);
    await pollMessages(roomId);
    chatPollTimer = setInterval(() => pollMessages(roomId), 3000);
}

async function renderModPanel(roomId) {
    const panel = document.getElementById('mod-panel-' + roomId); if (!panel) return;
    panel.innerHTML = `<button onclick="kickBanPrompt('${roomId}','kick_user')">👢 Kick</button>
        <button onclick="kickBanPrompt('${roomId}','ban_user')" style="color:#ff6b6b;">🚫 Ban</button>
        <button onclick="kickBanPrompt('${roomId}','unban_user')">✅ Unban</button>
        <button onclick="slowModePrompt('${roomId}')">🐢 Slow Mode</button>
        <button onclick="deleteRoomPrompt('${roomId}')" style="color:#ff6b6b;">🗑️ Delete Room</button>`;
}

async function kickBanPrompt(roomId, action) {
    const username = prompt(`Enter username to ${action.replace('_user','')}:`); if (!username) return;
    const form = new URLSearchParams(); form.append('room_id', roomId); form.append('username', username);
    const res = await fetch('core_chat_api.php?action=' + action, { method: 'POST', body: form }); const data = await res.json();
    if (data.status === 'success') alert('Done.'); else alert(data.error);
}

async function slowModePrompt(roomId) {
    const seconds = prompt("Slow mode delay in seconds (0 to disable):", "0"); if (seconds === null) return;
    const form = new URLSearchParams(); form.append('room_id', roomId); form.append('seconds', seconds);
    await fetch('core_chat_api.php?action=set_slow_mode', { method: 'POST', body: form }); alert('Slow mode updated.');
}

async function deleteRoomPrompt(roomId) {
    if (!confirm("Permanently delete this room and all its messages?")) return;
    const form = new URLSearchParams(); form.append('room_id', roomId);
    await fetch('core_chat_api.php?action=delete_room', { method: 'POST', body: form });
    renderChatRoomList(true);
}

async function pollMessages(roomId) {
    try {
        const res = await fetch(`core_chat_api.php?action=get_messages&room_id=${roomId}&since=${lastMsgId}`);
        const data = await res.json(); if (data.status !== 'success') return;
        const box = document.getElementById('chat-messages'); if (!box) return;
        data.messages.forEach(m => {
            lastMsgId = m.id;
            const mine = m.user === currentUsername;
            let inner = `<div class="m-user">${m.user}${m.role === 'admin' ? ' 🛡️' : ''}</div>`;
            if (m.type === 'file') {
                if (m.file_hidden) { inner += `<div class="msg-file">📎 File pending admin approval <span class="file-badge pending">pending</span></div>`; }
                else {
                    const badge = `<span class="file-badge ${m.file_status}">${m.file_status}</span>`;
                    inner += `<div class="msg-file">📎 <a href="core_chat_api.php?action=download_file&room_id=${roomId}&msg_id=${m.id}" style="color:inherit;" target="_blank">${m.file_name}</a> ${badge}
                        ${(currentUserRole==='admin' && m.file_status==='pending') ? `<button onclick="fileDecision('${roomId}','${m.id}','approve')" style="font-size:10px;padding:3px 6px;">✔</button><button onclick="fileDecision('${roomId}','${m.id}','reject')" style="font-size:10px;padding:3px 6px;">✘</button>` : ''}</div>`;
                }
            } else { inner += `<div>${m.text}</div>`; }
            box.insertAdjacentHTML('beforeend', `<div class="msg-bubble${mine ? ' mine' : ''}">${inner}</div>`);
        });
        if (data.messages.length) box.scrollTop = box.scrollHeight;
    } catch (e) { /* silent - keep polling */ }
}

async function fileDecision(roomId, msgId, decision) {
    const form = new URLSearchParams(); form.append('room_id', roomId); form.append('msg_id', msgId);
    await fetch(`core_chat_api.php?action=${decision}_file`, { method: 'POST', body: form });
}

async function sendChatMessage(roomId) {
    const input = document.getElementById('chat-text-input'); const text = input.value.trim(); if (!text) return;
    input.value = '';
    const form = new URLSearchParams(); form.append('room_id', roomId); form.append('text', text);
    const res = await fetch('core_chat_api.php?action=send_message', { method: 'POST', body: form }); const data = await res.json();
    if (data.error) alert(data.error);
}

async function uploadChatFile(roomId) {
    const input = document.getElementById('chat-file-input'); if (!input.files.length) return;
    const form = new FormData(); form.append('room_id', roomId); form.append('file', input.files[0]);
    const res = await fetch('core_chat_api.php?action=upload_file', { method: 'POST', body: form }); const data = await res.json();
    if (data.error) alert(data.error);
    input.value = '';
}

function showAddForm(module) {
    const area = document.getElementById('content-area');
    let formHtml = `<div id="add-form" class="glass-panel fade-in" style="padding:25px; max-width:400px; display:flex; flex-direction:column; gap:12px;">`;
    if (module === 'payments') { formHtml += `<label>Client Username</label><input type="text" name="client" placeholder="Exact Match"><label>Amount</label><input type="number" name="amount" placeholder="0.00"><label>Status</label><select name="status"><option>Pending</option><option>Received</option></select><label>Date</label><input type="date" name="date">`; } 
    else if (module === 'reminders') { formHtml += `<label>Task Description</label><input type="text" name="task" placeholder="..."><label>Priority</label><select name="priority"><option>High</option><option>Normal</option></select><label>Due Date</label><input type="date" name="due">`; } 
    else if (module === 'links') { formHtml += `<label>Link Title</label><input type="text" name="title" placeholder="..."><label>URL</label><input type="url" name="url" placeholder="https://...">`; }
    formHtml += `<div style="display:flex; gap:10px; margin-top:10px;"><button onclick="submitForm('${module}')" class="primary-btn" style="flex:1;">Save Record</button>`;
    formHtml += `<button onclick="renderUI('${module}')" style="flex:1; background:transparent; border:1px solid #ff6b6b; color:#ff6b6b;">Cancel</button></div></div>`;
    area.innerHTML = formHtml;
}

if (!window.location.href.includes("pay.html")) {
    checkAuth();
}
