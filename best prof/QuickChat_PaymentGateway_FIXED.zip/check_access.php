<?php
// check_access.php — called by index.html itself (public, no shared
// secret needed) purely to answer "is the link this visitor arrived on
// still good?" so the page can show the Pay button or a "get a new
// link" message. This does NOT consume/mark the link used — that only
// happens after an actual successful payment (see verify_payment.php /
// webhook.php), so refreshing the buy page mid-purchase doesn't break
// anything.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

$ip = get_client_ip();
if (!rate_limit_allow('check_access', $ip, 30, 600)) {
    json_out(['ok' => false, 'error' => 'rate_limited'], 429);
}

$linkToken = isset($_GET['access']) ? trim((string)$_GET['access']) : '';
if ($linkToken === '' || !preg_match('/^[a-f0-9]{48}$/', $linkToken)) {
    json_out(['ok' => false, 'error' => 'missing_link', 'message' => 'This page needs a valid Buy link — go back to QuickChat and click "Buy Super Access" again.'], 400);
}

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM access_links WHERE link_token = :token LIMIT 1');
$stmt->execute(['token' => $linkToken]);
$row = $stmt->fetch();

if (!$row) {
    json_out(['ok' => false, 'error' => 'invalid_link', 'message' => 'That Buy link is not recognized. Go back to QuickChat and click "Buy Super Access" again.'], 404);
}
if ($row['status'] === 'used') {
    json_out(['ok' => false, 'error' => 'link_used', 'message' => 'This Buy link has already been used. Go back to QuickChat and click "Buy Super Access" again for a fresh one.'], 409);
}
if ($row['expires_at'] < now_ms()) {
    json_out(['ok' => false, 'error' => 'link_expired', 'message' => 'This Buy link has expired. Go back to QuickChat and click "Buy Super Access" again.'], 410);
}

// Record which IP actually opened it (informational only).
if (empty($row['buyer_ip'])) {
    $pdo->prepare('UPDATE access_links SET buyer_ip = :ip WHERE id = :id')
        ->execute(['ip' => $ip, 'id' => $row['id']]);
}

json_out(['ok' => true, 'expiresAt' => (int)$row['expires_at']]);
