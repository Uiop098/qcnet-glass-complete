<?php
// create_order.php — called by index.html right before opening Razorpay
// Checkout. Creates the order on Razorpay's side and a matching
// "pending" row here, so we have a place to attach the access token
// once payment succeeds.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);

$ip = get_client_ip();
if (is_ip_blocked($ip)) json_out(['ok' => false, 'error' => 'blocked'], 403);
if (!rate_limit_allow('create_order', $ip, 10, 600)) {
    json_out(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many attempts — please wait a few minutes and try again.'], 429);
}

// Require a still-valid access link — stops anyone who bypasses the
// frontend and calls this endpoint directly without ever having gone
// through QuickChat's "Buy Super Access" button.
$body = json_decode(file_get_contents('php://input'), true);
$accessToken = isset($body['access']) ? trim((string)$body['access']) : '';
if ($accessToken === '' || !preg_match('/^[a-f0-9]{48}$/', $accessToken)) {
    json_out(['ok' => false, 'error' => 'missing_link', 'message' => 'Your Buy link is missing or malformed. Go back to QuickChat and click "Buy Super Access" again.'], 400);
}
$pdo = db();
$linkStmt = $pdo->prepare('SELECT * FROM access_links WHERE link_token = :token LIMIT 1');
$linkStmt->execute(['token' => $accessToken]);
$link = $linkStmt->fetch();
if (!$link || $link['status'] === 'used' || $link['expires_at'] < now_ms()) {
    json_out(['ok' => false, 'error' => 'invalid_link', 'message' => 'That Buy link is no longer valid. Go back to QuickChat and click "Buy Super Access" again.'], 410);
}

$receipt = 'qc_' . bin2hex(random_bytes(8));
$errorOut = null;
$order = razorpay_create_order(OFFER_AMOUNT_PAISE, OFFER_CURRENCY, $receipt, $errorOut);
if (!$order) {
    json_out(['ok' => false, 'error' => 'order_failed', 'message' => $errorOut ?: 'Could not create order.'], 502);
}

$stmt = $pdo->prepare(
    'INSERT INTO tokens (token, razorpay_order_id, amount_paise, currency, duration_days, status, buyer_ip, access_link_token, created_at)
     VALUES (:token, :order_id, :amount, :currency, :duration, "pending", :ip, :access, :now)'
);
// Placeholder token until payment is confirmed — verify_payment.php /
// webhook.php overwrite this with the real access token at that point.
$stmt->execute([
    'token' => 'pending_' . $order['id'],
    'order_id' => $order['id'],
    'amount' => OFFER_AMOUNT_PAISE,
    'currency' => OFFER_CURRENCY,
    'duration' => OFFER_DURATION_DAYS,
    'ip' => $ip,
    'access' => $accessToken,
    'now' => now_ms(),
]);

json_out([
    'ok' => true,
    'orderId' => $order['id'],
    'amount' => OFFER_AMOUNT_PAISE,
    'currency' => OFFER_CURRENCY,
    'keyId' => RAZORPAY_KEY_ID,
    'label' => OFFER_LABEL,
]);
