QuickChat Payment Gateway — setup guide
========================================

This is a SEPARATE site from the main QuickChat app. Deploy it on its
own InfinityFree (sub)domain, e.g. pay.yoursite.com or a fresh free
subdomain. It sells "Super Access" for QuickChat: buyer pays via
Razorpay, gets a one-time access token, pastes that token into
QuickChat's login page (Redeem tab) to create their own super account.

--------------------------------------------------------------------
1. Create the MySQL database (InfinityFree control panel)
--------------------------------------------------------------------
- Control Panel -> MySQL Databases -> create a new database.
- Note the hostname, database name, username, password shown there.
  The hostname is USUALLY something like sqlXXX.infinityfree.com —
  it is almost never "localhost" on InfinityFree.
- Open phpMyAdmin for that database (link is right there in the control
  panel) -> SQL tab -> paste the contents of schema.sql -> Go.

--------------------------------------------------------------------
2. Get your Razorpay keys
--------------------------------------------------------------------
- Sign up / log in at https://dashboard.razorpay.com
- Settings -> API Keys -> Generate Test Key (use TEST keys first —
  they start with rzp_test_). Copy the Key Id and Key Secret.
- Settings -> Webhooks -> Add New Webhook:
    Webhook URL:    https://YOUR-PAYMENT-DOMAIN/webhook.php
    Active events:  payment.captured
  Razorpay shows you a Webhook Secret when you save this — copy it too
  (it is DIFFERENT from the Key Secret above).

--------------------------------------------------------------------
3. Fill in config.php
--------------------------------------------------------------------
Open config.php and replace every REPLACE_WITH_... placeholder with the
real values from steps 1 and 2, plus a shared secret for talking to
your main QuickChat app:

    php -r "echo bin2hex(random_bytes(32));"

Run that once anywhere PHP is available, copy the output into
APP_SHARED_SECRET here — and paste the SAME string into the main app's
common.php (PAYMENT_GATEWAY_SECRET constant). This is what stops
random visitors from calling verify_token.php directly.

--------------------------------------------------------------------
4. Upload
--------------------------------------------------------------------
Upload every file in this folder to your payment domain's web root,
keeping the folder structure as-is.

--------------------------------------------------------------------
5. Point the main app at this gateway
--------------------------------------------------------------------
In the main QuickChat app's common.php, set:
    PAYMENT_GATEWAY_URL    = 'https://YOUR-PAYMENT-DOMAIN/verify_token.php'
    PAYMENT_GATEWAY_SECRET = the same APP_SHARED_SECRET from step 3

--------------------------------------------------------------------
6. Test it end-to-end BEFORE switching to live keys
--------------------------------------------------------------------
With rzp_test_ keys, Razorpay Checkout accepts these test values —
no real money moves:
    Card number: 4111 1111 1111 1111, any future expiry, any CVV
    UPI:         success@razorpay
- Visit your payment domain, pay ₹1 with the test card above.
- Confirm you get a token back on screen.
- Paste that token into QuickChat's login page -> Redeem tab -> confirm
  a super account gets created and you're logged in.
- Only after that works, switch config.php to your rzp_live_ keys (and
  re-create the webhook in Razorpay's LIVE mode — test and live webhooks
  are separate) to accept real payments.

--------------------------------------------------------------------
Notes
--------------------------------------------------------------------
- The ₹1 / 10-day offer is set in config.php (OFFER_AMOUNT_PAISE,
  OFFER_DURATION_DAYS, OFFER_LABEL) — change these when you're ready
  to move off the test price.
- Every token is single-use: once redeemed by the main app, it can't
  be redeemed again, even if someone else gets hold of it after you.
- Outbound HTTPS (this gateway calling api.razorpay.com, and the main
  app calling this gateway) uses the same file_get_contents()-based
  approach the main QuickChat app already uses successfully for GIF
  search and translation — known to work on InfinityFree. If either
  side ever reports "could not reach" errors, that specific host may be
  blocking outbound HTTPS and you'd need to ask their support or move
  that piece to a host that allows it.
