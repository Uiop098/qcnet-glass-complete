-- access_links.sql — run this in phpMyAdmin (SQL tab) same as schema.sql.
-- Adds the "temporary link to reach the buy page" feature: the payment
-- page (index.html) now refuses to show the Pay button unless the visitor
-- arrived via a fresh, unexpired link that the main QuickChat app
-- requested on their behalf when they clicked "Buy Super Access".

CREATE TABLE IF NOT EXISTS access_links (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  link_token  VARCHAR(64)  NOT NULL,
  status      ENUM('unused','used','expired') NOT NULL DEFAULT 'unused',
  created_at  BIGINT UNSIGNED NOT NULL,
  expires_at  BIGINT UNSIGNED NOT NULL,
  used_at     BIGINT UNSIGNED NULL,
  requested_by_ip VARCHAR(64) NULL,  -- IP of the main app server that requested it
  buyer_ip    VARCHAR(64) NULL,      -- IP that actually opened the link
  PRIMARY KEY (id),
  UNIQUE KEY uq_link_token (link_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Track which access link led to which purchase (nullable — old rows
-- created before this feature existed have no link).
ALTER TABLE tokens ADD COLUMN access_link_token VARCHAR(64) NULL AFTER buyer_ip;
