<?php
// request_access.php — called server-to-server by the main QuickChat
// app's buy_redirect.php, the moment someone clicks "Buy Super Access".
// Never called by a browser directly (it's authenticated with the same
// APP_SHARED_SECRET pattern as verify_token.php). Mints a short-lived
// link_token; the main app redirects the buyer's browser to
// index.html?access=<link_token>. The buy page is otherwise blocked —
// see check_access.php and index.html.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);

$ip = get_client_ip();
if (!rate_limit_allow('request_access', $ip, 30, 600)) {
    json_out(['ok' => false, 'error' => 'rate_limited'], 429);
}

$body = json_decode(file_get_contents('php://input'), true);
$appSecret = isset($body['appSecret']) ? (string)$body['appSecret'] : '';
if (!hash_equals(APP_SHARED_SECRET, $appSecret)) {
    json_out(['ok' => false, 'error' => 'unauthorized'], 401);
}

$pdo = db();

// Housekeeping: drop old unused/expired links so the table doesn't grow
// forever (no cron on InfinityFree's free tier, so do it opportunistically
// here — cheap, and this endpoint is called often enough to keep it tidy).
$pdo->prepare('DELETE FROM access_links WHERE status != "used" AND expires_at < :now')
    ->execute(['now' => now_ms()]);

$linkToken = bin2hex(random_bytes(24));
$now = now_ms();
$expiresAt = $now + (ACCESS_LINK_TTL_MINUTES * 60 * 1000);

$stmt = $pdo->prepare(
    'INSERT INTO access_links (link_token, status, created_at, expires_at, requested_by_ip)
     VALUES (:token, "unused", :now, :expires, :ip)'
);
$stmt->execute(['token' => $linkToken, 'now' => $now, 'expires' => $expiresAt, 'ip' => $ip]);

json_out([
    'ok' => true,
    'linkToken' => $linkToken,
    'expiresAt' => $expiresAt,
]);
