<?php
// verify_token.php — called server-to-server by the main QuickChat app's
// redeem.php, never by a browser directly. Redemption is single-use: a
// "paid" token is atomically flipped to "redeemed" in the same query
// that reads it, so two near-simultaneous redeem attempts (e.g. a
// double form submit) can't both succeed.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);

$ip = get_client_ip();
if (!rate_limit_allow('verify_token', $ip, 60, 600)) {
    json_out(['ok' => false, 'error' => 'rate_limited'], 429);
}

$body = json_decode(file_get_contents('php://input'), true);
$appSecret = isset($body['appSecret']) ? (string)$body['appSecret'] : '';
$token = isset($body['token']) ? trim((string)$body['token']) : '';

if (!hash_equals(APP_SHARED_SECRET, $appSecret)) {
    json_out(['ok' => false, 'error' => 'unauthorized'], 401);
}
if ($token === '' || !preg_match('/^[a-f0-9]{48}$/', $token)) {
    json_out(['ok' => false, 'error' => 'invalid_token', 'message' => 'That token looks malformed.'], 400);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare('SELECT * FROM tokens WHERE token = :token LIMIT 1 FOR UPDATE');
    $stmt->execute(['token' => $token]);
    $row = $stmt->fetch();

    if (!$row) {
        $pdo->rollBack();
        json_out(['ok' => false, 'error' => 'invalid_token', 'message' => 'That token was not found.'], 404);
    }
    if ($row['status'] === 'redeemed') {
        $pdo->rollBack();
        json_out(['ok' => false, 'error' => 'already_redeemed', 'message' => 'This token has already been used.'], 409);
    }
    if ($row['status'] === 'pending') {
        $pdo->rollBack();
        json_out(['ok' => false, 'error' => 'not_paid', 'message' => 'Payment for this token has not completed yet.'], 402);
    }

    $upd = $pdo->prepare('UPDATE tokens SET status = "redeemed", redeemed_at = :now, redeemed_by_app_ip = :ip WHERE id = :id');
    $upd->execute(['now' => now_ms(), 'ip' => $ip, 'id' => $row['id']]);
    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    json_out(['ok' => false, 'error' => 'server_error'], 500);
}

json_out([
    'ok' => true,
    'durationDays' => (int)$row['duration_days'],
    'purchasedAt' => (int)$row['paid_at'],
]);
