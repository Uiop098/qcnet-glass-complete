<?php
// upload.php — handles file uploads. Regular members are limited to a
// safe whitelist of file types; super users can upload virtually any
// file type EXCEPT a small blocklist of server-executable script
// extensions (kept even for super users, purely so nobody can
// accidentally drop a live script onto the server via chat).

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$room = isset($_POST['room']) ? $_POST['room'] : '';
$token = isset($_POST['token']) ? $_POST['token'] : '';
$caption = isset($_POST['caption']) ? trim(strip_tags($_POST['caption'])) : '';

$session = get_session($token);
if (!$session || $session['room'] !== safe_room_name($room)) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Session expired or invalid. Please rejoin.']);
    exit;
}

$config = read_config($room);
if (!$config) $config = default_config();
if ($session['role'] === 'member' && is_banned($config, $session['user'])) {
    remove_sessions_for_user($room, $session['user']);
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'banned', 'message' => 'You have been removed from this chat by the host.']);
    exit;
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $err = isset($_FILES['file']) ? $_FILES['file']['error'] : 'no file';
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Upload failed (code: ' . $err . ')']);
    exit;
}

$isSuper = ($session['role'] === 'super');

// Regular members: whitelist of common safe types.
$memberAllowedExtensions = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp',
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'rtf',
    'mp3', 'wav', 'ogg', 'm4a', 'aac',
    'mp4', 'webm', 'mov', 'mkv', 'avi',
    'zip', 'rar', '7z',
];

// Blocked for EVERYONE, including super users — server-executable script
// types that could be dangerous if the host ever executes files by
// extension. This is the only upload restriction super users still hit.
$dangerousExtensions = [
    'php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phar',
    'cgi', 'pl', 'py', 'sh', 'bash', 'exe', 'bat', 'cmd', 'com',
    'asp', 'aspx', 'jsp', 'htaccess', 'ini',
];

$maxFileSizeBytes = $isSuper ? (200 * 1024 * 1024) : (25 * 1024 * 1024);

$file = $_FILES['file'];
if ($file['size'] > $maxFileSizeBytes) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'File too large (max ' . round($maxFileSizeBytes / 1024 / 1024) . ' MB)']);
    exit;
}

$origName = basename($file['name']);
$ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));

if (in_array($ext, $dangerousExtensions, true)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => '.' . $ext . ' files are blocked for server safety, even for super users.']);
    exit;
}

if (!$isSuper && !in_array($ext, $memberAllowedExtensions, true)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'File type .' . $ext . ' is not allowed for regular members.']);
    exit;
}

$safeBase = preg_replace('/[^a-zA-Z0-9_\-]/', '_', pathinfo($origName, PATHINFO_FILENAME));
$safeBase = substr($safeBase, 0, 60) ?: 'file';
$uniqueName = $safeBase . '_' . date('Ymd_His') . '_' . substr(md5(uniqid('', true)), 0, 8) . ($ext !== '' ? '.' . $ext : '');

$destDir = room_files_dir($room);
$destPath = $destDir . '/' . $uniqueName;

if (!move_uploaded_file($file['tmp_name'], $destPath)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Could not save file on server']);
    exit;
}

$imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'];
$audioExts = ['mp3', 'wav', 'ogg', 'm4a', 'aac'];
$videoExts = ['mp4', 'webm', 'mov', 'mkv', 'avi'];

if (in_array($ext, $imageExts, true)) {
    $category = 'image';
} elseif (in_array($ext, $audioExts, true)) {
    $category = 'audio';
} elseif (in_array($ext, $videoExts, true)) {
    $category = 'video';
} else {
    $category = 'file';
}

$fileUrl = 'files/' . rawurlencode(safe_room_name($room)) . '/' . rawurlencode($uniqueName);

$newMsg = append_message($room, [
    'type' => 'file',
    'user' => $session['user'],
    'role' => $session['role'],
    'text' => $caption,
    'fileName' => $origName,
    'fileUrl' => $fileUrl,
    'fileSize' => $file['size'],
    'fileExt' => $ext,
    'fileCategory' => $category,
]);

echo json_encode(['ok' => true, 'message' => $newMsg]);
