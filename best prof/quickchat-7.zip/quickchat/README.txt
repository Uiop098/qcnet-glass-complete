QUICK CHAT — SELF-HOSTED, NO DEPENDENCIES
==========================================

WHAT'S INSIDE
  index.html    - frontend (HTML/CSS/JS, no external libraries)
  api.php       - fetch/send messages, clear chat (host/super only)
  auth.php      - login: member join, host login, super user login
  upload.php    - file uploads (restricted for members, open for super)
  kick.php      - removes a user from a room (host/super only)
  theme.php     - sets room theme + super message glow (super only)
  common.php    - shared storage/session/config helpers
  super_users.php - hardcoded super user accounts (see below)
  data/         - JSON files holding each room's messages, PIN, host
                  password, bans, presence, theme
                  (.htaccess blocks direct browser access)
  files/        - uploaded files, organized by room
                  (.htaccess blocks folder listing, direct links still work)

REQUIREMENTS
  Any PHP host works (PHP 7+). No database needed.

HOW TO DEPLOY
  1. Upload the whole "quickchat" folder (all files and the data/ and
     files/ subfolders) to your site via FTP or your host's File
     Manager. Example: htdocs/quickchat/  or  public_html/quickchat/
  2. Make sure the "data" and "files" folders are writable by PHP.
     Most hosts default to 755 permissions, which is fine. If uploads
     or messages fail, try setting these two folders to 755 or 775
     via your host's file manager (right-click > File Permissions).
  3. Visit https://yourdomain.com/quickchat/ on your devices.

ROLES — HOW THIS WORKS NOW
  There are three ways to enter a chat, each with different access:

  MEMBER (regular participant)
    - Joins with: room name + PIN + a username
    - Can send text messages and upload common file types
      (images, docs, audio, video, zip — same as before)
    - CANNOT clear the chat or remove other people
    - If the host removes them, they're instantly kicked out and
      cannot rejoin that room until unbanned (see below)

  HOST (one per room, password-protected)
    - Logs in with: room name + host password
    - The FIRST time anyone logs in as host for a given room, whatever
      password they enter BECOMES the host password for that room —
      write it down, there's no recovery if you forget it (you'd need
      to delete data/config_<room>.json on the server to reset it)
    - The host login screen also has an optional "Set/change PIN"
      field — use it to set the PIN members need to join, or to
      change it later. Leave it blank to keep the existing PIN.
    - Can clear the chat and kick members (tap "Manage" in the header)

  SUPER USER (global accounts, defined in super_users.php)
    - Logs in with a super username/password (see super_users.php —
      not tied to any one room)
    - Bypasses the room PIN entirely — can join any room by name
    - Can upload ANY file type (only a small blocklist of
      server-executable extensions like .php/.exe is still blocked,
      purely for server safety)
    - Can clear chat and kick people, same as host
    - Can set the room's background theme and their own message glow
      color (tap "Theme" in the header) — their messages always show
      a pulsing glow border so everyone can see they're a super user
    - A super user's "room" is just whatever room name they type on
      the Super Login screen — type "common" for a shared default
      room, or any other room name to join that one specifically

  ADDING MORE SUPER USERS
    Open super_users.php and add a line following the existing
    format — there are commented examples showing exactly how.
    Currently configured:
      username: xbot   password: #123xbot   default display name: 09

SECURITY NOTES (read this)
  - Passwords in super_users.php are stored in plain text. Anyone
    with server file access could read them — don't reuse these
    passwords anywhere sensitive.
  - PINs and host passwords ARE hashed (SHA-256) before being stored,
    so they're not sitting in plain text in data/config_<room>.json.
  - This still isn't bank-grade security — SHA-256 without salting is
    fine for casual/personal use but not hardened against a
    determined attacker with server access.
  - Traffic is only encrypted if your host serves the site over
    HTTPS. Check your host's control panel for a free SSL/HTTPS
    option if you haven't enabled one.
  - Sessions last 6 hours of activity (sliding — using the chat resets
    the timer) then expire automatically.

AUTOMATIC CLEANUP (24-HOUR EXPIRY)
  Messages and their uploaded files are automatically deleted once
  they're older than 24 hours — checked lazily whenever the chat is
  loaded or polled, no cron job needed. Edit
  $messageExpirySeconds in common.php to change this.

AI CHAT (NO API KEY REQUIRED)
  Type a message starting with "@ai" or "/ai" followed by your
  question, e.g. "@ai what's a good name for a gaming website?" — the
  reply is posted into the room as "AI Assistant", visible to everyone.

  This call happens directly from your BROWSER to LLM7.io
  (https://llm7.io), a free anonymous API — not through your PHP
  server, since many free hosts block outgoing server-side requests.
  It's rate-limited (~30 requests/minute per IP); if it errors, wait
  a moment and retry. To swap providers, edit the askAi() function in
  index.html.

FILE SHARING
  Members: images, audio, video, docs (pdf/doc/xls/ppt/txt/csv/rtf),
  and archives (zip/rar/7z) — shown inline where possible, download
  card otherwise.
  Super users: everything above PLUS any other file type, except a
  small blocklist of server-executable extensions.
  Default max size: 25 MB for members, 200 MB for super users — your
  host's own PHP upload_max_filesize/post_max_size settings may cap
  this lower regardless (check your host's control panel).

CUSTOMIZING
  - POLL_INTERVAL_MS in index.html — how often the chat checks for updates
  - $maxMessages in common.php — how much chat history is kept
  - $sessionTtlSeconds in common.php — how long logins stay valid
  - $memberAllowedExtensions / $dangerousExtensions in upload.php
