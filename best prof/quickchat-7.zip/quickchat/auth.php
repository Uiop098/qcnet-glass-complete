<?php
// auth.php — handles three kinds of login:
//   action=member : join a room with its PIN
//   action=host   : log in as host (first login for a room SETS the
//                   host password and, optionally, the PIN)
//   action=super  : log in with hardcoded super user credentials,
//                   bypassing PIN/bans entirely

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
$action = isset($body['action']) ? $body['action'] : '';
$room = isset($body['room']) ? $body['room'] : '';

function clean_username($raw) {
    $u = mb_substr(trim(strip_tags((string)$raw)), 0, 40);
    return $u;
}

if ($action === 'member') {
    $pin = trim((string)($body['pin'] ?? ''));
    $username = clean_username($body['username'] ?? '');

    if ($room === '' || $pin === '' || $username === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Room, PIN, and username are all required.']);
        exit;
    }
    if (strtolower($username) === 'host' || strtolower($username) === 'ai assistant') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'That username is reserved. Please choose another.']);
        exit;
    }

    $config = read_config($room);
    if (!$config) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'This room hasn\'t been set up yet. Ask the host to log in first.']);
        exit;
    }
    if (empty($config['pinHash'])) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'The host hasn\'t set a PIN for this room yet.']);
        exit;
    }
    if (hash('sha256', $pin) !== $config['pinHash']) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Incorrect PIN.']);
        exit;
    }
    if (is_banned($config, $username)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'You have been removed from this chat by the host.']);
        exit;
    }

    $token = create_session($room, $username, 'member');
    echo json_encode(['ok' => true, 'token' => $token, 'role' => 'member', 'user' => $username]);
    exit;
}

if ($action === 'host') {
    $hostPassword = trim((string)($body['hostPassword'] ?? ''));
    $newPin = isset($body['newPin']) ? trim((string)$body['newPin']) : '';

    if ($room === '' || $hostPassword === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Room and host password are required.']);
        exit;
    }

    $config = read_config($room);
    $isNewRoom = false;
    if (!$config) {
        $config = default_config();
        $isNewRoom = true;
    }

    if ($isNewRoom || empty($config['hostPasswordHash'])) {
        // First host login for this room sets the host password.
        $config['hostPasswordHash'] = hash('sha256', $hostPassword);
    } else {
        if (hash('sha256', $hostPassword) !== $config['hostPasswordHash']) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Incorrect host password.']);
            exit;
        }
    }

    if ($newPin !== '') {
        $config['pinHash'] = hash('sha256', $newPin);
    }

    write_config($room, $config);

    $token = create_session($room, 'Host', 'host');
    echo json_encode([
        'ok' => true,
        'token' => $token,
        'role' => 'host',
        'user' => 'Host',
        'pinIsSet' => !empty($config['pinHash']),
    ]);
    exit;
}

if ($action === 'super') {
    $superUsername = trim((string)($body['superUsername'] ?? ''));
    $superPassword = (string)($body['superPassword'] ?? '');
    $displayName = clean_username($body['displayName'] ?? '');

    if ($room === '' || $superUsername === '' || $superPassword === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Room, username, and password are all required.']);
        exit;
    }

    $superUsers = require __DIR__ . '/super_users.php';

    if (!isset($superUsers[$superUsername]) || !hash_equals($superUsers[$superUsername][0], $superPassword)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Invalid super user credentials.']);
        exit;
    }

    if ($displayName === '') {
        $displayName = $superUsers[$superUsername][1];
    }

    $config = read_config($room);
    if (!$config) {
        $config = default_config();
        write_config($room, $config);
    }

    $token = create_session($room, $displayName, 'super');
    echo json_encode(['ok' => true, 'token' => $token, 'role' => 'super', 'user' => $displayName]);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'Unknown action.']);
