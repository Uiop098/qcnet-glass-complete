<?php
// common.php — shared helpers: message storage, room config (PIN, host
// password, bans, presence, theme), and session/token management.

$GLOBALS['dataDir'] = __DIR__ . '/data';
$GLOBALS['filesDir'] = __DIR__ . '/files';
$GLOBALS['maxMessages'] = 300;
$GLOBALS['messageExpirySeconds'] = 24 * 60 * 60; // 24 hours
$GLOBALS['sessionTtlSeconds'] = 6 * 60 * 60; // 6 hours, sliding
$GLOBALS['presenceWindowMs'] = 10000; // "online" = seen in last 10s

if (!is_dir($GLOBALS['dataDir'])) {
    mkdir($GLOBALS['dataDir'], 0755, true);
}
if (!is_dir($GLOBALS['filesDir'])) {
    mkdir($GLOBALS['filesDir'], 0755, true);
}

$dataHtaccess = $GLOBALS['dataDir'] . '/.htaccess';
if (!file_exists($dataHtaccess)) {
    @file_put_contents($dataHtaccess, "Require all denied\n");
}
$filesHtaccess = $GLOBALS['filesDir'] . '/.htaccess';
if (!file_exists($filesHtaccess)) {
    @file_put_contents($filesHtaccess, "Options -Indexes\n");
}

// ---------------------------------------------------------------------
// Basic helpers
// ---------------------------------------------------------------------

function safe_room_name($room) {
    $room = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$room);
    return substr($room, 0, 64) ?: 'default';
}

function room_file($room) {
    return $GLOBALS['dataDir'] . '/room_' . safe_room_name($room) . '.json';
}

function room_config_file($room) {
    return $GLOBALS['dataDir'] . '/config_' . safe_room_name($room) . '.json';
}

function sessions_file() {
    return $GLOBALS['dataDir'] . '/sessions.json';
}

function room_files_dir($room) {
    $dir = $GLOBALS['filesDir'] . '/' . safe_room_name($room);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    return $dir;
}

function read_json_file($path) {
    if (!file_exists($path)) return null;
    $fp = fopen($path, 'r');
    if (!$fp) return null;
    flock($fp, LOCK_SH);
    $content = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    $data = json_decode($content, true);
    return $data;
}

function write_json_file($path, $data) {
    $fp = fopen($path, 'c+');
    if (!$fp) return false;
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return true;
}

// ---------------------------------------------------------------------
// Room config: PIN, host password, banned users, presence, theme
// ---------------------------------------------------------------------

function default_config() {
    return [
        'pinHash' => null,
        'hostPasswordHash' => null,
        'bannedUsers' => [],   // [{user: lowercase, ts: ms}]
        'presence' => [],      // usernameLower => {name, role, ts}
        'theme' => ['background' => '', 'glow' => ''],
    ];
}

function read_config($room) {
    $data = read_json_file(room_config_file($room));
    if (!is_array($data)) return null;
    return array_merge(default_config(), $data);
}

function write_config($room, $config) {
    return write_json_file(room_config_file($room), $config);
}

function is_banned($config, $username) {
    $uname = strtolower(trim($username));
    foreach ($config['bannedUsers'] as $b) {
        if (isset($b['user']) && $b['user'] === $uname) return true;
    }
    return false;
}

function ban_user(&$config, $username) {
    $uname = strtolower(trim($username));
    if ($uname === '') return;
    foreach ($config['bannedUsers'] as $b) {
        if (isset($b['user']) && $b['user'] === $uname) return; // already banned
    }
    $config['bannedUsers'][] = ['user' => $uname, 'ts' => round(microtime(true) * 1000)];
}

function touch_presence(&$config, $username, $role) {
    $config['presence'][strtolower($username)] = [
        'name' => $username,
        'role' => $role,
        'ts' => round(microtime(true) * 1000),
    ];
}

function active_presence($config) {
    $now = round(microtime(true) * 1000);
    $out = [];
    foreach ($config['presence'] as $p) {
        if (($now - $p['ts']) <= $GLOBALS['presenceWindowMs']) {
            $out[] = $p;
        }
    }
    return $out;
}

// ---------------------------------------------------------------------
// Sessions / tokens
// ---------------------------------------------------------------------

function read_sessions() {
    $data = read_json_file(sessions_file());
    return is_array($data) ? $data : [];
}

function write_sessions($sessions) {
    write_json_file(sessions_file(), $sessions);
}

function create_session($room, $user, $role) {
    $sessions = read_sessions();
    $now = time();
    foreach ($sessions as $t => $s) {
        if (!isset($s['expires']) || $s['expires'] < $now) unset($sessions[$t]);
    }
    $token = bin2hex(random_bytes(16));
    $sessions[$token] = [
        'room' => safe_room_name($room),
        'user' => $user,
        'role' => $role,
        'expires' => $now + $GLOBALS['sessionTtlSeconds'],
    ];
    write_sessions($sessions);
    return $token;
}

function get_session($token) {
    if (!$token) return null;
    $sessions = read_sessions();
    if (!isset($sessions[$token])) return null;
    $s = $sessions[$token];
    if (!isset($s['expires']) || $s['expires'] < time()) {
        unset($sessions[$token]);
        write_sessions($sessions);
        return null;
    }
    $sessions[$token]['expires'] = time() + $GLOBALS['sessionTtlSeconds']; // sliding expiry
    write_sessions($sessions);
    return $sessions[$token];
}

function remove_sessions_for_user($room, $username) {
    $sessions = read_sessions();
    $room = safe_room_name($room);
    $uname = strtolower(trim($username));
    $changed = false;
    foreach ($sessions as $t => $s) {
        if ($s['room'] === $room && strtolower($s['user']) === $uname) {
            unset($sessions[$t]);
            $changed = true;
        }
    }
    if ($changed) write_sessions($sessions);
}

// ---------------------------------------------------------------------
// Messages (with 24h auto-expiry)
// ---------------------------------------------------------------------

function purge_expired($room, $messages) {
    $expiryMs = $GLOBALS['messageExpirySeconds'] * 1000;
    $nowMs = round(microtime(true) * 1000);
    $changed = false;
    $kept = [];

    foreach ($messages as $m) {
        $age = $nowMs - (isset($m['ts']) ? $m['ts'] : 0);
        if ($age > $expiryMs) {
            $changed = true;
            if (isset($m['type']) && $m['type'] === 'file' && !empty($m['fileUrl'])) {
                $path = __DIR__ . '/' . ltrim($m['fileUrl'], '/');
                if (is_file($path)) @unlink($path);
            }
        } else {
            $kept[] = $m;
        }
    }

    if ($changed) {
        write_messages($room, $kept);
    }

    return $kept;
}

function read_messages($room) {
    $data = read_json_file(room_file($room));
    $messages = is_array($data) ? $data : [];
    return purge_expired($room, $messages);
}

function write_messages($room, $messages) {
    if (count($messages) > $GLOBALS['maxMessages']) {
        $messages = array_slice($messages, -1 * $GLOBALS['maxMessages']);
    }
    return write_json_file(room_file($room), $messages);
}

function next_message_id($messages) {
    $nextId = 1;
    foreach ($messages as $m) {
        if (isset($m['id']) && $m['id'] >= $nextId) {
            $nextId = $m['id'] + 1;
        }
    }
    return $nextId;
}

function append_message($room, $msg) {
    $messages = read_messages($room);
    $msg['id'] = next_message_id($messages);
    $msg['ts'] = round(microtime(true) * 1000);
    $messages[] = $msg;
    write_messages($room, $messages);
    return $msg;
}
