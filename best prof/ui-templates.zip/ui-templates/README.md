# Quick Chat — UI Templates

A reusable, framework-free chat widget: one HTML skeleton, one JS logic
file, and **11 swappable visual themes** covering major UI style trends.
Drop it into any project and pick a theme, or mix pieces from several.

```
ui-templates/
├── base/
│   ├── chat.html         ← the chat markup (copy this block into your page)
│   ├── chat-core.css     ← layout only (flexbox structure, no colors)
│   └── chat-core.js      ← all the logic (rendering, autoscroll, fake replies, theme switch)
├── themes/
│   ├── 01-skeuomorphism.css
│   ├── 02-minimalism.css
│   ├── 03-flat-design.css
│   ├── 04-bauhaus.css
│   ├── 05-bold-typography.css
│   ├── 06-neumorphism.css
│   ├── 07-glassmorphism.css
│   ├── 08-animation.css
│   ├── 09-illustration.css
│   ├── 10-dark-mode.css
│   └── 11-monochromatic.css
├── demo/
│   └── index.html        ← live demo with a dropdown to preview every theme
└── README.md
```

## How it works

- **`chat-core.css`** defines the *structure* (flexbox layout, spacing,
  sizing) and a set of CSS custom properties (`--bg`, `--accent`,
  `--bubble-out-bg`, etc.) with neutral fallback values.
- Each file in **`themes/`** overrides those custom properties (and adds
  a handful of theme-specific extras — gradients, shadows, blur, motion)
  to produce a completely different look **without touching the HTML or
  JS at all**.
- **`chat-core.js`** is framework-free vanilla JS. It handles rendering
  messages, a "smart" autoscroll (only scrolls if you were already near
  the bottom), a simulated typing indicator + reply, and a `setTheme()`
  helper that swaps the theme stylesheet and remembers your choice.

Because the JS/HTML never change between themes, you can add new theme
files later, or let users pick a theme in-app, with zero extra logic.

## Quick start (copy into a new project)

1. Copy the whole `ui-templates/` folder into your project, e.g. into
   `src/components/quick-chat/`.
2. In your page's `<head>`, load structure + one theme (order matters —
   theme must load **after** core):

   ```html
   <link rel="stylesheet" href="quick-chat/base/chat-core.css" />
   <link rel="stylesheet" id="chat-theme" href="quick-chat/themes/07-glassmorphism.css" />
   ```

   > Keep `id="chat-theme"` on that `<link>` — `ChatWidget.setTheme()`
   > looks it up by that id to swap themes at runtime.

3. Paste the markup from `base/chat.html` (the `<div class="chat-app">…`
   block) wherever you want the widget to appear.

   - **Glassmorphism only:** wrap that block in a container with class
     `glass-backdrop` (or your own colorful background) — frosted glass
     needs something behind it to blur.

4. Before `</body>`, load and initialize the JS:

   ```html
   <script src="quick-chat/base/chat-core.js"></script>
   <script>
     ChatWidget.init({
       greeting: "Hi! How can I help?",
       replies: [
         "Thanks, noted!",
         "Got it.",
         { when: ["price", "cost"], text: "Plans start at $9/mo." },
         { when: ["hello", "hi", "hey"], text: "Hey there! 👋" },
       ],
     });
   </script>
   ```

5. Open the page — you're done. To change styles later, just swap the
   `href` on the `#chat-theme` `<link>` for a different file in `themes/`.

## Wiring up a real backend

`chat-core.js` fakes replies with `pickReply()` inside `simulateReply()`.
To connect a real API, replace the body of `simulateReply()` with your
fetch call, and call `ChatWidget.appendMessage(text, 'in')` once the
response arrives — everything else (rendering, scrolling, the typing
indicator toggle) can stay exactly as-is.

## Letting users switch themes in-app

See `demo/index.html` for a working example: a `<select>` whose
`change` event calls `ChatWidget.setTheme(newHref)`. The chosen theme is
saved to `localStorage` automatically, so it persists across reloads.

## Previewing all 11 styles

Open `demo/index.html` directly in a browser (no build step, no server
required) and use the dropdown at the top to flip through every theme
live against the same chat conversation.

## The 11 themes, in one line each

| # | Theme | Core idea |
|---|-------|-----------|
| 1 | Skeuomorphism | Realistic materials — gradients, inset "carved" shadows, glossy buttons |
| 2 | Minimalism | Subtraction — whitespace, hairlines, one accent color |
| 3 | Flat Design | Solid fills only, zero gradients/shadows |
| 4 | Bauhaus Style | Primary colors + geometric shapes + thick black rules |
| 5 | Bold Typography | Oversized, heavy type as the main visual device |
| 6 | Neumorphism | Soft dual-shadow "extruded" shapes on a single-tone surface |
| 7 | Glassmorphism | Frosted translucent panels via `backdrop-filter` blur |
| 8 | Animation / Motion | Animated gradients, spring easing, pulsing status — motion as the design |
| 9 | Illustration | Playful hand-drawn-feeling SVG blob artwork behind the UI |
| 10 | Dark Mode | Layered near-black surfaces, softened contrast, minimal shadow reliance |
| 11 | Monochromatic | Every color a tint/shade of one hue, set via a single `--hue` variable |

## Notes

- No build tools, no dependencies — plain HTML/CSS/JS, works by opening
  the file directly or serving it statically.
- All comments describing *why* something works a certain way (autoscroll
  logic, reply selection, theme swapping) live in `chat-core.js` — read
  through it once before wiring up your own backend.
- Feel free to strip themes you won't use, or add a 12th by copying the
  custom-property block from any existing theme file as a starting point.
