/* ==========================================================================
   chat-core.js
   Framework-free chat logic. Works with the markup in chat.html.
   Drop this file + chat-core.css + one theme css file into any project
   and call ChatWidget.init({ ... }) once the DOM is ready.
   ========================================================================== */

const ChatWidget = (() => {

  // ---- internal state -----------------------------------------------
  let els = {};              // cached DOM references
  let botReplies = [];       // canned reply pool (array of strings, or fn)
  let replyIndex = 0;        // round-robin pointer, see pickReply()
  let typingTimeout = null;  // handle so we can cancel a pending "reply"

  /**
   * pickReply(userText)
   * ------------------------------------------------------------------
   * Very small reply-selection algorithm, meant as a placeholder for a
   * real backend call. Two strategies, tried in order:
   *
   *  1. Keyword match — if any configured reply has a `when` array of
   *     substrings and one of them appears in the user's message
   *     (case-insensitive), that reply wins. First match wins.
   *
   *  2. Round robin fallback — if nothing matches, cycle through the
   *     plain-string replies in order (replyIndex wraps with modulo),
   *     so the demo doesn't repeat the same line back-to-back.
   *
   * Swap this function out entirely to call your real API — everything
   * else (rendering, scrolling, typing indicator) stays the same.
   */
  function pickReply(userText) {
    const lower = userText.toLowerCase();

    const keywordHit = botReplies.find(
      (r) => typeof r === 'object' && r.when?.some((kw) => lower.includes(kw))
    );
    if (keywordHit) return keywordHit.text;

    const plainReplies = botReplies.filter((r) => typeof r === 'string');
    if (plainReplies.length === 0) return "Got it!";

    const reply = plainReplies[replyIndex % plainReplies.length];
    replyIndex += 1;
    return reply;
  }

  /**
   * formatTime(date)
   * Small locale-safe HH:MM formatter, avoids pulling in a date library
   * for a single label under each bubble.
   */
  function formatTime(date) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  /**
   * isScrolledNearBottom(el, threshold)
   * ------------------------------------------------------------------
   * "Smart autoscroll" check. We only want to auto-scroll to the newest
   * message if the user was already near the bottom — otherwise, if
   * they've scrolled up to read history, a new incoming message
   * shouldn't yank the viewport away from where they're reading.
   * threshold is in pixels of slack allowed.
   */
  function isScrolledNearBottom(el, threshold = 60) {
    return el.scrollHeight - el.scrollTop - el.clientHeight <= threshold;
  }

  /**
   * appendMessage(text, sender)
   * Builds and inserts one message bubble, then conditionally
   * autoscrolls per isScrolledNearBottom() above.
   */
  function appendMessage(text, sender = 'out') {
    const wasNearBottom = isScrolledNearBottom(els.messages);

    const bubble = document.createElement('div');
    bubble.className = `msg msg--${sender}`;

    const textNode = document.createElement('span');
    textNode.textContent = text; // textContent, not innerHTML — avoids XSS
    bubble.appendChild(textNode);

    const time = document.createElement('span');
    time.className = 'msg__time';
    time.textContent = formatTime(new Date());
    bubble.appendChild(time);

    els.messages.appendChild(bubble);

    if (wasNearBottom) {
      els.messages.scrollTop = els.messages.scrollHeight;
    }
  }

  /**
   * simulateReply(userText)
   * ------------------------------------------------------------------
   * Fakes network latency + "typing" so the widget feels alive with no
   * backend attached:
   *   1. show typing indicator after a short beat
   *   2. wait a duration scaled to reply length (reads more natural
   *      than a fixed delay — short replies arrive faster)
   *   3. hide indicator, append the reply
   * Cancels any previous pending reply first so rapid-fire sends don't
   * stack up multiple typing indicators.
   */
  function simulateReply(userText) {
    clearTimeout(typingTimeout);
    const reply = pickReply(userText);

    typingTimeout = setTimeout(() => {
      els.typing.hidden = false;
      els.messages.scrollTop = els.messages.scrollHeight;

      const thinkTime = 500 + Math.min(reply.length * 20, 1500);
      typingTimeout = setTimeout(() => {
        els.typing.hidden = true;
        appendMessage(reply, 'in');
      }, thinkTime);
    }, 400);
  }

  /**
   * handleSubmit(e)
   * Form submit handler: reads input, guards against empty/whitespace
   * sends, clears the field, then triggers the bot's fake reply.
   */
  function handleSubmit(e) {
    e.preventDefault();
    const text = els.input.value.trim();
    if (!text) return;

    appendMessage(text, 'out');
    els.input.value = '';
    simulateReply(text);
  }

  /**
   * setTheme(themeHref)
   * ------------------------------------------------------------------
   * Swaps the <link id="chat-theme"> stylesheet href and remembers the
   * choice in localStorage, so a theme picker (see demo/index.html)
   * persists across reloads. Because every theme only redefines CSS
   * custom properties + a few selectors, swapping the href is enough —
   * no class toggling or JS-driven style writes needed.
   */
  function setTheme(themeHref) {
    const link = document.getElementById('chat-theme');
    if (link) link.href = themeHref;
    try { localStorage.setItem('chatWidgetTheme', themeHref); } catch (_) {}
  }

  function loadSavedTheme(defaultHref) {
    let saved = null;
    try { saved = localStorage.getItem('chatWidgetTheme'); } catch (_) {}
    setTheme(saved || defaultHref);
  }

  /**
   * init(config)
   * config = {
   *   root: document (or a container element),
   *   greeting: "Hi! How can I help?"  (optional first bot message),
   *   replies: [ "sure!", { when: ["price","cost"], text: "It's $9/mo." } ],
   *   defaultTheme: "themes/02-minimalism.css" (optional)
   * }
   */
  function init(config = {}) {
    const root = config.root || document;
    els = {
      messages: root.getElementById('chatMessages'),
      typing: root.getElementById('typingIndicator'),
      form: root.getElementById('chatForm'),
      input: root.getElementById('chatInput'),
    };

    botReplies = config.replies || [
      "Thanks for the message!",
      "Got it — noted.",
      "Nice, tell me more.",
      { when: ['hello', 'hi', 'hey'], text: 'Hey there! 👋' },
      { when: ['bye'], text: 'Talk soon!' },
    ];

    els.form.addEventListener('submit', handleSubmit);

    if (config.defaultTheme) loadSavedTheme(config.defaultTheme);

    if (config.greeting) {
      appendMessage(config.greeting, 'in');
    }
  }

  return { init, setTheme, appendMessage };
})();
