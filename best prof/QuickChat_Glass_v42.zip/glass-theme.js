// Shared across all pages.
//
// 1) Restores whichever theme was last picked (localStorage survives
//    navigating to a different file, unlike in-page state).
// 2) Wires up the hamburger button (either the floating corner one, or
//    the one already inside the chat header) to open/close a slide-in
//    menu drawer.
// 3) Wires up the theme picker: a single tap-to-open trigger button
//    that lives inside the drawer (instead of 4 stacked buttons taking
//    up 4 lines), which opens a small popover sheet to pick a theme.
(function () {
  const STORAGE_KEY = 'glass_preview_theme';

  const THEMES = [
    { id: 'nocturne', label: 'Nocturne', dot: '#8b5cf6' },
    { id: 'aurora', label: 'Aurora', dot: '#2dd4bf' },
    { id: 'ember', label: 'Ember', dot: '#ff8a4c' },
    { id: 'frost', label: 'Frost', dot: '#2f6fd6' },
  ];

  let currentTheme = 'nocturne';

  function themeInfo(id) {
    return THEMES.find((t) => t.id === id) || THEMES[0];
  }

  function refreshThemeUI(theme) {
    const trigger = document.getElementById('themeTriggerBtn');
    if (trigger) {
      const info = themeInfo(theme);
      trigger.style.setProperty('--dot', info.dot);
      trigger.innerHTML =
        '<span class="dot"></span><span class="ttb-label">Theme: ' +
        info.label +
        '</span><span class="chev">›</span>';
    }
    document.querySelectorAll('.theme-option').forEach((b) => {
      const isActive = b.dataset.theme === theme;
      b.classList.toggle('active', isActive);
      b.setAttribute('aria-selected', isActive ? 'true' : 'false');
    });
  }

  function applyTheme(theme) {
    currentTheme = theme;
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem(STORAGE_KEY, theme);
    refreshThemeUI(theme);
  }

  // Restore saved theme as early as possible (avoids a flash of the
  // markup's default data-theme on load).
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) { document.body.setAttribute('data-theme', saved); currentTheme = saved; }

  function buildThemePopover() {
    let overlay = document.getElementById('themePopoverOverlay');
    if (overlay) return overlay;
    overlay = document.createElement('div');
    overlay.id = 'themePopoverOverlay';
    overlay.className = 'theme-popover-overlay';
    overlay.innerHTML =
      '<div class="theme-popover-sheet" role="dialog" aria-modal="true" aria-label="Choose UI theme">' +
      '<div class="theme-popover-header"><h3 class="fdisp">🎨 Choose theme</h3>' +
      '<button type="button" id="themePopoverClose" aria-label="Close">✕</button></div>' +
      '<div class="theme-grid" id="themeGrid"></div>' +
      '</div>';
    document.body.appendChild(overlay);

    const grid = overlay.querySelector('#themeGrid');
    THEMES.forEach((t) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'theme-option';
      b.dataset.theme = t.id;
      b.setAttribute('role', 'tab');
      b.style.setProperty('--dot', t.dot);
      b.innerHTML = '<span class="dot"></span>' + t.label;
      b.addEventListener('click', () => {
        applyTheme(t.id);
        closeThemePopover();
      });
      grid.appendChild(b);
    });

    function closeThemePopover() {
      overlay.classList.remove('open');
      overlay.setAttribute('aria-hidden', 'true');
    }
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeThemePopover(); });
    overlay.querySelector('#themePopoverClose').addEventListener('click', closeThemePopover);
    overlay._close = closeThemePopover;
    return overlay;
  }

  function buildThemeTrigger() {
    const mount = document.querySelector('.theme-switch');
    if (!mount) return;
    mount.innerHTML = '';
    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'theme-trigger-btn';
    trigger.id = 'themeTriggerBtn';
    trigger.setAttribute('aria-haspopup', 'dialog');
    mount.appendChild(trigger);
    trigger.addEventListener('click', () => {
      const overlay = buildThemePopover();
      overlay.classList.add('open');
      overlay.setAttribute('aria-hidden', 'false');
      refreshThemeUI(currentTheme);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    currentTheme = document.body.getAttribute('data-theme') || 'nocturne';
    buildThemeTrigger();
    refreshThemeUI(currentTheme);

    // ---- Menu drawer open / close ----
    const drawer = document.querySelector('.menu-drawer');
    const scrim = document.querySelector('.menu-scrim');
    const openers = document.querySelectorAll('[data-menu-open]');
    const closers = document.querySelectorAll('[data-menu-close]');

    function openDrawer() {
      if (!drawer) return;
      drawer.classList.add('open');
      if (scrim) scrim.classList.add('open');
      drawer.setAttribute('aria-hidden', 'false');
    }
    function closeDrawer() {
      if (!drawer) return;
      drawer.classList.remove('open');
      if (scrim) scrim.classList.remove('open');
      drawer.setAttribute('aria-hidden', 'true');
    }

    openers.forEach((el) =>
      el.addEventListener('click', (e) => {
        e.preventDefault();
        openDrawer();
      })
    );
    closers.forEach((el) => el.addEventListener('click', closeDrawer));
    if (scrim) scrim.addEventListener('click', closeDrawer);
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      const overlay = document.getElementById('themePopoverOverlay');
      if (overlay && overlay.classList.contains('open')) { overlay._close(); return; }
      closeDrawer();
    });
  });
})();
