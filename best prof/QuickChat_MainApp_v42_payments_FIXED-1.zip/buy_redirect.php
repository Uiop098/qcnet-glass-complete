<?php
// buy_redirect.php — this is what "Buy Super Access" in login.html now
// points to, instead of linking straight to the payment domain. It asks
// the payment gateway (server-to-server, authenticated with the same
// PAYMENT_GATEWAY_SECRET used by redeem.php) to mint a short-lived link,
// then bounces the browser there. Visiting the gateway's index.html
// directly, without going through here first, shows a "link required"
// page instead of the buy button — see the gateway's check_access.php.

require_once __DIR__ . '/common.php';

$fwIp = get_client_ip();
if (!rate_limit_allow('buy_redirect', $fwIp, 20, 600)) {
    http_response_code(429);
    header('Content-Type: text/plain');
    echo "Too many attempts — please wait a few minutes and try again.";
    exit;
}

$errorOut = null;
$link = request_access_link($errorOut);

if (!$link || empty($link['linkToken'])) {
    http_response_code(502);
    header('Content-Type: text/plain');
    echo "Could not start the purchase right now (" . ($errorOut ?: 'unknown error') . "). Please try again in a moment.";
    exit;
}

$dest = PAYMENT_GATEWAY_BASE_URL . '/?access=' . urlencode($link['linkToken']);
header('Location: ' . $dest);
exit;
