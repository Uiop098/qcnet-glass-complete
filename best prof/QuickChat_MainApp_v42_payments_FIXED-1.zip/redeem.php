<?php
// redeem.php — action=redeem_token. Takes a token bought from the
// separate payment gateway, verifies it server-to-server (that gateway
// is the only place tokens are ever created), and on success creates a
// brand-new super account here with an expiry date, then logs the
// buyer straight in (same shape of response as auth.php's super_login,
// so login.html can reuse the same "enter as super" code path).

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$fwIp = get_client_ip();
if (!rate_limit_allow('redeem_token', $fwIp, 10, 600)) {
    http_response_code(429);
    echo json_encode(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many attempts — please wait a few minutes and try again.']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
$token = trim((string)($body['token'] ?? ''));
$username = mb_substr(trim((string)($body['superUsername'] ?? '')), 0, 40);
$password = (string)($body['superPassword'] ?? '');
$displayName = mb_substr(trim((string)($body['displayName'] ?? '')), 0, 40);

if ($token === '' || $username === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Token, username, and password are all required.']);
    exit;
}
if (!preg_match('/^[a-f0-9]{48}$/', $token)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'That token looks malformed — copy it exactly as shown on the payment page.']);
    exit;
}
if (!preg_match('/^[a-zA-Z0-9_\-]{3,40}$/', $username)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Username must be 3-40 characters: letters, numbers, _ or - only.']);
    exit;
}
if (mb_strlen($password) < 6) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Password must be at least 6 characters.']);
    exit;
}

$store = read_super_credentials();
if (isset($store[$username])) {
    http_response_code(409);
    echo json_encode(['ok' => false, 'error' => 'That username is already taken. Choose another.']);
    exit;
}

$errorOut = null;
$result = redeem_access_token($token, $errorOut);
if (!$result) {
    // A gateway-side "already redeemed"/"not paid"/"invalid" message
    // reaches the person as-is; a network failure gets a clear label.
    http_response_code(502);
    echo json_encode(['ok' => false, 'error' => $errorOut ?: 'Could not verify that token.']);
    exit;
}

$durationDays = isset($result['durationDays']) ? (int)$result['durationDays'] : 10;
$purchasedAt = isset($result['purchasedAt']) && $result['purchasedAt'] > 0 ? (int)$result['purchasedAt'] : now_ms();
$expiresAt = $purchasedAt + ($durationDays * 24 * 60 * 60 * 1000);

if (now_ms() >= $expiresAt) {
    // Extremely unlikely (would mean the token sat unredeemed longer
    // than its own validity window) but handle it plainly rather than
    // silently creating an already-expired account.
    http_response_code(410);
    echo json_encode(['ok' => false, 'error' => 'This token\'s validity window has already passed.']);
    exit;
}

$finalDisplayName = $displayName !== '' ? $displayName : $username;
$store[$username] = [
    'passwordHash' => hash('sha256', $password),
    'displayName' => $finalDisplayName,
    'expiresAt' => $expiresAt,
    'source' => 'purchased',
];
write_super_credentials($store);

$masterToken = create_session($GLOBALS['MASTER_ROOM'], $finalDisplayName, 'super_master');
echo json_encode([
    'ok' => true,
    'masterToken' => $masterToken,
    'defaultDisplayName' => $finalDisplayName,
    'superUsername' => $username,
    'expiresAt' => $expiresAt,
]);
