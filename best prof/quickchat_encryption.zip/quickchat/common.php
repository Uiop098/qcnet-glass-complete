<?php
// common.php — shared helpers: message storage, room config (PIN, host
// password, bans, mutes, presence, theme, title), and session/token
// management (including the super-user "master" session used to browse
// rooms before joining one).

$GLOBALS['dataDir'] = __DIR__ . '/data';
$GLOBALS['filesDir'] = __DIR__ . '/files';
$GLOBALS['maxMessages'] = 300;
$GLOBALS['messageExpirySeconds'] = 24 * 60 * 60; // 24 hours
$GLOBALS['sessionTtlSeconds'] = 6 * 60 * 60; // 6 hours, sliding
$GLOBALS['presenceWindowMs'] = 10000; // "online" = seen in last 10s
$GLOBALS['MASTER_ROOM'] = '__super_master__'; // sentinel room for super pre-join sessions

if (!is_dir($GLOBALS['dataDir'])) {
    mkdir($GLOBALS['dataDir'], 0755, true);
}
if (!is_dir($GLOBALS['filesDir'])) {
    mkdir($GLOBALS['filesDir'], 0755, true);
}

$dataHtaccess = $GLOBALS['dataDir'] . '/.htaccess';
if (!file_exists($dataHtaccess)) {
    @file_put_contents($dataHtaccess, "Require all denied\n");
}
$filesHtaccess = $GLOBALS['filesDir'] . '/.htaccess';
if (!file_exists($filesHtaccess)) {
    @file_put_contents($filesHtaccess, "Options -Indexes\n");
}

function now_ms() {
    return round(microtime(true) * 1000);
}

// ---------------------------------------------------------------------
// Basic helpers
// ---------------------------------------------------------------------

function safe_room_name($room) {
    $room = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$room);
    return substr($room, 0, 64) ?: 'default';
}

function room_file($room) {
    return $GLOBALS['dataDir'] . '/room_' . safe_room_name($room) . '.json';
}

function room_config_file($room) {
    return $GLOBALS['dataDir'] . '/config_' . safe_room_name($room) . '.json';
}

function sessions_file() {
    return $GLOBALS['dataDir'] . '/sessions.json';
}

function room_files_dir($room) {
    $dir = $GLOBALS['filesDir'] . '/' . safe_room_name($room);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    return $dir;
}

function room_wallpapers_dir($room) {
    $dir = room_files_dir($room) . '/wallpapers';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    return $dir;
}

function read_json_file($path) {
    if (!file_exists($path)) return null;
    $fp = fopen($path, 'r');
    if (!$fp) return null;
    flock($fp, LOCK_SH);
    $content = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return json_decode($content, true);
}

function write_json_file($path, $data) {
    $fp = fopen($path, 'c+');
    if (!$fp) return false;
    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return true;
}

// ---------------------------------------------------------------------
// Room config: PIN, host password, bans, mutes, presence, theme, title
// ---------------------------------------------------------------------

function default_config() {
    return [
        'pinHash' => null,
        'hostPasswordHash' => null,
        'bannedUsers' => [],   // [{user: lowercase, ts: ms}]
        'mutedUsers' => [],    // usernameLower => muteUntilMs
        'presence' => [],      // usernameLower => {name, role, ts, typingUntil}
        'title' => '',
        'createdAt' => null,
        'lastActivity' => null,
        'roomTheme' => ['background' => '', 'glowColor' => ''], // super-controlled, room-wide
        'pinnedMessageId' => null,
        'encEnabled' => false, // client-side end-to-end encryption toggle
        'encSalt' => null,     // random, non-secret — used to derive the key from the room's encryption passphrase (never stored here)
    ];
}

function read_config($room) {
    $data = read_json_file(room_config_file($room));
    if (!is_array($data)) return null;
    return array_merge(default_config(), $data);
}

function write_config($room, $config) {
    return write_json_file(room_config_file($room), $config);
}

// End-to-end encryption toggle. The server only ever stores a random,
// non-secret salt — the actual passphrase/key never touches the server.
// Enabling (or rotating) always issues a fresh salt, since a new key means
// old ciphertext can no longer be derived-and-checked against it anyway.
function enable_encryption(&$config) {
    $config['encEnabled'] = true;
    $config['encSalt'] = base64_encode(random_bytes(16));
}

function disable_encryption(&$config) {
    $config['encEnabled'] = false;
    $config['encSalt'] = null;
}

function is_banned($config, $username) {
    $uname = strtolower(trim($username));
    foreach ($config['bannedUsers'] as $b) {
        if (isset($b['user']) && $b['user'] === $uname) return true;
    }
    return false;
}

function ban_user(&$config, $username) {
    $uname = strtolower(trim($username));
    if ($uname === '') return;
    foreach ($config['bannedUsers'] as $b) {
        if (isset($b['user']) && $b['user'] === $uname) return;
    }
    $config['bannedUsers'][] = ['user' => $uname, 'ts' => now_ms()];
}

function unban_user(&$config, $username) {
    $uname = strtolower(trim($username));
    $config['bannedUsers'] = array_values(array_filter($config['bannedUsers'], function ($b) use ($uname) {
        return !(isset($b['user']) && $b['user'] === $uname);
    }));
}

// Returns remaining mute milliseconds (>0) if currently muted, else 0.
function mute_remaining_ms($config, $username) {
    $uname = strtolower(trim($username));
    if (!isset($config['mutedUsers'][$uname])) return 0;
    $remaining = $config['mutedUsers'][$uname] - now_ms();
    return $remaining > 0 ? $remaining : 0;
}

function mute_user(&$config, $username, $minutes) {
    $uname = strtolower(trim($username));
    if ($uname === '') return;
    if ($minutes <= 0) {
        unset($config['mutedUsers'][$uname]);
    } else {
        $config['mutedUsers'][$uname] = now_ms() + ($minutes * 60 * 1000);
    }
}

function touch_presence(&$config, $username, $role) {
    $existing = isset($config['presence'][strtolower($username)]) ? $config['presence'][strtolower($username)] : [];
    $config['presence'][strtolower($username)] = [
        'name' => $username,
        'role' => $role,
        'ts' => now_ms(),
        'typingUntil' => isset($existing['typingUntil']) ? $existing['typingUntil'] : 0,
    ];
}

function set_typing(&$config, $username, $role) {
    touch_presence($config, $username, $role);
    $config['presence'][strtolower($username)]['typingUntil'] = now_ms() + 4000;
}

// Names currently typing, excluding $exceptUser, visible to everyone (not admin-only).
function typing_users($config, $exceptUser) {
    $now = now_ms();
    $exceptLower = strtolower($exceptUser);
    $out = [];
    foreach ($config['presence'] as $key => $p) {
        if ($key === $exceptLower) continue;
        if (!empty($p['typingUntil']) && $p['typingUntil'] > $now) {
            $out[] = $p['name'];
        }
    }
    return $out;
}

function active_presence($config) {
    $now = now_ms();
    $out = [];
    foreach ($config['presence'] as $p) {
        if (($now - $p['ts']) <= $GLOBALS['presenceWindowMs']) {
            $out[] = $p;
        }
    }
    return $out;
}

// List every room that has a config file, with summary info for the
// super-user room browser (no room-name typing needed).
function list_rooms() {
    $rooms = [];
    $pattern = $GLOBALS['dataDir'] . '/config_*.json';
    foreach (glob($pattern) as $path) {
        $base = basename($path, '.json');
        $slug = substr($base, strlen('config_'));
        if ($slug === '') continue;
        $config = read_config($slug);
        if (!$config) continue;

        $msgs = read_json_file(room_file($slug));
        $msgCount = is_array($msgs) ? count($msgs) : 0;

        $rooms[] = [
            'room' => $slug,
            'title' => $config['title'] !== '' ? $config['title'] : $slug,
            'createdAt' => $config['createdAt'],
            'lastActivity' => $config['lastActivity'],
            'hostSet' => !empty($config['hostPasswordHash']),
            'pinSet' => !empty($config['pinHash']),
            'encEnabled' => !empty($config['encEnabled']),
            'activeUsers' => active_presence($config),
            'messageCount' => $msgCount,
        ];
    }
    usort($rooms, function ($a, $b) {
        $at = $a['lastActivity'] ?? $a['createdAt'] ?? 0;
        $bt = $b['lastActivity'] ?? $b['createdAt'] ?? 0;
        return $bt <=> $at;
    });
    return $rooms;
}

// ---------------------------------------------------------------------
// Sessions / tokens
// ---------------------------------------------------------------------

function read_sessions() {
    $data = read_json_file(sessions_file());
    return is_array($data) ? $data : [];
}

function write_sessions($sessions) {
    write_json_file(sessions_file(), $sessions);
}

function create_session($room, $user, $role) {
    $sessions = read_sessions();
    $now = time();
    foreach ($sessions as $t => $s) {
        if (!isset($s['expires']) || $s['expires'] < $now) unset($sessions[$t]);
    }
    $token = bin2hex(random_bytes(16));
    $roomSlug = ($room === $GLOBALS['MASTER_ROOM']) ? $GLOBALS['MASTER_ROOM'] : safe_room_name($room);
    $sessions[$token] = [
        'room' => $roomSlug,
        'user' => $user,
        'role' => $role,
        'expires' => $now + $GLOBALS['sessionTtlSeconds'],
    ];
    write_sessions($sessions);
    return $token;
}

function get_session($token) {
    if (!$token) return null;
    $sessions = read_sessions();
    if (!isset($sessions[$token])) return null;
    $s = $sessions[$token];
    if (!isset($s['expires']) || $s['expires'] < time()) {
        unset($sessions[$token]);
        write_sessions($sessions);
        return null;
    }
    $sessions[$token]['expires'] = time() + $GLOBALS['sessionTtlSeconds'];
    write_sessions($sessions);
    return $sessions[$token];
}

function remove_sessions_for_user($room, $username) {
    $sessions = read_sessions();
    $room = safe_room_name($room);
    $uname = strtolower(trim($username));
    $changed = false;
    foreach ($sessions as $t => $s) {
        if ($s['room'] === $room && strtolower($s['user']) === $uname) {
            unset($sessions[$t]);
            $changed = true;
        }
    }
    if ($changed) write_sessions($sessions);
}

function remove_host_sessions($room) {
    $sessions = read_sessions();
    $room = safe_room_name($room);
    $changed = false;
    foreach ($sessions as $t => $s) {
        if ($s['room'] === $room && $s['role'] === 'host') {
            unset($sessions[$t]);
            $changed = true;
        }
    }
    if ($changed) write_sessions($sessions);
}

// ---------------------------------------------------------------------
// Messages (with 24h auto-expiry)
// ---------------------------------------------------------------------

function purge_expired($room, $messages) {
    $expiryMs = $GLOBALS['messageExpirySeconds'] * 1000;
    $nowMs = now_ms();
    $changed = false;
    $kept = [];

    foreach ($messages as $m) {
        $age = $nowMs - (isset($m['ts']) ? $m['ts'] : 0);
        if ($age > $expiryMs) {
            $changed = true;
            if (isset($m['type']) && $m['type'] === 'file' && !empty($m['fileUrl'])) {
                $path = __DIR__ . '/' . ltrim($m['fileUrl'], '/');
                if (is_file($path)) @unlink($path);
            }
        } else {
            $kept[] = $m;
        }
    }

    if ($changed) {
        write_messages($room, $kept);
    }

    return $kept;
}

function read_messages($room) {
    $data = read_json_file(room_file($room));
    $messages = is_array($data) ? $data : [];
    return purge_expired($room, $messages);
}

function write_messages($room, $messages) {
    if (count($messages) > $GLOBALS['maxMessages']) {
        $messages = array_slice($messages, -1 * $GLOBALS['maxMessages']);
    }
    return write_json_file(room_file($room), $messages);
}

function find_message($room, $id) {
    $messages = read_messages($room);
    foreach ($messages as $m) {
        if (isset($m['id']) && $m['id'] == $id) return $m;
    }
    return null;
}

// Builds a short quoted snippet of a message for use as a reply-to preview.
function build_reply_snippet($msg) {
    if (!$msg) return null;
    $text = isset($msg['text']) ? $msg['text'] : '';
    if ($text === '' && isset($msg['type']) && $msg['type'] === 'file') {
        $text = '📎 ' . (isset($msg['fileName']) ? $msg['fileName'] : 'file');
    }
    // Encrypted envelopes must stay intact — truncating a base64 ciphertext
    // blob makes it undecryptable client-side. Plain text still gets trimmed.
    if (strpos($text, 'encv1:') !== 0) {
        $text = mb_substr(str_replace("\n", ' ', $text), 0, 120);
    }
    return [
        'id' => $msg['id'],
        'user' => $msg['user'],
        'text' => $text,
    ];
}

// Toggles $username's reaction with $emoji on a message. A user can only
// have one active reaction per message — picking a new emoji replaces
// their old one on that message.
function toggle_reaction($room, $messageId, $username, $emoji) {
    $messages = read_messages($room);
    $found = false;
    $userLower = strtolower($username);
    foreach ($messages as &$m) {
        if (!isset($m['id']) || $m['id'] != $messageId) continue;
        $found = true;
        if (!isset($m['reactions']) || !is_array($m['reactions'])) $m['reactions'] = [];

        $hadThisEmoji = isset($m['reactions'][$emoji]) && in_array($username, $m['reactions'][$emoji], true);

        // Remove this user from every emoji bucket first.
        foreach ($m['reactions'] as $e => $users) {
            $m['reactions'][$e] = array_values(array_filter($users, function ($u) use ($username) {
                return strtolower($u) !== $userLower;
            }));
            if (empty($m['reactions'][$e])) unset($m['reactions'][$e]);
        }

        // Re-add only if they weren't already reacting with this same emoji (i.e. toggle off).
        if (!$hadThisEmoji) {
            if (!isset($m['reactions'][$emoji])) $m['reactions'][$emoji] = [];
            $m['reactions'][$emoji][] = $username;
        }
        break;
    }
    unset($m);
    if ($found) write_messages($room, $messages);
    return $found ? find_message($room, $messageId) : null;
}

function next_message_id($messages) {
    $nextId = 1;
    foreach ($messages as $m) {
        if (isset($m['id']) && $m['id'] >= $nextId) {
            $nextId = $m['id'] + 1;
        }
    }
    return $nextId;
}

function append_message($room, $msg) {
    $messages = read_messages($room);
    $msg['id'] = next_message_id($messages);
    $msg['ts'] = now_ms();
    $messages[] = $msg;
    write_messages($room, $messages);

    // bump last-activity on the room config too
    $config = read_config($room);
    if ($config) {
        $config['lastActivity'] = $msg['ts'];
        write_config($room, $config);
    }

    return $msg;
}
