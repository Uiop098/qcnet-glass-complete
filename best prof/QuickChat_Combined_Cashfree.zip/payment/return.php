<?php
// payment/return.php — Cashfree redirects the buyer's browser HERE
// after checkout (see the return_url built in create_order.php).
// Unlike Razorpay's JS callback (which hands the browser a signature to
// verify), Cashfree's redirect can't be trusted on its own — a person
// could land on this URL with any order_id. So this always re-checks
// the order's real status directly against Cashfree's API before
// treating it as paid.

require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

$orderId = isset($_GET['order_id']) ? trim((string)$_GET['order_id']) : '';

function render_page($bodyHtml) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
       . '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
       . '<title>QuickChat Super Access</title><style>'
       . 'body{margin:0;min-height:100vh;font-family:Segoe UI,Roboto,sans-serif;color:#f3eefc;'
       . 'background:radial-gradient(700px 600px at 85% 90%,#8b5cf6 0%,transparent 45%),linear-gradient(160deg,#1b1030,#05040a);'
       . 'display:flex;align-items:center;justify-content:center;padding:20px;}'
       . '.card{width:100%;max-width:380px;background:rgba(139,92,246,0.10);border:1px solid rgba(255,255,255,0.14);'
       . 'border-radius:22px;padding:28px 24px;text-align:center;backdrop-filter:blur(18px);}'
       . 'h1{font-size:20px;margin:0 0 12px;} a{color:#b388ff;}'
       . '.token-box{font-family:monospace;font-size:13px;word-break:break-all;background:rgba(0,0,0,0.3);padding:10px;border-radius:10px;margin:14px 0;}'
       . '.copy-btn{border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.08);color:#f3eefc;border-radius:8px;padding:7px 14px;font-size:12px;cursor:pointer;}'
       . '.fine-print{font-size:11px;color:#a89bc2;margin-top:14px;line-height:1.6;}'
       . '</style></head><body><div class="card">' . $bodyHtml . '</div></body></html>';
    exit;
}

if ($orderId === '' || !preg_match('/^qc_[a-f0-9]{20}$/', $orderId)) {
    render_page('<h1>Something went wrong</h1><div class="fine-print">No valid order was found. If you completed a payment, contact support with your bank/UPI reference.<br><br><a href="../login.html">&larr; Back to QuickChat</a></div>');
}

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM tokens WHERE gateway_order_id = :order_id LIMIT 1');
$stmt->execute(['order_id' => $orderId]);
$row = $stmt->fetch();

if (!$row) {
    render_page('<h1>Order not found</h1><div class="fine-print">We could not find that order. If you completed a payment, contact support.<br><br><a href="../login.html">&larr; Back to QuickChat</a></div>');
}

// Already confirmed (e.g. the webhook beat us to it) — show the same
// token instead of re-verifying or issuing a second one.
if ($row['status'] !== 'pending') {
    render_page(
        '<h1>✅ Payment successful!</h1>'
        . '<div class="token-box" id="tokenBox">' . htmlspecialchars($row['token']) . '</div>'
        . '<button class="copy-btn" onclick="navigator.clipboard.writeText(document.getElementById(\'tokenBox\').textContent);this.textContent=\'Copied!\'">Copy token</button>'
        . '<div class="fine-print">Paste this into QuickChat &rarr; Login &rarr; Redeem tab. Valid for ' . (int)$row['duration_days'] . ' days from purchase.</div>'
        . '<div class="fine-print"><a href="../login.html">Go to QuickChat login &rarr;</a></div>'
    );
}

// Still "pending" in our DB — ask Cashfree directly what actually happened.
$errorOut = null;
$order = cashfree_get_order($orderId, $errorOut);
if (!$order) {
    render_page('<h1>Could not confirm payment</h1><div class="fine-print">' . htmlspecialchars($errorOut ?: 'Unknown error') . ' Please refresh this page in a minute — Cashfree may still be processing.<br><br><a href="../login.html">&larr; Back to QuickChat</a></div>');
}

$status = $order['order_status'] ?? '';

if ($status !== 'PAID') {
    render_page(
        '<h1>Payment not completed</h1>'
        . '<div class="fine-print">Order status: ' . htmlspecialchars($status ?: 'unknown') . '. If you completed payment and see this, wait a minute and refresh — otherwise, go back and try again.</div>'
        . '<div class="fine-print"><a href="../login.html">&larr; Back to QuickChat</a></div>'
    );
}

// Confirmed PAID — mint the token (single UPDATE guarded by the
// "pending" check so a concurrent webhook call can't double-issue one).
$accessToken = generate_access_token();
$upd = $pdo->prepare(
    'UPDATE tokens SET token = :token, gateway_payment_id = :payment_id, status = "paid", paid_at = :now
     WHERE gateway_order_id = :order_id AND status = "pending"'
);
$upd->execute([
    'token' => $accessToken,
    'payment_id' => isset($order['cf_order_id']) ? (string)$order['cf_order_id'] : null,
    'now' => now_ms(),
    'order_id' => $orderId,
]);

if ($upd->rowCount() === 0) {
    // Lost the race to the webhook between our SELECT and UPDATE.
    $stmt->execute(['order_id' => $orderId]);
    $row = $stmt->fetch();
    $accessToken = $row['token'];
}

// Purchase complete — the Buy session is now spent.
session_start();
unset($_SESSION['buy_access_until']);

render_page(
    '<h1>✅ Payment successful!</h1>'
    . '<div class="token-box" id="tokenBox">' . htmlspecialchars($accessToken) . '</div>'
    . '<button class="copy-btn" onclick="navigator.clipboard.writeText(document.getElementById(\'tokenBox\').textContent);this.textContent=\'Copied!\'">Copy token</button>'
    . '<div class="fine-print">Paste this into QuickChat &rarr; Login &rarr; Redeem tab. Valid for ' . (int)OFFER_DURATION_DAYS . ' days from now.</div>'
    . '<div class="fine-print"><a href="../login.html">Go to QuickChat login &rarr;</a></div>'
);
