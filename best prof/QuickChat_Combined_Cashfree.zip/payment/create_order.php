<?php
// payment/create_order.php — called by buy.php right before opening
// Cashfree Checkout. Creates the order on Cashfree's side and a
// matching "pending" row here, so we have a place to attach the access
// token once payment succeeds.

require_once __DIR__ . '/../common.php'; // get_client_ip(), rate_limit_allow(), now_ms()
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') pg_json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);

session_start();
if (empty($_SESSION['buy_access_until']) || $_SESSION['buy_access_until'] <= now_ms()) {
    pg_json_out(['ok' => false, 'error' => 'no_access', 'message' => 'Your Buy session expired. Go back to QuickChat and click "Buy Super Access" again.'], 403);
}

$ip = get_client_ip();
if (!rate_limit_allow('create_order', $ip, 10, 600)) {
    pg_json_out(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many attempts — please wait a few minutes and try again.'], 429);
}

// Unlike Razorpay (which generates the order id for you), Cashfree
// expects US to pick one — must be unique per order.
$orderId = 'qc_' . bin2hex(random_bytes(10));

// Cashfree redirects the browser back here after checkout, appending
// ?order_id=... itself.
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$returnUrl = $scheme . '://' . $_SERVER['HTTP_HOST'] . '/payment/return.php?order_id={order_id}';

$errorOut = null;
$order = cashfree_create_order($orderId, OFFER_AMOUNT_INR, OFFER_CURRENCY, $returnUrl, $errorOut);
if (!$order || empty($order['payment_session_id'])) {
    pg_json_out(['ok' => false, 'error' => 'order_failed', 'message' => $errorOut ?: 'Could not create order.'], 502);
}

$stmt = db()->prepare(
    'INSERT INTO tokens (token, gateway_order_id, amount_inr, currency, duration_days, status, buyer_ip, created_at)
     VALUES (:token, :order_id, :amount, :currency, :duration, "pending", :ip, :now)'
);
// Placeholder token until payment is confirmed — return.php / webhook.php
// overwrite this with the real access token at that point.
$stmt->execute([
    'token' => 'pending_' . $orderId,
    'order_id' => $orderId,
    'amount' => OFFER_AMOUNT_INR,
    'currency' => OFFER_CURRENCY,
    'duration' => OFFER_DURATION_DAYS,
    'ip' => $ip,
    'now' => now_ms(),
]);

pg_json_out([
    'ok' => true,
    'orderId' => $orderId,
    'paymentSessionId' => $order['payment_session_id'],
    'mode' => CASHFREE_MODE,
]);
