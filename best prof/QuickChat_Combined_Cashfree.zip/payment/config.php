<?php
// payment/config.php — every value in here MUST be changed before you go
// live. Blocked from direct browser access by payment/.htaccess.

// ---------------------------------------------------------------------
// 1) MySQL — create a database in your InfinityFree control panel
//    (Control Panel -> MySQL Databases), then paste its details here.
//    InfinityFree DB hostnames are usually NOT "localhost" — copy the
//    exact hostname shown next to your database (something like
//    sqlXXX.infinityfree.com).
// ---------------------------------------------------------------------
define('DB_HOST', 'sql211.infinityfree.com');
define('DB_NAME', 'if0_41238775_passingwork_database');
define('DB_USER', 'if0_41238775');
define('DB_PASS', 'rrriop01');

// ---------------------------------------------------------------------
// 2) Cashfree — PRODUCTION keys, from https://merchant.cashfree.com ->
//    Developers -> API Keys -> Production. These process REAL money —
//    double check the amount below before going live.
//
//    Production API keys are only issued after Cashfree approves your
//    account (business KYC, bank details, etc. under Settings ->
//    Business Settings on the merchant dashboard). If you don't have
//    Production keys yet, you'll need to complete that first — trying
//    to use Sandbox keys with CASHFREE_MODE set to 'production' below
//    will fail with an authentication error.
// ---------------------------------------------------------------------
define('CASHFREE_MODE', 'production');   // 'sandbox' while testing, 'production' when live
define('CASHFREE_APP_ID', '13882855287c0c607763abf4e5c5828831');
define('CASHFREE_SECRET_KEY', 'cfsk_ma_prod_1c287184abf205f7d600c91b5e027ccd_013c24e9');
define('CASHFREE_API_VERSION', '2023-08-01');

// Developers -> Webhooks -> Add Webhook on the Cashfree dashboard.
//   Webhook URL: https://yourdomain.com/payment/webhook.php
//   Event: PAYMENT_SUCCESS_WEBHOOK
// Cashfree signs webhooks using the same CASHFREE_SECRET_KEY above —
// no separate webhook secret to configure.

define('CASHFREE_BASE_URL',
    CASHFREE_MODE === 'production'
        ? 'https://api.cashfree.com/pg'
        : 'https://sandbox.cashfree.com/pg'
);

// ---------------------------------------------------------------------
// 3) The offer. Amount is in RUPEES for Cashfree (unlike Razorpay,
//    which used paise) — 1 = ₹1.00.
// ---------------------------------------------------------------------
define('OFFER_AMOUNT_INR', 1);          // ₹1
define('OFFER_CURRENCY', 'INR');
define('OFFER_DURATION_DAYS', 10);
define('OFFER_LABEL', 'QuickChat Super Access — 10 days');

require_once __DIR__ . '/db.php';
