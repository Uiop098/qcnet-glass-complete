-- payment/schema.sql — run this once in your InfinityFree control
-- panel's phpMyAdmin (open your database -> SQL tab -> paste -> Go).
--
-- If you previously ran the Razorpay version of this schema, DROP that
-- old `tokens` table first (Cashfree uses rupees, not paise, and
-- generic column names instead of razorpay_-prefixed ones):
--   DROP TABLE IF EXISTS tokens;

CREATE TABLE IF NOT EXISTS tokens (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  token              VARCHAR(64)  NOT NULL,
  gateway_order_id   VARCHAR(64)  NOT NULL,
  gateway_payment_id VARCHAR(64)  NULL,
  amount_inr         DECIMAL(10,2) NOT NULL,
  currency           VARCHAR(8)   NOT NULL DEFAULT 'INR',
  duration_days      INT UNSIGNED NOT NULL,
  status             ENUM('pending','paid','redeemed') NOT NULL DEFAULT 'pending',
  buyer_ip           VARCHAR(64)  NULL,
  created_at         BIGINT UNSIGNED NOT NULL,
  paid_at            BIGINT UNSIGNED NULL,
  redeemed_at        BIGINT UNSIGNED NULL,
  redeemed_by_app_ip VARCHAR(64)  NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_token (token),
  UNIQUE KEY uq_order (gateway_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
