<?php
// payment/lib.php — Cashfree + access-token helpers. Deliberately does
// NOT define now_ms(), get_client_ip(), or rate_limit_allow() — those
// already exist in ../common.php and ../firewall.php, which every file
// in this folder requires before this one, to avoid a fatal "cannot
// redeclare" error.

function generate_access_token() {
    return bin2hex(random_bytes(24)); // 48 hex chars
}

function pg_json_out($arr, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($arr);
    exit;
}

// Shared low-level caller for Cashfree's REST API — every Cashfree call
// uses the same header shape (API-key auth, not Basic auth like
// Razorpay). Uses file_get_contents + stream_context (not curl) — the
// same approach the rest of QuickChat already uses successfully for
// outbound calls (Tenor GIFs, translation) on InfinityFree.
function cashfree_request($method, $path, $body = null, &$errorOut = null) {
    $headers = "Content-Type: application/json\r\n"
             . "x-client-id: " . CASHFREE_APP_ID . "\r\n"
             . "x-client-secret: " . CASHFREE_SECRET_KEY . "\r\n"
             . "x-api-version: " . CASHFREE_API_VERSION . "\r\n";

    $ctx = stream_context_create([
        'http' => [
            'method' => $method,
            'header' => $headers,
            'content' => $body !== null ? json_encode($body) : null,
            'timeout' => 15,
            'ignore_errors' => true,
        ],
    ]);

    $result = @file_get_contents(CASHFREE_BASE_URL . $path, false, $ctx);
    if ($result === false) {
        $errorOut = 'Could not reach Cashfree (network error, or outbound HTTPS is blocked on this host).';
        return null;
    }

    $data = json_decode($result, true);
    if (!is_array($data)) {
        $errorOut = 'Cashfree returned an unexpected response.';
        return null;
    }
    // Cashfree error responses include a "message" (and sometimes "code"/"type").
    if (isset($data['message']) && isset($data['type']) && strpos($data['type'], 'error') !== false) {
        $errorOut = $data['message'];
        return null;
    }
    return $data;
}

// Creates a Cashfree Order. $orderId is ours (we generate it), unlike
// Razorpay where the gateway generated the order id for us.
// Returns the decoded order array (includes payment_session_id used by
// the Cashfree JS SDK), or null + $errorOut.
function cashfree_create_order($orderId, $amountInr, $currency, $returnUrl, &$errorOut = null) {
    $payload = [
        'order_id' => $orderId,
        'order_amount' => (float)$amountInr,
        'order_currency' => $currency,
        'customer_details' => [
            // Cashfree requires a customer_id/email/phone even for a
            // simple one-off purchase like this — synthetic values are
            // fine since we don't otherwise collect buyer identity here.
            'customer_id' => 'qc_' . substr(md5($orderId), 0, 16),
            'customer_email' => 'buyer+' . substr(md5($orderId), 0, 8) . '@example.com',
            'customer_phone' => '9999999999',
        ],
        'order_meta' => [
            'return_url' => $returnUrl, // Cashfree appends ?order_id=... automatically
        ],
    ];
    return cashfree_request('POST', '/orders', $payload, $errorOut);
}

// Fetches an order's current status directly from Cashfree — this is
// the authoritative check after the browser lands back on return.php,
// since Cashfree's redirect flow (unlike Razorpay's JS callback) can't
// be trusted on its own; always re-verify server-side against Cashfree.
function cashfree_get_order($orderId, &$errorOut = null) {
    return cashfree_request('GET', '/orders/' . urlencode($orderId), null, $errorOut);
}

// Verifies a Cashfree WEBHOOK signature.
// Per Cashfree docs: expected = base64( HMAC-SHA256(timestamp + rawBody, CASHFREE_SECRET_KEY) )
function cashfree_verify_webhook_signature($rawBody, $timestamp, $signature) {
    $expected = base64_encode(hash_hmac('sha256', $timestamp . $rawBody, CASHFREE_SECRET_KEY, true));
    return hash_equals($expected, (string)$signature);
}
