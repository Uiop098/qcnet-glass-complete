<?php
// payment/webhook.php — Cashfree calls this directly, server-to-server,
// when a payment succeeds. This is the SOURCE OF TRUTH: unlike
// return.php (which depends on the buyer's browser successfully
// redirecting back), this fires even if they closed the tab or their
// bank redirect got interrupted. Point Cashfree's dashboard webhook at:
//   https://yourdomain.com/payment/webhook.php
// with event "PAYMENT_SUCCESS_WEBHOOK".
//
// Idempotent by design: if return.php already marked this order paid,
// this just no-ops instead of issuing a second token.

require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

$rawBody = file_get_contents('php://input');
$timestamp = isset($_SERVER['HTTP_X_WEBHOOK_TIMESTAMP']) ? $_SERVER['HTTP_X_WEBHOOK_TIMESTAMP'] : '';
$signature = isset($_SERVER['HTTP_X_WEBHOOK_SIGNATURE']) ? $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] : '';

if (!cashfree_verify_webhook_signature($rawBody, $timestamp, $signature)) {
    http_response_code(400);
    exit('bad signature');
}

$data = json_decode($rawBody, true);
$eventType = isset($data['type']) ? $data['type'] : '';

if ($eventType !== 'PAYMENT_SUCCESS_WEBHOOK') {
    http_response_code(200); // acknowledge everything else, we just don't act on it
    exit('ignored');
}

$orderId = $data['data']['order']['order_id'] ?? null;
$paymentId = $data['data']['payment']['cf_payment_id'] ?? null;
$paymentStatus = $data['data']['payment']['payment_status'] ?? '';

if (!$orderId || $paymentStatus !== 'SUCCESS') {
    http_response_code(200);
    exit('not a successful payment');
}

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM tokens WHERE gateway_order_id = :order_id LIMIT 1');
$stmt->execute(['order_id' => $orderId]);
$row = $stmt->fetch();

if (!$row) {
    // Order not found — most likely create_order.php's insert didn't
    // happen (shouldn't occur in normal flow). Nothing safe to do.
    http_response_code(200);
    exit('unknown order');
}

if ($row['status'] === 'pending') {
    $accessToken = generate_access_token();
    $upd = $pdo->prepare(
        'UPDATE tokens SET token = :token, gateway_payment_id = :payment_id, status = "paid", paid_at = :now
         WHERE gateway_order_id = :order_id AND status = "pending"'
    );
    $upd->execute(['token' => $accessToken, 'payment_id' => $paymentId, 'now' => now_ms(), 'order_id' => $orderId]);
}

http_response_code(200);
echo 'ok';
