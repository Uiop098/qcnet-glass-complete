<?php
// payment/buy.php — this is what buy_redirect.php sends people to after
// they click "Buy Super Access" on the login page. Reaching this page
// directly (without going through buy_redirect.php first) shows a
// blocked message instead of the offer — see the session check below.
//
// Same-site session gate: buy_redirect.php sets $_SESSION['buy_access_until']
// right before redirecting here. No signed link, no second domain, no
// network call needed — it's all one PHP app now, so a native PHP
// session is enough.

require_once __DIR__ . '/../common.php'; // get_client_ip(), rate_limit_allow(), now_ms()
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

session_start();
$hasAccess = !empty($_SESSION['buy_access_until']) && $_SESSION['buy_access_until'] > now_ms();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>QuickChat Super Access</title>
<style>
  :root { --bg-a:#1b1030; --bg-b:#05040a; --accent:#b388ff; --text-hi:#f3eefc; --text-lo:#a89bc2; --border:rgba(255,255,255,0.14); }
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; font-family: 'Segoe UI', Roboto, sans-serif; color: var(--text-hi);
    background: radial-gradient(700px 600px at 85% 90%, #8b5cf6 0%, transparent 45%), linear-gradient(160deg, var(--bg-a), var(--bg-b));
    display: flex; align-items: center; justify-content: center; padding: 20px;
  }
  .card {
    width: 100%; max-width: 380px; background: rgba(139,92,246,0.10); border: 1px solid var(--border);
    border-radius: 22px; padding: 28px 24px; text-align: center; backdrop-filter: blur(18px);
  }
  .badge { display: inline-block; background: rgba(139,92,246,0.25); border: 1px solid var(--border); border-radius: 999px; padding: 5px 14px; font-size: 11px; letter-spacing: 0.05em; text-transform: uppercase; margin-bottom: 14px; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .price { font-size: 44px; font-weight: 800; margin: 14px 0 2px; }
  .price small { font-size: 16px; font-weight: 500; color: var(--text-lo); }
  .duration { font-size: 13px; color: var(--text-lo); margin-bottom: 20px; }
  ul { text-align: left; font-size: 13px; color: var(--text-lo); line-height: 1.9; padding-left: 20px; margin: 0 0 22px; }
  button.pay {
    width: 100%; border: none; border-radius: 999px; background: var(--accent); color: #14101f;
    font-weight: 700; font-size: 15px; padding: 14px; cursor: pointer;
  }
  button.pay:disabled { opacity: 0.6; cursor: not-allowed; }
  .fine-print { font-size: 10.5px; color: var(--text-lo); margin-top: 14px; line-height: 1.6; }
  .result { display: none; margin-top: 18px; padding: 16px; border-radius: 14px; background: rgba(255,255,255,0.06); border: 1px solid var(--border); text-align: left; }
  .result.show { display: block; }
  .result.error { border-color: #ff8a8a; }
  .token-box { font-family: monospace; font-size: 13px; word-break: break-all; background: rgba(0,0,0,0.3); padding: 10px; border-radius: 10px; margin: 10px 0; }
  .copy-btn { border: 1px solid var(--border); background: rgba(255,255,255,0.08); color: var(--text-hi); border-radius: 8px; padding: 7px 14px; font-size: 12px; cursor: pointer; }
</style>
</head>
<body>

<?php if (!$hasAccess): ?>

<div class="card">
  <div class="badge">Link required</div>
  <h1>This page isn't open directly</h1>
  <div class="fine-print">You need to come from QuickChat's login page. Go back and click "Buy Super Access" — it'll bring you straight back here.</div>
  <div class="fine-print"><a href="../login.html" style="color:var(--accent)">&larr; Back to QuickChat</a></div>
</div>

<?php else: ?>

<div class="card">
  <div class="badge">Limited-time offer</div>
  <h1>QuickChat Super Access</h1>
  <div class="price">₹<?= (int)OFFER_AMOUNT_INR ?> <small>one-time</small></div>
  <div class="duration">Valid for <?= (int)OFFER_DURATION_DAYS ?> days from purchase</div>
  <ul>
    <li>Log into any QuickChat room without a PIN</li>
    <li>Upload any file type</li>
    <li>Custom room wallpaper &amp; message glow color</li>
    <li>Glowing "Super" badge in chat</li>
  </ul>
  <button class="pay" id="payBtn">Pay ₹<?= (int)OFFER_AMOUNT_INR ?> &amp; Get Access</button>
  <div class="fine-print">You'll get a one-time access token after payment. Copy it into QuickChat's login screen under the "Redeem" tab to activate your account.</div>

  <div class="result" id="resultBox"></div>
</div>

<script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
<script>
const payBtn = document.getElementById('payBtn');
const resultBox = document.getElementById('resultBox');

function showResult(html, isError) {
  resultBox.innerHTML = html;
  resultBox.className = 'result show' + (isError ? ' error' : '');
}

payBtn.addEventListener('click', async () => {
  payBtn.disabled = true;
  payBtn.textContent = 'Starting…';
  try {
    const orderRes = await fetch('create_order.php', { method: 'POST' });
    const orderData = await orderRes.json();
    if (!orderRes.ok || !orderData.ok) {
      showResult((orderData.message || 'Could not start payment. Please try again.'), true);
      payBtn.disabled = false;
      payBtn.textContent = 'Pay ₹<?= (int)OFFER_AMOUNT_INR ?> & Get Access';
      return;
    }

    // Full-page redirect to Cashfree's hosted checkout. Cashfree sends
    // the browser back to payment/return.php (set as return_url when
    // the order was created) once the payment finishes — that's where
    // the token actually gets issued, since a redirect can be spoofed
    // and always needs re-checking server-side against Cashfree's API.
    const cashfree = Cashfree({ mode: orderData.mode === 'production' ? 'production' : 'sandbox' });
    cashfree.checkout({
      paymentSessionId: orderData.paymentSessionId,
      redirectTarget: '_self',
    });
  } catch (e) {
    showResult('Could not reach the payment server. Please try again.', true);
    payBtn.disabled = false;
    payBtn.textContent = 'Pay ₹<?= (int)OFFER_AMOUNT_INR ?> & Get Access';
  }
});
</script>

<?php endif; ?>

</body>
</html>
