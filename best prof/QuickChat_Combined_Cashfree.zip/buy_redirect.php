<?php
// buy_redirect.php — this is what "Buy Super Access" in login.html
// points to. It sets a short-lived session flag and sends the browser
// to payment/buy.php, which checks that flag before showing the offer.
// Visiting payment/buy.php directly, without clicking Buy first, shows
// a "link required" message instead — see payment/buy.php.
//
// Everything (chat app + payment) is one site now, so this is just a
// same-origin PHP session — no signed link, no second domain, no
// network call to anywhere.

require_once __DIR__ . '/common.php';

$fwIp = get_client_ip();
if (!rate_limit_allow('buy_redirect', $fwIp, 20, 600)) {
    http_response_code(429);
    header('Content-Type: text/plain');
    echo "Too many attempts — please wait a few minutes and try again.";
    exit;
}

session_start();
$_SESSION['buy_access_until'] = now_ms() + (20 * 60 * 1000); // 20 minutes

header('Location: payment/buy.php');
exit;
