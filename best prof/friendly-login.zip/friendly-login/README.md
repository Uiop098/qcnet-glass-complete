# User-Friendly Login Page

A single self-contained login page focused on real usability — not just
looks. Copy `friendly-login.html` into any project; no build step, no
dependencies.

## What makes it "user friendly"

| Feature | Why it helps |
|---|---|
| Floating labels | The field's purpose stays visible even after typing, unlike a placeholder that disappears |
| Inline valid/invalid marks (✓ / !) | Instant visual feedback without reading text first |
| Live password strength meter | Guides users toward a stronger password *before* they submit |
| Caps Lock warning | Catches the #1 cause of "my password isn't working" support tickets |
| Submit button disabled until valid | Prevents a failed-submit round trip for errors that are already known |
| Light/dark toggle (persisted) | Respects system preference by default, remembers manual choice via `localStorage` |
| `aria-live` regions on all hints/errors | Screen reader users get the same real-time feedback sighted users get |
| Visible focus rings on every control | Keyboard-only users can always see where they are |
| `prefers-reduced-motion` respected | Animations turn off for users who've asked for that |

## Quick start

1. Copy `friendly-login.html` into your project (rename if you like).
2. Update the brand colors in the `:root` block — both a light and a
   dark palette are defined; edit `--brand` in each.
3. Swap the placeholder `<div class="login-card__logo">` for your real
   logo.
4. Wire up real authentication: open `handleSubmit()` near the bottom of
   the `<script>` tag and replace the demo `setTimeout` with the
   commented-out `fetch()` example right above it. On a failed login,
   set `formBanner.textContent` and add the `.show` class — it's already
   wired to announce itself to screen readers via `role="alert"`.

## Notes on the strength meter

`scorePasswordStrength()` is a simple additive heuristic (length,
digits, mixed case, symbols) — good enough to nudge users in the right
direction, but not a substitute for real breach-list checking or a
library like zxcvbn if you need rigorous strength estimation server-side.

## Browser support note

The focus/validity styling uses `color-mix()` for translucent accent
tints, supported in all current major browsers (Chrome/Edge 111+,
Safari 16.2+, Firefox 113+). On older browsers the glow simply won't
show — everything else still works.
