// ---------- Glass UI theme switch (Nocturne / Aurora / Ember / Frost) ----------
// Split out of index.html's inline <script> block into its own file.
// Loaded via <script src="glass-theme.js"> in the exact spot the inline
// block used to sit — right after the hamburger menu drawer's
// openMenu/closeMenu are defined, since the theme-switch buttons live
// inside that same #menuDrawer and need to already exist in the DOM.
//
// Namespaced localStorage key so this never collides with the existing
// 'qc_light_mode' key used by #themeToggleBtn. Picking a glass theme
// also clears light-mode so the two systems don't fight — Frost
// already reads as the "light" option among the four.
(function () {
  const GLASS_KEY = 'qc_glass_theme';

  function applyGlassTheme(theme) {
    document.body.setAttribute('data-theme', theme);
    document.body.classList.remove('light-mode');
    try { localStorage.setItem(GLASS_KEY, theme); } catch (e) {}
    try { localStorage.removeItem('qc_light_mode'); } catch (e) {}
    document.querySelectorAll('.theme-switch button').forEach((b) => {
      const isActive = b.dataset.theme === theme;
      b.classList.toggle('active', isActive);
      b.setAttribute('aria-selected', isActive ? 'true' : 'false');
    });
  }

  let saved;
  try { saved = localStorage.getItem(GLASS_KEY); } catch (e) { saved = null; }
  if (saved) document.body.setAttribute('data-theme', saved);

  const current = document.body.getAttribute('data-theme') || 'nocturne';
  document.querySelectorAll('.theme-switch button').forEach((btn) => {
    const isActive = btn.dataset.theme === current;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
    btn.addEventListener('click', () => applyGlassTheme(btn.dataset.theme));
  });
})();
