<?php
// dash_chat_bridge.php — lets the Dashboard embed the real QuickChat room
// UI (room.html, in an iframe) without the user ever seeing a room-name/PIN
// login step. It mints QuickChat sessions directly via create_session()
// (the same function auth.php uses after a normal login), for two flows:
//
//   1. Admin <-> Client "chat with admin" — a fixed, deterministic room per
//      client, auto-created on first use. The admin always appears as
//      "Admin" in it; the client sees their own name.
//   2. Client <-> Client peer chat — request/accept via a short-lived
//      token, same pattern as every other invite-token flow in this app.
//      Only between clients of the SAME business (tenant) — this isn't a
//      platform-wide directory.
//
// Room PINs are still generated (for schema consistency with the rest of
// QuickChat) but never shown to anyone — access here is entirely gated by
// the Dashboard's own session + this bridge's participant checks, not by
// knowing a PIN.
require_once 'dash_firewall.php';
require_once 'dash_crypto.php';
require_once 'common.php';
require_once 'dash_audit.php';
header('Content-Type: application/json');

if (!isset($_SESSION['dash_admin']) && !isset($_SESSION['dash_user'])) die(json_encode(["error" => "Unauthorized access."]));
$is_admin = isset($_SESSION['dash_admin']);
$my_username = $is_admin ? $_SESSION['dash_admin'] : $_SESSION['dash_user'];
$tenant_id = $_SESSION['dash_tenant'] ?? 'main';
$safe_tenant = preg_replace('/[^a-zA-Z0-9_\-]/', '', $tenant_id);
$dir = ($tenant_id === 'main') ? __DIR__ . '/data_dash' : __DIR__ . '/data_dash/' . $safe_tenant;
$action = $_GET['action'] ?? '';

function tenant_admin_display($tenant_id, $dir) {
    // Admins always show as literally "Admin" inside a client's DM room —
    // requested explicitly, and it keeps a consistent identity regardless
    // of which admin account happens to be logged in.
    return 'Admin';
}
function my_display_name($dir, $username, $is_admin) {
    if ($is_admin) return tenant_admin_display(null, $dir);
    $users = get_secure_table($dir . '/users.json');
    return $users[$username]['name'] ?? $username;
}
function ensure_room($room) {
    $config = read_config($room);
    if (!$config) {
        $config = default_config();
        $config['createdAt'] = now_ms();
        $config['pinHash'] = hash('sha256', bin2hex(random_bytes(8))); // never revealed — access is bridge-gated, not PIN-gated
        write_config($room, $config);
    }
}

switch ($action) {

    case 'get_admin_dm':
        // A client opening their support channel with this business's admin.
        if ($is_admin) die(json_encode(["error" => "Open a specific client's chat from Contacts instead."]));
        $room = 'dm-' . $safe_tenant . '-' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $my_username);
        ensure_room($room);
        $token = create_session($room, my_display_name($dir, $my_username, false), 'member');
        echo json_encode(["status" => "success", "token" => $token, "room" => safe_room_name($room), "role" => "member", "user" => my_display_name($dir, $my_username, false), "peer_label" => "Admin"]);
        break;

    case 'get_dm_with_user':
        // The admin opening a specific client's support channel.
        if (!$is_admin) die(json_encode(["error" => "Only the admin can open a client's chat this way."]));
        $target = trim($_GET['username'] ?? '');
        $users = get_secure_table($dir . '/users.json');
        if (!isset($users[$target])) die(json_encode(["error" => "User not found."]));
        $room = 'dm-' . $safe_tenant . '-' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $target);
        ensure_room($room);
        $token = create_session($room, tenant_admin_display($tenant_id, $dir), 'host');
        echo json_encode(["status" => "success", "token" => $token, "room" => safe_room_name($room), "role" => "host", "user" => tenant_admin_display($tenant_id, $dir), "peer_label" => $users[$target]['name'] ?? $target]);
        break;

    case 'request_peer_chat':
        if ($is_admin) die(json_encode(["error" => "Peer chat is between clients only."]));
        if (!rate_limit_allow('chat_peer_request', get_client_ip(), 15, 600)) { http_response_code(429); die(json_encode(["error" => "Too many requests."])); }
        $target = trim($_POST['username'] ?? '');
        $users = get_secure_table($dir . '/users.json');
        if ($target === $my_username) die(json_encode(["error" => "You can't request a chat with yourself."]));
        if (!isset($users[$target])) die(json_encode(["error" => "No user with that username in this business."]));
        $requests_file = $dir . '/peer_chat_requests.json'; $requests = get_secure_table($requests_file);
        $now = time(); $requests = array_filter($requests, function ($r) use ($now) { return $r['expires_at'] > $now; });
        $alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; $token = '';
        for ($i = 0; $i < 8; $i++) { $token .= $alphabet[random_int(0, strlen($alphabet) - 1)]; }
        $requests[$token] = ["from" => $my_username, "to" => $target, "expires_at" => $now + (24 * 60 * 60)];
        save_secure_table($requests_file, $requests);
        echo json_encode(["status" => "success", "token" => $token]);
        break;

    case 'redeem_peer_token':
        if ($is_admin) die(json_encode(["error" => "Peer chat is between clients only."]));
        if (!rate_limit_allow('chat_peer_redeem', get_client_ip(), 15, 600)) { http_response_code(429); die(json_encode(["error" => "Too many attempts."])); }
        $token = strtoupper(trim($_POST['token'] ?? ''));
        $requests_file = $dir . '/peer_chat_requests.json'; $requests = get_secure_table($requests_file);
        if (!isset($requests[$token]) || $requests[$token]['expires_at'] < time()) die(json_encode(["error" => "Invalid or expired token."]));
        $from = $requests[$token]['from'];
        if ($from === $my_username) die(json_encode(["error" => "You can't redeem your own request token."]));
        $room = 'peer-' . $safe_tenant . '-' . bin2hex(random_bytes(6));
        ensure_room($room);
        $chats_file = $dir . '/peer_chats.json'; $chats = get_secure_table($chats_file);
        $chats[$room] = ["participants" => [$from, $my_username], "created_at" => time()];
        save_secure_table($chats_file, $chats);
        unset($requests[$token]); save_secure_table($requests_file, $requests);
        log_activity($dir, $my_username, 'peer_chat_started', "Started a chat with $from.");
        echo json_encode(["status" => "success", "room" => $room]);
        break;

    case 'get_my_chats':
        if ($is_admin) die(json_encode(["error" => "Not applicable for admin accounts."]));
        $users = get_secure_table($dir . '/users.json');
        $chats = get_secure_table($dir . '/peer_chats.json');
        $out = [["type" => "admin", "room" => 'dm-' . $safe_tenant . '-' . $my_username, "label" => "Admin", "icon" => "🛡️"]];
        foreach ($chats as $room => $c) {
            if (!in_array($my_username, $c['participants'], true)) continue;
            $other = $c['participants'][0] === $my_username ? $c['participants'][1] : $c['participants'][0];
            $out[] = ["type" => "peer", "room" => $room, "label" => $users[$other]['name'] ?? $other, "icon" => "💬"];
        }
        echo json_encode(["status" => "success", "chats" => $out]);
        break;

    case 'open_chat_session':
        // Re-issues a fresh session token for a chat the caller is already
        // part of — used every time the chat window is (re)opened, since
        // QuickChat sessions are short-lived by design.
        $room = trim($_GET['room'] ?? '');
        $is_admin_dm = (strpos($room, 'dm-' . $safe_tenant . '-') === 0);
        ensure_room($room);
        if ($is_admin_dm) {
            $owner = substr($room, strlen('dm-' . $safe_tenant . '-'));
            if ($is_admin) { $token = create_session($room, tenant_admin_display($tenant_id, $dir), 'host'); $display = tenant_admin_display($tenant_id, $dir); $role = 'host'; }
            elseif ($owner === $my_username) { $token = create_session($room, my_display_name($dir, $my_username, false), 'member'); $display = my_display_name($dir, $my_username, false); $role = 'member'; }
            else { die(json_encode(["error" => "Not your chat."])); }
        } else {
            $chats = get_secure_table($dir . '/peer_chats.json');
            if (!isset($chats[$room]) || !in_array($my_username, $chats[$room]['participants'], true)) die(json_encode(["error" => "Not your chat."]));
            $display = my_display_name($dir, $my_username, false);
            $token = create_session($room, $display, 'member'); $role = 'member';
        }
        echo json_encode(["status" => "success", "token" => $token, "room" => safe_room_name($room), "role" => $role, "user" => $display]);
        break;

    default: http_response_code(400); echo json_encode(["error" => "Unknown action."]); break;
}
?>
