<?php
// auth.php — handles:
//   action=member       : join a room with its PIN
//   action=host         : log in as host (first login for a room SETS
//                         the host password and, optionally, the PIN)
//   action=super_login  : verify super credentials, returns a
//                         "master" token used to browse rooms
//   action=super_join   : master token + chosen room -> room-bound
//                         session (as Super, or anonymously as Host)

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
$action = isset($body['action']) ? $body['action'] : '';
$fwIp = get_client_ip();

function clean_username($raw) {
    return mb_substr(trim((string)$raw), 0, 40);
}

if ($action === 'member') {
    if (!rate_limit_allow('login_member', $fwIp, 12, 600)) {
        http_response_code(429);
        echo json_encode(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many join attempts — please wait a few minutes and try again.']);
        exit;
    }
    $room = isset($body['room']) ? $body['room'] : '';
    $pin = trim((string)($body['pin'] ?? ''));
    $username = clean_username($body['username'] ?? '');

    if ($room === '' || $pin === '' || $username === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Room, PIN, and username are all required.']);
        exit;
    }
    if (in_array(strtolower($username), ['host'], true)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'That username is reserved. Please choose another.']);
        exit;
    }

    $config = read_config($room);
    if (!$config) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'This room hasn\'t been set up yet. Ask the host to log in first.']);
        exit;
    }
    if (empty($config['pinHash'])) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'The host hasn\'t set a PIN for this room yet.']);
        exit;
    }
    if (hash('sha256', $pin) !== $config['pinHash']) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Incorrect PIN.']);
        exit;
    }
    if (is_banned($config, $username)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'You have been removed from this chat by the host.']);
        exit;
    }
    if (is_ip_banned($config, $fwIp)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'This device has been blocked from this chat.']);
        exit;
    }
    record_user_ip($config, $username, $fwIp);
    write_config($room, $config);

    $token = create_session($room, $username, 'member');
    $response = ['ok' => true, 'token' => $token, 'role' => 'member', 'user' => $username, 'room' => safe_room_name($room)];
    if (!empty($body['remember'])) {
        $response['rememberToken'] = create_remember_token($room, $username, 'member');
    }
    echo json_encode($response);
    exit;
}

if ($action === 'host') {
    if (!rate_limit_allow('login_host', $fwIp, 8, 600)) {
        http_response_code(429);
        echo json_encode(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many login attempts — please wait a few minutes and try again.']);
        exit;
    }
    $room = isset($body['room']) ? $body['room'] : '';
    $hostPassword = trim((string)($body['hostPassword'] ?? ''));
    $newPin = isset($body['newPin']) ? trim((string)$body['newPin']) : '';

    if ($room === '' || $hostPassword === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Room and host password are required.']);
        exit;
    }

    $config = read_config($room);
    $isNewRoom = false;
    if (!$config) {
        $config = default_config();
        $config['createdAt'] = now_ms();
        $isNewRoom = true;
    }

    if ($isNewRoom || empty($config['hostPasswordHash'])) {
        $config['hostPasswordHash'] = hash('sha256', $hostPassword);
    } else {
        if (hash('sha256', $hostPassword) !== $config['hostPasswordHash']) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Incorrect host password.']);
            exit;
        }
    }

    if ($newPin !== '') {
        $config['pinHash'] = hash('sha256', $newPin);
    }

    record_user_ip($config, 'Host', $fwIp);
    write_config($room, $config);

    $token = create_session($room, 'Host', 'host');
    $response = [
        'ok' => true,
        'token' => $token,
        'role' => 'host',
        'user' => 'Host',
        'room' => safe_room_name($room),
        'pinIsSet' => !empty($config['pinHash']),
    ];
    if (!empty($body['remember'])) {
        $response['rememberToken'] = create_remember_token($room, 'Host', 'host');
    }
    echo json_encode($response);
    exit;
}

if ($action === 'super_login') {
    if (!rate_limit_allow('login_super', $fwIp, 6, 600)) {
        http_response_code(429);
        echo json_encode(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many login attempts — please wait a few minutes and try again.']);
        exit;
    }
    $superUsername = trim((string)($body['superUsername'] ?? ''));
    $superPassword = (string)($body['superPassword'] ?? '');

    if ($superUsername === '' || $superPassword === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Username and password are required.']);
        exit;
    }

    $superUsers = require __DIR__ . '/super_users.php';

    if (!isset($superUsers[$superUsername]) || !hash_equals($superUsers[$superUsername][0], $superPassword)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Invalid super user credentials.']);
        exit;
    }

    $defaultName = $superUsers[$superUsername][1];
    $masterToken = create_session($GLOBALS['MASTER_ROOM'], $defaultName, 'super_master');
    echo json_encode(['ok' => true, 'masterToken' => $masterToken, 'defaultDisplayName' => $defaultName]);
    exit;
}

if ($action === 'super_join') {
    $masterToken = isset($body['masterToken']) ? $body['masterToken'] : '';
    $room = trim((string)($body['room'] ?? ''));
    $displayName = clean_username($body['displayName'] ?? '');
    $asHost = !empty($body['asHost']);

    $master = get_session($masterToken);
    if (!$master || $master['role'] !== 'super_master') {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Your super login expired. Please log in again.']);
        exit;
    }

    if ($room === '') $room = 'common';

    $config = read_config($room);
    $isNewRoom = false;
    if (!$config) {
        $config = default_config();
        $config['createdAt'] = now_ms();
        write_config($room, $config);
        $isNewRoom = true;
    }

    if ($asHost) {
        $token = create_session($room, 'Host', 'host');
        echo json_encode(['ok' => true, 'token' => $token, 'role' => 'host', 'user' => 'Host', 'room' => safe_room_name($room), 'isNewRoom' => $isNewRoom]);
        exit;
    }

    $user = $displayName !== '' ? $displayName : $master['user'];
    $token = create_session($room, $user, 'super');
    echo json_encode(['ok' => true, 'token' => $token, 'role' => 'super', 'user' => $user, 'room' => safe_room_name($room), 'isNewRoom' => $isNewRoom]);
    exit;
}

if ($action === 'remember_login') {
    if (!rate_limit_allow('remember_login', $fwIp, 20, 600)) {
        http_response_code(429);
        echo json_encode(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many attempts — please wait a few minutes and try again.']);
        exit;
    }
    $rememberToken = isset($body['rememberToken']) ? $body['rememberToken'] : '';
    $result = consume_remember_token($rememberToken);

    if (!$result) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'remember_expired', 'message' => 'Your saved login expired. Please log in again.']);
        exit;
    }

    // Re-check ban status — a kicked member's remember token is deleted
    // at kick time (see kick.php), but this covers the same-session edge
    // case where a ban happens between requests.
    $config = read_config($result['room']);
    if ($result['role'] === 'member' && $config && is_banned($config, $result['user'])) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'You have been removed from this chat by the host.']);
        exit;
    }

    $token = create_session($result['room'], $result['user'], $result['role']);
    echo json_encode([
        'ok' => true,
        'token' => $token,
        'role' => $result['role'],
        'user' => $result['user'],
        'room' => $result['room'],
        'rememberToken' => $result['newToken'], // rotated — client must overwrite its stored copy
    ]);
    exit;
}

if ($action === 'remember_logout') {
    $rememberToken = isset($body['rememberToken']) ? $body['rememberToken'] : '';
    revoke_remember_token($rememberToken);
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'Unknown action.']);
