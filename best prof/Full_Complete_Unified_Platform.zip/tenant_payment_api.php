<?php
require_once 'dash_firewall.php';
require_once 'cashfree_config.php';
require_once 'dash_crypto.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
if (!isset($_SESSION['dash_user'])) die(json_encode(["error" => "Please login to purchase."]));

$tenant_id = $_SESSION['dash_tenant'] ?? 'main';
$dir = ($tenant_id === 'main') ? __DIR__ . '/data_dash' : __DIR__ . '/data_dash/' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $tenant_id);
$settings = get_secure_table($dir . '/settings.json');
$products = get_secure_table($dir . '/products.json');

$use_custom = ($settings['payment_mode'] ?? 'server') === 'self';
$app_id = $use_custom ? ($settings['cf_app_id'] ?? CF_APP_ID) : CF_APP_ID;
$secret_key = $use_custom ? ($settings['cf_secret_key'] ?? CF_SECRET_KEY) : CF_SECRET_KEY;
$env = $use_custom ? ($settings['cf_env'] ?? CF_ENV) : CF_ENV;
$cf_url = ($env === 'PROD') ? 'https://api.cashfree.com/pg' : 'https://sandbox.cashfree.com/pg';

if ($action === 'buy_product') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $product_id = $_POST['product_id'] ?? '';
        $target_product = null;
        foreach ($products as $p) { if (($p['id'] ?? '') === $product_id) { $target_product = $p; break; } }
        if (!$target_product) die(json_encode(["error" => "Product not found."]));

        $username = $_SESSION['dash_user'];
        $users = get_secure_table($dir . '/users.json');
        $user_data = $users[$username] ?? [];
        
        $order_id = 'prod_' . uniqid() . '_' . time();
        $payload = [
            "order_id" => $order_id, "order_amount" => floatval($target_product['price']), "order_currency" => "INR",
            "customer_details" => [
                "customer_id" => "cust_" . $username, 
                "customer_name" => $user_data['name'] ?? 'User', 
                "customer_email" => $user_data['email'] ?? 'test@example.com', 
                "customer_phone" => $user_data['mobile'] ?? '9999999999'
            ],
            "order_meta" => ["return_url" => "https://" . $_SERVER['HTTP_HOST'] . "/dash_user.html"],
            "order_note" => "Purchase: " . $target_product['name']
        ];
        
        $ch = curl_init($cf_url . '/orders');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'x-client-id: ' . $app_id, 'x-client-secret: ' . $secret_key, 'x-api-version: ' . CF_API_VERSION]);
        $response = curl_exec($ch); curl_close($ch);
        
        $res_data = json_decode($response, true);
        if (isset($res_data['payment_session_id'])) {
            echo json_encode(["status" => "success", "payment_session_id" => $res_data['payment_session_id'], "order_id" => $order_id]);
        } else echo json_encode(["error" => "Gateway Error.", "details" => $res_data]);
    }
}
?>