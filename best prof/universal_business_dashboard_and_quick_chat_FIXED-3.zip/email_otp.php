<?php
// =============================================================================
// email_otp.php — Email OTP verification with multi-provider fallback
// =============================================================================
// Delivery priority (auto-fallback, server-side health cache):
//   1. Brevo (Sendinblue)  — PRIMARY
//   2. Mailgun             — FALLBACK 1
//   3. SendGrid            — FALLBACK 2
//   4. Resend              — FALLBACK 3
//   5. PHP mail()          — LAST RESORT
//
// The provider health system records each provider's last outcome in a small
// JSON file (OTP_HEALTH_FILE). On every send attempt:
//   — Providers marked as DOWN within OTP_HEALTH_FAIL_TTL seconds are skipped.
//   — The first provider not marked DOWN is tried.
//   — On success the provider is marked UP and delivery stops.
//   — On failure the provider is marked DOWN and the next is tried.
// This means a single outage never blocks OTP delivery as long as one
// other provider is configured and working.
//
// Security properties preserved from the original design:
//   — OTP stored as password_hash() only — raw code never persists.
//   — AES-256 encrypted at rest via dash_crypto.php.
//   — Rate-limited at both send (6/10 min) and verify (15/10 min) layers.
//   — Cooldown between resend requests (OTP_RESEND_COOLDOWN seconds).
//   — Verified marker consumed on first use (one-time, time-limited window).
//   — Provider names / API responses never leak to the HTTP caller.
// =============================================================================

require_once __DIR__ . '/dash_crypto.php';
if (file_exists(__DIR__ . '/email_config.php')) require_once __DIR__ . '/email_config.php';

// ---------------------------------------------------------------------------
// OTP constants
// ---------------------------------------------------------------------------
define('OTP_LENGTH',              6);
define('OTP_TTL_SECONDS',         10 * 60);   // code valid 10 minutes
define('OTP_MAX_ATTEMPTS',        5);
define('OTP_RESEND_COOLDOWN',     60);         // seconds between resend requests
define('OTP_VERIFIED_TTL_SECONDS',20 * 60);   // window to complete registration after verify

// ---------------------------------------------------------------------------
// File helpers
// ---------------------------------------------------------------------------
function otp_dir() {
    $dir = __DIR__ . '/data_dash/otp';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}
function otp_key($email, $purpose)          { return md5(strtolower(trim($email)) . '|' . $purpose); }
function otp_file($email, $purpose)         { return otp_dir() . '/otp_'      . otp_key($email, $purpose) . '.json'; }
function otp_verified_file($email, $purpose){ return otp_dir() . '/verified_' . otp_key($email, $purpose) . '.json'; }
function is_valid_email($email)             { return filter_var($email, FILTER_VALIDATE_EMAIL) !== false; }

// ---------------------------------------------------------------------------
// Shared OTP email HTML template
// ---------------------------------------------------------------------------
function otp_email_html($code) {
    $safe = htmlspecialchars((string)$code, ENT_QUOTES, 'UTF-8');
    return '<!DOCTYPE html><html><body>'
        . '<div style="font-family:sans-serif;max-width:440px;margin:32px auto;background:#fff;border-radius:10px;padding:32px;border:1px solid #e5e7eb;">'
        . '<h2 style="margin:0 0 8px;color:#111;">Email Verification</h2>'
        . '<p style="color:#444;margin:0 0 20px;">Enter this code to verify your email address:</p>'
        . '<div style="font-size:32px;letter-spacing:8px;font-weight:700;background:#f4f4f7;padding:18px 0;text-align:center;border-radius:8px;color:#111;">' . $safe . '</div>'
        . '<p style="color:#888;font-size:12px;margin-top:20px;">Expires in 10 minutes. If you did not request this, ignore this email — no action is needed.</p>'
        . '</div></body></html>';
}

// =============================================================================
// PROVIDER HEALTH CACHE
// Stores per-provider last-success / last-failure timestamps so the system
// can skip recently-failed providers without waiting for a live timeout.
// The file is tiny (< 1 KB) and is re-read/re-written on every send attempt.
// It is NOT encrypted (no sensitive data, only timestamps + provider names).
// =============================================================================

function _health_read() {
    $file = defined('OTP_HEALTH_FILE') ? OTP_HEALTH_FILE : (__DIR__ . '/data_dash/otp/provider_health.json');
    if (!file_exists($file)) return [];
    $raw = @file_get_contents($file);
    return $raw ? (json_decode($raw, true) ?: []) : [];
}

function _health_write(array $data) {
    $file = defined('OTP_HEALTH_FILE') ? OTP_HEALTH_FILE : (__DIR__ . '/data_dash/otp/provider_health.json');
    $dir  = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
}

function _health_mark(string $provider, bool $success) {
    $data = _health_read();
    $data[$provider] = [
        'lastAttempt' => time(),
        'ok'          => $success,
    ];
    _health_write($data);
}

/**
 * Returns true if the provider should be SKIPPED (recently failed and still
 * within the failure cool-down window).
 */
function _health_is_down(string $provider): bool {
    $failTtl = defined('OTP_HEALTH_FAIL_TTL') ? OTP_HEALTH_FAIL_TTL : 300;
    $data    = _health_read();
    if (!isset($data[$provider])) return false;          // never tried → assume up
    $entry = $data[$provider];
    if ($entry['ok']) return false;                      // last attempt was success → up
    return (time() - ($entry['lastAttempt'] ?? 0)) < $failTtl;  // failed recently → down
}

// =============================================================================
// INDIVIDUAL PROVIDER SENDERS
// Each returns true on success, false on any failure.
// None of them throw, and none leak API keys or raw responses to the caller.
// =============================================================================

/**
 * 1. Brevo (Sendinblue) — PRIMARY
 * Docs: https://developers.brevo.com/reference/sendtransacemail
 */
function _send_via_brevo(string $to, string $code): bool {
    if (!defined('BREVO_API_KEY') || BREVO_API_KEY === '' || BREVO_API_KEY === 'YOUR_BREVO_API_KEY') return false;
    $payload = [
        'sender'      => ['name' => OTP_SENDER_NAME, 'email' => OTP_SENDER_EMAIL],
        'to'          => [['email' => $to]],
        'subject'     => 'Your verification code',
        'htmlContent' => otp_email_html($code),
    ];
    $ch = curl_init('https://api.brevo.com/v3/smtp/email');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Accept: application/json',
            'api-key: ' . BREVO_API_KEY,
        ],
    ]);
    $response = curl_exec($ch);
    $http     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err      = curl_error($ch);
    curl_close($ch);
    if ($err) { error_log("OTP[Brevo] cURL error: $err"); return false; }
    if ($http < 200 || $http >= 300) { error_log("OTP[Brevo] HTTP $http: $response"); return false; }
    return true;
}

/**
 * 2. Mailgun — FALLBACK 1
 * Docs: https://documentation.mailgun.com/en/latest/api-sending.html
 */
function _send_via_mailgun(string $to, string $code): bool {
    if (!defined('MAILGUN_API_KEY') || MAILGUN_API_KEY === '' || MAILGUN_API_KEY === 'YOUR_MAILGUN_API_KEY') return false;
    if (!defined('MAILGUN_DOMAIN')  || MAILGUN_DOMAIN  === '' || MAILGUN_DOMAIN  === 'mg.yourdomain.com')   return false;
    $region = (defined('MAILGUN_REGION') && MAILGUN_REGION === 'eu') ? 'api.eu.mailgun.net' : 'api.mailgun.net';
    $url    = "https://{$region}/v3/" . MAILGUN_DOMAIN . "/messages";
    $fields = [
        'from'    => OTP_SENDER_NAME . ' <' . OTP_SENDER_EMAIL . '>',
        'to'      => $to,
        'subject' => 'Your verification code',
        'html'    => otp_email_html($code),
    ];
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_USERPWD        => 'api:' . MAILGUN_API_KEY,
        CURLOPT_POSTFIELDS     => $fields,
    ]);
    $response = curl_exec($ch);
    $http     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err      = curl_error($ch);
    curl_close($ch);
    if ($err) { error_log("OTP[Mailgun] cURL error: $err"); return false; }
    if ($http < 200 || $http >= 300) { error_log("OTP[Mailgun] HTTP $http: $response"); return false; }
    return true;
}

/**
 * 3. SendGrid — FALLBACK 2
 * Docs: https://docs.sendgrid.com/api-reference/mail-send/mail-send
 */
function _send_via_sendgrid(string $to, string $code): bool {
    if (!defined('SENDGRID_API_KEY') || SENDGRID_API_KEY === '' || SENDGRID_API_KEY === 'YOUR_SENDGRID_API_KEY') return false;
    $payload = [
        'personalizations' => [['to' => [['email' => $to]]]],
        'from'             => ['email' => OTP_SENDER_EMAIL, 'name' => OTP_SENDER_NAME],
        'subject'          => 'Your verification code',
        'content'          => [['type' => 'text/html', 'value' => otp_email_html($code)]],
    ];
    $ch = curl_init('https://api.sendgrid.com/v3/mail/send');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . SENDGRID_API_KEY,
        ],
    ]);
    $response = curl_exec($ch);
    $http     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err      = curl_error($ch);
    curl_close($ch);
    if ($err) { error_log("OTP[SendGrid] cURL error: $err"); return false; }
    // SendGrid returns 202 Accepted on success
    if ($http < 200 || $http >= 300) { error_log("OTP[SendGrid] HTTP $http: $response"); return false; }
    return true;
}

/**
 * 4. Resend — FALLBACK 3
 * Docs: https://resend.com/docs/api-reference/emails/send-email
 */
function _send_via_resend(string $to, string $code): bool {
    if (!defined('RESEND_API_KEY') || RESEND_API_KEY === '' || RESEND_API_KEY === 'YOUR_RESEND_API_KEY') return false;
    $payload = [
        'from'    => OTP_SENDER_NAME . ' <' . OTP_SENDER_EMAIL . '>',
        'to'      => [$to],
        'subject' => 'Your verification code',
        'html'    => otp_email_html($code),
    ];
    $ch = curl_init('https://api.resend.com/emails');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . RESEND_API_KEY,
        ],
    ]);
    $response = curl_exec($ch);
    $http     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err      = curl_error($ch);
    curl_close($ch);
    if ($err) { error_log("OTP[Resend] cURL error: $err"); return false; }
    if ($http < 200 || $http >= 300) { error_log("OTP[Resend] HTTP $http: $response"); return false; }
    return true;
}

/**
 * 5. PHP mail() — LAST RESORT
 * Only used if OTP_PHPMAIL_ENABLED === true in email_config.php.
 * Health cache still applies so a broken mail() doesn't slow every send.
 */
function _send_via_phpmail(string $to, string $code): bool {
    if (!defined('OTP_PHPMAIL_ENABLED') || !OTP_PHPMAIL_ENABLED) return false;
    $subject = 'Your verification code';
    $headers = implode("\r\n", [
        'From: ' . OTP_SENDER_NAME . ' <' . OTP_SENDER_EMAIL . '>',
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'X-Mailer: PHP/' . phpversion(),
    ]);
    $sent = @mail($to, $subject, otp_email_html($code), $headers);
    if (!$sent) error_log("OTP[phpmail] mail() returned false for $to");
    return (bool)$sent;
}

// =============================================================================
// MULTI-PROVIDER DISPATCHER
// Tries each provider in priority order, skipping those marked DOWN in the
// health cache. Updates the health cache after every attempt.
// Returns true as soon as one provider succeeds; false if all fail.
// Provider names never reach the HTTP response layer.
// =============================================================================
function send_otp_email(string $email, string $code): bool {
    // Provider registry: [ name => callable ]
    $providers = [
        'brevo'    => '_send_via_brevo',
        'mailgun'  => '_send_via_mailgun',
        'sendgrid' => '_send_via_sendgrid',
        'resend'   => '_send_via_resend',
        'phpmail'  => '_send_via_phpmail',
    ];

    foreach ($providers as $name => $fn) {
        // Skip if recently failed
        if (_health_is_down($name)) {
            error_log("OTP[dispatcher] skipping $name (marked DOWN in health cache)");
            continue;
        }
        $ok = call_user_func($fn, $email, $code);
        _health_mark($name, $ok);
        if ($ok) {
            error_log("OTP[dispatcher] sent via $name to $email");
            return true;
        }
        error_log("OTP[dispatcher] $name failed, trying next provider");
    }

    error_log("OTP[dispatcher] ALL providers failed for $email");
    return false;
}

// =============================================================================
// PUBLIC API — unchanged signatures (backward-compatible with all callers)
// =============================================================================

/**
 * Generates, stores (hashed + encrypted), and sends a new OTP.
 * Returns ['status'=>'success'] or ['error'=>'...', 'cooldownRemaining'=>N].
 */
function request_otp(string $email, string $purpose): array {
    if (!is_valid_email($email)) return ['error' => 'Enter a valid email address.'];
    $file     = otp_file($email, $purpose);
    $existing = get_secure_table($file);
    $now      = time();
    if (!empty($existing) && isset($existing['lastSent'])) {
        $remaining = OTP_RESEND_COOLDOWN - ($now - $existing['lastSent']);
        if ($remaining > 0) return ['error' => 'Please wait before requesting another code.', 'cooldownRemaining' => $remaining];
    }
    // Cryptographically secure 6-digit code, zero-padded
    $code   = sprintf('%0' . OTP_LENGTH . 'd', random_int(0, (10 ** OTP_LENGTH) - 1));
    $record = [
        'email'   => strtolower(trim($email)),
        'purpose' => $purpose,
        'otpHash' => password_hash($code, PASSWORD_DEFAULT),
        'expires' => $now + OTP_TTL_SECONDS,
        'attempts'=> 0,
        'lastSent'=> $now,
    ];
    if (!send_otp_email($email, $code)) {
        return ['error' => 'Could not send the verification email. All delivery methods are currently unavailable. Please try again shortly.'];
    }
    save_secure_table($file, $record);
    return ['status' => 'success', 'expiresInSeconds' => OTP_TTL_SECONDS];
}

/**
 * Verifies a submitted code. On success writes a short-lived verified marker
 * and invalidates the OTP so it cannot be reused.
 */
function verify_otp(string $email, string $purpose, string $code): array {
    $file   = otp_file($email, $purpose);
    $record = get_secure_table($file);
    if (empty($record))                           return ['error' => 'No verification code was requested for this email. Request one first.'];
    if (time() > ($record['expires'] ?? 0))       { @unlink($file); return ['error' => 'That code has expired. Request a new one.']; }
    if (($record['attempts'] ?? 0) >= OTP_MAX_ATTEMPTS) { @unlink($file); return ['error' => 'Too many incorrect attempts. Request a new code.']; }
    if (!password_verify((string)$code, $record['otpHash'])) {
        $record['attempts'] = ($record['attempts'] ?? 0) + 1;
        save_secure_table($file, $record);
        $left = OTP_MAX_ATTEMPTS - $record['attempts'];
        return ['error' => 'Incorrect code.' . ($left > 0 ? " {$left} attempt(s) left." : '')];
    }
    // Success — invalidate OTP, write verified marker
    @unlink($file);
    save_secure_table(otp_verified_file($email, $purpose), [
        'email'      => strtolower(trim($email)),
        'purpose'    => $purpose,
        'verifiedAt' => time(),
        'expires'    => time() + OTP_VERIFIED_TTL_SECONDS,
    ]);
    return ['status' => 'success'];
}

/**
 * Checked by registration/payment endpoints before proceeding.
 * Consumes the verified marker on success (one-time use).
 */
function is_email_verified(string $email, string $purpose, bool $consume = true): bool {
    $file   = otp_verified_file($email, $purpose);
    $record = get_secure_table($file);
    if (empty($record))                                          return false;
    if (strtolower(trim($email)) !== ($record['email'] ?? ''))  return false;
    if (time() > ($record['expires'] ?? 0))                     { @unlink($file); return false; }
    if ($consume) @unlink($file);
    return true;
}

// =============================================================================
// HTTP ACTION ROUTER (direct endpoint mode)
// Called when this file is the SCRIPT_FILENAME (e.g. fetch('/email_otp.php?action=send_otp'))
// =============================================================================
if (basename($_SERVER['SCRIPT_FILENAME']) === 'email_otp.php') {
    require_once __DIR__ . '/dash_firewall.php';
    header('Content-Type: application/json');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        die(json_encode(['error' => 'Method not allowed.']));
    }

    $action  = $_GET['action'] ?? '';
    $email   = trim($_POST['email']   ?? '');
    $purpose = trim($_POST['purpose'] ?? '');

    $allowedPurposes = ['user_register', 'admin_register', 'payment'];
    if (!in_array($purpose, $allowedPurposes, true)) {
        die(json_encode(['error' => 'Invalid verification context.']));
    }

    if ($action === 'send_otp') {
        if (!rate_limit_allow('otp_send', get_client_ip(), 6, 600)) {
            http_response_code(429);
            die(json_encode(['error' => 'Too many requests. Please wait a few minutes.']));
        }
        echo json_encode(request_otp($email, $purpose));
        exit;
    }

    if ($action === 'verify_otp') {
        if (!rate_limit_allow('otp_verify', get_client_ip(), 15, 600)) {
            http_response_code(429);
            die(json_encode(['error' => 'Too many attempts. Please wait a few minutes.']));
        }
        $code = trim($_POST['code'] ?? '');
        echo json_encode(verify_otp($email, $purpose, $code));
        exit;
    }

    http_response_code(400);
    echo json_encode(['error' => 'Unknown action.']);
}
?>
