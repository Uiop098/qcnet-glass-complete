QUICK CHAT — SELF-HOSTED, NO DEPENDENCIES
==========================================

WHAT'S INSIDE
  index.html       - frontend (HTML/CSS/JS, no external libraries)
  api.php          - fetch/send messages, clear chat (host/super only)
  auth.php         - login: member join, host login, super login/join
  upload.php       - file uploads (restricted for members, open for super)
  edit.php         - edits your own text message ("edited" tag)
  read.php         - read-receipt heartbeat ("seen by" tracking)
  linkpreview.php  - server-side link preview fetch (title/desc/image)
  export.php       - export a room's chat history, .txt/.json (host/super)
  kick.php         - removes a user from a room (host/super only)
  mute.php         - temporary "spammer timer" mute (host/super only)
  admin.php        - room title, host password reset, unban, pin/unpin
  theme.php        - room wallpaper + glow color (super only, room-wide)
  wallpaper_upload.php - uploads a wallpaper image to the server (super only)
  typing.php       - marks a user as "currently typing"
  react.php        - toggles an emoji reaction on a message
  rooms.php        - lists all rooms for the super-user room browser
  common.php       - shared storage/session/config helpers
  super_users.php  - hardcoded super user accounts (see below)
  data/            - JSON files: messages, PINs, host passwords, bans,
                     mutes, presence (incl. read receipts), room
                     titles/timestamps, theme, remember-me tokens (see
                     "REMEMBER ME" below), link-preview cache
                     (.htaccess blocks direct browser access)
  files/           - uploaded files, organized by room, including a
                     wallpapers/ subfolder per room
                     (.htaccess blocks folder listing, direct links work)

REQUIREMENTS
  Any PHP host works (PHP 7+). No database needed. The optional
  super-encryption-bypass feature needs the PHP openssl extension,
  which is enabled by default on almost every host (including free
  ones like InfinityFree) — nothing extra to install in practice.

HOW TO DEPLOY
  Upload the whole "quickchat" folder (all files, plus the data/ and
  files/ subfolders) to your site via FTP or your host's File
  Manager. Example: htdocs/quickchat/  or  public_html/quickchat/
  Make sure "data" and "files" are writable by PHP (755/775 if you
  hit errors). Then visit https://yourdomain.com/quickchat/

ROLES
  MEMBER — joins with room name + PIN + username. Sends messages,
  uploads common file types. Can be muted or kicked by a host/super.

  HOST — one per room, password-protected. The FIRST login for a new
  room sets that password (write it down — no recovery except via
  server access, or a super user resetting it, see below). Can clear
  chat, mute, and kick. The optional PIN field on the host login
  screen sets/changes the room PIN members need to join.

  SUPER USER — global accounts from super_users.php. Logs in with
  username + password only (no room name needed) and then browses
  EVERY room that exists — running or past — in a list showing:
  whether a host password is set, whether a PIN is set, who's
  currently active, when the room was created, and when it was last
  active. From there, join any room either as a visible Super User
  (crown icon, animated glowing message border) or "as Host
  (anonymously)" — entering with full host powers under the plain
  "Host" identity, indistinguishable from a real host login. Can also
  create brand-new rooms from the same screen.

  Super users can:
    - Upload any file type (except a small blocklist of
      server-executable extensions like .php/.exe, kept for safety)
    - Clear chat, mute, kick — like a host, in ANY room
    - Rename the room (emoji titles supported, e.g. "🎮 Game Night")
    - Reset a room's host password (kicks the current host session;
      whoever logs in as host next sets a new password)
    - Unban previously kicked users
    - Automatically read every encrypted room without knowing the
      encryption key — this is now unconditional for every room, with
      no per-room opt-out (see MESSAGE ENCRYPTION)

  ADDING MORE SUPER USERS
    Open super_users.php and add a line following the existing
    format — commented examples are right there.
    Currently configured: username "xbot", password "#123xbot",
    default display name "09".

REMEMBER ME (AUTO-LOGIN)
  Member and Host login both have a "Remember me on this device"
  checkbox. Checking it keeps you signed in across browser restarts —
  normal sessions last 6 hours (sliding) and clear when the tab
  closes; a remember-me token instead lasts 30 days and is stored in
  the browser's localStorage (not sessionStorage), so it survives
  closing the tab or restarting the browser entirely.

  How it works under the hood:
    - The server never stores the raw token — only a hash of half of
      it (a "selector/validator" split), in data/remember_tokens.json.
      Even direct server file access wouldn't hand over usable tokens.
    - Every time it's used to auto-login, the token rotates — a new
      one is issued and the old one is invalidated. A copy that leaked
      but hasn't been used yet only works once before rotating out.
    - Reopening the site with no active session automatically tries
      the stored token before falling back to the login screen.

  It's automatically forgotten (revoked server-side, not just deleted
  from the browser) when:
    - You click "Leave"
    - A host or super user kicks/bans you (as a member)
    - A super user resets a room's host password (as a host)

  NOT available for Super Login — intentionally. Super accounts are
  your highest-privilege, plain-text-stored credentials (see SECURITY
  NOTES), so they're excluded from long-lived auto-login by design.

SPAM TIMER (MUTE)
  Both hosts and super users can mute anyone in the room via the
  "Manage" panel — pick a duration in minutes (0 unmutes early). A
  muted person sees a banner and can't send messages or upload files
  until it expires.

THEME & WALLPAPER — LOCAL TO EACH PERSON, NOT SHARED
  Every user has a 🌓 button to toggle dark/light mode.
  Super users additionally get a 🎨 Theme panel to set a background
  color, paste an image URL, upload an image from their device, or
  pick from built-in presets.
  IMPORTANT: none of this is sent to the server or shown to anyone
  else — it's saved only in that person's own browser (localStorage),
  so a super user's wallpaper choice never changes what other people
  see. The only thing that's visible to everyone is the animated
  rotating glow border automatically shown around every Super User's
  chat messages — that's fixed and not configurable, it's just how
  super identity is indicated to the room.
  Note: wallpapers uploaded from a device only last for that browser
  tab/session (they're not saved as a file anywhere) — pick a preset
  or paste a URL for something that persists across visits.

AUTOMATIC CLEANUP (24-HOUR EXPIRY)
  Messages and their uploaded files are automatically deleted once
  they're older than 24 hours — checked whenever the chat is loaded
  or polled, no cron job needed. Edit $messageExpirySeconds in
  common.php to change this.

ROOM WALLPAPER & MESSAGE GLOW (SUPER-CONTROLLED, ROOM-WIDE)
  Only a super user can change a room's wallpaper — from the 🎨 Theme
  button, they can pick a color, paste an image URL, upload an image
  from their device (stored on the server so it persists), or use a
  built-in preset. Whatever they set applies to EVERYONE currently in
  that room and anyone who joins later — nobody else can override it,
  and it's not something a regular member or host can change.
  Super users can also set their own glow color for the animated
  border around their messages (default is a rotating rainbow if left
  unset) — this is visible to everyone as an identity indicator.
  Everyone still gets a personal, purely local 🌓 dark/light toggle
  for basic contrast — that one stays private per-browser and doesn't
  touch the server at all.

MESSAGE REACTIONS
  Tap "😊 React" under any message to pick from six quick emoji
  (👍❤️😂😮😢🔥). One active reaction per person per message — picking
  a different emoji swaps your old one out. Reaction counts sync to
  everyone in the room, including on older messages.

REPLY / QUOTE
  Tap ↩️ next to any message to reply to it — a preview bar appears
  above the input showing what you're replying to (with a ✕ to cancel).
  The message you send shows a small quoted snippet of the original
  above it.

TYPING INDICATOR
  While someone has text in the message box, others see "X is
  typing…" above the message list. Clears automatically a few seconds
  after they stop.

SOUND + TAB NOTIFICATION
  If the browser tab isn't focused when a new message arrives, you'll
  hear a short beep (generated in-browser, no audio file needed) and
  the tab title updates to show an unread count, e.g. "(3) Quick
  Chat" — clears automatically when you switch back to the tab.

PIN MESSAGE (SUPER — PREMIUM)
  Super users can tap 📌 on any message to pin it — it shows in a gold
  bar at the top of the chat for everyone, with an "Unpin" button
  (super-only) to remove it.

MESSAGE EDITING
  Tap ✏️ next to your own text messages (not files/voice notes) to
  edit them in place. Saved edits show a small "(edited)" tag next to
  your name. You can only edit your own messages — host/super get no
  special bypass here.

@MENTIONS
  Typing @username (a single word — letters, digits, "._-") highlights
  it in the sent message. If it matches the first word of someone's
  display name, they get a sound + tab-title notification even if
  their tab is currently focused (normal messages only notify while
  the tab is hidden) — that's the point of a mention.

LINK PREVIEWS
  The first http(s) link in a plain-text message gets a small preview
  card (title/description/image) fetched and cached server-side via
  linkpreview.php — browsers can't read arbitrary cross-origin pages
  directly (CORS), so this has to happen on the server. Only public,
  non-private IP addresses are ever fetched (see SECURITY NOTES).

READ RECEIPTS
  Piggybacks on the existing presence heartbeat: every active person's
  highest-seen message id is tracked and shown as "✓✓ Seen by …" under
  your own most recent message, once someone else has read that far.

EXPORT CHAT HISTORY (HOST/SUPER ONLY)
  Manage panel > "⬇️ Export chat history" downloads the room as .txt or
  .json. If the room is encrypted, exported message text is the raw
  ciphertext (encv1:...) — export.php doesn't have the room's key any
  more than an outside viewer would.

SLASH COMMANDS
  Type these into the message box instead of using the panel buttons:
    /clear                  — clear the chat (host/super)
    /mute @user [minutes]   — mute someone, default 5 min (host/super)
    /unmute @user           — remove a mute (host/super)
    /kick @user             — remove someone from the room (host/super)
    /pin                    — pin the message you're currently
                               replying to (super only — reply to a
                               message first, then send /pin)
    /help                   — lists these in an alert
  An unrecognized "/word" is just sent as normal text.

VOICE MESSAGES
  Tap 🎤 to record audio directly from the browser (MediaRecorder API,
  no plugin needed) — a red recording bar with a timer appears; "Stop
  & send" uploads it as an audio message (5-minute safety cap), or
  "Cancel" discards it. Uses the same upload pipeline as file
  attachments, just tagged so it always renders as playable audio
  regardless of which container format your browser recorded in
  (webm/mp4/ogg all work). Requires microphone permission and HTTPS on
  most browsers (localhost is exempt).

MESSAGE COMPOSER, CODE BLOCKS & COPY
  The message box is a multi-line textarea. Enter always just adds a
  new line — it never sends by itself anymore (this was the bug where
  writing/pasting code with line breaks could accidentally send
  mid-way through). Tap "Send" to send, or use Ctrl+Enter (Cmd+Enter
  on Mac) as a keyboard shortcut.

  Any message containing a line break is automatically shown in a
  proper code box: monospace font, horizontal scrolling for long
  lines (nothing gets cut off or wrapped awkwardly), and its own
  "📋 Copy" button in the corner that copies the exact text, line
  breaks included. Plain single-line messages get a small copy button
  next to the sender's name instead.

  The per-message length limit is 20,000 characters — plenty for
  pasted code.

FILE SHARING
  Members: images, audio, video, docs (pdf/doc/xls/ppt/txt/csv/rtf),
  archives (zip/rar/7z) — shown inline where possible, download card
  otherwise.
  Super users: everything above PLUS any other file type, except the
  small server-safety blocklist.
  Default max size: 25 MB (members) / 200 MB (super) — your host's
  own PHP upload_max_filesize/post_max_size may cap this lower.

MESSAGE ENCRYPTION (OPTIONAL, PER ROOM)
  Any host or super user can turn on client-side encryption for a room
  from Manage > "🔒 End-to-end message encryption". Turning it on asks
  for an encryption key — a separate secret from the room PIN. From
  then on, message TEXT is encrypted in the browser with AES-256-GCM
  before it's sent, using a key derived from that passphrase (PBKDF2).
  The server only ever stores ciphertext and a random, non-secret
  salt — by default it never sees the key or the plaintext.

  Because the key is separate from the PIN, members and hosts need it
  to read message text. The first time you're in an encrypted room
  without it, an "Enter the room's encryption key" bar appears once;
  dismiss it or enter the key. You can reopen it anytime from the
  "🔒 Key" button in the header. If the key is wrong or hasn't been
  entered yet, affected messages just show a dimmed "🔒 Encrypted
  message" placeholder — no repeated prompting.

  If you already know a room's encryption key, you can skip that
  prompt entirely by typing it into the optional "Encryption key"
  field right on the Join Chat / Host Login / Super Login screen
  before you even enter the room — it gets cached the moment you're
  in, so if the room turns out to be encrypted you're already unlocked.
  Leave it blank if you don't know it yet, or if the room isn't
  encrypted at all.

  SUPER-USER AUTOMATIC BYPASS — ALWAYS ON, NO OPT-OUT (read this
  carefully — it changes the security model described above, and
  applies to every encrypted room, unconditionally)
  There is no checkbox for this anymore. Every time encryption is
  turned on for a room:
    - The server keeps an extra copy of the passphrase, encrypted
      with a fixed secret (SUPER_MASTER_SECRET in common.php) that
      only this server's own code can ever decrypt.
    - Whenever anyone with a verified super-user session loads the
      room, the server automatically decrypts that copy server-side
      and hands the plaintext passphrase to their browser — no manual
      key entry, ever, for any super user, in any room.
    - This means super users can ALWAYS read every message in every
      room, regardless of who set the encryption key or when, and
      there is no way for a host to prevent it.
  This is a deliberate, requested design, not a bug — but it's
  important to understand what it means for anyone using this tool:
  the "🔒 End-to-end message encryption" label is not fully accurate.
  It protects message text from anyone who is neither a super user
  nor has direct file access to your server, but it does NOT protect
  against super users — they have permanent, automatic, silent read
  access to every room's message text by design, with no per-room way
  to turn that off. If your members should know that a super user can
  always read "encrypted" messages, tell them — the app itself doesn't
  currently disclose this to anyone below the host/super role.
  Change SUPER_MASTER_SECRET in common.php to your own long random
  string before relying on this — anyone who has that exact string
  (which normally means server file access) can decrypt the
  super-recovery copy too, same as any super user could.

  Limitations to know:
  - Only message text is encrypted — uploaded files/images are not.
  - It's one shared key for the room, not per-person keys — anyone
    who has the key can read everything, same trust model as the PIN.
  - Changing (rotating) or disabling the key makes older encrypted
    messages unreadable, since a new salt is issued each time.
  - The key is cached in the browser's sessionStorage per room so you
    aren't asked again on refresh; it's cleared if you leave the chat
    or close the tab. (Super users get it freshly re-recovered from
    the server every time instead, so this doesn't apply to them.)

SECURITY NOTES (read this)
  - Passwords in super_users.php are plain text — anyone with server
    file access could read them. Don't reuse these passwords elsewhere.
  - PINs and host passwords ARE hashed (SHA-256) before storage.
  - SUPER_MASTER_SECRET in common.php is used only for the optional
    super-encryption-bypass feature (see MESSAGE ENCRYPTION above).
    Change it from the placeholder value before relying on that
    feature — anyone who has this exact string can decrypt any room's
    recovered passphrase, the same as a super-user session can.
  - This is casual/personal-use security, not hardened against a
    determined attacker with server access.
  - Traffic is only encrypted if your host serves the site over
    HTTPS — check your host's control panel for free SSL if unsure.
  - Sessions last 6 hours of activity (sliding) then expire.
  - Remember-me tokens last 30 days, are stored hashed (never the raw
    token), and rotate on every use — see "REMEMBER ME" above.
  - Link previews (linkpreview.php) only fetch http/https URLs on
    ports 80/443 whose resolved IP is a public address — private,
    loopback, link-local, and reserved ranges are rejected, and
    redirects aren't followed, to prevent using the server as an
    internal-network probe (SSRF). Still, fetching arbitrary external
    URLs always carries some inherent risk; disable link previews by
    removing the call to fetchLinkPreview() in index.html if you'd
    rather not do any of that.

CUSTOMIZING
  - POLL_INTERVAL_MS in index.html — how often the chat checks updates
  - $maxMessages in common.php — how much history is kept
  - $sessionTtlSeconds in common.php — how long logins stay valid
  - $rememberTtlSeconds in common.php — how long "Remember me" lasts
    (default 30 days)
  - $memberAllowedExtensions / $dangerousExtensions in upload.php
  - THEME_PRESETS / WALLPAPER_PRESETS in index.html — the quick-pick
    swatches in the super user's theme panel
  - SUPER_MASTER_SECRET in common.php — change this before relying on
    the super-encryption-bypass feature (see SECURITY NOTES above)
  - $linkPreviewCacheSeconds in common.php — how long a fetched link
    preview is cached before being re-fetched (default 6 hours)
