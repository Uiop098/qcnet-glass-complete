QUICK CHAT — SELF-HOSTED, NO DEPENDENCIES
==========================================

WHAT'S INSIDE
  index.html   - frontend (HTML/CSS/JS, no external libraries)
  api.php      - backend (plain PHP, no database, no Composer, no npm)
  data/        - folder where messages are stored as JSON files
                 (.htaccess blocks direct browser access to this folder)

REQUIREMENTS
  Any PHP host works (PHP 7+). No MySQL needed. Confirmed compatible
  with InfinityFree and similar free shared hosting.

HOW TO DEPLOY
  1. Upload the whole "quickchat" folder (index.html, api.php, data/)
     to your site via FTP or your host's File Manager.
     Example: htdocs/quickchat/  or  public_html/quickchat/

  2. Make sure the "data" folder is writable by PHP.
     Most hosts default to 755 permissions, which is fine.
     If you get a "cannot reach server" or write error, try setting
     the data folder permissions to 755 or 775 via your host's file
     manager (right-click > File Permissions).

  3. Visit https://yourdomain.com/quickchat/ on BOTH your phone and PC.

  4. On each device, enter the SAME room name (e.g. "raj-room-1") and
     any username, then tap "Join Chat". Messages sync automatically
     every 2 seconds.

CUSTOMIZING
  - Change POLL_INTERVAL_MS in index.html to poll faster/slower.
  - Change $maxMessages in api.php to keep more/less chat history.
  - To host api.php on a different domain than index.html, update
    the API_URL constant at the top of the <script> in index.html.

NOTES
  - This has no login system — the "username" is just a display
    label, not an authenticated account. Anyone who knows your room
    name and URL can join that room. Pick a non-obvious room name
    if you want basic privacy.
  - Messages are stored as plain JSON files in data/, not a database.
    Fine for personal use; not built for high traffic.
