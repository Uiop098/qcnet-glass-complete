<?php
// api.php — simple file-based chat backend, no database required.

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// --- Config ---
$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
}
$maxMessages = 200; // trim old messages beyond this count

// --- Helpers ---
function safe_room_name($room) {
    // allow letters, numbers, dash, underscore only
    $room = preg_replace('/[^a-zA-Z0-9_\-]/', '', $room);
    return substr($room, 0, 64) ?: 'default';
}

function room_file($room) {
    global $dataDir;
    return $dataDir . '/room_' . safe_room_name($room) . '.json';
}

function read_messages($room) {
    $file = room_file($room);
    if (!file_exists($file)) {
        return [];
    }
    $fp = fopen($file, 'r');
    if (!$fp) return [];
    flock($fp, LOCK_SH);
    $content = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

function write_messages($room, $messages) {
    global $maxMessages;
    $file = room_file($room);
    $fp = fopen($file, 'c+');
    if (!$fp) return false;
    flock($fp, LOCK_EX);
    if (count($messages) > $maxMessages) {
        $messages = array_slice($messages, -1 * $maxMessages);
    }
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($messages, JSON_UNESCAPED_UNICODE));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return true;
}

// --- Routing ---
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $room = isset($_GET['room']) ? $_GET['room'] : 'default';
    $since = isset($_GET['since']) ? intval($_GET['since']) : 0;

    $messages = read_messages($room);

    if ($since > 0) {
        $messages = array_values(array_filter($messages, function ($m) use ($since) {
            return isset($m['id']) && $m['id'] > $since;
        }));
    }

    echo json_encode([
        'ok' => true,
        'messages' => $messages,
    ]);
    exit;
}

if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $body = json_decode($raw, true);

    if (!$body || empty($body['room']) || empty($body['user']) || !isset($body['text'])) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Missing room, user, or text']);
        exit;
    }

    $room = $body['room'];
    $user = mb_substr(trim(strip_tags($body['user'])), 0, 40);
    $text = trim(strip_tags($body['text']));

    if ($text === '' || $user === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Empty user or text']);
        exit;
    }
    if (mb_strlen($text) > 2000) {
        $text = mb_substr($text, 0, 2000);
    }

    $messages = read_messages($room);
    $nextId = 1;
    foreach ($messages as $m) {
        if (isset($m['id']) && $m['id'] >= $nextId) {
            $nextId = $m['id'] + 1;
        }
    }

    $newMsg = [
        'id' => $nextId,
        'user' => $user,
        'text' => $text,
        'ts' => round(microtime(true) * 1000),
    ];

    $messages[] = $newMsg;
    write_messages($room, $messages);

    echo json_encode(['ok' => true, 'message' => $newMsg]);
    exit;
}

if ($method === 'DELETE') {
    $room = isset($_GET['room']) ? $_GET['room'] : 'default';
    write_messages($room, []);
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
