<?php
// telegram_setwebhook.php — run this ONCE (as the master admin) after
// filling in telegram_config.php, to tell Telegram where to send updates.
//
// Gated by a direct master-password check on this page itself, rather
// than only trusting the existing PHP session — this avoids issues where
// the session doesn't carry over into a new tab (cookie settings, some
// browser extensions) even though you really are logged in as master
// elsewhere. Verifying the password fresh here works regardless of that.
require_once __DIR__ . '/dash_crypto.php';
require_once __DIR__ . '/dash_firewall.php';

function verified_as_master() {
    // Accept either: an existing master-tier dashboard session, OR a
    // freshly-submitted master password on this page (see below). Either
    // one is sufficient — this isn't weakening the check, just offering a
    // second valid way to prove the same thing.
    if (isset($_SESSION['dash_admin']) && ($_SESSION['dash_tenant'] ?? '') === 'main') return true;
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['master_username'], $_POST['master_password'])) {
        if (!rate_limit_allow('telegram_setwebhook_auth', get_client_ip(), 8, 600)) return false;
        $masters = get_secure_table(__DIR__ . '/data_dash/master.json');
        $u = trim($_POST['master_username']); $p = $_POST['master_password'];
        if (isset($masters[$u]) && password_verify($p, $masters[$u]['password_hash'])) return true;
    }
    return false;
}

$authed = verified_as_master();
$authFailed = ($_SERVER['REQUEST_METHOD'] === 'POST' && !$authed);

header('Content-Type: text/html');
echo '<!DOCTYPE html><html><body style="font-family:sans-serif; max-width:500px; margin:60px auto; line-height:1.6;">';
echo '<h2>Telegram Webhook Setup</h2>';

if (!$authed) {
    if ($authFailed) echo '<p style="color:red;">❌ Incorrect master username or password (or too many attempts — wait a few minutes and try again).</p>';
    echo '<p style="color:#666; font-size:13px;">Only the default master admin account can run this. Enter its credentials directly here — this works even if your browser session from another tab isn\'t carrying over.</p>';
    echo '<form method="POST">
        <input type="text" name="master_username" placeholder="Master username" required style="display:block; width:100%; padding:10px; margin-bottom:10px; box-sizing:border-box;">
        <input type="password" name="master_password" placeholder="Master password" required style="display:block; width:100%; padding:10px; margin-bottom:10px; box-sizing:border-box;">
        <button type="submit" style="padding:10px 20px;">Verify &amp; Continue</button>
    </form>';
    echo '</body></html>';
    exit;
}

// ---- Verified — proceed with the actual webhook registration ----
require_once __DIR__ . '/telegram_config.php';

$host = $_SERVER['HTTP_HOST'] ?? '';
if (!preg_match('/^[a-zA-Z0-9.\-]+(:\d+)?$/', $host)) { die('Could not determine this server\'s domain — open this page directly in your browser rather than via a proxy.'); }
$webhookUrl = 'https://' . $host . '/telegram_webhook.php';

$ch = curl_init('https://api.telegram.org/bot' . TELEGRAM_BOT_TOKEN . '/setWebhook');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['url' => $webhookUrl, 'secret_token' => TELEGRAM_WEBHOOK_SECRET]));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$response = curl_exec($ch);
$curlErrno = curl_errno($ch);
$curlErr = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$result = json_decode($response, true);

echo '<p><b>URL registered:</b> ' . htmlspecialchars($webhookUrl) . '</p>';
if ($curlErrno) {
    // curl_exec() itself failed — this server never got a response from
    // Telegram at all, so there's no Telegram error message to show. The
    // curl error number/message below is the actual cause.
    echo '<p style="color:red;">❌ Could not reach Telegram at all.</p>';
    echo '<p><b>cURL error ' . $curlErrno . ':</b> ' . htmlspecialchars($curlErr) . '</p>';
    echo '<p style="font-size:13px; color:#666;">Common causes on shared hosting:<br>';
    if ($curlErrno === 60 || $curlErrno === 51) {
        echo '<b>SSL certificate verification failed</b> — your host\'s cURL is missing or has an outdated CA certificate bundle for verifying api.telegram.org\'s certificate. This is a host-level issue, not something fixable in this file. Contact your hosting provider, or ask them to update the CA bundle PHP\'s cURL uses.';
    } elseif ($curlErrno === 6 || $curlErrno === 7) {
        echo 'Could not resolve or connect to api.telegram.org — your host may be blocking outbound HTTPS to this domain, or there\'s a temporary network issue. Try again in a minute; if it persists, contact your host about outbound connection restrictions.';
    } elseif ($curlErrno === 28) {
        echo 'The request timed out — your host\'s outbound network to Telegram may be slow or blocked.';
    } else {
        echo 'See <a href="https://curl.se/libcurl/c/libcurl-errors.html" target="_blank">curl error code reference</a> for error ' . $curlErrno . '.';
    }
    echo '</p>';
} elseif (!empty($result['ok'])) {
    echo '<p style="color:green;">✅ Success — Telegram confirmed the webhook. Message your bot on Telegram to test it (try /start).</p>';
} else {
    echo '<p style="color:red;">❌ Failed (HTTP ' . htmlspecialchars((string)$httpCode) . '): ' . htmlspecialchars($result['description'] ?? ($response !== '' ? $response : '(empty response from Telegram)')) . '</p>';
    echo '<p>Check that TELEGRAM_BOT_TOKEN in telegram_config.php is correct, and that this domain is reachable over HTTPS (Telegram requires a valid HTTPS certificate — a self-signed one will not work).</p>';
}
echo '</body></html>';
?>
