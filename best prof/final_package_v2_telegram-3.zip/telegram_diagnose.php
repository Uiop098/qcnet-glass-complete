<?php
// telegram_diagnose.php — checks each layer of the bot setup and reports
// exactly which one is broken, instead of guessing. Master admin only.
require_once __DIR__ . '/dash_crypto.php';
require_once __DIR__ . '/dash_firewall.php';

// Same dual-path check as telegram_setwebhook.php: an existing master
// session, OR a freshly-submitted master password on this page — the
// latter works even when a session from another tab isn't carrying over.
function verified_as_master() {
    if (isset($_SESSION['dash_admin']) && ($_SESSION['dash_tenant'] ?? '') === 'main') return true;
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['master_username'], $_POST['master_password'])) {
        if (!rate_limit_allow('telegram_diagnose_auth', get_client_ip(), 8, 600)) return false;
        $masters = get_secure_table(__DIR__ . '/data_dash/master.json');
        $u = trim($_POST['master_username']); $p = $_POST['master_password'];
        if (isset($masters[$u]) && password_verify($p, $masters[$u]['password_hash'])) return true;
    }
    return false;
}

$authed = verified_as_master();
$authFailed = ($_SERVER['REQUEST_METHOD'] === 'POST' && !$authed);

header('Content-Type: text/html');

if (!$authed) {
    echo '<!DOCTYPE html><html><body style="font-family:sans-serif; max-width:500px; margin:60px auto; line-height:1.6;">';
    echo '<h2>🔍 Telegram Bot Diagnostic</h2>';
    if ($authFailed) echo '<p style="color:red;">❌ Incorrect master username or password (or too many attempts — wait a few minutes).</p>';
    echo '<p style="color:#666; font-size:13px;">Only the default master admin account can run this.</p>';
    echo '<form method="POST">
        <input type="text" name="master_username" placeholder="Master username" required style="display:block; width:100%; padding:10px; margin-bottom:10px; box-sizing:border-box;">
        <input type="password" name="master_password" placeholder="Master password" required style="display:block; width:100%; padding:10px; margin-bottom:10px; box-sizing:border-box;">
        <button type="submit" style="padding:10px 20px;">Verify &amp; Continue</button>
    </form>';
    echo '</body></html>';
    exit;
}

echo '<!DOCTYPE html><html><body style="font-family:sans-serif; max-width:700px; margin:40px auto; line-height:1.7;">';
echo '<h2>🔍 Telegram Bot Diagnostic</h2>';

function step($label, $ok, $detail) {
    $icon = $ok ? '✅' : '❌';
    $color = $ok ? 'green' : 'red';
    echo "<p><b>$icon $label</b><br><span style='color:$color; font-size:14px;'>" . htmlspecialchars($detail) . "</span></p><hr>";
    return $ok;
}

// 1. Config file present and filled in
if (!file_exists(__DIR__ . '/telegram_config.php')) {
    step('Config file exists', false, 'telegram_config.php not found.');
    echo '</body></html>'; exit;
}
require_once __DIR__ . '/telegram_config.php';
$tokenSet = defined('TELEGRAM_BOT_TOKEN') && strpos(TELEGRAM_BOT_TOKEN, 'REPLACE_ME') === false;
if (!step('Bot token configured', $tokenSet, $tokenSet ? 'Token is set.' : 'TELEGRAM_BOT_TOKEN still has the placeholder value — paste the real token from @BotFather.')) {
    echo '</body></html>'; exit;
}
$secretSet = defined('TELEGRAM_WEBHOOK_SECRET') && strpos(TELEGRAM_WEBHOOK_SECRET, 'REPLACE_ME') === false;
step('Webhook secret configured', $secretSet, $secretSet ? 'Secret is set.' : 'TELEGRAM_WEBHOOK_SECRET still has the placeholder — set it to any random string.');

// 2. Token actually valid — ask Telegram who this bot is
$ch = curl_init('https://api.telegram.org/bot' . TELEGRAM_BOT_TOKEN . '/getMe');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$meResponse = curl_exec($ch);
$curlErr = curl_error($ch);
curl_close($ch);
$me = json_decode($meResponse, true);
if ($curlErr) {
    step('Server can reach Telegram', false, "cURL error: $curlErr — this host may be blocking outbound HTTPS requests. Contact your host if so.");
    echo '</body></html>'; exit;
}
$tokenValid = !empty($me['ok']);
step('Bot token is valid', $tokenValid, $tokenValid ? 'Connected as @' . $me['result']['username'] : 'Telegram rejected this token: ' . ($me['description'] ?? 'unknown error') . ' — double-check you copied the full token from @BotFather.');
if (!$tokenValid) { echo '</body></html>'; exit; }

// 3. What does Telegram currently have registered as the webhook?
$ch = curl_init('https://api.telegram.org/bot' . TELEGRAM_BOT_TOKEN . '/getWebhookInfo');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$infoResponse = curl_exec($ch);
curl_close($ch);
$info = json_decode($infoResponse, true)['result'] ?? [];

$expectedUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? '') . '/telegram_webhook.php';
$registeredUrl = $info['url'] ?? '';
$urlMatches = ($registeredUrl === $expectedUrl);
step('Webhook is registered', !empty($registeredUrl), $registeredUrl ? "Registered URL: $registeredUrl" : 'No webhook is registered at all — run telegram_setwebhook.php.');

if ($registeredUrl) {
    step('Registered URL matches this domain', $urlMatches, $urlMatches ? 'Matches.' : "Registered as \"$registeredUrl\" but this page is on \"$expectedUrl\" — re-run telegram_setwebhook.php if you changed domains.");
}

if (!empty($info['last_error_message'])) {
    step('Telegram\'s last delivery attempt', false, 'Telegram reported an error last time it tried to deliver a message: "' . $info['last_error_message'] . '" (at ' . date('Y-m-d H:i:s', $info['last_error_date'] ?? 0) . ' UTC). This usually means telegram_webhook.php returned an error or timed out — check your host\'s PHP error log for that time.');
} elseif (!empty($registeredUrl)) {
    step('No delivery errors reported', true, 'Telegram has not reported any errors delivering to your webhook.');
}

if (isset($info['pending_update_count']) && $info['pending_update_count'] > 0) {
    step('Pending updates', false, $info['pending_update_count'] . ' update(s) are queued and not yet delivered — Telegram will keep retrying, but this usually means your endpoint is failing or timing out.');
}

echo '<p style="color:#666; font-size:13px;">If everything above is ✅ but the bot still does not reply: message it, then immediately check your host\'s PHP error log (usually in your control panel\'s "Error Logs" section) for a fatal error in telegram_webhook.php — that would cause Telegram to log a delivery failure that will show up here on your NEXT run of this page.</p>';
echo '</body></html>';
?>
