<?php
// create_order.php — called by index.html right before opening Razorpay
// Checkout. Creates the order on Razorpay's side and a matching
// "pending" row here, so we have a place to attach the access token
// once payment succeeds.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);

$ip = get_client_ip();
if (is_ip_blocked($ip)) json_out(['ok' => false, 'error' => 'blocked'], 403);
if (!rate_limit_allow('create_order', $ip, 10, 600)) {
    json_out(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many attempts — please wait a few minutes and try again.'], 429);
}

$receipt = 'qc_' . bin2hex(random_bytes(8));
$errorOut = null;
$order = razorpay_create_order(OFFER_AMOUNT_PAISE, OFFER_CURRENCY, $receipt, $errorOut);
if (!$order) {
    json_out(['ok' => false, 'error' => 'order_failed', 'message' => $errorOut ?: 'Could not create order.'], 502);
}

$stmt = db()->prepare(
    'INSERT INTO tokens (token, razorpay_order_id, amount_paise, currency, duration_days, status, buyer_ip, created_at)
     VALUES (:token, :order_id, :amount, :currency, :duration, "pending", :ip, :now)'
);
// Placeholder token until payment is confirmed — verify_payment.php /
// webhook.php overwrite this with the real access token at that point.
$stmt->execute([
    'token' => 'pending_' . $order['id'],
    'order_id' => $order['id'],
    'amount' => OFFER_AMOUNT_PAISE,
    'currency' => OFFER_CURRENCY,
    'duration' => OFFER_DURATION_DAYS,
    'ip' => $ip,
    'now' => now_ms(),
]);

json_out([
    'ok' => true,
    'orderId' => $order['id'],
    'amount' => OFFER_AMOUNT_PAISE,
    'currency' => OFFER_CURRENCY,
    'keyId' => RAZORPAY_KEY_ID,
    'label' => OFFER_LABEL,
]);
