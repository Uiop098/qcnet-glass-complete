<?php
// verify_payment.php — the browser calls this right after Razorpay
// Checkout's own success callback fires, with the three values Razorpay
// hands back. We verify those cryptographically (never trust them
// blindly) before treating the order as paid.
//
// This is the FAST path for showing the token to the buyer immediately.
// webhook.php is the AUTHORITATIVE path (Razorpay's own server telling
// us directly) and exists as a fallback in case the browser closes/loses
// connection before this runs — see webhook.php for why both exist.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);

$ip = get_client_ip();
if (!rate_limit_allow('verify_payment', $ip, 20, 600)) {
    json_out(['ok' => false, 'error' => 'rate_limited'], 429);
}

$body = json_decode(file_get_contents('php://input'), true);
$orderId = isset($body['razorpay_order_id']) ? (string)$body['razorpay_order_id'] : '';
$paymentId = isset($body['razorpay_payment_id']) ? (string)$body['razorpay_payment_id'] : '';
$signature = isset($body['razorpay_signature']) ? (string)$body['razorpay_signature'] : '';

if ($orderId === '' || $paymentId === '' || $signature === '') {
    json_out(['ok' => false, 'error' => 'missing_fields'], 400);
}
if (!razorpay_verify_payment_signature($orderId, $paymentId, $signature)) {
    json_out(['ok' => false, 'error' => 'bad_signature', 'message' => 'Payment could not be verified.'], 400);
}

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM tokens WHERE razorpay_order_id = :order_id LIMIT 1');
$stmt->execute(['order_id' => $orderId]);
$row = $stmt->fetch();
if (!$row) json_out(['ok' => false, 'error' => 'unknown_order'], 404);

// Already confirmed (e.g. the webhook beat us to it) — hand back the
// same token instead of generating a second one for the same payment.
if ($row['status'] !== 'pending') {
    json_out(['ok' => true, 'token' => $row['token'], 'durationDays' => (int)$row['duration_days']]);
}

$accessToken = generate_access_token();
$upd = $pdo->prepare(
    'UPDATE tokens SET token = :token, razorpay_payment_id = :payment_id, status = "paid", paid_at = :now
     WHERE razorpay_order_id = :order_id AND status = "pending"'
);
$upd->execute(['token' => $accessToken, 'payment_id' => $paymentId, 'now' => now_ms(), 'order_id' => $orderId]);

if ($upd->rowCount() === 0) {
    // Lost the race to the webhook between our SELECT and UPDATE — read
    // back whatever it set instead of erroring out.
    $stmt->execute(['order_id' => $orderId]);
    $row = $stmt->fetch();
    json_out(['ok' => true, 'token' => $row['token'], 'durationDays' => (int)$row['duration_days']]);
}

json_out(['ok' => true, 'token' => $accessToken, 'durationDays' => OFFER_DURATION_DAYS]);
