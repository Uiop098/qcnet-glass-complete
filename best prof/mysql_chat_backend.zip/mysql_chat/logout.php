<?php
require 'db.php';
header('Content-Type: application/json');
session_start();

// Revoke the remember-me token in the DB, not just the cookie
if (!empty($_COOKIE['remember_me'])) {
    $parts = explode(':', $_COOKIE['remember_me']);
    if (count($parts) === 2) {
        $stmt = $pdo->prepare('DELETE FROM auth_tokens WHERE selector = ?');
        $stmt->execute([$parts[0]]);
    }
    setcookie('remember_me', '', ['expires' => time() - 3600, 'path' => '/']);
}

$_SESSION = [];
session_destroy();

echo json_encode(['success' => true]);
