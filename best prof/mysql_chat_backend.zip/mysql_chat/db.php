<?php
// Database connection — fill in your InfinityFree MySQL credentials
// Find these in your InfinityFree control panel under "MySQL Databases"

$host = 'sqlXXX.infinityfree.com'; // your MySQL hostname
$dbname = 'epiz_XXXXXXX_chatdb';    // your database name
$user = 'epiz_XXXXXXX';             // your MySQL username
$pass = 'YOUR_PASSWORD_HERE';       // your MySQL password

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'Database connection failed']));
}
