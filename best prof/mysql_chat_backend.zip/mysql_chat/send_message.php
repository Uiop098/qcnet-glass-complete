<?php
require 'db.php';
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode(['error' => 'Not logged in']));
}

$data = json_decode(file_get_contents('php://input'), true);
$room_id = (int)($data['room_id'] ?? 0);
$content = trim($data['content'] ?? '');

if (!$room_id || $content === '') {
    http_response_code(400);
    die(json_encode(['error' => 'Missing room_id or content']));
}

// Cap message length to prevent abuse
$content = mb_substr($content, 0, 2000);

$stmt = $pdo->prepare(
    'INSERT INTO messages (room_id, sender_id, content) VALUES (?, ?, ?)'
);
$stmt->execute([$room_id, $_SESSION['user_id'], $content]);

echo json_encode([
    'success' => true,
    'message_id' => $pdo->lastInsertId(),
    'created_at' => date('Y-m-d H:i:s'),
]);
