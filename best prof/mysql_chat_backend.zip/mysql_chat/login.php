<?php
require 'db.php';
header('Content-Type: application/json');
session_start();

$data = json_decode(file_get_contents('php://input'), true);
$username = trim($data['username'] ?? '');
$password = $data['password'] ?? '';
$remember = !empty($data['remember_me']);

if (!$username || !$password) {
    http_response_code(400);
    die(json_encode(['error' => 'Missing fields']));
}

$stmt = $pdo->prepare('SELECT id, username, password_hash FROM users WHERE username = ?');
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    die(json_encode(['error' => 'Invalid username or password']));
}

$upd = $pdo->prepare('UPDATE users SET last_seen = NOW() WHERE id = ?');
$upd->execute([$user['id']]);

$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];

if ($remember) {
    // Selector/validator pattern — never store the raw token in the DB
    $selector = bin2hex(random_bytes(9));
    $validator = bin2hex(random_bytes(33));
    $tokenHash = hash('sha256', $validator);
    $expiresAt = date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30); // 30 days

    $ins = $pdo->prepare(
        'INSERT INTO auth_tokens (user_id, selector, token_hash, expires_at) VALUES (?, ?, ?, ?)'
    );
    $ins->execute([$user['id'], $selector, $tokenHash, $expiresAt]);

    $cookieValue = $selector . ':' . $validator;
    setcookie('remember_me', $cookieValue, [
        'expires' => time() + 60 * 60 * 24 * 30,
        'path' => '/',
        'secure' => true,     // HTTPS only
        'httponly' => true,   // not accessible to JS — blocks XSS token theft
        'samesite' => 'Lax',
    ]);
}

echo json_encode(['success' => true, 'user_id' => $user['id'], 'username' => $user['username']]);
