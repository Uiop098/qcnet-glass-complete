<?php
// Include this at the very top of any protected page/endpoint,
// after session_start(), to auto-login returning users via their
// remember-me cookie if they don't already have an active session.

require_once __DIR__ . '/db.php';

function try_auto_login($pdo) {
    if (isset($_SESSION['user_id'])) {
        return; // already logged in
    }
    if (empty($_COOKIE['remember_me'])) {
        return; // no remember-me cookie
    }

    $parts = explode(':', $_COOKIE['remember_me']);
    if (count($parts) !== 2) {
        return;
    }
    [$selector, $validator] = $parts;

    $stmt = $pdo->prepare(
        'SELECT at.user_id, at.token_hash, at.expires_at, u.username
         FROM auth_tokens at
         JOIN users u ON u.id = at.user_id
         WHERE at.selector = ?'
    );
    $stmt->execute([$selector]);
    $row = $stmt->fetch();

    if (!$row || strtotime($row['expires_at']) < time()) {
        return; // no matching token or expired
    }

    // Constant-time comparison to prevent timing attacks
    if (!hash_equals($row['token_hash'], hash('sha256', $validator))) {
        return; // token mismatch — possible tampering
    }

    // Valid — log the user in and rotate the token (prevents replay if stolen)
    $_SESSION['user_id'] = $row['user_id'];
    $_SESSION['username'] = $row['username'];

    $newSelector = bin2hex(random_bytes(9));
    $newValidator = bin2hex(random_bytes(33));
    $newHash = hash('sha256', $newValidator);
    $newExpires = date('Y-m-d H:i:s', time() + 60 * 60 * 24 * 30);

    $upd = $pdo->prepare(
        'UPDATE auth_tokens SET selector = ?, token_hash = ?, expires_at = ? WHERE selector = ?'
    );
    $upd->execute([$newSelector, $newHash, $newExpires, $selector]);

    setcookie('remember_me', $newSelector . ':' . $newValidator, [
        'expires' => time() + 60 * 60 * 24 * 30,
        'path' => '/',
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    $touch = $pdo->prepare('UPDATE users SET last_seen = NOW() WHERE id = ?');
    $touch->execute([$row['user_id']]);
}

try_auto_login($pdo);
