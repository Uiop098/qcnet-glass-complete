<?php
require 'db.php';
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode(['error' => 'Not logged in']));
}

$room_id = (int)($_GET['room_id'] ?? 0);
$since = $_GET['since'] ?? '1970-01-01 00:00:00'; // last timestamp client has

if (!$room_id) {
    http_response_code(400);
    die(json_encode(['error' => 'Missing room_id']));
}

$stmt = $pdo->prepare(
    'SELECT m.id, m.sender_id, u.username, m.content, m.created_at
     FROM messages m
     JOIN users u ON u.id = m.sender_id
     WHERE m.room_id = ? AND m.created_at > ?
     ORDER BY m.created_at ASC
     LIMIT 100'
);
$stmt->execute([$room_id, $since]);
$messages = $stmt->fetchAll();

echo json_encode(['messages' => $messages]);
