import { useEffect, useMemo, useState, type CSSProperties, type ReactNode } from "react";
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Bell,
  Building2,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  ClipboardList,
  CreditCard,
  Download,
  FileText,
  Filter,
  LayoutDashboard,
  LineChart,
  LockKeyhole,
  Menu,
  MoreHorizontal,
  Palette,
  PanelLeft,
  Plus,
  Search,
  Server,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  UserRound,
  UserCog,
  UsersRound,
  WalletCards,
  X,
} from "lucide-react";

type ThemeName = "Nocturne" | "Aurora" | "Ember" | "Frost";
type Page = "Overview" | "Operations" | "Businesses" | "People" | "Payments" | "Reports" | "Profile" | "Settings" | "Access" | "Theme Studio";
type Role = "Admin" | "Member";
type AssignableRole = "Owner" | "Admin" | "Manager" | "Member" | "Viewer";
type LayoutMode = "Auto" | "Desktop" | "Mobile";
type ChartMode = "bar" | "line";
type HostedManifest = { version?: number; defaultTheme?: string; themes?: { id: string; name: string }[] };
type ThemePalette = { accent: string; accentSoft: string; bg: string; panel: string; panelStrong: string; text: string; muted: string; border: string; glow: string };
type Business = { id: string; name: string; type: string; status: string; members: number; revenue: string; lastActivity: string };
type DataRow = { id: number; label: string; value: number };
type WorkspaceUser = { id: string; initials: string; name: string; email: string; role: AssignableRole; status: string; tone: string };
type Permission = { id: string; label: string; description: string; group: string };

const themes: Record<ThemeName, ThemePalette> = {
  Nocturne: { accent: "#8de7c1", accentSoft: "rgba(141,231,193,.15)", bg: "#111b22", panel: "rgba(28,44,54,.68)", panelStrong: "rgba(39,59,69,.9)", text: "#edf6f2", muted: "#9aafb0", border: "rgba(181,215,207,.15)", glow: "rgba(109,212,187,.22)" },
  Aurora: { accent: "#b8d6ff", accentSoft: "rgba(184,214,255,.16)", bg: "#111b2b", panel: "rgba(36,52,78,.64)", panelStrong: "rgba(46,68,102,.88)", text: "#eff5ff", muted: "#9caec7", border: "rgba(193,216,255,.16)", glow: "rgba(119,164,238,.22)" },
  Ember: { accent: "#f4b27e", accentSoft: "rgba(244,178,126,.16)", bg: "#21191a", panel: "rgba(66,42,39,.62)", panelStrong: "rgba(87,52,45,.9)", text: "#fff3ec", muted: "#c4a6a0", border: "rgba(255,204,177,.15)", glow: "rgba(228,126,94,.22)" },
  Frost: { accent: "#94ddd9", accentSoft: "rgba(148,221,217,.18)", bg: "#102027", panel: "rgba(37,61,68,.62)", panelStrong: "rgba(49,80,88,.9)", text: "#e9fbfa", muted: "#9bb8ba", border: "rgba(196,242,239,.17)", glow: "rgba(91,193,191,.22)" },
};

const navItems: { label: Page; icon: typeof LayoutDashboard; adminOnly?: boolean }[] = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "Operations", icon: Activity },
  { label: "Businesses", icon: Building2 },
  { label: "People", icon: UsersRound },
  { label: "Access", icon: UserCog, adminOnly: true },
  { label: "Payments", icon: CreditCard },
  { label: "Reports", icon: BarChart3 },
  { label: "Profile", icon: UserRound },
  { label: "Settings", icon: Settings2, adminOnly: true },
  { label: "Theme Studio", icon: Palette },
];

const initialBusinesses: Business[] = [
  { id: "lumen", name: "Lumen House LLC", type: "Creative studio", status: "Active", members: 24, revenue: "$42,680", lastActivity: "12 min ago" },
  { id: "nook", name: "Nook & Co.", type: "Retail partner", status: "Active", members: 8, revenue: "$18,240", lastActivity: "Yesterday" },
  { id: "northstar", name: "Northstar Labs", type: "Consulting", status: "Onboarding", members: 5, revenue: "$7,940", lastActivity: "2 days ago" },
];

const initialRows: DataRow[] = [
  { id: 1, label: "Jan", value: 21800 },
  { id: 2, label: "Feb", value: 26400 },
  { id: 3, label: "Mar", value: 23900 },
  { id: 4, label: "Apr", value: 31800 },
  { id: 5, label: "May", value: 35600 },
  { id: 6, label: "Jun", value: 42680 },
];

const permissions: Permission[] = [
  { id: "overview", label: "View overview", description: "See business health, activity, and summary metrics.", group: "Workspace" },
  { id: "businesses", label: "Manage businesses", description: "Create workspaces, switch businesses, and edit identity.", group: "Workspace" },
  { id: "people", label: "Manage people", description: "Invite people, assign roles, and review access.", group: "Workspace" },
  { id: "operations", label: "Manage operations", description: "Create, complete, and prioritize action items.", group: "Workspace" },
  { id: "payments_view", label: "View payments", description: "Read transactions, payouts, and payment health.", group: "Finance" },
  { id: "payments_manage", label: "Manage payments", description: "Record payments, issue refunds, and export finance data.", group: "Finance" },
  { id: "reports", label: "Build reports", description: "Edit tables, create graphs, save reports, and export.", group: "Insights" },
  { id: "settings", label: "Manage settings", description: "Change notifications, security, and business configuration.", group: "Administration" },
  { id: "themes", label: "Manage themes", description: "Choose, edit, sync, and publish hosted themes.", group: "Administration" },
];

const defaultRolePermissions: Record<AssignableRole, Record<string, boolean>> = {
  Owner: Object.fromEntries(permissions.map(permission => [permission.id, true])),
  Admin: Object.fromEntries(permissions.map(permission => [permission.id, true])),
  Manager: Object.fromEntries(permissions.map(permission => [permission.id, !["payments_manage", "settings"].includes(permission.id)])),
  Member: Object.fromEntries(permissions.map(permission => [permission.id, ["overview", "people", "operations", "payments_view", "reports"].includes(permission.id)])),
  Viewer: Object.fromEntries(permissions.map(permission => [permission.id, ["overview", "payments_view", "reports"].includes(permission.id)])),
};

const initialUsers: WorkspaceUser[] = [
  { id: "rowan", initials: "RC", name: "Rowan Chen", email: "rowan@lumen.house", role: "Owner", status: "Online", tone: "sage" },
  { id: "ari", initials: "AS", name: "Ari Singh", email: "ari@lumen.house", role: "Member", status: "Online", tone: "sage" },
  { id: "jordan", initials: "JP", name: "Jordan Park", email: "jordan@lumen.house", role: "Manager", status: "Away", tone: "amber" },
  { id: "priya", initials: "PS", name: "Priya Shah", email: "priya@lumen.house", role: "Admin", status: "Online", tone: "lilac" },
  { id: "mara", initials: "ML", name: "Mara Lewis", email: "mara@lumen.house", role: "Viewer", status: "Offline", tone: "coral" },
];

function hexToRgba(value: string, opacity: number) {
  const match = value.replace("#", "").match(/^([0-9a-f]{6})$/i);
  if (!match) return `rgba(141,231,193,${opacity})`;
  const number = Number.parseInt(match[1], 16);
  return `rgba(${number >> 16},${(number >> 8) & 255},${number & 255},${opacity})`;
}

function Surface({ children, className = "", strong = false }: { children: ReactNode; className?: string; strong?: boolean }) {
  return <section className={`dash-surface ${strong ? "dash-surface-strong" : ""} ${className}`}>{children}</section>;
}

function Avatar({ initials, tone = "sage" }: { initials: string; tone?: string }) {
  return <span className={`dash-avatar dash-avatar-${tone}`}>{initials}</span>;
}

function MiniChart({ accent }: { accent: string }) {
  const points = "0,48 14,43 28,45 42,30 56,34 70,21 84,28 98,17 112,23 126,10 140,14 154,4";
  return <svg viewBox="0 0 154 56" className="h-14 w-full overflow-visible" aria-label="Revenue trend chart" role="img"><defs><linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={accent} stopOpacity=".3" /><stop offset="1" stopColor={accent} stopOpacity="0" /></linearGradient></defs><polygon points={`0,56 ${points} 154,56`} fill="url(#chartFill)" /><polyline points={points} fill="none" stroke={accent} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /><circle cx="154" cy="4" r="3.5" fill={accent} /></svg>;
}

export function UniversalDashboard() {
  const [page, setPage] = useState<Page>("Overview");
  const [themeName, setThemeName] = useState<ThemeName>("Nocturne");
  const [customAccent, setCustomAccent] = useState<string | null>(null);
  const [role, setRole] = useState<Role>("Admin");
  const [layout, setLayout] = useState<LayoutMode>("Auto");
  const [density, setDensity] = useState(74);
  const [studioTab, setStudioTab] = useState<"themes" | "tokens">("themes");
  const [json, setJson] = useState('{\n  "accent": "#8de7c1",\n  "surfaceOpacity": 0.68,\n  "radius": 18,\n  "glow": "soft"\n}');
  const [toast, setToast] = useState("");
  const [mobileNav, setMobileNav] = useState(false);
  const [hostedManifest, setHostedManifest] = useState<HostedManifest | null>(null);
  const [businesses, setBusinesses] = useState(initialBusinesses);
  const [activeBusinessId, setActiveBusinessId] = useState("lumen");
  const [newBusinessName, setNewBusinessName] = useState("");
  const [rows, setRows] = useState(initialRows);
  const [chartMode, setChartMode] = useState<ChartMode>("bar");
  const [users, setUsers] = useState<WorkspaceUser[]>(initialUsers);
  const [selectedAccessRole, setSelectedAccessRole] = useState<AssignableRole>("Manager");
  const [rolePermissions, setRolePermissions] = useState(defaultRolePermissions);
  const [userOverrides, setUserOverrides] = useState<Record<string, Record<string, boolean>>>({});

  const baseTheme = themes[themeName];
  const theme = useMemo(() => customAccent ? { ...baseTheme, accent: customAccent, accentSoft: hexToRgba(customAccent, .16), glow: hexToRgba(customAccent, .22) } : baseTheme, [baseTheme, customAccent]);
  const isMember = role === "Member";
  const activeBusiness = businesses.find(business => business.id === activeBusinessId) ?? businesses[0];
  const compact = density < 52;
  const maxWidth = layout === "Mobile" ? 590 : layout === "Desktop" ? 1480 : density > 82 ? 1480 : 1180;
  const cssVars = useMemo(() => ({
    "--dash-accent": theme.accent,
    "--dash-accent-soft": theme.accentSoft,
    "--dash-bg": theme.bg,
    "--dash-panel": theme.panel,
    "--dash-panel-strong": theme.panelStrong,
    "--dash-text": theme.text,
    "--dash-muted": theme.muted,
    "--dash-border": theme.border,
    "--dash-glow": theme.glow,
    "--dash-gap": compact ? "12px" : "18px",
  } as CSSProperties), [theme, compact]);

  useEffect(() => {
    const previewRoot = window.location.pathname.split("/preview/")[0] || "/__mockup";
    fetch(`${previewRoot}/themes.json`)
      .then(response => response.ok ? response.json() as Promise<HostedManifest> : Promise.reject(new Error("Theme manifest unavailable")))
      .then(setHostedManifest)
      .catch(() => setHostedManifest(null));
  }, []);

  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2400);
  };

  const chooseTheme = (name: ThemeName) => {
    setThemeName(name);
    setCustomAccent(null);
    setJson(`{\n  "accent": "${themes[name].accent}",\n  "surfaceOpacity": 0.68,\n  "radius": 18,\n  "glow": "soft"\n}`);
    notify(`${name} theme applied`);
  };

  const createBusiness = () => {
    const name = newBusinessName.trim();
    if (!name) {
      notify("Enter a business name first");
      return;
    }
    const id = `${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now()}`;
    setBusinesses(current => [...current, { id, name, type: "New workspace", status: "Setup needed", members: 1, revenue: "$0", lastActivity: "Just now" }]);
    setActiveBusinessId(id);
    setNewBusinessName("");
    notify(`${name} workspace created`);
  };

  const updateRow = (id: number, key: "label" | "value", value: string) => {
    setRows(current => current.map(row => row.id === id ? { ...row, [key]: key === "value" ? Number(value) || 0 : value } : row));
  };

  const addRow = () => setRows(current => [...current, { id: Math.max(0, ...current.map(row => row.id)) + 1, label: "New", value: 0 }]);
  const removeRow = (id: number) => setRows(current => current.filter(row => row.id !== id));

  const applyCustomTheme = () => {
    try {
      const parsed = JSON.parse(json) as { accent?: unknown };
      if (typeof parsed.accent !== "string" || !/^#[0-9a-f]{6}$/i.test(parsed.accent)) {
        notify("Accent must be a six-digit hex color");
        return;
      }
      setCustomAccent(parsed.accent);
      notify("Custom theme saved and applied");
    } catch {
      notify("Fix the JSON syntax before applying");
    }
  };

  const updateUserRole = (userId: string, userRole: AssignableRole) => {
    setUsers(current => current.map(user => user.id === userId ? { ...user, role: userRole } : user));
    notify("User role updated");
  };

  const toggleRolePermission = (userRole: AssignableRole, permissionId: string) => {
    setRolePermissions(current => ({ ...current, [userRole]: { ...current[userRole], [permissionId]: !current[userRole][permissionId] } }));
    notify(`${userRole} permissions updated`);
  };

  const toggleUserOverride = (userId: string, permissionId: string) => {
    const user = users.find(item => item.id === userId);
    if (!user) return;
    const currentValue = userOverrides[userId]?.[permissionId] ?? rolePermissions[user.role][permissionId];
    setUserOverrides(current => ({ ...current, [userId]: { ...current[userId], [permissionId]: !currentValue } }));
    notify("Individual access override updated");
  };

  return (
    <div className="universal-shell" style={cssVars}>
      <style>{`
        .universal-shell{min-height:100vh;background:radial-gradient(circle at 82% 8%,var(--dash-glow),transparent 28%),radial-gradient(circle at 15% 85%,rgba(45,99,109,.18),transparent 30%),var(--dash-bg);color:var(--dash-text);font-family:'DM Sans','Plus Jakarta Sans',ui-sans-serif,sans-serif;letter-spacing:-.01em}
        .universal-shell *{box-sizing:border-box}.dash-surface{background:var(--dash-panel);border:1px solid var(--dash-border);box-shadow:0 18px 55px rgba(1,8,12,.22),inset 0 1px rgba(255,255,255,.04);backdrop-filter:blur(22px);border-radius:20px}.dash-surface-strong{background:var(--dash-panel-strong)}
        .dash-avatar{width:31px;height:31px;display:inline-grid;place-items:center;border-radius:10px;font-size:10px;font-weight:800;color:#112025;background:#a8ddc7}.dash-avatar-lilac{background:#b8c3f4;color:#1a2237}.dash-avatar-amber{background:#efbc86;color:#39251b}.dash-avatar-coral{background:#ef9c83;color:#3b201a}
        .dash-button{transition:transform .18s ease,background .18s ease,border-color .18s ease}.dash-button:hover{transform:translateY(-1px)}.dash-button:focus-visible,.dash-nav:focus-visible{outline:2px solid var(--dash-accent);outline-offset:3px}
        .dash-nav{color:var(--dash-muted);transition:all .18s ease}.dash-nav:hover,.dash-nav-active{background:var(--dash-accent-soft);color:var(--dash-text)}.dash-nav-active{box-shadow:inset 3px 0 var(--dash-accent)}
        .dash-input,.dash-select{background:rgba(7,16,22,.25);border:1px solid var(--dash-border);color:var(--dash-text);outline:none}.dash-input:focus,.dash-select:focus{border-color:var(--dash-accent);box-shadow:0 0 0 3px var(--dash-accent-soft)}.dash-select option{background:#182b35;color:#edf6f2}
        .dash-scroll::-webkit-scrollbar{width:5px}.dash-scroll::-webkit-scrollbar-thumb{background:var(--dash-border);border-radius:9px}.dash-table input{min-width:0;background:transparent;color:var(--dash-text);outline:none}.dash-table input:focus{border-bottom:1px solid var(--dash-accent)}
        @media(max-width:800px){.dash-sidebar{display:none}.dash-content{padding:18px!important}.dash-grid{grid-template-columns:1fr!important}.dash-header-title{font-size:25px!important}.dash-topbar{padding:16px!important}.dash-mobile-nav{display:flex!important}.dash-content{max-height:none!important}.dash-table{min-width:540px}.dash-table-wrap{overflow-x:auto}}
      `}</style>
      <div className="mx-auto flex min-h-screen" style={{ maxWidth }}>
        <aside className="dash-sidebar flex w-[226px] shrink-0 flex-col border-r px-4 py-5" style={{ borderColor: theme.border }}>
          <div className="mb-8 flex items-center gap-3 px-2"><div className="grid h-9 w-9 place-items-center rounded-xl" style={{ background: theme.accent, color: theme.bg }}><Sparkles size={18} /></div><div><div className="font-semibold tracking-tight">Lumen / HQ</div><div className="text-[10px] uppercase tracking-[.18em]" style={{ color: theme.muted }}>Operator workspace</div></div></div>
          <div className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.18em]" style={{ color: theme.muted }}>Workspace</div>
          <nav className="space-y-1" aria-label="Main navigation">{navItems.filter(item => !item.adminOnly || !isMember).map(({ label, icon: Icon }) => <button key={label} onClick={() => setPage(label)} className={`dash-nav flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm ${page === label ? "dash-nav-active font-semibold" : ""}`}><Icon size={17} strokeWidth={1.8} /><span>{label}</span>{label === "Operations" && <span className="ml-auto rounded-md px-1.5 py-0.5 text-[10px]" style={{ background: theme.accentSoft, color: theme.accent }}>3</span>}{label === "Payments" && <span className="ml-auto rounded-md px-1.5 py-0.5 text-[10px]" style={{ background: "rgba(240,165,125,.13)", color: "#f0a57d" }}>4</span>}</button>)}</nav>
          <div className="mt-auto"><div className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.18em]" style={{ color: theme.muted }}>Workspace role</div><div className="flex rounded-xl border p-1" style={{ borderColor: theme.border, background: "rgba(4,12,17,.2)" }}>{(["Admin", "Member"] as Role[]).map(currentRole => <button key={currentRole} onClick={() => { setRole(currentRole); if (currentRole === "Member" && page === "Settings") setPage("Profile"); notify(`${currentRole} view enabled`); }} className="flex-1 rounded-lg px-2 py-2 text-xs font-semibold" style={{ background: role === currentRole ? theme.accentSoft : "transparent", color: role === currentRole ? theme.accent : theme.muted }}>{currentRole}</button>)}</div><button onClick={() => notify("Help center opened")} className="dash-button mt-5 flex items-center gap-2 px-3 text-xs" style={{ color: theme.muted }}><CircleHelp size={15} /> Help center <ChevronRight size={13} className="ml-auto" /></button></div>
        </aside>
        <main className="min-w-0 flex-1">
          <header className="dash-topbar flex flex-wrap items-center justify-between gap-4 border-b px-7 py-5" style={{ borderColor: theme.border }}>
            <div className="flex min-w-0 items-center gap-3"><button onClick={() => setMobileNav(!mobileNav)} className="dash-mobile-nav hidden rounded-lg border p-2" style={{ borderColor: theme.border }} aria-label="Toggle navigation">{mobileNav ? <X size={17} /> : <Menu size={17} />}</button><div className="min-w-0"><div className="text-xs" style={{ color: theme.muted }}>Tuesday, October 24, 2024</div><h1 className="dash-header-title mt-1 truncate text-2xl font-semibold tracking-tight">{page === "Overview" ? `Good morning, Rowan.` : page}</h1></div></div>
            <div className="flex items-center gap-2"><div className="hidden items-center gap-2 sm:flex"><Building2 size={14} style={{ color: theme.muted }} /><select className="dash-select rounded-lg px-2.5 py-2 text-xs" value={activeBusinessId} onChange={event => { setActiveBusinessId(event.target.value); notify("Business workspace switched"); }} aria-label="Choose business">{businesses.map(business => <option key={business.id} value={business.id}>{business.name}</option>)}</select><ChevronDown size={13} style={{ color: theme.muted }} /></div><button onClick={() => notify("No new notifications")} className="dash-button rounded-xl border p-2.5" style={{ borderColor: theme.border, color: theme.muted }} aria-label="Notifications"><Bell size={17} /></button><div className="hidden h-8 w-px sm:block" style={{ background: theme.border }} /><button onClick={() => setPage("Profile")} className="flex items-center gap-2"><Avatar initials="RC" /><span className="hidden text-sm font-medium sm:block">Rowan Chen</span></button></div>
          </header>
          {mobileNav && <div className="dash-mobile-nav border-b px-5 py-3 md:hidden" style={{ borderColor: theme.border }}><div className="mb-3 flex items-center gap-2"><Building2 size={14} style={{ color: theme.muted }} /><select className="dash-select flex-1 rounded-lg px-2.5 py-2 text-xs" value={activeBusinessId} onChange={event => setActiveBusinessId(event.target.value)} aria-label="Choose business">{businesses.map(business => <option key={business.id} value={business.id}>{business.name}</option>)}</select></div>{navItems.filter(item => !item.adminOnly || !isMember).map(({ label, icon: Icon }) => <button key={label} onClick={() => { setPage(label); setMobileNav(false); }} className="mr-2 inline-flex items-center gap-2 rounded-lg px-2 py-2 text-xs" style={{ background: page === label ? theme.accentSoft : "transparent", color: page === label ? theme.accent : theme.muted }}><Icon size={14} />{label}</button>)}</div>}
          <div className="dash-content dash-scroll max-h-[calc(100vh-84px)] overflow-auto px-7 py-7">
            {page === "Overview" && <Overview theme={theme} business={activeBusiness} member={isMember} compact={compact} notify={notify} setPage={setPage} />}
            {page === "Operations" && <Operations theme={theme} notify={notify} />}
            {page === "Businesses" && <BusinessesPage theme={theme} businesses={businesses} activeBusinessId={activeBusinessId} setActiveBusinessId={id => { setActiveBusinessId(id); notify("Business workspace selected"); }} newBusinessName={newBusinessName} setNewBusinessName={setNewBusinessName} createBusiness={createBusiness} member={isMember} notify={notify} />}
            {page === "People" && <People theme={theme} notify={notify} member={isMember} />}
            {page === "Access" && <AccessPage theme={theme} users={users} selectedRole={selectedAccessRole} setSelectedRole={setSelectedAccessRole} rolePermissions={rolePermissions} userOverrides={userOverrides} updateUserRole={updateUserRole} toggleRolePermission={toggleRolePermission} toggleUserOverride={toggleUserOverride} notify={notify} />}
            {page === "Payments" && <Payments theme={theme} notify={notify} member={isMember} business={activeBusiness} />}
            {page === "Reports" && <Reports theme={theme} notify={notify} rows={rows} chartMode={chartMode} setChartMode={setChartMode} updateRow={updateRow} addRow={addRow} removeRow={removeRow} business={activeBusiness} />}
            {page === "Profile" && <Profile theme={theme} notify={notify} member={isMember} />}
            {page === "Settings" && <Settings theme={theme} notify={notify} member={isMember} />}
            {page === "Theme Studio" && <ThemeStudio theme={theme} themeName={themeName} setTheme={chooseTheme} studioTab={studioTab} setStudioTab={setStudioTab} json={json} setJson={setJson} applyCustomTheme={applyCustomTheme} notify={notify} layout={layout} setLayout={setLayout} density={density} setDensity={setDensity} hostedManifest={hostedManifest} />}
          </div>
        </main>
      </div>
      {toast && <div className="fixed bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-xl border px-4 py-3 text-sm shadow-2xl" style={{ background: theme.panelStrong, borderColor: theme.accent, color: theme.text }}><Check size={16} style={{ color: theme.accent }} />{toast}</div>}
    </div>
  );
}

function Overview({ theme, business, member, compact, notify, setPage }: { theme: ThemePalette; business: Business; member: boolean; compact: boolean; notify: (s: string) => void; setPage: (page: Page) => void }) {
  return <div className="space-y-5">
    <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="text-sm" style={{ color: theme.muted }}>{business.name} · {business.type}</p><p className="mt-1 text-xs" style={{ color: theme.muted }}>Here’s the pulse across your workspace.</p></div><div className="flex gap-2"><button onClick={() => setPage("Reports")} className="dash-button flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-semibold" style={{ borderColor: theme.border, color: theme.text }}><BarChart3 size={14} /> Build report</button><button onClick={() => notify("Report exported")} className="dash-button flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-semibold" style={{ borderColor: theme.border, color: theme.text }}><Download size={14} /> Export</button></div></div>
    <div className="dash-grid grid gap-4 md:grid-cols-[1.15fr_.85fr]">
      <Surface strong className="p-5"><div className="flex items-start justify-between"><div><div className="flex items-center gap-2 text-xs font-medium" style={{ color: theme.muted }}><WalletCards size={15} /> Net revenue <span className="rounded-md px-1.5 py-0.5 text-[10px]" style={{ background: theme.accentSoft, color: theme.accent }}>This month</span></div><div className="mt-3 text-4xl font-semibold tracking-[-.05em]">{business.revenue}<span className="text-lg" style={{ color: theme.muted }}>.40</span></div><div className="mt-2 flex items-center gap-1 text-xs" style={{ color: theme.accent }}><ArrowUpRight size={14} /> 12.8% from last month</div></div><div className="rounded-xl p-2" style={{ background: theme.accentSoft, color: theme.accent }}><ArrowUpRight size={18} /></div></div><div className="mt-7"><MiniChart accent={theme.accent} /><div className="mt-2 flex justify-between text-[10px]" style={{ color: theme.muted }}><span>Oct 01</span><span>Oct 08</span><span>Oct 15</span><span>Oct 24</span></div></div></Surface>
      <Surface className="p-5"><div className="flex items-center justify-between"><div className="text-xs font-medium" style={{ color: theme.muted }}>Workspace health</div><span className="flex items-center gap-1 text-[10px]" style={{ color: theme.accent }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: theme.accent }} /> Healthy</span></div><div className="mt-4 flex items-center gap-5"><div className="relative grid h-24 w-24 place-items-center rounded-full" style={{ background: `conic-gradient(${theme.accent} 0 86%, ${theme.accentSoft} 86% 100%)` }}><div className="grid h-[74px] w-[74px] place-items-center rounded-full" style={{ background: theme.panelStrong }}><span className="text-2xl font-semibold">86</span></div></div><div className="space-y-3 text-xs"><div><span style={{ color: theme.muted }}>Tasks complete</span><div className="mt-1 font-semibold">48 of 56</div></div><div><span style={{ color: theme.muted }}>Response time</span><div className="mt-1 font-semibold">1h 42m</div></div></div></div><div className="mt-5 border-t pt-4 text-xs" style={{ borderColor: theme.border, color: theme.muted }}>Strong week. Your team is <span style={{ color: theme.text }}>8% faster</span> than September.</div></Surface>
    </div>
    <div className="dash-grid grid gap-4 md:grid-cols-4"><Metric icon={UsersRound} label="Active people" value={member ? "12" : String(business.members)} detail="+3 this week" theme={theme} /><Metric icon={CreditCard} label="Successful payments" value="184" detail="96.4% success rate" theme={theme} /><Metric icon={Building2} label="Businesses" value="03" detail="1 onboarding" theme={theme} /><Metric icon={Activity} label="Open actions" value={compact ? "7" : "07"} detail="3 need attention" theme={theme} /></div>
    <div className="dash-grid grid gap-4 md:grid-cols-[1fr_1fr]"><Surface className="p-5"><SectionTitle title="Pending actions" eyebrow="Keep the loop moving" theme={theme} action="View all" onAction={() => setPage("Operations")} /><div className="mt-4 space-y-1">{[["Approve access for Priya", "Security · 12 min ago", ShieldCheck, "amber"], ["Review October payouts", "Finance · due today", WalletCards, "sage"], ["Update business profile", "Workspace · 2 days ago", UserRound, "lilac"]].slice(0, member ? 2 : 3).map(([title, sub, Icon, tone]) => <button key={title as string} onClick={() => notify(`${title} opened`)} className="dash-button flex w-full items-center gap-3 rounded-xl p-3 text-left" style={{ background: "rgba(3,12,17,.18)" }}><span className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg dash-avatar-${tone}`}><Icon size={16} /></span><span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{title as string}</span><span className="block text-[11px]" style={{ color: theme.muted }}>{sub as string}</span></span><ChevronRight size={15} style={{ color: theme.muted }} /></button>)}</div></Surface>
      <Surface className="p-5"><SectionTitle title="Recent activity" eyebrow="A quiet trail of progress" theme={theme} action="See history" onAction={() => notify("Activity history opened")} /><div className="mt-4 space-y-4">{[["RC", "Rowan approved a payout", "11:24 AM", "sage"], ["AM", "Ari added a new client", "09:18 AM", "lilac"], ["JP", "Jordan completed onboarding", "Yesterday", "amber"]].map(([initials, text, time, tone]) => <div className="flex items-center gap-3" key={text}><Avatar initials={initials as string} tone={tone as string} /><div className="min-w-0 flex-1"><p className="truncate text-sm">{text}</p><p className="text-[11px]" style={{ color: theme.muted }}>{time}</p></div><MoreHorizontal size={15} style={{ color: theme.muted }} /></div>)}</div></Surface></div>
  </div>;
}

function Metric({ icon: Icon, label, value, detail, theme }: { icon: typeof Activity; label: string; value: string; detail: string; theme: ThemePalette }) {
  return <Surface className="p-4"><div className="flex items-center justify-between"><span className="text-xs" style={{ color: theme.muted }}>{label}</span><Icon size={16} style={{ color: theme.accent }} /></div><div className="mt-4 text-2xl font-semibold">{value}</div><div className="mt-1 flex items-center gap-1 text-[11px]" style={{ color: theme.accent }}><ArrowUpRight size={12} />{detail}</div></Surface>;
}

function SectionTitle({ title, eyebrow, theme, action, onAction }: { title: string; eyebrow: string; theme: ThemePalette; action: string; onAction: () => void }) {
  return <div className="flex items-end justify-between"><div><div className="text-[10px] uppercase tracking-[.16em]" style={{ color: theme.accent }}>{eyebrow}</div><h2 className="mt-1 text-base font-semibold">{title}</h2></div><button onClick={onAction} className="text-xs" style={{ color: theme.muted }}>{action} <ChevronRight size={13} className="inline" /></button></div>;
}

function PageIntro({ kicker, title, theme, action, onAction }: { kicker: string; title: string; theme: ThemePalette; action: string; onAction: () => void }) {
  return <div className="flex flex-wrap items-end justify-between gap-4"><div><div className="text-[10px] uppercase tracking-[.18em]" style={{ color: theme.accent }}>{kicker}</div><h2 className="mt-2 text-3xl font-semibold tracking-[-.045em]">{title}</h2></div><button onClick={onAction} className="dash-button flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold" style={{ background: theme.accent, color: theme.bg }}><Plus size={15} /> {action}</button></div>;
}

function Operations({ theme, notify }: { theme: ThemePalette; notify: (s: string) => void }) {
  return <div className="space-y-5"><PageIntro kicker="Operations / 24 active" title="Make the next move obvious." theme={theme} action="New task" onAction={() => notify("New task created")} /><Surface className="overflow-hidden"><div className="flex items-center justify-between border-b p-5" style={{ borderColor: theme.border }}><div><h2 className="font-semibold">Action queue</h2><p className="mt-1 text-xs" style={{ color: theme.muted }}>Prioritized by urgency and owner.</p></div><button onClick={() => notify("Filters opened")} className="dash-button rounded-lg border p-2" style={{ borderColor: theme.border }} aria-label="Filter actions"><Filter size={16} /></button></div>{[["Approve access for Priya Shah", "Security", "Due in 2 hours", "High"], ["Reconcile payout #8831", "Finance", "Due today", "Medium"], ["Send welcome sequence to Nook & Co.", "Client success", "Tomorrow", "Low"], ["Review quarterly vendor contract", "Operations", "Friday", "Low"]].map(([name, type, due, priority]) => <div key={name} className="flex flex-wrap items-center gap-3 border-b px-5 py-4 last:border-0" style={{ borderColor: theme.border }}><div className="h-2 w-2 rounded-full" style={{ background: priority === "High" ? "#ef9b78" : priority === "Medium" ? theme.accent : theme.muted }} /><div className="min-w-[220px] flex-1"><div className="text-sm font-medium">{name}</div><div className="mt-1 text-xs" style={{ color: theme.muted }}>{type}</div></div><div className="text-xs" style={{ color: theme.muted }}>{due}</div><span className="rounded-md px-2 py-1 text-[10px]" style={{ color: theme.accent, background: theme.accentSoft }}>{priority}</span><button onClick={() => notify(`${name} marked complete`)} className="dash-button rounded-lg border p-2" style={{ borderColor: theme.border }} aria-label={`Complete ${name}`}><Check size={14} /></button></div>)}</Surface></div>;
}

function BusinessesPage({ theme, businesses, activeBusinessId, setActiveBusinessId, newBusinessName, setNewBusinessName, createBusiness, member, notify }: { theme: ThemePalette; businesses: Business[]; activeBusinessId: string; setActiveBusinessId: (id: string) => void; newBusinessName: string; setNewBusinessName: (value: string) => void; createBusiness: () => void; member: boolean; notify: (s: string) => void }) {
  return <div className="space-y-5"><PageIntro kicker="Business / Portfolio" title="Everything you operate, together." theme={theme} action={member ? "Request access" : "Create business"} onAction={() => member ? notify("Access request sent to an admin") : document.getElementById("new-business")?.focus()} /><div className="dash-grid grid gap-4 md:grid-cols-3">{[["Portfolio revenue", "$68,860", "Across 3 workspaces"], ["People managed", "37", "12 active today"], ["Setup completion", "84%", "One workspace needs setup"]].map(([label, value, detail], index) => <Surface key={label} className="p-5"><div className="text-xs" style={{ color: theme.muted }}>{label}</div><div className="mt-3 text-2xl font-semibold">{value}</div><div className="mt-1 text-[11px]" style={{ color: index === 2 ? "#f0a57d" : theme.accent }}>{detail}</div></Surface>)}</div><Surface className="overflow-hidden"><div className="flex flex-wrap items-center justify-between gap-3 border-b p-5" style={{ borderColor: theme.border }}><div><h2 className="font-semibold">Business workspaces</h2><p className="mt-1 text-xs" style={{ color: theme.muted }}>Choose a workspace to update its people, money, and settings.</p></div><div className="flex gap-2"><input id="new-business" value={newBusinessName} onChange={event => setNewBusinessName(event.target.value)} onKeyDown={event => event.key === "Enter" && createBusiness()} className="dash-input rounded-lg px-3 py-2 text-xs" placeholder="New business name" aria-label="New business name" /><button onClick={createBusiness} className="dash-button rounded-lg px-3 py-2 text-xs font-semibold" style={{ background: theme.accent, color: theme.bg }}><Plus size={14} /> Add</button></div></div>{businesses.map(business => <button key={business.id} onClick={() => setActiveBusinessId(business.id)} className="flex w-full flex-wrap items-center gap-3 border-b px-5 py-4 text-left last:border-0" style={{ borderColor: theme.border, background: business.id === activeBusinessId ? theme.accentSoft : "transparent" }}><span className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: theme.accentSoft, color: theme.accent }}><Building2 size={18} /></span><span className="min-w-[180px] flex-1"><span className="block text-sm font-semibold">{business.name}</span><span className="mt-1 block text-xs" style={{ color: theme.muted }}>{business.type} · {business.members} people</span></span><span className="text-right"><span className="block text-sm font-semibold">{business.revenue}</span><span className="mt-1 block text-[11px]" style={{ color: business.status === "Active" ? theme.accent : "#f0a57d" }}>{business.status}</span></span><span className="hidden text-xs sm:block" style={{ color: theme.muted }}>{business.lastActivity}</span><ChevronRight size={16} style={{ color: theme.muted }} /></button>)}</Surface></div>;
}

function People({ theme, notify, member }: { theme: ThemePalette; notify: (s: string) => void; member: boolean }) {
  const people = [["AS", "Ari Singh", "Client success", "Online", "sage"], ["JP", "Jordan Park", "Operations", "Away", "amber"], ["PS", "Priya Shah", "Finance", "Online", "lilac"], ["ML", "Mara Lewis", "Design partner", "Offline", "coral"]];
  return <div className="space-y-5"><PageIntro kicker={`People / ${member ? "Your team" : "24 members"}`} title="Your people, in context." theme={theme} action="Invite person" onAction={() => notify(member ? "Invite request sent to an admin" : "Invite link copied")} /><div className="flex items-center gap-3"><div className="relative flex-1"><Search className="absolute left-3 top-1/2 -translate-y-1/2" size={15} style={{ color: theme.muted }} /><input className="dash-input w-full rounded-xl py-2.5 pl-9 pr-3 text-sm" placeholder="Search people" /></div><button onClick={() => notify("People filters opened")} className="dash-button rounded-xl border p-2.5" style={{ borderColor: theme.border }} aria-label="Filter people"><SlidersHorizontal size={17} /></button></div><Surface className="overflow-hidden">{people.map(([initials, name, role, status, tone]) => <div className="flex items-center gap-3 border-b px-5 py-4 last:border-0" style={{ borderColor: theme.border }} key={name}><Avatar initials={initials} tone={tone} /><div className="flex-1"><div className="text-sm font-medium">{name}</div><div className="text-xs" style={{ color: theme.muted }}>{role}</div></div><span className="text-xs" style={{ color: status === "Online" ? theme.accent : theme.muted }}>{status}</span><button onClick={() => notify(`Profile for ${name} opened`)} className="dash-button rounded-lg border p-2" style={{ borderColor: theme.border }} aria-label={`Open ${name}`}><ChevronRight size={15} /></button></div>)}</Surface></div>;
}

function AccessPage({ theme, users, selectedRole, setSelectedRole, rolePermissions, userOverrides, updateUserRole, toggleRolePermission, toggleUserOverride, notify }: { theme: ThemePalette; users: WorkspaceUser[]; selectedRole: AssignableRole; setSelectedRole: (role: AssignableRole) => void; rolePermissions: Record<AssignableRole, Record<string, boolean>>; userOverrides: Record<string, Record<string, boolean>>; updateUserRole: (userId: string, role: AssignableRole) => void; toggleRolePermission: (role: AssignableRole, permissionId: string) => void; toggleUserOverride: (userId: string, permissionId: string) => void; notify: (message: string) => void }) {
  const enabledForRole = permissions.filter(permission => rolePermissions[selectedRole][permission.id]).length;
  return <div className="space-y-5"><PageIntro kicker="Access / Role management" title="Give every person the right controls." theme={theme} action="Save access policy" onAction={() => notify("Access policy saved")} /><div className="grid gap-4 md:grid-cols-[.72fr_1.28fr]"><Surface className="p-5"><div className="flex items-center gap-2"><ShieldCheck size={17} style={{ color: theme.accent }} /><h2 className="font-semibold">Role presets</h2></div><p className="mt-1 text-xs" style={{ color: theme.muted }}>Start with a role, then make individual exceptions below.</p><div className="mt-5 space-y-2">{(["Owner", "Admin", "Manager", "Member", "Viewer"] as AssignableRole[]).map(role => { const count = permissions.filter(permission => rolePermissions[role][permission.id]).length; return <button key={role} onClick={() => setSelectedRole(role)} className="flex w-full items-center gap-3 rounded-xl border p-3 text-left" style={{ borderColor: selectedRole === role ? theme.accent : theme.border, background: selectedRole === role ? theme.accentSoft : "transparent" }}><span className="grid h-9 w-9 place-items-center rounded-lg" style={{ background: theme.accentSoft, color: theme.accent }}><UserCog size={16} /></span><span className="flex-1"><span className="block text-sm font-semibold">{role}</span><span className="mt-1 block text-[11px]" style={{ color: theme.muted }}>{count} of {permissions.length} capabilities</span></span><ChevronRight size={15} style={{ color: theme.muted }} /></button>; })}</div></Surface><Surface className="p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><div className="text-[10px] uppercase tracking-[.16em]" style={{ color: theme.accent }}>Editing role</div><h2 className="mt-1 text-xl font-semibold">{selectedRole} capabilities</h2><p className="mt-1 text-xs" style={{ color: theme.muted }}>{enabledForRole} of {permissions.length} capabilities enabled by default.</p></div><span className="rounded-lg px-2.5 py-1.5 text-[10px]" style={{ background: theme.accentSoft, color: theme.accent }}>Role default</span></div><div className="mt-5 space-y-2">{permissions.map(permission => <button key={permission.id} onClick={() => toggleRolePermission(selectedRole, permission.id)} className="flex w-full items-center gap-3 rounded-xl border p-3 text-left" style={{ borderColor: theme.border, background: rolePermissions[selectedRole][permission.id] ? "rgba(8,30,31,.2)" : "rgba(4,12,17,.18)" }}><span className="grid h-7 w-7 place-items-center rounded-lg" style={{ background: rolePermissions[selectedRole][permission.id] ? theme.accentSoft : "rgba(255,255,255,.06)", color: rolePermissions[selectedRole][permission.id] ? theme.accent : theme.muted }}>{rolePermissions[selectedRole][permission.id] ? <Check size={14} /> : <X size={14} />}</span><span className="min-w-0 flex-1"><span className="block text-sm font-medium">{permission.label}</span><span className="mt-1 block text-[11px]" style={{ color: theme.muted }}>{permission.description}</span></span><span className="text-[10px]" style={{ color: rolePermissions[selectedRole][permission.id] ? theme.accent : theme.muted }}>{rolePermissions[selectedRole][permission.id] ? "Allowed" : "Blocked"}</span></button>)}</div></Surface></div><Surface className="p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><div className="flex items-center gap-2"><UsersRound size={17} style={{ color: theme.accent }} /><h2 className="font-semibold">People and personal overrides</h2></div><p className="mt-1 text-xs" style={{ color: theme.muted }}>Assign a role to each person, then override any capability for that person only.</p></div><button onClick={() => notify("Invite flow opened")} className="dash-button rounded-lg border px-3 py-2 text-xs" style={{ borderColor: theme.border }}><Plus size={14} /> Invite user</button></div><div className="mt-5 grid gap-3 md:grid-cols-2">{users.map(user => <div key={user.id} className="rounded-2xl border p-4" style={{ borderColor: theme.border, background: "rgba(4,12,17,.15)" }}><div className="flex items-center gap-3"><Avatar initials={user.initials} tone={user.tone} /><div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{user.name}</div><div className="truncate text-[11px]" style={{ color: theme.muted }}>{user.email} · {user.status}</div></div><select value={user.role} onChange={event => updateUserRole(user.id, event.target.value as AssignableRole)} className="dash-select rounded-lg px-2 py-1.5 text-xs" aria-label={`Role for ${user.name}`}>{(["Owner", "Admin", "Manager", "Member", "Viewer"] as AssignableRole[]).map(role => <option key={role} value={role}>{role}</option>)}</select></div><div className="mt-4 grid gap-2 sm:grid-cols-2">{permissions.map(permission => { const isOverridden = userOverrides[user.id]?.[permission.id] !== undefined; const allowed = userOverrides[user.id]?.[permission.id] ?? rolePermissions[user.role][permission.id]; return <button key={permission.id} onClick={() => toggleUserOverride(user.id, permission.id)} className="flex items-center gap-2 rounded-lg px-2 py-2 text-left text-[11px]" style={{ background: allowed ? theme.accentSoft : "rgba(255,255,255,.045)", color: allowed ? theme.accent : theme.muted }}><span className="grid h-5 w-5 shrink-0 place-items-center rounded-md" style={{ background: allowed ? theme.accent : "rgba(255,255,255,.12)", color: allowed ? theme.bg : theme.muted }}>{allowed ? <Check size={11} /> : <X size={11} />}</span><span className="min-w-0 flex-1 truncate">{permission.label.replace("Manage ", "").replace("View ", "")}</span>{isOverridden && <span className="text-[9px]" style={{ color: "#f0a57d" }}>override</span>}</button>; })}</div></div>)}</div></Surface></div>;
}

function Payments({ theme, notify, member, business }: { theme: ThemePalette; notify: (s: string) => void; member: boolean; business: Business }) {
  const payments = [["#8831", "Nook & Co.", "Oct 24, 2024", "$4,280.00", "Paid"], ["#8827", "Northstar Labs", "Oct 23, 2024", "$2,940.00", "Pending"], ["#8818", "Lumen House", "Oct 22, 2024", "$1,280.40", "Paid"], ["#8809", "Mara Lewis", "Oct 20, 2024", "$680.00", "Refunded"]];
  return <div className="space-y-5"><PageIntro kicker={`Payments / ${business.name}`} title="Money that is easy to follow." theme={theme} action={member ? "Request payout" : "Record payment"} onAction={() => notify(member ? "Payout request sent for review" : "Payment draft created")} /><div className="dash-grid grid gap-4 md:grid-cols-4">{[["Collected this month", "$42,680", "+12.8%"], ["Pending review", "$2,940", "1 payment"], ["Success rate", "96.4%", "+2.1%"], ["Refunds", "$680", "1 this month"]].map(([label, value, detail], index) => <Surface key={label} className="p-5"><div className="flex items-center justify-between text-xs" style={{ color: theme.muted }}>{label}{index === 3 ? <ArrowDownRight size={15} style={{ color: "#f0a57d" }} /> : <ArrowUpRight size={15} style={{ color: theme.accent }} />}</div><div className="mt-4 text-2xl font-semibold">{value}</div><div className="mt-1 text-[11px]" style={{ color: index === 3 ? "#f0a57d" : theme.accent }}>{detail}</div></Surface>)}</div><Surface className="overflow-hidden"><div className="flex flex-wrap items-center justify-between gap-3 border-b p-5" style={{ borderColor: theme.border }}><div><h2 className="font-semibold">Recent transactions</h2><p className="mt-1 text-xs" style={{ color: theme.muted }}>{member ? "Your assigned payment activity" : "All payment activity for this business"}</p></div><div className="flex gap-2"><button onClick={() => notify("Payment filters opened")} className="dash-button flex items-center gap-2 rounded-lg border px-3 py-2 text-xs" style={{ borderColor: theme.border }}><Filter size={14} /> Filter</button><button onClick={() => notify("Payment CSV exported")} className="dash-button flex items-center gap-2 rounded-lg border px-3 py-2 text-xs" style={{ borderColor: theme.border }}><Download size={14} /> Export</button></div></div><div className="dash-table-wrap"><table className="dash-table w-full min-w-[680px] text-left text-sm"><thead><tr className="text-[10px] uppercase tracking-[.15em]" style={{ color: theme.muted }}>{["Payment", "Customer", "Date", "Amount", "Status", ""].map(label => <th key={label} className="px-5 py-3 font-medium">{label}</th>)}</tr></thead><tbody>{payments.map(([id, customer, date, amount, status]) => <tr key={id} className="border-t" style={{ borderColor: theme.border }}><td className="px-5 py-4 font-mono text-xs">{id}</td><td className="px-5 py-4">{customer}</td><td className="px-5 py-4 text-xs" style={{ color: theme.muted }}>{date}</td><td className="px-5 py-4 font-semibold">{amount}</td><td className="px-5 py-4"><span className="rounded-md px-2 py-1 text-[10px]" style={{ color: status === "Paid" ? theme.accent : status === "Refunded" ? "#f0a57d" : "#b8c3f4", background: status === "Paid" ? theme.accentSoft : "rgba(255,255,255,.07)" }}>{status}</span></td><td className="px-5 py-4 text-right"><button onClick={() => notify(`${id} details opened`)} className="dash-button rounded-lg border p-2" style={{ borderColor: theme.border }} aria-label={`Open ${id}`}><MoreHorizontal size={15} /></button></td></tr>)}</tbody></table></div></Surface></div>;
}

function Reports({ theme, notify, rows, chartMode, setChartMode, updateRow, addRow, removeRow, business }: { theme: ThemePalette; notify: (s: string) => void; rows: DataRow[]; chartMode: ChartMode; setChartMode: (mode: ChartMode) => void; updateRow: (id: number, key: "label" | "value", value: string) => void; addRow: () => void; removeRow: (id: number) => void; business: Business }) {
  const max = Math.max(...rows.map(row => row.value), 1);
  const total = rows.reduce((sum, row) => sum + row.value, 0);
  const points = rows.map((row, index) => `${index * (100 / Math.max(rows.length - 1, 1))},${100 - (row.value / max) * 82}`).join(" ");
  return <div className="space-y-5"><PageIntro kicker={`Reports / ${business.name}`} title="Build a view from your own data." theme={theme} action="Save report" onAction={() => notify("Report saved to your workspace")} /><div className="dash-grid grid gap-4 md:grid-cols-[.95fr_1.05fr]"><Surface className="overflow-hidden"><div className="flex flex-wrap items-center justify-between gap-3 border-b p-5" style={{ borderColor: theme.border }}><div><h2 className="font-semibold">Data table</h2><p className="mt-1 text-xs" style={{ color: theme.muted }}>Edit rows and the graph updates instantly.</p></div><button onClick={addRow} className="dash-button flex items-center gap-1 rounded-lg border px-3 py-2 text-xs" style={{ borderColor: theme.border }}><Plus size={14} /> Add row</button></div><div className="dash-table-wrap"><table className="dash-table w-full min-w-[420px] text-left text-sm"><thead><tr className="text-[10px] uppercase tracking-[.15em]" style={{ color: theme.muted }}><th className="px-5 py-3 font-medium">Label</th><th className="px-5 py-3 font-medium">Value</th><th className="px-5 py-3 text-right font-medium">Remove</th></tr></thead><tbody>{rows.map(row => <tr key={row.id} className="border-t" style={{ borderColor: theme.border }}><td className="px-5 py-3"><input className="w-full rounded px-1 py-1" value={row.label} onChange={event => updateRow(row.id, "label", event.target.value)} aria-label={`Label for row ${row.id}`} /></td><td className="px-5 py-3"><input className="w-full rounded px-1 py-1 font-mono text-xs" type="number" value={row.value} onChange={event => updateRow(row.id, "value", event.target.value)} aria-label={`Value for row ${row.id}`} /></td><td className="px-5 py-3 text-right"><button onClick={() => removeRow(row.id)} className="dash-button rounded-lg p-2" style={{ color: theme.muted }} aria-label={`Remove row ${row.id}`}><Trash2 size={14} /></button></td></tr>)}</tbody></table></div><div className="flex items-center justify-between border-t p-5 text-xs" style={{ borderColor: theme.border }}><span style={{ color: theme.muted }}>{rows.length} rows</span><span>Total <strong className="ml-2 text-sm">{total.toLocaleString()}</strong></span></div></Surface><Surface className="p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><div className="flex items-center gap-2 text-xs" style={{ color: theme.muted }}><LineChart size={15} style={{ color: theme.accent }} /> Live visualization</div><h2 className="mt-2 font-semibold">Revenue by period</h2><p className="mt-1 text-xs" style={{ color: theme.muted }}>A graph generated from the table on the left.</p></div><div className="flex rounded-lg border p-1" style={{ borderColor: theme.border }}>{([["bar", BarChart3], ["line", LineChart]] as const).map(([mode, Icon]) => <button key={mode} onClick={() => setChartMode(mode)} className="rounded-md p-2" style={{ background: chartMode === mode ? theme.accentSoft : "transparent", color: chartMode === mode ? theme.accent : theme.muted }} aria-label={`${mode} chart`}><Icon size={15} /></button>)}</div></div><div className="mt-8 h-56">{chartMode === "bar" ? <div className="flex h-full items-end gap-3 border-b border-l px-3 pb-0 pt-5" style={{ borderColor: theme.border }}>{rows.map(row => <div key={row.id} className="flex h-full flex-1 flex-col items-center justify-end gap-2"><div className="w-full max-w-10 rounded-t-lg transition-all" style={{ height: `${Math.max(6, (row.value / max) * 82)}%`, background: `linear-gradient(to top, ${theme.accent}, ${theme.accentSoft})` }} /><span className="text-[10px]" style={{ color: theme.muted }}>{row.label}</span></div>)}</div> : <div className="relative h-full border-b border-l px-3 pb-0 pt-5" style={{ borderColor: theme.border }}><svg viewBox="0 0 100 100" preserveAspectRatio="none" className="h-[calc(100%-25px)] w-full overflow-visible"><polyline points={points} fill="none" stroke={theme.accent} strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" /></svg><div className="absolute inset-x-3 bottom-0 flex justify-between text-[10px]" style={{ color: theme.muted }}>{rows.map(row => <span key={row.id}>{row.label}</span>)}</div></div>}</div><div className="mt-5 flex items-center justify-between border-t pt-4 text-xs" style={{ borderColor: theme.border, color: theme.muted }}><span>Source: editable workspace table</span><button onClick={() => notify("Graph downloaded")} className="flex items-center gap-1" style={{ color: theme.accent }}><Download size={13} /> Download graph</button></div></Surface></div><Surface className="p-5"><div className="flex items-center gap-2"><ClipboardList size={16} style={{ color: theme.accent }} /><h2 className="font-semibold">Report management</h2></div><div className="mt-4 grid gap-3 md:grid-cols-3">{[["Monthly revenue", "Updated today", FileText], ["Payment health", "Updated yesterday", CreditCard], ["People capacity", "Updated Monday", UsersRound]].map(([name, updated, Icon]) => <button key={name as string} onClick={() => notify(`${name} opened`)} className="dash-button flex items-center gap-3 rounded-xl border p-3 text-left" style={{ borderColor: theme.border }}><span className="grid h-9 w-9 place-items-center rounded-lg" style={{ background: theme.accentSoft, color: theme.accent }}><Icon size={16} /></span><span><span className="block text-sm">{name as string}</span><span className="mt-1 block text-[11px]" style={{ color: theme.muted }}>{updated as string}</span></span><ChevronRight size={14} className="ml-auto" style={{ color: theme.muted }} /></button>)}</div></Surface></div>;
}

function Profile({ theme, notify, member }: { theme: ThemePalette; notify: (s: string) => void; member: boolean }) {
  return <div className="space-y-5"><PageIntro kicker="Account / Personal" title="A profile with a point of view." theme={theme} action="Save changes" onAction={() => notify("Profile changes saved")} /><Surface strong className="p-6"><div className="flex flex-wrap items-center gap-5"><div className="grid h-20 w-20 place-items-center rounded-3xl text-2xl font-semibold" style={{ background: theme.accent, color: theme.bg }}>RC</div><div><h2 className="text-xl font-semibold">Rowan Chen</h2><p className="mt-1 text-sm" style={{ color: theme.muted }}>{member ? "Workspace member" : "Operator"} · Lumen House</p><button onClick={() => notify("Avatar picker opened")} className="mt-3 text-xs font-semibold" style={{ color: theme.accent }}>Change avatar</button></div></div><div className="mt-7 grid gap-4 md:grid-cols-2"><Field label="Full name" value="Rowan Chen" theme={theme} /><Field label="Email address" value="rowan@lumen.house" theme={theme} /><Field label="Time zone" value="Pacific Time (PT)" theme={theme} /><Field label="Role" value={member ? "Workspace member" : "Workspace administrator"} theme={theme} /></div></Surface><div className="grid gap-4 md:grid-cols-2"><Surface className="p-5"><h3 className="font-semibold">Security posture</h3><p className="mt-1 text-xs" style={{ color: theme.muted }}>Two protective layers are active.</p><div className="mt-5 flex items-center justify-between border-t pt-4 text-sm" style={{ borderColor: theme.border }}><span className="flex items-center gap-2"><LockKeyhole size={15} style={{ color: theme.accent }} />Two-factor authentication</span><span style={{ color: theme.accent }}>On</span></div></Surface><Surface className="p-5"><h3 className="font-semibold">Notification rhythm</h3><p className="mt-1 text-xs" style={{ color: theme.muted }}>Daily digest, sent at 8:30 AM.</p><button onClick={() => notify("Notification schedule updated")} className="dash-button mt-5 rounded-lg border px-3 py-2 text-xs" style={{ borderColor: theme.border }}>Edit schedule</button></Surface></div></div>;
}

function Settings({ theme, notify, member }: { theme: ThemePalette; notify: (s: string) => void; member: boolean }) {
  return <div className="space-y-5"><PageIntro kicker="Workspace / Configuration" title="Settings that stay out of the way." theme={theme} action="Save settings" onAction={() => notify("Settings saved")} /><Surface className="p-5"><h2 className="font-semibold">Business identity</h2><p className="mt-1 text-xs" style={{ color: theme.muted }}>The details your clients see on receipts and invitations.</p><div className="mt-5 grid gap-4 md:grid-cols-2"><Field label="Business name" value="Lumen House LLC" theme={theme} /><Field label="Website" value="lumen.house" theme={theme} /><Field label="Support email" value="hello@lumen.house" theme={theme} /><Field label="Default currency" value="USD — US Dollar" theme={theme} /></div></Surface><Surface className="p-5"><div className="flex items-center gap-2"><Bell size={16} style={{ color: theme.accent }} /><h2 className="font-semibold">{member ? "Your notifications" : "Workspace notifications"}</h2></div>{["Payment received", "Access requests", "Weekly workspace digest"].map((item, i) => <div className="flex items-center justify-between border-b py-4 last:border-0" style={{ borderColor: theme.border }} key={item}><span className="text-sm">{item}</span><button onClick={() => notify(`${item} ${i === 1 ? "muted" : "enabled"}`)} className="relative h-6 w-11 rounded-full p-1" style={{ background: i === 1 ? theme.border : theme.accent }} aria-label={`Toggle ${item}`}><span className="block h-4 w-4 rounded-full transition-transform" style={{ background: theme.bg, transform: i === 1 ? "translateX(0)" : "translateX(20px)" }} /></button></div>)}</Surface><Surface className="border-[#d98572]/35 p-5"><div className="flex items-start gap-3"><Trash2 size={18} style={{ color: "#e59b83" }} /><div><h2 className="font-semibold">Danger zone</h2><p className="mt-1 text-xs" style={{ color: theme.muted }}>Export your workspace before permanently closing it.</p><button onClick={() => notify("Workspace export prepared")} className="dash-button mt-4 rounded-lg border px-3 py-2 text-xs" style={{ borderColor: theme.border }}>Export workspace data</button></div></div></Surface></div>;
}

function ThemeStudio({ theme, themeName, setTheme, studioTab, setStudioTab, json, setJson, applyCustomTheme, notify, layout, setLayout, density, setDensity, hostedManifest }: { theme: ThemePalette; themeName: ThemeName; setTheme: (name: ThemeName) => void; studioTab: "themes" | "tokens"; setStudioTab: (tab: "themes" | "tokens") => void; json: string; setJson: (value: string) => void; applyCustomTheme: () => void; notify: (s: string) => void; layout: LayoutMode; setLayout: (mode: LayoutMode) => void; density: number; setDensity: (value: number) => void; hostedManifest: HostedManifest | null }) {
  return <div className="space-y-5"><PageIntro kicker="Appearance / Hosted themes" title="Tune the atmosphere." theme={theme} action="Preview changes" onAction={() => notify("Preview refreshed")} /><div className="flex gap-2 border-b pb-3" style={{ borderColor: theme.border }}><button onClick={() => setStudioTab("themes")} className="rounded-lg px-3 py-2 text-sm" style={{ color: studioTab === "themes" ? theme.accent : theme.muted, background: studioTab === "themes" ? theme.accentSoft : "transparent" }}>Theme selection</button><button onClick={() => setStudioTab("tokens")} className="rounded-lg px-3 py-2 text-sm" style={{ color: studioTab === "tokens" ? theme.accent : theme.muted, background: studioTab === "tokens" ? theme.accentSoft : "transparent" }}>Theme tokens</button></div>{studioTab === "themes" ? <><div className="grid gap-4 md:grid-cols-2">{(Object.keys(themes) as ThemeName[]).map(name => { const t = themes[name]; return <button key={name} onClick={() => setTheme(name)} className="dash-button relative overflow-hidden rounded-2xl border p-4 text-left" style={{ background: t.bg, borderColor: name === themeName ? theme.accent : t.border }}><div className="absolute -right-7 -top-8 h-28 w-28 rounded-full blur-2xl" style={{ background: t.glow }} /><div className="relative"><div className="flex items-center justify-between"><span className="text-sm font-semibold" style={{ color: t.text }}>{name}</span>{name === themeName && <Check size={16} style={{ color: t.accent }} />}</div><div className="mt-5 flex gap-2"><i className="h-7 w-7 rounded-lg" style={{ background: t.accent }} /><i className="h-7 w-14 rounded-lg" style={{ background: t.panelStrong }} /><i className="h-7 flex-1 rounded-lg" style={{ background: t.panel }} /></div><p className="mt-3 text-[11px]" style={{ color: t.muted }}>Glass surfaces · {name === "Ember" ? "warm contrast" : "soft contrast"}</p></div></button>; })}</div><Surface className="p-5"><div className="flex items-start gap-3"><Server size={18} style={{ color: theme.accent }} /><div className="flex-1"><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold">Server sync</h3><span className="rounded-md px-2 py-1 text-[10px]" style={{ background: theme.accentSoft, color: theme.accent }}>{hostedManifest ? "Connected" : "Waiting for manifest"}</span></div><p className="mt-1 text-xs" style={{ color: theme.muted }}>{hostedManifest ? `${hostedManifest.themes?.length ?? 0} themes loaded from themes.json · server default: ${hostedManifest.defaultTheme ?? "not set"} · manifest v${hostedManifest.version ?? 1}` : "Looking for the hosted themes.json resource…"}</p></div><button onClick={() => notify(hostedManifest ? "Theme manifest synced" : "Theme manifest is not available")} className="dash-button rounded-lg border px-3 py-2 text-xs" style={{ borderColor: theme.border }}>Sync now</button></div></Surface></> : <Surface className="p-5"><div className="flex items-center justify-between"><div><h2 className="font-semibold">Custom theme manifest</h2><p className="mt-1 text-xs" style={{ color: theme.muted }}>Edit tokens, then save and apply locally.</p></div><span className="font-mono text-[10px]" style={{ color: theme.muted }}>theme.json</span></div><textarea value={json} onChange={event => setJson(event.target.value)} className="dash-input mt-5 h-48 w-full resize-none rounded-xl p-4 font-mono text-xs leading-6" spellCheck={false} /><div className="mt-4 flex flex-wrap justify-end gap-2"><button onClick={() => setJson('{\n  "accent": "#8de7c1",\n  "surfaceOpacity": 0.68,\n  "radius": 18,\n  "glow": "soft"\n}')} className="dash-button rounded-lg border px-3 py-2 text-xs" style={{ borderColor: theme.border }}>Reset</button><button onClick={applyCustomTheme} className="dash-button rounded-lg px-3 py-2 text-xs font-semibold" style={{ background: theme.accent, color: theme.bg }}>Save & apply</button></div></Surface>}<Surface className="p-5"><div className="flex items-center gap-2"><PanelLeft size={16} style={{ color: theme.accent }} /><h2 className="font-semibold">Preview layout</h2></div><div className="mt-4 flex flex-wrap gap-2">{(["Auto", "Desktop", "Mobile"] as LayoutMode[]).map(mode => <button key={mode} onClick={() => setLayout(mode)} className="dash-button rounded-lg border px-3 py-2 text-xs" style={{ borderColor: layout === mode ? theme.accent : theme.border, color: layout === mode ? theme.accent : theme.muted, background: layout === mode ? theme.accentSoft : "transparent" }}>{mode}</button>)}</div><div className="mt-5 flex items-center gap-3"><SlidersHorizontal size={15} style={{ color: theme.muted }} /><span className="text-xs" style={{ color: theme.muted }}>Density</span><input type="range" min="35" max="100" value={density} onChange={event => setDensity(Number(event.target.value))} className="flex-1 accent-[var(--dash-accent)]" /><span className="w-8 text-right font-mono text-xs">{density}</span></div></Surface></div>;
}

function Field({ label, value, theme }: { label: string; value: string; theme: ThemePalette }) {
  return <label className="block"><span className="mb-2 block text-[11px] font-medium" style={{ color: theme.muted }}>{label}</span><input className="dash-input w-full rounded-xl px-3 py-2.5 text-sm" defaultValue={value} /></label>;
}