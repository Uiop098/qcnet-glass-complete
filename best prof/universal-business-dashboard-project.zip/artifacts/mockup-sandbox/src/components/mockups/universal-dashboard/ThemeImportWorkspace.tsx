import { useMemo, useState } from "react";
import {
  AlertCircle,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleDot,
  Code2,
  Copy,
  Eye,
  FileJson,
  GitBranch,
  History,
  Layers3,
  MoreHorizontal,
  Plus,
  RotateCcw,
  Send,
  Settings2,
  SwatchBook,
  X,
} from "lucide-react";

type Stage = "Import" | "Validate" | "Preview" | "Publish";

const palette = [
  { name: "Signal mint", value: "#9DE8C7" },
  { name: "Deep tide", value: "#182C35" },
  { name: "Paper", value: "#F4F0E8" },
  { name: "Coral note", value: "#F29A78" },
];

const revisions = [
  { version: "v2.4", title: "Atlas refresh", time: "Today, 09:42", status: "Current", color: "#9DE8C7" },
  { version: "v2.3", title: "Quiet contrast", time: "Yesterday, 16:18", status: "Published", color: "#B6C8FF" },
  { version: "v2.2", title: "First light", time: "Jun 11, 11:06", status: "Archived", color: "#F29A78" },
];

export function ThemeImportWorkspace() {
  const [stage, setStage] = useState<Stage>("Preview");
  const [fileName, setFileName] = useState("atlas-theme.json");
  const [density, setDensity] = useState(68);
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState("");
  const [activeRevision, setActiveRevision] = useState("v2.4");

  const json = useMemo(
    () => `{
  "name": "Atlas",
  "accent": "#9DE8C7",
  "surface": "#182C35",
  "radius": 18,
  "density": ${density}
}`,
    [density],
  );

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2200);
  }

  function copyJson() {
    navigator.clipboard?.writeText(json);
    setCopied(true);
    notify("Manifest copied to clipboard");
    window.setTimeout(() => setCopied(false), 1800);
  }

  return (
    <main className="min-h-[100dvh] overflow-hidden bg-[#101C22] text-[#EAF3EF]" style={{ fontFamily: "ui-sans-serif, system-ui, sans-serif" }}>
      <div className="mx-auto flex min-h-[100dvh] max-w-[1540px] flex-col">
        <header className="flex h-[76px] shrink-0 items-center justify-between border-b border-[#B9D7CE]/10 px-5 sm:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#9DE8C7] text-[#15252B]"><SwatchBook size={18} /></div>
            <div>
              <div className="flex items-center gap-2 text-[13px] font-semibold tracking-wide">Theme supply chain <span className="rounded bg-[#9DE8C7]/10 px-1.5 py-0.5 text-[9px] uppercase tracking-[.16em] text-[#9DE8C7]">Workspace</span></div>
              <p className="mt-0.5 text-[11px] text-[#90A7A7]">Product system / visual tokens</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => notify("Documentation opened in a new tab")} className="hidden items-center gap-2 rounded-lg px-3 py-2 text-xs text-[#9EB4B3] hover:bg-white/5 sm:flex"><Code2 size={15} /> Token docs</button>
            <button onClick={() => notify("Workspace settings opened")} className="rounded-lg border border-[#B9D7CE]/15 p-2 text-[#9EB4B3] hover:bg-white/5"><Settings2 size={16} /></button>
            <div className="ml-1 flex h-8 w-8 items-center justify-center rounded-full bg-[#F29A78] text-[11px] font-bold text-[#271B1C]">MK</div>
          </div>
        </header>

        <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
          <aside className="w-full shrink-0 border-b border-[#B9D7CE]/10 p-5 lg:w-[232px] lg:border-b-0 lg:border-r lg:p-7">
            <div className="mb-7 flex items-center justify-between"><p className="text-[10px] uppercase tracking-[.2em] text-[#90A7A7]">Release path</p><button onClick={() => notify("New import started")} className="text-[#9DE8C7]"><Plus size={15} /></button></div>
            <div className="flex gap-2 lg:block">
              {(["Import", "Validate", "Preview", "Publish"] as Stage[]).map((item, index) => {
                const active = item === stage;
                const complete = index < ["Import", "Validate", "Preview", "Publish"].indexOf(stage);
                return <button key={item} onClick={() => setStage(item)} className={`group flex flex-1 items-center gap-3 rounded-xl px-3 py-3 text-left transition-colors lg:mb-2 lg:w-full ${active ? "bg-[#9DE8C7]/10 text-[#EAF3EF]" : "text-[#829998] hover:bg-white/[.035]"}`}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full border text-[10px] font-semibold ${complete ? "border-[#9DE8C7] bg-[#9DE8C7] text-[#15252B]" : active ? "border-[#9DE8C7] text-[#9DE8C7]" : "border-[#52706E]"} `}>{complete ? <Check size={13} /> : index + 1}</span>
                  <span className="hidden text-[12px] font-medium sm:block lg:block">{item}</span>
                </button>;
              })}
            </div>
            <div className="mt-9 hidden rounded-2xl border border-[#B9D7CE]/10 bg-[#17262D] p-4 lg:block">
              <div className="flex items-center gap-2 text-[11px] font-semibold"><GitBranch size={14} className="text-[#9DE8C7]" /> main <ChevronDown size={13} className="ml-auto text-[#748B8B]" /></div>
              <p className="mt-3 text-[11px] leading-5 text-[#819796]">Changes publish to the shared theme registry after review.</p>
              <div className="mt-4 flex items-center gap-2 text-[10px] text-[#9DE8C7]"><CircleDot size={12} /> 3 collaborators online</div>
            </div>
          </aside>

          <section className="min-w-0 flex-1 overflow-auto p-5 sm:p-8">
            <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
              <div><p className="mb-2 text-[10px] uppercase tracking-[.22em] text-[#9DE8C7]">Step 03 / visual review</p><h1 className="text-[30px] font-semibold tracking-[-.05em] text-[#F1F7F2] sm:text-[38px]">Preview the change.</h1><p className="mt-2 max-w-[560px] text-[13px] leading-6 text-[#91A9A6]">Compare the imported tokens against your current system before they touch production.</p></div>
              <div className="flex items-center gap-2"><span className="flex items-center gap-1.5 rounded-full border border-[#9DE8C7]/20 bg-[#9DE8C7]/[.07] px-3 py-1.5 text-[10px] text-[#9DE8C7]"><CheckCircle2 size={13} /> 12 checks passed</span><button onClick={() => notify("More revision actions")} className="rounded-lg border border-[#B9D7CE]/15 p-2 text-[#8EA5A3]"><MoreHorizontal size={16} /></button></div>
            </div>

            <div className="grid gap-5 xl:grid-cols-[minmax(360px,1fr)_minmax(300px,.82fr)]">
              <div className="space-y-5">
                <div className="rounded-2xl border border-[#B9D7CE]/12 bg-[#17262D] p-5 sm:p-6">
                  <div className="mb-5 flex items-start justify-between"><div className="flex gap-3"><div className="rounded-xl bg-[#263B42] p-2.5 text-[#9DE8C7]"><FileJson size={19} /></div><div><h2 className="text-sm font-semibold">Incoming manifest</h2><p className="mt-1 text-[11px] text-[#829997]">Last modified 4 minutes ago · 8.4 KB</p></div></div><button onClick={() => notify("Manifest actions opened")} className="text-[#829997]"><MoreHorizontal size={16} /></button></div>
                  <div className="relative rounded-xl border border-[#B9D7CE]/10 bg-[#101C22] p-4 font-mono text-[11px] leading-6 text-[#A8C7BB]"><button onClick={copyJson} className="absolute right-3 top-3 rounded-md bg-[#24363C] p-1.5 text-[#91ABA6] hover:text-[#9DE8C7]">{copied ? <Check size={13} /> : <Copy size={13} />}</button><pre className="overflow-auto">{json}</pre></div>
                  <div className="mt-4 flex items-center justify-between gap-3"><button onClick={() => { setFileName("atlas-theme.json"); notify("Manifest replaced"); }} className="flex items-center gap-2 text-[11px] text-[#9EB4B3]"><RotateCcw size={13} /> Replace file</button><span className="text-[10px] text-[#67817F]">{fileName}</span></div>
                </div>

                <div className="rounded-2xl border border-[#B9D7CE]/12 bg-[#17262D] p-5 sm:p-6">
                  <div className="mb-5 flex items-center justify-between"><div><h2 className="text-sm font-semibold">Revision history</h2><p className="mt-1 text-[11px] text-[#829997]">A reversible record of every visual decision.</p></div><History size={17} className="text-[#718987]" /></div>
                  <div className="space-y-1">{revisions.map((revision) => <button key={revision.version} onClick={() => { setActiveRevision(revision.version); notify(`${revision.version} selected`); }} className={`flex w-full items-center gap-3 rounded-xl p-3 text-left ${activeRevision === revision.version ? "bg-[#263A40]" : "hover:bg-white/[.03]"}`}><span className="h-2 w-2 rounded-full" style={{ background: revision.color }} /><span className="w-10 font-mono text-[10px] text-[#B6CAC4]">{revision.version}</span><span className="flex-1 text-[11px] font-medium">{revision.title}</span><span className="hidden text-[10px] text-[#708784] sm:block">{revision.time}</span>{revision.status === "Current" ? <span className="rounded bg-[#9DE8C7]/10 px-2 py-1 text-[9px] text-[#9DE8C7]">Current</span> : <ChevronRight size={14} className="text-[#627A78]" />}</button>)}</div>
                </div>
              </div>

              <div className="space-y-5">
                <div className="rounded-2xl border border-[#B9D7CE]/12 bg-[#17262D] p-5 sm:p-6">
                  <div className="mb-5 flex items-center justify-between"><div><h2 className="text-sm font-semibold">Live surface</h2><p className="mt-1 text-[11px] text-[#829997]">Atlas / desktop dashboard</p></div><button onClick={() => notify("Preview opened full screen")} className="flex items-center gap-1.5 rounded-lg border border-[#B9D7CE]/15 px-2.5 py-2 text-[10px] text-[#A4B9B5]"><Eye size={13} /> Inspect</button></div>
                  <div className="overflow-hidden rounded-xl border border-[#B9D7CE]/10 bg-[#F4F0E8] p-3 text-[#182C35]">
                    <div className="mb-4 flex items-center gap-2"><div className="h-5 w-5 rounded-md bg-[#182C35]" /><div className="h-2 w-20 rounded-full bg-[#C6D0C9]" /><div className="ml-auto h-5 w-5 rounded-full bg-[#F29A78]" /></div>
                    <div className="grid grid-cols-[1.15fr_.85fr] gap-2"><div className="rounded-lg bg-[#DDE7DF] p-3"><div className="h-2 w-14 rounded-full bg-[#718B82]" /><div className="mt-3 text-xl font-semibold">$84,260</div><div className="mt-3 h-9 rounded-md bg-[#9DE8C7]/60" /></div><div className="rounded-lg bg-[#E7ECE4] p-3"><div className="h-2 w-10 rounded-full bg-[#9EADA2]" /><div className="mt-3 flex h-12 items-end gap-1">{[35,52,42,70,56,88,76].map((h, i) => <span key={i} className="flex-1 rounded-t bg-[#F29A78]" style={{ height: `${h}%` }} />)}</div></div></div>
                    <div className="mt-2 grid grid-cols-3 gap-2">{[1,2,3].map(i => <div key={i} className="h-12 rounded-lg bg-[#E7ECE4]" />)}</div>
                  </div>
                  <div className="mt-5 flex items-center gap-3"><span className="text-[10px] text-[#829997]">Surface density</span><input aria-label="Surface density" type="range" min="35" max="100" value={density} onChange={(e) => setDensity(Number(e.target.value))} className="flex-1 accent-[#9DE8C7]" /><span className="w-7 text-right font-mono text-[10px] text-[#BBD0C9]">{density}%</span></div>
                </div>
                <div className="rounded-2xl border border-[#B9D7CE]/12 bg-[#17262D] p-5 sm:p-6"><div className="mb-5 flex items-center justify-between"><div><h2 className="text-sm font-semibold">Token impact</h2><p className="mt-1 text-[11px] text-[#829997]">What will change in the next release.</p></div><Layers3 size={17} className="text-[#718987]" /></div><div className="grid grid-cols-2 gap-3">{palette.map((token) => <div key={token.name} className="rounded-xl border border-[#B9D7CE]/10 bg-[#101C22] p-3"><div className="mb-3 h-8 rounded-lg" style={{ background: token.value }} /><p className="text-[10px] font-medium text-[#BED0CA]">{token.name}</p><p className="mt-1 font-mono text-[9px] text-[#6C8581]">{token.value}</p></div>)}</div></div>
              </div>
            </div>
            <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#B9D7CE]/12 bg-[#17262D] p-4"><div className="flex items-center gap-3 text-[11px] text-[#A4B9B4]"><AlertCircle size={16} className="text-[#F29A78]" /><span><strong className="text-[#EAF3EF]">One review requested.</strong> The contrast note needs an owner.</span></div><div className="flex gap-2"><button onClick={() => { setStage("Validate"); notify("Returned to validation"); }} className="rounded-lg border border-[#B9D7CE]/15 px-3 py-2 text-[11px] text-[#A6BBB6]">Back to validation</button><button onClick={() => { setStage("Publish"); notify("Ready for publish review"); }} className="flex items-center gap-2 rounded-lg bg-[#9DE8C7] px-4 py-2 text-[11px] font-semibold text-[#15252B]"><Send size={13} /> Request publish</button></div></div>
          </section>
        </div>
      </div>
      {toast && <div className="fixed bottom-5 left-1/2 z-10 flex -translate-x-1/2 items-center gap-2 rounded-full border border-[#9DE8C7]/20 bg-[#20343A] px-4 py-2.5 text-[11px] text-[#D9EAE3] shadow-2xl"><CheckCircle2 size={14} className="text-[#9DE8C7]" /> {toast}<button onClick={() => setToast("")}><X size={13} className="ml-2 text-[#819996]" /></button></div>}
    </main>
  );
}