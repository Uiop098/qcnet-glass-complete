<?php
require_once 'dash_firewall.php';
require_once 'dash_crypto.php';
header('Content-Type: application/json');

if (!isset($_SESSION['dash_admin']) && !isset($_SESSION['dash_user'])) die(json_encode(["error" => "Unauthorized access. Please log in."]));

$is_admin = isset($_SESSION['dash_admin']);
$action = $_GET['action'] ?? '';
$tenant_id = $_SESSION['dash_tenant'] ?? 'main';
$dir = ($tenant_id === 'main') ? __DIR__ . '/data_dash' : __DIR__ . '/data_dash/' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $tenant_id);
if (!is_dir($dir)) @mkdir($dir, 0755, true);

$db_files = ['users' => $dir . '/users.json', 'payments' => $dir . '/payments.json', 'reminders' => $dir . '/reminders.json', 'links' => $dir . '/links.json'];
foreach ($db_files as $file) { if (!file_exists($file)) save_secure_table($file, []); }

switch ($action) {
    case 'get_dashboard_data':
        $data = ["status" => "success", "links" => get_secure_table($db_files['links']), "reminders" => get_secure_table($db_files['reminders'])];
        if ($is_admin) {
            $data["users"] = get_secure_table($db_files['users']); $data["payments"] = get_secure_table($db_files['payments']);
        } else {
            $user_id = $_SESSION['dash_user']; $all_payments = get_secure_table($db_files['payments']);
            $my_payments = array_filter($all_payments, function($p) use ($user_id) { return ($p['client'] ?? '') === $user_id; });
            $data["payments"] = array_values($my_payments); $u = get_secure_table($db_files['users']); $data["my_profile"] = $u[$user_id] ?? [];
        }
        echo json_encode($data); break;
    case 'add_record':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$is_admin) die(json_encode(["error" => "Only administrators can add records."]));
            $table = $_POST['table'] ?? ''; if (!array_key_exists($table, $db_files)) die(json_encode(["error" => "Invalid table."]));
            $data = get_secure_table($db_files[$table]); $new_record = ["id" => uniqid(), "created_at" => time()];
            foreach ($_POST as $key => $value) if ($key !== 'table') $new_record[$key] = $value;
            $data[] = $new_record; save_secure_table($db_files[$table], $data); echo json_encode(["status" => "success"]);
        }
        break;
    case 'update_user':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_admin) {
            $username = $_POST['username'] ?? ''; $users = get_secure_table($db_files['users']);
            if (isset($users[$username])) {
                $users[$username]['name'] = $_POST['name'] ?? $users[$username]['name']; $users[$username]['mobile'] = $_POST['mobile'] ?? '';
                $users[$username]['email'] = $_POST['email'] ?? ''; $users[$username]['address'] = $_POST['address'] ?? '';
                $users[$username]['tags'] = $_POST['tags'] ?? ''; $users[$username]['notes'] = $_POST['notes'] ?? ''; $users[$username]['admin_message'] = $_POST['admin_message'] ?? '';
                save_secure_table($db_files['users'], $users); echo json_encode(["status" => "success"]);
            } else echo json_encode(["error" => "User not found"]);
        }
        break;
    case 'update_my_profile':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_admin) {
            $user_id = $_SESSION['dash_user']; $users = get_secure_table($db_files['users']);
            if (isset($users[$user_id])) {
                $users[$user_id]['mobile'] = $_POST['mobile'] ?? ''; $users[$user_id]['email'] = $_POST['email'] ?? '';
                $users[$user_id]['address'] = $_POST['address'] ?? ''; save_secure_table($db_files['users'], $users); echo json_encode(["status" => "success"]);
            } else echo json_encode(["error" => "User not found"]);
        }
        break;
    case 'delete_user':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_admin) {
            $username = $_POST['username'] ?? ''; $users = get_secure_table($db_files['users']);
            if (isset($users[$username])) { unset($users[$username]); save_secure_table($db_files['users'], $users); echo json_encode(["status" => "success"]); } 
            else echo json_encode(["error" => "User not found"]);
        }
        break;
    default: http_response_code(405); echo json_encode(["error" => "Direct access is not allowed."]); break;
}
?>