<?php
$GLOBALS['dataDir'] = __DIR__ . '/data';
$GLOBALS['filesDir'] = __DIR__ . '/files';
$GLOBALS['maxMessages'] = 3000; // Increased capacity for business
$GLOBALS['messageExpirySeconds'] = 36500 * 24 * 60 * 60; // 100 years -> STOPS 24H AUTO-DELETE
$GLOBALS['sessionTtlSeconds'] = 6 * 60 * 60; 
$GLOBALS['presenceWindowMs'] = 10000; 
$GLOBALS['MASTER_ROOM'] = '__super_master__'; 
$GLOBALS['linkPreviewCacheSeconds'] = 6 * 60 * 60; 
$GLOBALS['messageEditWindowSeconds'] = null; 

if (!defined('SUPER_MASTER_SECRET')) {
    define('SUPER_MASTER_SECRET', 'CHANGE-ME-a8f3k2m9x7q1w5e0r4t6y8u2i0o3p9-CHANGE-ME');
}

require_once __DIR__ . '/firewall.php';

if (is_ip_blocked(get_client_ip())) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'blocked', 'message' => 'Your connection has been blocked from this site.']);
    exit;
}

if (!is_dir($GLOBALS['dataDir'])) { mkdir($GLOBALS['dataDir'], 0755, true); }
if (!is_dir($GLOBALS['filesDir'])) { mkdir($GLOBALS['filesDir'], 0755, true); }

$dataHtaccess = $GLOBALS['dataDir'] . '/.htaccess';
if (!file_exists($dataHtaccess)) { @file_put_contents($dataHtaccess, "Require all denied\n"); }

$filesHtaccessExpected = "Require all denied\nHeader set Content-Disposition \"attachment\"\n";
$filesHtaccess = $GLOBALS['filesDir'] . '/.htaccess';
if (!file_exists($filesHtaccess) || file_get_contents($filesHtaccess) !== $filesHtaccessExpected) {
    @file_put_contents($filesHtaccess, $filesHtaccessExpected);
}

function now_ms() { return round(microtime(true) * 1000); }
function safe_room_name($room) { $room = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$room); return substr($room, 0, 64) ?: 'default'; }
function room_file($room) { return $GLOBALS['dataDir'] . '/room_' . safe_room_name($room) . '.json'; }
function room_config_file($room) { return $GLOBALS['dataDir'] . '/config_' . safe_room_name($room) . '.json'; }
function sessions_file() { return $GLOBALS['dataDir'] . '/sessions.json'; }
function remember_tokens_file() { return $GLOBALS['dataDir'] . '/remember_tokens.json'; }
function room_files_dir($room) { $dir = $GLOBALS['filesDir'] . '/' . safe_room_name($room); if (!is_dir($dir)) mkdir($dir, 0755, true); return $dir; }

function ext_mime_candidates($ext) {
    static $map = null;
    if ($map === null) {
        $ole = ['application/msword', 'application/vnd.ms-excel', 'application/vnd.ms-powerpoint', 'application/x-ole-storage', 'application/CDFV2', 'application/CDFV2-corrupt'];
        $ooxml = ['application/zip', 'application/x-zip', 'application/octet-stream'];
        $map = [
            'jpg' => ['image/jpeg'], 'jpeg' => ['image/jpeg'], 'png' => ['image/png'], 'gif' => ['image/gif'], 'webp' => ['image/webp'], 'bmp' => ['image/bmp', 'image/x-ms-bmp'],
            'pdf' => ['application/pdf'], 'doc' => $ole, 'xls' => $ole, 'ppt' => $ole,
            'docx' => array_merge($ooxml, ['application/vnd.openxmlformats-officedocument.wordprocessingml.document']),
            'xlsx' => array_merge($ooxml, ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']),
            'pptx' => array_merge($ooxml, ['application/vnd.openxmlformats-officedocument.presentationml.presentation']),
            'txt' => ['text/plain'], 'csv' => ['text/plain', 'text/csv'], 'rtf' => ['text/rtf', 'application/rtf', 'text/plain'],
            'mp3' => ['audio/mpeg'], 'wav' => ['audio/wav', 'audio/x-wav', 'audio/vnd.wave'], 'ogg' => ['audio/ogg', 'video/ogg', 'application/ogg'],
            'm4a' => ['audio/mp4', 'audio/x-m4a', 'video/mp4'], 'aac' => ['audio/aac', 'audio/x-aac', 'audio/mp4', 'audio/mpeg'],
            'mp4' => ['video/mp4', 'application/mp4'], 'webm' => ['video/webm', 'audio/webm'], 'mov' => ['video/quicktime'],
            'mkv' => ['video/x-matroska'], 'avi' => ['video/x-msvideo', 'video/avi', 'video/msvideo'],
            'zip' => ['application/zip', 'application/x-zip'], 'rar' => ['application/x-rar-compressed', 'application/vnd.rar', 'application/x-rar'],
            '7z' => ['application/x-7z-compressed'],
        ];
    }
    return isset($map[$ext]) ? $map[$ext] : null;
}

function safe_download_mime($ext) {
    static $canonical = null;
    if ($canonical === null) {
        $canonical = [
            'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp', 'bmp' => 'image/bmp',
            'svg' => 'image/svg+xml', 'pdf' => 'application/pdf', 'doc' => 'application/msword', 'xls' => 'application/vnd.ms-excel',
            'ppt' => 'application/vnd.ms-powerpoint', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'rtf' => 'application/rtf', 'mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'ogg' => 'audio/ogg', 'm4a' => 'audio/mp4', 'aac' => 'audio/aac',
            'mp4' => 'video/mp4', 'webm' => 'video/webm', 'mov' => 'video/quicktime', 'mkv' => 'video/x-matroska', 'avi' => 'video/x-msvideo',
            'zip' => 'application/zip', 'rar' => 'application/x-rar-compressed', '7z' => 'application/x-7z-compressed',
        ];
        foreach (code_and_text_exts() as $textExt) { $canonical[$textExt] = 'text/plain'; }
    }
    return isset($canonical[$ext]) ? $canonical[$ext] : 'application/octet-stream';
}

function verify_file_format($path, $ext) {
    $ext = strtolower($ext);
    if ($ext === 'svg') {
        $head = @file_get_contents($path, false, null, 0, 4096);
        if ($head === false) return false;
        return (stripos($head, '<svg') !== false) && (stripos($head, '<?php') === false);
    }
    if (in_array($ext, code_and_text_exts(), true)) { return looks_like_safe_text($path); }
    $candidates = ext_mime_candidates($ext);
    if ($candidates === null) return true; 
    if (!function_exists('finfo_open')) return true; 
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if (!$finfo) return true;
    $detected = finfo_file($finfo, $path);
    finfo_close($finfo);
    return in_array($detected, $candidates, true);
}

function code_and_text_exts() {
    return [ 'txt', 'csv', 'md', 'log', 'json', 'xml', 'yml', 'yaml', 'js', 'ts', 'jsx', 'tsx', 'css', 'scss', 'html', 'htm', 'java', 'c', 'cpp', 'cc', 'h', 'hpp', 'cs', 'go', 'rb', 'rs', 'swift', 'kt', 'sql', 'vue', ];
}

function looks_like_safe_text($path) {
    $head = @file_get_contents($path, false, null, 0, 8192);
    if ($head === false) return false;
    if ($head === '') return true; 
    if (strpos($head, "\0") !== false) return false;
    $binarySignatures = [ "MZ", "\x7fELF", "%PDF", "PK\x03\x04", "\x89PNG", "GIF8", "\xFF\xD8\xFF", "\x1f\x8b", "Rar!", "7z\xBC\xAF\x27\x1C" ];
    foreach ($binarySignatures as $sig) { if (strncmp($head, $sig, strlen($sig)) === 0) return false; }
    return true;
}

function room_wallpapers_dir($room) {
    $dir = room_files_dir($room) . '/wallpapers';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $wallpaperHtaccessExpected = "Require all granted\n";
    $wallpaperHtaccess = $dir . '/.htaccess';
    if (!file_exists($wallpaperHtaccess) || file_get_contents($wallpaperHtaccess) !== $wallpaperHtaccessExpected) { @file_put_contents($wallpaperHtaccess, $wallpaperHtaccessExpected); }
    return $dir;
}

function read_json_file($path) {
    if (!file_exists($path)) return null;
    $fp = fopen($path, 'r'); if (!$fp) return null;
    flock($fp, LOCK_SH); $content = stream_get_contents($fp); flock($fp, LOCK_UN); fclose($fp);
    return json_decode($content, true);
}

function write_json_file($path, $data) {
    $fp = fopen($path, 'c+'); if (!$fp) return false;
    flock($fp, LOCK_EX); ftruncate($fp, 0); rewind($fp); fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE)); fflush($fp); flock($fp, LOCK_UN); fclose($fp);
    return true;
}

function super_credentials_file() { return $GLOBALS['dataDir'] . '/super_credentials.json'; }

function read_super_credentials() {
    $data = read_json_file(super_credentials_file());
    if (!is_array($data)) $data = [];

    // SEAMLESS INTEGRATION: Pull Dashboard Master Admin into QuickChat
    $master_file = __DIR__ . '/data_dash/master.json';
    if (file_exists($master_file)) {
        $masters = json_decode(@file_get_contents($master_file), true);
        if (is_array($masters)) {
            foreach ($masters as $u => $m) {
                $data[$u] = ['passwordHash' => $m['password_hash'], 'displayName' => 'Master Admin'];
            }
        }
    }

    // SEAMLESS INTEGRATION: Pull ALL Custom Purchased Dashboard Admins into QuickChat Super Users
    $tenants_file = __DIR__ . '/data_dash/tenants.json';
    if (file_exists($tenants_file)) {
        $tenants = json_decode(@file_get_contents($tenants_file), true);
        if (is_array($tenants)) {
            foreach ($tenants as $u => $t) {
                $data[$u] = ['passwordHash' => $t['password_hash'], 'displayName' => $t['name'] ?? $u];
            }
        }
    }

    // Fallback seed
    if (empty($data) && file_exists(__DIR__ . '/super_users.php')) {
        $seed = require __DIR__ . '/super_users.php';
        foreach ($seed as $username => $entry) {
            $data[$username] = ['passwordHash' => $entry[0], 'displayName' => $entry[1]];
        }
        write_json_file(super_credentials_file(), $data);
    }
    
    return $data;
}

function write_super_credentials($store) { return write_json_file(super_credentials_file(), $store); }

function is_super_account_active($entry) {
    if (empty($entry['expiresAt'])) return true;
    return now_ms() < $entry['expiresAt'];
}

function stream_file_with_range($path, $mimeType, $downloadName, $inline) {
    $size = filesize($path); if ($size === false) { http_response_code(404); exit; }
    $safeName = preg_replace('/[\r\n"]/', '_', $downloadName);
    $disposition = ($inline ? 'inline' : 'attachment') . '; filename="' . $safeName . '"';
    header('Content-Type: ' . $mimeType); header('X-Content-Type-Options: nosniff'); header('Content-Disposition: ' . $disposition); header('Accept-Ranges: bytes'); header('Cache-Control: private, max-age=3600');
    $start = 0; $end = $size - 1; $status = 200;
    if (!empty($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $m)) {
        $reqStart = $m[1] === '' ? null : (int)$m[1]; $reqEnd = $m[2] === '' ? null : (int)$m[2];
        if ($reqStart === null && $reqEnd !== null) { $start = max(0, $size - $reqEnd); $end = $size - 1; } 
        else { $start = $reqStart ?? 0; $end = $reqEnd ?? ($size - 1); }
        $start = max(0, min($start, $size - 1)); $end = max($start, min($end, $size - 1));
        $status = 206; header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
    }
    http_response_code($status); header('Content-Length: ' . ($end - $start + 1));
    $fp = fopen($path, 'rb'); if (!$fp) { http_response_code(500); exit; }
    fseek($fp, $start); $remaining = $end - $start + 1; $chunkSize = 8192;
    while ($remaining > 0 && !feof($fp)) { $read = min($chunkSize, $remaining); echo fread($fp, $read); $remaining -= $read; @ob_flush(); @flush(); }
    fclose($fp); exit;
}

function default_config() {
    return [
        'pinHash' => null, 'hostPasswordHash' => null, 'bannedUsers' => [], 'bannedIps' => [], 'userIps' => [], 'mutedUsers' => [], 'presence' => [],
        'title' => '', 'createdAt' => null, 'lastActivity' => null, 'roomTheme' => ['background' => '', 'glowColor' => '', 'uiSkin' => ''],
        'pinnedMessageId' => null, 'encEnabled' => false, 'encSalt' => null, 'encSuperRecovery' => null, 'requireFileApproval' => false, 'fileRequests' => [],
        'extraUploads' => [ 'enabled' => false, 'expiresAt' => 0, 'allowAll' => false, 'extensions' => [] ],
        'bannedWords' => [], 'slowModeSeconds' => 0, 'lastMessageAtByUser' => [], 'lastMessageTextByUser' => [], 'reports' => [],
        'coHosts' => [], 'coSupers' => [], 'hostNotifyEmail' => '', 'hostLastDigestAt' => 0, 'scheduledMessages' => [], 'polls' => [], 'autoCleanupDays' => 0,
    ];
}

function extra_upload_catalog() { return [ 'psd', 'ai', 'eps', 'indd', 'apk', 'ipa', 'dmg', 'iso', 'deb', 'rpm', 'epub', 'mobi', 'ttf', 'otf', 'woff', 'woff2', 'torrent', 'sqlite', 'dwg', 'blend' ]; }

function extra_uploads_is_active(&$config) {
    if (empty($config['extraUploads']['enabled'])) return false;
    $expiresAt = isset($config['extraUploads']['expiresAt']) ? $config['extraUploads']['expiresAt'] : 0;
    if ($expiresAt > 0 && $expiresAt <= now_ms()) { $config['extraUploads']['enabled'] = false; $config['extraUploads']['expiresAt'] = 0; return false; }
    return true;
}

function extra_upload_extension_allowed(&$config, $ext) {
    if (!extra_uploads_is_active($config)) return false;
    if (!empty($config['extraUploads']['allowAll'])) return true;
    $extensions = isset($config['extraUploads']['extensions']) ? $config['extraUploads']['extensions'] : [];
    return in_array($ext, $extensions, true);
}

function read_config($room) {
    $data = read_json_file(room_config_file($room));
    if (!is_array($data)) return null;
    return array_merge(default_config(), $data);
}

function write_config($room, $config) { return write_json_file(room_config_file($room), $config); }

function super_encrypt_passphrase($plaintext) {
    $key = hash('sha256', SUPER_MASTER_SECRET, true); 
    $iv = openssl_random_pseudo_bytes(16);
    $ciphertext = openssl_encrypt($plaintext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    if ($ciphertext === false) return null;
    return base64_encode($iv . $ciphertext);
}

function super_decrypt_passphrase($blob) {
    if (!$blob) return null;
    $raw = base64_decode($blob, true);
    if ($raw === false || strlen($raw) < 17) return null;
    $iv = substr($raw, 0, 16); $ciphertext = substr($raw, 16);
    $key = hash('sha256', SUPER_MASTER_SECRET, true);
    $plaintext = openssl_decrypt($ciphertext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $plaintext === false ? null : $plaintext;
}

function enable_encryption(&$config, $passphraseForSuperRecovery = null) {
    $config['encEnabled'] = true; $config['encSalt'] = base64_encode(random_bytes(16));
    $config['encSuperRecovery'] = $passphraseForSuperRecovery !== null ? super_encrypt_passphrase($passphraseForSuperRecovery) : null;
}

function disable_encryption(&$config) { $config['encEnabled'] = false; $config['encSalt'] = null; $config['encSuperRecovery'] = null; }

function is_banned($config, $username) {
    $uname = strtolower(trim($username));
    foreach ($config['bannedUsers'] as $b) { if (isset($b['user']) && $b['user'] === $uname) return true; }
    return false;
}

function ban_user(&$config, $username) {
    $uname = strtolower(trim($username)); if ($uname === '') return;
    foreach ($config['bannedUsers'] as $b) { if (isset($b['user']) && $b['user'] === $uname) return; }
    $config['bannedUsers'][] = ['user' => $uname, 'ts' => now_ms()];
}

function unban_user(&$config, $username) {
    $uname = strtolower(trim($username));
    $config['bannedUsers'] = array_values(array_filter($config['bannedUsers'], function ($b) use ($uname) { return !(isset($b['user']) && $b['user'] === $uname); }));
}

function record_user_ip(&$config, $username, $ip) {
    $uname = strtolower(trim($username)); if ($uname === '' || !$ip) return;
    $config['userIps'][$uname] = $ip;
}

function is_ip_banned($config, $ip) {
    if (!$ip) return false;
    foreach ($config['bannedIps'] as $b) { if (isset($b['ip']) && $b['ip'] === $ip) return true; }
    return false;
}

function ban_ip(&$config, $ip) {
    $ip = trim((string)$ip); if ($ip === '') return;
    foreach ($config['bannedIps'] as $b) { if (isset($b['ip']) && $b['ip'] === $ip) return; }
    $config['bannedIps'][] = ['ip' => $ip, 'ts' => now_ms()];
}

function unban_ip(&$config, $ip) {
    $ip = trim((string)$ip);
    $config['bannedIps'] = array_values(array_filter($config['bannedIps'], function ($b) use ($ip) { return !(isset($b['ip']) && $b['ip'] === $ip); }));
}

function add_file_request(&$config, $request) {
    $request['id'] = 'freq_' . now_ms() . '_' . substr(md5(uniqid('', true)), 0, 6); $request['ts'] = now_ms();
    $config['fileRequests'][] = $request; return $request;
}
function find_file_request($config, $id) { foreach ($config['fileRequests'] as $r) { if (isset($r['id']) && $r['id'] === $id) return $r; } return null; }
function remove_file_request(&$config, $id) { $config['fileRequests'] = array_values(array_filter($config['fileRequests'], function ($r) use ($id) { return !(isset($r['id']) && $r['id'] === $id); })); }

function delete_room($room) {
    @unlink(room_config_file($room)); @unlink(room_file($room));
    $slug = safe_room_name($room); $dir = $GLOBALS['filesDir'] . '/' . $slug;
    if (is_dir($dir)) {
        $items = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($items as $item) { $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname()); }
        @rmdir($dir);
    }
    $sessions = read_sessions(); foreach ($sessions as $t => $s) { if (isset($s['room']) && $s['room'] === $slug) unset($sessions[$t]); } write_sessions($sessions);
    $tokens = read_remember_tokens(); foreach ($tokens as $t => $tok) { if (isset($tok['room']) && $tok['room'] === $slug) unset($tokens[$t]); } write_remember_tokens($tokens);
}

function mute_remaining_ms($config, $username) {
    $uname = strtolower(trim($username)); if (!isset($config['mutedUsers'][$uname])) return 0;
    $remaining = $config['mutedUsers'][$uname] - now_ms(); return $remaining > 0 ? $remaining : 0;
}

function mute_user(&$config, $username, $minutes) {
    $uname = strtolower(trim($username)); if ($uname === '') return;
    if ($minutes <= 0) { unset($config['mutedUsers'][$uname]); } else { $config['mutedUsers'][$uname] = now_ms() + ($minutes * 60 * 1000); }
}

function touch_presence(&$config, $username, $role) {
    $existing = isset($config['presence'][strtolower($username)]) ? $config['presence'][strtolower($username)] : [];
    $config['presence'][strtolower($username)] = [
        'name' => $username, 'role' => $role, 'ts' => now_ms(), 'typingUntil' => isset($existing['typingUntil']) ? $existing['typingUntil'] : 0,
        'ip' => function_exists('get_client_ip') ? get_client_ip() : ($existing['ip'] ?? null),
    ];
}

function set_typing(&$config, $username, $role) { touch_presence($config, $username, $role); $config['presence'][strtolower($username)]['typingUntil'] = now_ms() + 4000; }

function typing_users($config, $exceptUser) {
    $now = now_ms(); $exceptLower = strtolower($exceptUser); $out = [];
    foreach ($config['presence'] as $key => $p) {
        if ($key === $exceptLower) continue;
        if (!empty($p['typingUntil']) && $p['typingUntil'] > $now) { $out[] = $p['name']; }
    }
    return $out;
}

function active_presence($config) {
    $now = now_ms(); $out = [];
    foreach ($config['presence'] as $p) { if (($now - $p['ts']) <= $GLOBALS['presenceWindowMs']) { $out[] = $p; } }
    return $out;
}

function list_rooms() {
    $rooms = []; $pattern = $GLOBALS['dataDir'] . '/config_*.json';
    foreach (glob($pattern) as $path) {
        $base = basename($path, '.json'); $slug = substr($base, strlen('config_'));
        if ($slug === '') continue;
        $config = read_config($slug); if (!$config) continue;
        if (room_auto_cleanup_if_due($slug, $config)) continue;
        $msgs = read_json_file(room_file($slug)); $msgCount = is_array($msgs) ? count($msgs) : 0;
        $rooms[] = [
            'room' => $slug, 'title' => $config['title'] !== '' ? $config['title'] : $slug, 'createdAt' => $config['createdAt'],
            'lastActivity' => $config['lastActivity'], 'hostSet' => !empty($config['hostPasswordHash']), 'pinSet' => !empty($config['pinHash']),
            'encEnabled' => !empty($config['encEnabled']), 'activeUsers' => active_presence($config), 'messageCount' => $msgCount,
            'bannedUserCount' => count($config['bannedUsers']), 'bannedIpCount' => count($config['bannedIps']), 'pendingDeleteAt' => $config['pendingDeleteAt'] ?? null,
        ];
    }
    usort($rooms, function ($a, $b) { $at = $a['lastActivity'] ?? $a['createdAt'] ?? 0; $bt = $b['lastActivity'] ?? $b['createdAt'] ?? 0; return $bt <=> $at; });
    return $rooms;
}

function read_sessions() { $data = read_json_file(sessions_file()); return is_array($data) ? $data : []; }
function write_sessions($sessions) { write_json_file(sessions_file(), $sessions); }

function create_session($room, $user, $role) {
    $sessions = read_sessions(); $now = time();
    foreach ($sessions as $t => $s) { if (!isset($s['expires']) || $s['expires'] < $now) unset($sessions[$t]); }
    $token = bin2hex(random_bytes(16));
    $roomSlug = ($room === $GLOBALS['MASTER_ROOM']) ? $GLOBALS['MASTER_ROOM'] : safe_room_name($room);
    $sessions[$token] = [ 'room' => $roomSlug, 'user' => $user, 'role' => $role, 'expires' => $now + $GLOBALS['sessionTtlSeconds'] ];
    write_sessions($sessions); return $token;
}

function get_session($token) {
    if (!$token) return null;
    $sessions = read_sessions(); if (!isset($sessions[$token])) return null;
    $s = $sessions[$token];
    if (!isset($s['expires']) || $s['expires'] < time()) { unset($sessions[$token]); write_sessions($sessions); return null; }
    $sessions[$token]['expires'] = time() + $GLOBALS['sessionTtlSeconds']; write_sessions($sessions); return $sessions[$token];
}

function remove_sessions_for_user($room, $username) {
    $sessions = read_sessions(); $room = safe_room_name($room); $uname = strtolower(trim($username)); $changed = false;
    foreach ($sessions as $t => $s) { if ($s['room'] === $room && strtolower($s['user']) === $uname) { unset($sessions[$t]); $changed = true; } }
    if ($changed) write_sessions($sessions);
}

function remove_host_sessions($room) {
    $sessions = read_sessions(); $room = safe_room_name($room); $changed = false;
    foreach ($sessions as $t => $s) { if ($s['room'] === $room && $s['role'] === 'host') { unset($sessions[$t]); $changed = true; } }
    if ($changed) write_sessions($sessions);
}

$GLOBALS['rememberTtlSeconds'] = 30 * 24 * 60 * 60; 

function read_remember_tokens() { $data = read_json_file(remember_tokens_file()); return is_array($data) ? $data : []; }
function write_remember_tokens($tokens) { write_json_file(remember_tokens_file(), $tokens); }

function create_remember_token($room, $user, $role) {
    $tokens = read_remember_tokens(); $now = time();
    foreach ($tokens as $sel => $t) { if (!isset($t['expires']) || $t['expires'] < $now) unset($tokens[$sel]); }
    $selector = bin2hex(random_bytes(9)); $validator = bin2hex(random_bytes(33));
    $roomSlug = ($room === $GLOBALS['MASTER_ROOM']) ? $GLOBALS['MASTER_ROOM'] : safe_room_name($room);
    $tokens[$selector] = [ 'hash' => hash('sha256', $validator), 'room' => $roomSlug, 'user' => $user, 'role' => $role, 'expires' => $now + $GLOBALS['rememberTtlSeconds'] ];
    write_remember_tokens($tokens); return $selector . ':' . $validator;
}

function consume_remember_token($raw) {
    if (!is_string($raw) || strpos($raw, ':') === false) return null;
    [$selector, $validator] = explode(':', $raw, 2);
    $tokens = read_remember_tokens(); if (!isset($tokens[$selector])) return null;
    $t = $tokens[$selector];
    if (!isset($t['expires']) || $t['expires'] < time()) { unset($tokens[$selector]); write_remember_tokens($tokens); return null; }
    if (!hash_equals($t['hash'], hash('sha256', $validator))) { return null; }
    unset($tokens[$selector]); $newRaw = create_remember_token($t['room'], $t['user'], $t['role']); 
    return [ 'room' => $t['room'], 'user' => $t['user'], 'role' => $t['role'], 'newToken' => $newRaw ];
}

function revoke_remember_token($raw) {
    if (!is_string($raw) || strpos($raw, ':') === false) return;
    [$selector] = explode(':', $raw, 2); $tokens = read_remember_tokens();
    if (isset($tokens[$selector])) { unset($tokens[$selector]); write_remember_tokens($tokens); }
}

function remove_remember_tokens_for_user($room, $username) {
    $tokens = read_remember_tokens(); $room = safe_room_name($room); $uname = strtolower(trim($username)); $changed = false;
    foreach ($tokens as $sel => $t) { if ($t['room'] === $room && strtolower($t['user']) === $uname) { unset($tokens[$sel]); $changed = true; } }
    if ($changed) write_remember_tokens($tokens);
}

function remove_host_remember_tokens($room) {
    $tokens = read_remember_tokens(); $room = safe_room_name($room); $changed = false;
    foreach ($tokens as $sel => $t) { if ($t['room'] === $room && $t['role'] === 'host') { unset($tokens[$sel]); $changed = true; } }
    if ($changed) write_remember_tokens($tokens);
}

function purge_expired($room, $messages) {
    $expiryMs = $GLOBALS['messageExpirySeconds'] * 1000;
    $nowMs = now_ms(); $changed = false; $kept = [];
    foreach ($messages as $m) {
        $age = $nowMs - (isset($m['ts']) ? $m['ts'] : 0);
        if ($age > $expiryMs) {
            $changed = true;
            if (isset($m['type']) && $m['type'] === 'file' && !empty($m['fileUrl'])) { $path = __DIR__ . '/' . ltrim($m['fileUrl'], '/'); if (is_file($path)) @unlink($path); }
        } else { $kept[] = $m; }
    }
    if ($changed) { write_messages($room, $kept); }
    return $kept;
}

function read_messages($room) {
    $data = read_json_file(room_file($room)); $messages = is_array($data) ? $data : [];
    return purge_expired($room, $messages);
}

function write_messages($room, $messages) {
    if (count($messages) > $GLOBALS['maxMessages']) { $messages = array_slice($messages, -1 * $GLOBALS['maxMessages']); }
    return write_json_file(room_file($room), $messages);
}

function find_message($room, $id) {
    $messages = read_messages($room);
    foreach ($messages as $m) { if (isset($m['id']) && $m['id'] == $id) return $m; }
    return null;
}

function build_reply_snippet($msg) {
    if (!$msg) return null;
    $text = isset($msg['text']) ? $msg['text'] : '';
    if ($text === '' && isset($msg['type']) && $msg['type'] === 'file') { $text = '📎 ' . (isset($msg['fileName']) ? $msg['fileName'] : 'file'); }
    if (strpos($text, 'encv1:') !== 0) { $text = mb_substr(str_replace("\n", ' ', $text), 0, 120); }
    return [ 'id' => $msg['id'], 'user' => $msg['user'], 'text' => $text ];
}

function toggle_reaction($room, $messageId, $username, $emoji) {
    $messages = read_messages($room); $found = false; $userLower = strtolower($username);
    foreach ($messages as &$m) {
        if (!isset($m['id']) || $m['id'] != $messageId) continue;
        $found = true;
        if (!isset($m['reactions']) || !is_array($m['reactions'])) $m['reactions'] = [];
        $hadThisEmoji = isset($m['reactions'][$emoji]) && in_array($username, $m['reactions'][$emoji], true);
        foreach ($m['reactions'] as $e => $users) {
            $m['reactions'][$e] = array_values(array_filter($users, function ($u) use ($username) { return strtolower($u) !== $userLower; }));
            if (empty($m['reactions'][$e])) unset($m['reactions'][$e]);
        }
        if (!$hadThisEmoji) { if (!isset($m['reactions'][$emoji])) $m['reactions'][$emoji] = []; $m['reactions'][$emoji][] = $username; }
        break;
    }
    unset($m);
    if ($found) write_messages($room, $messages);
    return $found ? find_message($room, $messageId) : null;
}

function next_message_id($messages) {
    $nextId = 1; foreach ($messages as $m) { if (isset($m['id']) && $m['id'] >= $nextId) { $nextId = $m['id'] + 1; } } return $nextId;
}

function append_message($room, $msg) {
    $messages = read_messages($room); $msg['id'] = next_message_id($messages); $msg['ts'] = now_ms(); $messages[] = $msg;
    write_messages($room, $messages);
    $config = read_config($room);
    if ($config) { $config['lastActivity'] = $msg['ts']; write_config($room, $config); }
    return $msg;
}

function edit_message($room, $id, $username, $newText) {
    $messages = read_messages($room); $updated = null;
    foreach ($messages as &$m) {
        if (!isset($m['id']) || $m['id'] != $id) continue;
        if (!isset($m['user']) || strtolower($m['user']) !== strtolower($username)) { return null; }
        if (isset($m['type']) && $m['type'] !== 'text') { return null; }
        $m['text'] = $newText; $m['edited'] = true; $m['editedAt'] = now_ms(); $updated = $m; break;
    }
    unset($m);
    if ($updated) write_messages($room, $messages);
    return $updated;
}

function mark_read(&$config, $username, $role, $messageId) {
    touch_presence($config, $username, $role);
    $key = strtolower($username);
    $current = isset($config['presence'][$key]['lastReadId']) ? $config['presence'][$key]['lastReadId'] : 0;
    if ($messageId > $current) { $config['presence'][$key]['lastReadId'] = $messageId; }
}

function read_receipts($config, $exceptUser) {
    $now = now_ms(); $exceptLower = strtolower($exceptUser); $out = [];
    foreach ($config['presence'] as $key => $p) {
        if ($key === $exceptLower) continue;
        if (($now - $p['ts']) > $GLOBALS['presenceWindowMs']) continue;
        $out[] = ['user' => $p['name'], 'lastReadId' => isset($p['lastReadId']) ? $p['lastReadId'] : 0];
    }
    return $out;
}

function link_preview_cache_file($url) { return $GLOBALS['dataDir'] . '/linkpreview_' . hash('sha256', $url) . '.json'; }
function is_public_ip($ip) { return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false; }

function url_is_safe_to_fetch($url) {
    $parts = parse_url($url); if (!$parts || empty($parts['host'])) return false;
    $scheme = strtolower($parts['scheme'] ?? ''); if (!in_array($scheme, ['http', 'https'], true)) return false;
    $port = $parts['port'] ?? ($scheme === 'https' ? 443 : 80); if (!in_array((int)$port, [80, 443], true)) return false;
    $host = $parts['host'];
    if (filter_var($host, FILTER_VALIDATE_IP)) { return is_public_ip($host); }
    $records = @dns_get_record($host, DNS_A + DNS_AAAA); if (!$records) return false;
    foreach ($records as $r) { $ip = $r['ip'] ?? ($r['ipv6'] ?? null); if ($ip && !is_public_ip($ip)) return false; }
    return true;
}

function fetch_link_preview($url) {
    $cacheFile = link_preview_cache_file($url); $cached = read_json_file($cacheFile);
    if (is_array($cached) && isset($cached['fetchedAt']) && (now_ms() - $cached['fetchedAt']) < ($GLOBALS['linkPreviewCacheSeconds'] * 1000)) { return $cached['preview']; }
    $preview = null;
    if (url_is_safe_to_fetch($url)) {
        $ctx = stream_context_create([ 'http' => [ 'method' => 'GET', 'timeout' => 4, 'follow_location' => 0, 'header' => "User-Agent: QuickChatLinkPreview/1.0\r\n", ], 'https' => [ 'timeout' => 4, 'follow_location' => 0, ], ]);
        $html = @file_get_contents($url, false, $ctx, 0, 300000);
        if ($html !== false && $html !== '') { $preview = parse_preview_html($html, $url); }
    }
    write_json_file($cacheFile, ['fetchedAt' => now_ms(), 'preview' => $preview]); return $preview;
}

function parse_preview_html($html, $url) {
    $title = null; $description = null; $image = null; $siteName = null;
    if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $m)) { $title = trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES)); }
    $meta = function ($property) use ($html) {
        if (preg_match('/<meta[^>]+(?:property|name)=["\']' . preg_quote($property, '/') . '["\'][^>]+content=["\']([^"\']*)["\']/is', $html, $m)) { return trim(html_entity_decode($m[1], ENT_QUOTES)); }
        return null;
    };
    $ogTitle = $meta('og:title'); if ($ogTitle) $title = $ogTitle;
    $description = $meta('og:description') ?: $meta('description'); $image = $meta('og:image');
    $siteName = $meta('og:site_name') ?: parse_url($url, PHP_URL_HOST);
    if ($title) $title = mb_substr($title, 0, 200); if ($description) $description = mb_substr($description, 0, 300);
    if (!$title && !$description && !$image) return null;
    if ($image && !preg_match('#^https?://#i', $image)) {
        $base = parse_url($url); $image = ($base['scheme'] ?? 'https') . '://' . ($base['host'] ?? '') . '/' . ltrim($image, '/');
    }
    if ($image && !url_is_safe_to_fetch($image)) $image = null;
    return [ 'title' => $title, 'description' => $description, 'image' => $image, 'siteName' => $siteName, 'url' => $url, ];
}

function first_url_in_text($text) {
    if (!is_string($text)) return null;
    if (preg_match('#https?://[^\s<>"]+#i', $text, $m)) { return rtrim($m[0], '.,)]!?'); }
    return null;
}

function find_banned_word($config, $text) {
    if (empty($config['bannedWords']) || !is_string($text) || $text === '') return null;
    $lower = mb_strtolower($text);
    foreach ($config['bannedWords'] as $word) {
        $w = mb_strtolower(trim((string)$word)); if ($w === '') continue;
        if (mb_strpos($lower, $w) !== false) return $word;
    }
    return null;
}

function add_banned_word(&$config, $word) {
    $word = trim((string)$word); if ($word === '' || mb_strlen($word) > 100) return false;
    $lower = mb_strtolower($word);
    foreach ($config['bannedWords'] as $w) { if (mb_strtolower($w) === $lower) return false; }
    if (count($config['bannedWords']) >= 200) return false;
    $config['bannedWords'][] = $word; return true;
}

function remove_banned_word(&$config, $word) {
    $lower = mb_strtolower(trim((string)$word));
    $config['bannedWords'] = array_values(array_filter($config['bannedWords'], function ($w) use ($lower) { return mb_strtolower($w) !== $lower; }));
}

function slow_mode_remaining_seconds($config, $username) {
    $seconds = isset($config['slowModeSeconds']) ? (int)$config['slowModeSeconds'] : 0; if ($seconds <= 0) return 0;
    $uname = strtolower(trim($username)); $last = isset($config['lastMessageAtByUser'][$uname]) ? $config['lastMessageAtByUser'][$uname] : 0; if ($last <= 0) return 0;
    $elapsedMs = now_ms() - $last; $remainingMs = ($seconds * 1000) - $elapsedMs;
    return $remainingMs > 0 ? (int)ceil($remainingMs / 1000) : 0;
}

function record_message_for_spam_tracking(&$config, $username, $text) {
    $uname = strtolower(trim($username)); if ($uname === '') return false;
    $config['lastMessageAtByUser'][$uname] = now_ms();
    if (!isset($config['lastMessageTextByUser'][$uname]) || !is_array($config['lastMessageTextByUser'][$uname])) { $config['lastMessageTextByUser'][$uname] = []; }
    $history = $config['lastMessageTextByUser'][$uname];
    $isRepeat = count($history) >= 2 && $history[count($history) - 1] === $text && $history[count($history) - 2] === $text;
    $history[] = $text; if (count($history) > 3) $history = array_slice($history, -3);
    $config['lastMessageTextByUser'][$uname] = $history;
    return $isRepeat && $text !== '';
}

function add_report(&$config, $messageId, $reportedUser, $reporterUser, $reason) {
    $report = [ 'id' => 'rpt_' . now_ms() . '_' . substr(md5(uniqid('', true)), 0, 6), 'messageId' => $messageId, 'reportedUser' => $reportedUser, 'reporterUser' => $reporterUser, 'reason' => mb_substr(trim((string)$reason), 0, 300), 'ts' => now_ms(), 'status' => 'open', ];
    $config['reports'][] = $report; return $report;
}

function resolve_report(&$config, $reportId) { foreach ($config['reports'] as &$r) { if (isset($r['id']) && $r['id'] === $reportId) { $r['status'] = 'resolved'; return true; } } unset($r); return false; }
function open_report_count($config) { $n = 0; foreach ($config['reports'] as $r) { if (($r['status'] ?? 'open') === 'open') $n++; } return $n; }

function is_co_host($config, $username) { $uname = strtolower(trim($username)); return in_array($uname, $config['coHosts'], true); }
function is_effective_host($config, $session) { if (in_array($session['role'], ['host', 'super'], true)) return true; return $session['role'] === 'member' && is_co_host($config, $session['user']); }
function add_co_host(&$config, $username) { $uname = strtolower(trim($username)); if ($uname === '' || in_array($uname, $config['coHosts'], true)) return; $config['coHosts'][] = $uname; }
function remove_co_host(&$config, $username) { $uname = strtolower(trim($username)); $config['coHosts'] = array_values(array_filter($config['coHosts'], function ($u) use ($uname) { return $u !== $uname; })); }
function is_co_super($config, $username) { $uname = strtolower(trim($username)); return in_array($uname, $config['coSupers'], true); }
function has_limited_theme_access($config, $session) { return $session['role'] === 'member' && is_co_super($config, $session['user']); }
function add_co_super(&$config, $username) { $uname = strtolower(trim($username)); if ($uname === '' || in_array($uname, $config['coSupers'], true)) return; $config['coSupers'][] = $uname; }
function remove_co_super(&$config, $username) { $uname = strtolower(trim($username)); $config['coSupers'] = array_values(array_filter($config['coSupers'], function ($u) use ($uname) { return $u !== $uname; })); }

$GLOBALS['digestHostInactiveMs'] = 15 * 60 * 1000;
$GLOBALS['digestCooldownMs'] = 60 * 60 * 1000;

function host_is_active($config) { foreach ($config['presence'] as $p) { if (($p['role'] ?? '') === 'host' && (now_ms() - $p['ts']) <= $GLOBALS['presenceWindowMs']) return true; } return false; }
function maybe_send_report_digest(&$config, $room) {
    if (empty($config['hostNotifyEmail'])) return false;
    $openCount = open_report_count($config); if ($openCount <= 0) return false;
    if (host_is_active($config)) return false;
    $now = now_ms(); if (($now - ($config['hostLastDigestAt'] ?? 0)) < $GLOBALS['digestCooldownMs']) return false;
    $roomLabel = $config['title'] !== '' ? $config['title'] : $room;
    $subject = 'QuickChat: ' . $openCount . ' open report(s) in "' . $roomLabel . '"';
    $body = "There are $openCount unresolved report(s) waiting in your room \"$roomLabel\" while you have been away.\n\nOpen the room's Manage panel to review and act on them.\n";
    $config['hostLastDigestAt'] = $now; @mail($config['hostNotifyEmail'], $subject, $body, "From: no-reply@quickchat.local\r\n"); return true;
}

function add_scheduled_message(&$config, $text, $user, $role, $postAtMs) {
    $item = [ 'id' => 'sch_' . now_ms() . '_' . substr(md5(uniqid('', true)), 0, 6), 'text' => $text, 'user' => $user, 'role' => $role, 'postAt' => $postAtMs, ];
    $config['scheduledMessages'][] = $item; return $item;
}
function remove_scheduled_message(&$config, $id) { $config['scheduledMessages'] = array_values(array_filter($config['scheduledMessages'], function ($s) use ($id) { return !(isset($s['id']) && $s['id'] === $id); })); }
function process_due_scheduled_messages($room, &$config) {
    if (empty($config['scheduledMessages'])) return [];
    $now = now_ms(); $due = []; $remaining = [];
    foreach ($config['scheduledMessages'] as $s) { if (($s['postAt'] ?? PHP_INT_MAX) <= $now) { $due[] = $s; } else { $remaining[] = $s; } }
    if (empty($due)) return [];
    $config['scheduledMessages'] = $remaining; $posted = [];
    foreach ($due as $s) { $posted[] = append_message($room, [ 'type' => 'text', 'user' => $s['user'], 'role' => $s['role'], 'text' => $s['text'], 'replyTo' => null, 'reactions' => [], 'wasScheduled' => true, ]); }
    return $posted;
}

function create_poll(&$config, $question, $options, $createdBy) {
    $id = 'poll_' . now_ms() . '_' . substr(md5(uniqid('', true)), 0, 6); $opts = [];
    foreach (array_values($options) as $i => $text) { $text = trim((string)$text); if ($text === '') continue; $opts[] = ['id' => 'o' . $i, 'text' => mb_substr($text, 0, 120)]; }
    $poll = [ 'id' => $id, 'question' => mb_substr(trim((string)$question), 0, 200), 'options' => $opts, 'votes' => [], 'createdBy' => $createdBy, 'ts' => now_ms(), 'closed' => false, ];
    $config['polls'][$id] = $poll; return $poll;
}
function cast_poll_vote(&$config, $pollId, $username, $optionId) {
    if (!isset($config['polls'][$pollId])) return null; $poll = &$config['polls'][$pollId]; if (!empty($poll['closed'])) return null;
    $validOption = false; foreach ($poll['options'] as $o) { if ($o['id'] === $optionId) { $validOption = true; break; } }
    if (!$validOption) return null; $poll['votes'][strtolower(trim($username))] = $optionId; return $poll;
}
function close_poll(&$config, $pollId) { if (!isset($config['polls'][$pollId])) return false; $config['polls'][$pollId]['closed'] = true; return true; }
function poll_results($poll) {
    $counts = []; foreach ($poll['options'] as $o) $counts[$o['id']] = 0;
    foreach ($poll['votes'] as $optId) { if (isset($counts[$optId])) $counts[$optId]++; } return $counts;
}

function room_auto_cleanup_if_due($slug, $config) {
    $days = isset($config['autoCleanupDays']) ? (int)$config['autoCleanupDays'] : 0; if ($days <= 0) return false;
    $last = $config['lastActivity'] ?? $config['createdAt'] ?? 0; if ($last <= 0) return false;
    $thresholdMs = $days * 24 * 60 * 60 * 1000; if ((now_ms() - $last) < $thresholdMs) return false;
    delete_room($slug); return true;
}

function templates_file() { return $GLOBALS['dataDir'] . '/templates.json'; }
function read_templates() { $data = read_json_file(templates_file()); return is_array($data) ? $data : []; }
function save_template($name, $config) {
    $name = trim((string)$name); if ($name === '') return false;
    $templates = read_templates();
    $templates[$name] = [ 'name' => $name, 'roomTheme' => $config['roomTheme'], 'slowModeSeconds' => $config['slowModeSeconds'] ?? 0, 'bannedWords' => $config['bannedWords'] ?? [], 'requireFileApproval' => $config['requireFileApproval'] ?? false, 'savedAt' => now_ms(), ];
    write_json_file(templates_file(), $templates); return true;
}
function delete_template($name) { $templates = read_templates(); unset($templates[$name]); write_json_file(templates_file(), $templates); }
function apply_template(&$config, $name) {
    $templates = read_templates(); if (!isset($templates[$name])) return false;
    $t = $templates[$name];
    if (isset($t['roomTheme'])) $config['roomTheme'] = $t['roomTheme']; if (isset($t['slowModeSeconds'])) $config['slowModeSeconds'] = $t['slowModeSeconds'];
    if (isset($t['bannedWords'])) $config['bannedWords'] = $t['bannedWords']; if (isset($t['requireFileApproval'])) $config['requireFileApproval'] = $t['requireFileApproval'];
    return true;
}

function search_messages($room, $query, $limit = 50) {
    $query = trim((string)$query); if ($query === '') return [];
    $messages = read_messages($room); $lowerQuery = mb_strtolower($query); $results = [];
    for ($i = count($messages) - 1; $i >= 0 && count($results) < $limit; $i--) {
        $m = $messages[$i]; $haystack = '';
        if (isset($m['text'])) $haystack .= $m['text'] . ' '; if (isset($m['fileName'])) $haystack .= $m['fileName'];
        if (strpos($haystack, 'encv1:') === 0) continue;
        if (mb_strpos(mb_strtolower($haystack), $lowerQuery) !== false) { $results[] = $m; }
    }
    return $results;
}

function clear_users_messages($room, $username) {
    $messages = read_messages($room); $uname = strtolower(trim($username)); $kept = []; $removedCount = 0;
    foreach ($messages as $m) {
        if (isset($m['user']) && strtolower($m['user']) === $uname) {
            $removedCount++;
            if (isset($m['type']) && $m['type'] === 'file' && !empty($m['fileUrl'])) { $path = __DIR__ . '/' . ltrim($m['fileUrl'], '/'); if (is_file($path)) @unlink($path); }
        } else { $kept[] = $m; }
    }
    if ($removedCount > 0) write_messages($room, $kept); return $removedCount;
}

$GLOBALS['undoDeleteGraceMs'] = 10 * 1000;
function mark_room_pending_delete($room) { $config = read_config($room); if (!$config) return false; $config['pendingDeleteAt'] = now_ms(); write_config($room, $config); return true; }
function undo_room_delete($room) { $config = read_config($room); if (!$config || empty($config['pendingDeleteAt'])) return false; unset($config['pendingDeleteAt']); write_config($room, $config); return true; }
function sweep_pending_deletes() {
    $pattern = $GLOBALS['dataDir'] . '/config_*.json';
    foreach (glob($pattern) as $path) {
        $base = basename($path, '.json'); $slug = substr($base, strlen('config_')); if ($slug === '') continue;
        $config = read_config($slug); if (!$config || empty($config['pendingDeleteAt'])) continue;
        if ((now_ms() - $config['pendingDeleteAt']) >= $GLOBALS['undoDeleteGraceMs']) { delete_room($slug); }
    }
}

function site_dashboard_stats() {
    $rooms = list_rooms(); $totalRooms = count($rooms); $totalActiveUsers = 0; $totalMessages = 0; $totalBanned = 0; $messagesToday = 0;
    $todayStartMs = strtotime('today') * 1000;
    foreach ($rooms as $r) {
        $totalActiveUsers += count($r['activeUsers']); $totalMessages += $r['messageCount']; $totalBanned += $r['bannedUserCount'];
        $msgs = read_json_file(room_file($r['room']));
        if (is_array($msgs)) { foreach ($msgs as $m) { if (($m['ts'] ?? 0) >= $todayStartMs) $messagesToday++; } }
    }
    return [ 'totalRooms' => $totalRooms, 'totalActiveUsers' => $totalActiveUsers, 'totalMessages' => $totalMessages, 'messagesToday' => $messagesToday, 'totalBannedUsers' => $totalBanned, 'blockedIps' => count(list_blocked_ips()), 'generatedAt' => now_ms(), ];
}

function translate_text($text, $targetLang) {
    $text = mb_substr(trim((string)$text), 0, 2000); if ($text === '') return null;
    $targetLang = preg_replace('/[^a-z\-]/i', '', (string)$targetLang); if ($targetLang === '') $targetLang = 'en';
    $payload = json_encode(['q' => $text, 'source' => 'auto', 'target' => $targetLang, 'format' => 'text']);
    $ctx = stream_context_create([ 'http' => [ 'method' => 'POST', 'header' => "Content-Type: application/json\r\nAccept: application/json\r\n", 'content' => $payload, 'timeout' => 6, ], ]);
    $result = @file_get_contents('https://libretranslate.com/translate', false, $ctx);
    if ($result === false) return null; $data = json_decode($result, true); return isset($data['translatedText']) ? $data['translatedText'] : null;
}

if (!defined('TENOR_API_KEY')) { define('TENOR_API_KEY', 'LIVDSRZULELA'); }
function search_gifs($query, $limit = 12, &$errorOut = null) {
    $query = trim((string)$query); if ($query === '') return [];
    $limit = max(1, min(24, (int)$limit));
    $url = 'https://api.tenor.com/v1/search?' . http_build_query([ 'q' => $query, 'key' => TENOR_API_KEY, 'limit' => $limit, 'media_filter' => 'minimal', 'contentfilter' => 'medium', ]);
    $ctx = stream_context_create(['http' => ['timeout' => 6, 'ignore_errors' => true]]);
    $result = @file_get_contents($url, false, $ctx);
    if ($result === false) { $errorOut = 'Could not reach Tenor (network error or blocked outbound HTTPS on this host).'; return []; }
    $data = json_decode($result, true);
    if (!is_array($data) || isset($data['error'])) { $errorOut = isset($data['error']) ? ('Tenor error: ' . $data['error']) : 'Tenor returned an unexpected response.'; return []; }
    if (!isset($data['results']) || !is_array($data['results'])) { $errorOut = 'Tenor returned an unexpected response.'; return []; }
    $out = [];
    foreach ($data['results'] as $g) {
        $media = isset($g['media'][0]) ? $g['media'][0] : null; $gifUrl = $media['gif']['url'] ?? null; $previewUrl = $media['tinygif']['url'] ?? $gifUrl;
        if (!$gifUrl) continue; $out[] = ['url' => $gifUrl, 'preview' => $previewUrl, 'description' => $g['content_description'] ?? ''];
    }
    return $out;
}

function sticker_catalog() {
    return [
        ['id' => 'wave', 'emoji' => '👋', 'label' => 'Wave'], ['id' => 'thumbsup', 'emoji' => '👍', 'label' => 'Thumbs up'], ['id' => 'fire', 'emoji' => '🔥', 'label' => 'Fire'],
        ['id' => 'heart', 'emoji' => '❤️', 'label' => 'Heart'], ['id' => 'laugh', 'emoji' => '🤣', 'label' => 'Laughing'], ['id' => 'clap', 'emoji' => '👏', 'label' => 'Clap'],
        ['id' => 'party', 'emoji' => '🎉', 'label' => 'Party'], ['id' => 'think', 'emoji' => '🤔', 'label' => 'Thinking'], ['id' => 'cool', 'emoji' => '😎', 'label' => 'Cool'],
        ['id' => 'cry', 'emoji' => '😭', 'label' => 'Crying'], ['id' => 'shock', 'emoji' => '😱', 'label' => 'Shocked'], ['id' => 'sleep', 'emoji' => '😴', 'label' => 'Sleepy'],
        ['id' => 'rocket', 'emoji' => '🚀', 'label' => 'Rocket'], ['id' => 'star', 'emoji' => '⭐', 'label' => 'Star'], ['id' => 'ok', 'emoji' => '👌', 'label' => 'OK'],
        ['id' => 'wave-bye', 'emoji' => '🙌', 'label' => 'Celebration'],
    ];
}
function sticker_by_id($id) { foreach (sticker_catalog() as $s) { if ($s['id'] === $id) return $s; } return null; }

function build_data_backup_zip() {
    if (!class_exists('ZipArchive')) return null;
    $tmpPath = tempnam(sys_get_temp_dir(), 'qcbackup_'); if ($tmpPath === false) return null;
    @unlink($tmpPath); $tmpPath .= '.zip';
    $zip = new ZipArchive(); if ($zip->open($tmpPath, ZipArchive::CREATE) !== true) return null;
    foreach (glob($GLOBALS['dataDir'] . '/*.json') as $file) { $zip->addFile($file, basename($file)); }
    $zip->close(); return $tmpPath;
}
?>