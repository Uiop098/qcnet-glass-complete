<?php
// telegram_link_redeem.php — the landing page for the URL /link sends in
// Telegram. Mints a FRESH QuickChat session (same create_session() the
// normal web login uses) from the stored room/role/user, then hands off
// to room.html — from that point on it's the exact same live web chat
// experience as logging in on the website directly, with proper live
// polling instead of the bot's catch-up-on-next-message relay.
require_once __DIR__ . '/dash_crypto.php';
$GLOBALS['dataDir'] = __DIR__ . '/data';
$GLOBALS['filesDir'] = __DIR__ . '/files';
require_once __DIR__ . '/common.php';

$token = $_GET['token'] ?? '';
$links = get_secure_table(__DIR__ . '/data_dash/telegram_link_tokens.json');

if (!isset($links[$token]) || time() > $links[$token]['expires']) {
    http_response_code(410);
    echo '<!DOCTYPE html><html><body style="font-family:sans-serif;text-align:center;padding:60px;background:#0B0814;color:#F7F4FF;">
        <h2>Link expired or already used</h2>
        <p>Go back to Telegram and send <b>/link</b> again to get a fresh one.</p>
    </body></html>';
    exit;
}

$link = $links[$token];
unset($links[$token]); // single-use
save_secure_table(__DIR__ . '/data_dash/telegram_link_tokens.json', $links);

$freshToken = create_session($link['room'], $link['user'], $link['role']);
if ($link['role'] === 'super_master') {
    $sessions = read_json_file(sessions_file()) ?: [];
    if (isset($sessions[$freshToken])) {
        $sessions[$freshToken]['tier'] = $link['tier'] ?? 'master';
        $sessions[$freshToken]['username'] = $link['username'] ?? $link['user'];
        write_json_file(sessions_file(), $sessions);
    }
}
$redirectTo = $link['role'] === 'super_master' ? 'rooms.html' : 'room.html';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Opening your chat…</title>
<style>body{font-family:sans-serif;background:#0B0814;color:#F7F4FF;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}</style>
</head>
<body>
<p>Opening your chat…</p>
<script>
sessionStorage.setItem('qc_session', JSON.stringify({
    token: <?php echo json_encode($freshToken); ?>,
    room: <?php echo json_encode($link['room']); ?>,
    role: <?php echo json_encode($link['role']); ?>,
    user: <?php echo json_encode($link['user']); ?>
}));
<?php if ($link['role'] === 'super_master'): ?>
sessionStorage.setItem('qc_master_token', <?php echo json_encode($freshToken); ?>);
sessionStorage.setItem('qc_master_name', <?php echo json_encode($link['user']); ?>);
sessionStorage.setItem('qc_master_username', <?php echo json_encode($link['username'] ?? $link['user']); ?>);
sessionStorage.setItem('qc_master_tier', <?php echo json_encode($link['tier'] ?? 'master'); ?>);
<?php endif; ?>
window.location.href = <?php echo json_encode($redirectTo); ?>;
</script>
</body>
</html>
