<?php
// telegram_setwebhook.php — run this ONCE (as the master admin) after
// filling in telegram_config.php, to tell Telegram where to send updates.
// Safe to leave on the server afterward — it's gated to the master admin
// and just re-confirms the same webhook URL if run again.
require_once __DIR__ . '/dash_firewall.php';

if (!isset($_SESSION['dash_admin']) || ($_SESSION['dash_tenant'] ?? '') !== 'main') {
    http_response_code(403); die('Only the default super admin can run this.');
}
require_once __DIR__ . '/telegram_config.php';

$host = $_SERVER['HTTP_HOST'] ?? '';
if (!preg_match('/^[a-zA-Z0-9.\-]+(:\d+)?$/', $host)) { die('Could not determine this server\'s domain — open this page directly in your browser rather than via a proxy.'); }
$webhookUrl = 'https://' . $host . '/telegram_webhook.php';

$ch = curl_init('https://api.telegram.org/bot' . TELEGRAM_BOT_TOKEN . '/setWebhook');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['url' => $webhookUrl, 'secret_token' => TELEGRAM_WEBHOOK_SECRET]));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$response = curl_exec($ch);
curl_close($ch);
$result = json_decode($response, true);

header('Content-Type: text/html');
echo '<!DOCTYPE html><html><body style="font-family:sans-serif; max-width:600px; margin:60px auto; line-height:1.6;">';
echo '<h2>Telegram Webhook Setup</h2>';
echo '<p><b>URL registered:</b> ' . htmlspecialchars($webhookUrl) . '</p>';
if (!empty($result['ok'])) {
    echo '<p style="color:green;">✅ Success — Telegram confirmed the webhook. Message your bot on Telegram to test it (try /start).</p>';
} else {
    echo '<p style="color:red;">❌ Failed: ' . htmlspecialchars($result['description'] ?? $response) . '</p>';
    echo '<p>Check that TELEGRAM_BOT_TOKEN in telegram_config.php is correct, and that this domain is reachable over HTTPS (Telegram requires a valid HTTPS certificate — a self-signed one will not work).</p>';
}
echo '</body></html>';
?>
