<?php
// telegram_config.php — from @BotFather (create a bot, get the token).
// TELEGRAM_WEBHOOK_SECRET is a string you make up yourself — set it here,
// then when registering the webhook with Telegram, pass the same value as
// secret_token. Telegram echoes it back in every request's
// X-Telegram-Bot-Api-Secret-Token header, which telegram_webhook.php
// checks before processing anything — without this, anyone who found the
// webhook URL could POST fake "messages" to it.
define('TELEGRAM_BOT_TOKEN', 'REPLACE_ME:AAAA-your-bot-token-from-botfather');
define('TELEGRAM_WEBHOOK_SECRET', 'REPLACE_ME_with_a_random_string');
?>
