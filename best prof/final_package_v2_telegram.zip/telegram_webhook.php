<?php
// telegram_webhook.php — Telegram POSTs every incoming bot message here
// (webhook mode; InfinityFree can't run the alternative long-polling mode,
// which needs a persistent process).
//
// Three ways to log in, all reusing the exact same server-side checks the
// web login uses — this file doesn't reimplement auth, it calls the same
// primitives (create_session(), password_verify() against the same
// stores, totp_verify()):
//   /join <room> <pin>      — member login
//   /host <room> <password> — host login (first use sets the password)
//   /super <user> <pass>    — Dashboard/Super credentials, with the same
//                             2FA challenge (and cross-system bridge) as
//                             everywhere else if the account has it on
//
// Once logged in, any plain-text message (no leading /) is relayed into
// the room as a chat message, and the reply includes any new messages
// that arrived since the last time this chat interacted with the bot.
// That "since last interaction" qualifier is the honest limit here:
// InfinityFree has no persistent process, so there's no way to push a
// brand new room message into Telegram the instant it arrives if the
// person's just sitting idle — it delivers on your next message instead
// of truly live. /link sidesteps that entirely by handing back a one-time
// URL that opens the exact same session in a real browser tab, where the
// normal web chat (with its own live polling) takes over completely.
//
// SECURITY NOTE (inherent to using Telegram as a login surface, not
// something code can fix): a room PIN, host password, or Dashboard
// password typed into Telegram is stored in that chat's own message
// history like any other message — Telegram doesn't mask it the way a
// browser's password field does. That's Telegram's own behavior, not a
// bug here; anyone using /host or /super over Telegram should treat that
// chat history as sensitive, same as they would a password manager note.

require_once __DIR__ . '/telegram_config.php';
require_once __DIR__ . '/dash_crypto.php';
require_once __DIR__ . '/dash_2fa.php';
require_once __DIR__ . '/dash_audit.php';

// Same fix as dash_msg_bridge.php: point dataDir/filesDir at the real
// QuickChat stores before common.php loads, so its own rate-limit/IP-block
// checks (and every room helper) read the right files instead of a
// possibly-different path some other already-loaded file set first.
$GLOBALS['dataDir'] = __DIR__ . '/data';
$GLOBALS['filesDir'] = __DIR__ . '/files';
require_once __DIR__ . '/common.php';

header('Content-Type: application/json');

// ---- Verify this really came from Telegram ----
$secretHeader = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '';
if (!hash_equals(TELEGRAM_WEBHOOK_SECRET, $secretHeader)) { http_response_code(403); exit; }

$update = json_decode(file_get_contents('php://input'), true);
$message = $update['message'] ?? null;
if (!$message || empty($message['chat']['id'])) { echo json_encode(['ok' => true]); exit; }
$chatId = (string)$message['chat']['id'];
$text = trim($message['text'] ?? '');

if (!rate_limit_allow('telegram_bot', 'chat_' . $chatId, 30, 60)) {
    tg_reply($chatId, "You're sending messages too fast — please slow down a little.");
    exit;
}

// ---- Per-chat storage (this bot has no browser session, so everything
// persists here instead, keyed by Telegram chat id) ----
function tg_sessions_file() { return __DIR__ . '/data_dash/telegram_sessions.json'; }
function tg_state_file() { return __DIR__ . '/data_dash/telegram_state.json'; }
function tg_get_session($chatId) { $s = get_secure_table(tg_sessions_file()); return $s[$chatId] ?? null; }
function tg_set_session($chatId, $data) { $s = get_secure_table(tg_sessions_file()); $s[$chatId] = $data; save_secure_table(tg_sessions_file(), $s); }
function tg_clear_session($chatId) { $s = get_secure_table(tg_sessions_file()); unset($s[$chatId]); save_secure_table(tg_sessions_file(), $s); }
function tg_get_state($chatId) { $s = get_secure_table(tg_state_file()); return $s[$chatId] ?? null; }
function tg_set_state($chatId, $data) { $s = get_secure_table(tg_state_file()); $s[$chatId] = $data; save_secure_table(tg_state_file(), $s); }
function tg_clear_state($chatId) { $s = get_secure_table(tg_state_file()); unset($s[$chatId]); save_secure_table(tg_state_file(), $s); }

function tg_reply($chatId, $text) {
    $ch = curl_init('https://api.telegram.org/bot' . TELEGRAM_BOT_TOKEN . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['chat_id' => $chatId, 'text' => $text, 'parse_mode' => 'HTML']));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_exec($ch); curl_close($ch);
}

function tg_help_text() {
    return "🤖 <b>QuickChat Bot</b>\n\n"
        . "<b>/join room pin</b> — join a room as a regular member\n"
        . "<b>/host room password</b> — log in as host (first time sets the password)\n"
        . "<b>/super username password</b> — log in with Dashboard/Super credentials\n"
        . "<b>/whoami</b> — show your current session\n"
        . "<b>/link</b> — get a one-time link to open this chat in your browser\n"
        . "<b>/logout</b> — end your session here\n\n"
        . "Once logged in, just type normally to chat.\n\n"
        . "⚠️ Anything you type here (including passwords/PINs) stays in this Telegram chat's own history — Telegram doesn't mask it like a website's password box.";
}

// ---- Commands that don't need an existing session ----
$parts = preg_split('/\s+/', $text, 3);
$cmd = strtolower($parts[0] ?? '');

if ($cmd === '/start' || $cmd === '/help') { tg_reply($chatId, tg_help_text()); tg_clear_state($chatId); exit; }

if ($cmd === '/logout') {
    tg_clear_session($chatId); tg_clear_state($chatId);
    tg_reply($chatId, 'Logged out. Use /join, /host, or /super to start a new session.');
    exit;
}

if ($cmd === '/whoami') {
    $s = tg_get_session($chatId);
    tg_reply($chatId, $s ? "Logged in as <b>{$s['user']}</b> ({$s['role']}) in room <b>{$s['room']}</b>." : 'Not logged in yet. Try /join, /host, or /super.');
    exit;
}

if ($cmd === '/link') {
    $s = tg_get_session($chatId);
    if (!$s) { tg_reply($chatId, 'You need to log in first — /join, /host, or /super.'); exit; }
    // Stores what's needed to mint a FRESH session at redemption time
    // (not the current token itself) — the person might click this
    // minutes or hours after generating it, and a freshly-minted session
    // is more robust than hoping the original one hasn't expired.
    $linkToken = bin2hex(random_bytes(24));
    $links = get_secure_table(__DIR__ . '/data_dash/telegram_link_tokens.json');
    $linkData = ['room' => $s['room'], 'role' => $s['role'], 'user' => $s['user'], 'expires' => time() + 300];
    if ($s['role'] === 'super_master') {
        // Carry tier/username through so a re-minted session on the web
        // side still gets tier-gated correctly in super_join/rooms.php —
        // without this a tenant-tier admin's re-minted session would
        // silently default to master tier (unrestricted room access).
        $cur = get_session($s['token']);
        $linkData['tier'] = $cur['tier'] ?? 'master';
        $linkData['username'] = $cur['username'] ?? $s['user'];
    }
    $links[$linkToken] = $linkData;
    save_secure_table(__DIR__ . '/data_dash/telegram_link_tokens.json', $links);
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $url = (preg_match('/^[a-zA-Z0-9.\-]+(:\d+)?$/', $host) ? $host : 'your-domain.example') . '/telegram_link_redeem.php?token=' . $linkToken;
    tg_reply($chatId, "🔗 Open this in your browser (valid 5 minutes, one-time use):\nhttps://$url");
    exit;
}

if ($cmd === '/join' || $cmd === '/host' || $cmd === '/super') {
    // Support both one-shot ("/join room pin") and conversational (bot
    // asks step by step) — whichever's easier for the person typing.
    if (count($parts) >= 3) {
        tg_handle_login($chatId, $cmd, $parts[1], $parts[2]);
    } else {
        tg_set_state($chatId, ['flow' => $cmd, 'step' => 1, 'data' => []]);
        $prompt = $cmd === '/super' ? 'What is your Dashboard/Super <b>username</b>?' : 'What is the <b>room name</b>?';
        tg_reply($chatId, $prompt);
    }
    exit;
}

// ---- Mid-conversation step (room name / PIN / password / 2FA code) ----
$state = tg_get_state($chatId);
if ($state) {
    tg_continue_flow($chatId, $state, $text);
    exit;
}

// ---- Plain text: relay into the room if logged in ----
$session = tg_get_session($chatId);
if (!$session) { tg_reply($chatId, "Not logged in. Use /join, /host, or /super — or /help for details."); exit; }
if ($text === '') { exit; }

tg_relay_and_catch_up($chatId, $session, $text);
exit;

// ================= Flow handlers =================

function tg_continue_flow($chatId, $state, $text) {
    $flow = $state['flow']; $step = $state['step']; $data = $state['data'];
    if ($flow === '/super') {
        if ($step === 1) { $data['username'] = $text; tg_set_state($chatId, ['flow' => $flow, 'step' => 2, 'data' => $data]); tg_reply($chatId, 'And your <b>password</b>?'); return; }
        if ($step === 2) { $data['password'] = $text; tg_login_super($chatId, $data['username'], $data['password']); return; }
        if ($step === 3) { tg_verify_super_2fa($chatId, $state['pending_token'], $text); return; }
    } else {
        // /join or /host: room name then PIN/password
        if ($step === 1) { $data['room'] = $text; tg_set_state($chatId, ['flow' => $flow, 'step' => 2, 'data' => $data]); tg_reply($chatId, $flow === '/host' ? 'Set/enter the <b>host password</b>:' : 'Enter the <b>room PIN</b>:'); return; }
        if ($step === 2) { tg_handle_login($chatId, $flow, $data['room'], $text); return; }
    }
}

function tg_handle_login($chatId, $cmd, $room, $secret) {
    tg_clear_state($chatId);
    if (!rate_limit_allow('telegram_login', 'chat_' . $chatId, 8, 600)) { tg_reply($chatId, 'Too many attempts — please wait a few minutes.'); return; }
    $room = safe_room_name($room);
    $config = read_config($room);

    if ($cmd === '/join') {
        if (!$config) { tg_reply($chatId, 'That room does not exist yet.'); return; }
        if (is_banned($config, 'telegram:' . $chatId)) { tg_reply($chatId, 'You are banned from this room.'); return; }
        if (empty($config['pinHash'])) { tg_reply($chatId, "This room's host hasn't set a PIN yet."); return; }
        if (!hash_equals($config['pinHash'], hash('sha256', $secret))) { tg_reply($chatId, 'Incorrect PIN.'); return; }
        $displayName = 'TG-' . substr($chatId, -4);
        $token = create_session($room, $displayName, 'member');
        tg_set_session($chatId, ['token' => $token, 'room' => $room, 'role' => 'member', 'user' => $displayName, 'last_seen_id' => '']);
        tg_reply($chatId, "✅ Joined <b>$room</b> as $displayName. Type a message to chat, or /link to open it in your browser.");
        return;
    }

    if ($cmd === '/host') {
        $displayName = 'Host';
        if (!$config) {
            $config = default_config(); $config['createdAt'] = now_ms(); $config['hostPasswordHash'] = hash('sha256', $secret);
            write_config($room, $config);
        } elseif (empty($config['hostPasswordHash'])) {
            $config['hostPasswordHash'] = hash('sha256', $secret); write_config($room, $config);
        } elseif (!hash_equals($config['hostPasswordHash'], hash('sha256', $secret))) {
            tg_reply($chatId, 'Incorrect host password.'); return;
        }
        $token = create_session($room, $displayName, 'host');
        tg_set_session($chatId, ['token' => $token, 'room' => $room, 'role' => 'host', 'user' => $displayName, 'last_seen_id' => '']);
        tg_reply($chatId, "✅ Hosting <b>$room</b>. Type a message to chat, or /link to open it in your browser.");
        return;
    }
}

function tg_login_super($chatId, $username, $password) {
    if (!rate_limit_allow('telegram_super_login', 'chat_' . $chatId, 8, 600)) { tg_clear_state($chatId); tg_reply($chatId, 'Too many attempts — please wait a few minutes.'); return; }
    $superUsers = read_super_credentials();
    if (!isset($superUsers[$username])) { tg_clear_state($chatId); tg_reply($chatId, 'Invalid credentials.'); return; }
    $storedHash = $superUsers[$username]['passwordHash'];
    $ok = (strpos($storedHash, '$2y$') === 0) ? password_verify($password, $storedHash) : hash_equals($storedHash, hash('sha256', $password));
    if (!$ok) { tg_clear_state($chatId); tg_reply($chatId, 'Invalid credentials.'); return; }

    $tier = $superUsers[$username]['tier'] ?? 'master';
    if (!empty($superUsers[$username]['twofaEnabled']) && !is_2fa_recently_verified($username)) {
        $pendingToken = bin2hex(random_bytes(24));
        $tempDir = __DIR__ . '/data_dash/temp'; if (!is_dir($tempDir)) @mkdir($tempDir, 0755, true);
        file_put_contents($tempDir . '/2fa_pending_' . $pendingToken . '.json', json_encode([
            'context' => 'telegram_super_login', 'username' => $username, 'tier' => $tier,
            'secret' => $superUsers[$username]['twofaSecret'], 'recovery_codes' => $superUsers[$username]['twofaRecoveryCodes'] ?? [],
            'expires' => time() + 300,
        ]));
        tg_set_state($chatId, ['flow' => '/super', 'step' => 3, 'data' => [], 'pending_token' => $pendingToken]);
        tg_reply($chatId, '🔐 This account has 2FA enabled. Enter your 6-digit code (or a recovery code):');
        return;
    }
    tg_clear_state($chatId);
    tg_finish_super_login($chatId, $username, $tier);
}

function tg_verify_super_2fa($chatId, $pendingToken, $code) {
    if (!rate_limit_allow('telegram_2fa_verify', 'chat_' . $chatId, 10, 600)) { tg_clear_state($chatId); tg_reply($chatId, 'Too many attempts — please wait a few minutes.'); return; }
    $pf = __DIR__ . '/data_dash/temp/2fa_pending_' . preg_replace('/[^a-zA-Z0-9]/', '', $pendingToken) . '.json';
    if (!file_exists($pf)) { tg_clear_state($chatId); tg_reply($chatId, 'That login attempt expired. Start again with /super.'); return; }
    $pending = json_decode(file_get_contents($pf), true);
    if (($pending['context'] ?? '') !== 'telegram_super_login' || time() > $pending['expires']) { @unlink($pf); tg_clear_state($chatId); tg_reply($chatId, 'That login attempt expired. Start again with /super.'); return; }
    $code = trim($code);
    if (!totp_verify($pending['secret'], $code)) {
        $codes = $pending['recovery_codes'] ?? [];
        if (array_search(strtoupper($code), array_map('strtoupper', $codes), true) === false) { tg_reply($chatId, 'Incorrect code. Try again, or /logout to cancel.'); return; }
    }
    @unlink($pf); tg_clear_state($chatId);
    mark_2fa_verified($pending['username']);
    tg_finish_super_login($chatId, $pending['username'], $pending['tier']);
}

function tg_finish_super_login($chatId, $username, $tier) {
    // Super logins land in the master room, same as the web login, then
    // the person opens a specific room via /join or /link from there.
    $displayName = $tier === 'master' ? 'Master Admin' : $username;
    $token = create_session($GLOBALS['MASTER_ROOM'], $displayName, 'super_master');
    $sessions = read_json_file(sessions_file()) ?: [];
    if (isset($sessions[$token])) { $sessions[$token]['tier'] = $tier; $sessions[$token]['username'] = $username; write_json_file(sessions_file(), $sessions); }
    tg_set_session($chatId, ['token' => $token, 'room' => $GLOBALS['MASTER_ROOM'], 'role' => 'super_master', 'user' => $displayName, 'last_seen_id' => '']);
    tg_reply($chatId, "✅ Logged in as <b>$displayName</b>. Use /join &lt;room&gt; &lt;pin&gt; to enter a specific room, or /link to continue in your browser.");
}

function tg_relay_and_catch_up($chatId, $session, $text) {
    $room = $session['room'];
    $sess = get_session($session['token']);
    if (!$sess) { tg_clear_session($chatId); tg_reply($chatId, 'Your session expired. Please log in again.'); return; }

    // Super-master sessions (not yet bound to a specific room) can't send
    // a chat message — nudge toward picking a room first.
    if ($session['role'] === 'super_master') { tg_reply($chatId, 'Use /join &lt;room&gt; &lt;pin&gt; to enter a specific room first.'); return; }

    $config = read_config($room);
    if (!$config) { tg_clear_session($chatId); tg_reply($chatId, 'That room no longer exists.'); return; }
    if (is_banned($config, $session['user'])) { tg_clear_session($chatId); tg_reply($chatId, 'You have been banned from this room.'); return; }

    $messages = read_messages($room);
    $newMsg = ['id' => uniqid('m_', true), 'user' => $session['user'], 'role' => $session['role'], 'text' => htmlspecialchars($text, ENT_QUOTES, 'UTF-8'), 'ts' => now_ms()];
    $messages[] = $newMsg;
    write_messages($room, $messages);
    log_activity(__DIR__ . '/data_dash', 'telegram:' . $chatId, 'telegram_message_sent', 'Sent a message via Telegram to room ' . $room . '.');

    // "Catch up" reply: any messages that arrived since this chat's last
    // interaction, sent from someone else — the closest this setup gets to
    // pushing new messages without a persistent background process.
    $sessionsAll = get_secure_table(tg_sessions_file());
    $lastSeen = $sessionsAll[$chatId]['last_seen_id'] ?? '';
    $others = [];
    $foundLast = ($lastSeen === '');
    foreach ($messages as $m) {
        if (!$foundLast) { if ($m['id'] === $lastSeen) $foundLast = true; continue; }
        if ($m['id'] === $newMsg['id']) continue;
        if (($m['user'] ?? '') === $session['user']) continue;
        $others[] = $m;
    }
    $sessionsAll[$chatId]['last_seen_id'] = $newMsg['id'];
    save_secure_table(tg_sessions_file(), $sessionsAll);

    $reply = "✅ Sent to $room.";
    if ($others) {
        $reply .= "\n\n<b>New in the room:</b>\n" . implode("\n", array_map(function ($m) { return '<b>' . htmlspecialchars($m['user']) . ':</b> ' . ($m['text'] ?? '[file/other]'); }, array_slice($others, -10)));
    }
    tg_reply($chatId, $reply);
}

echo json_encode(['ok' => true]);
?>
