# Premium Login — Purple & Gold Theme

A single self-contained login page for premium/paid-tier users: a
frosted glass card over a deep violet, animated glow backdrop, with gold
used as the one accent color throughout (badge, logo, focus states,
button, top tier of the strength meter). No build step, no dependencies
— just open the file or drop it into any project.

## What's inside

- **Visual style:** Glassmorphism card (`backdrop-filter: blur()`) +
  drifting purple/gold glow blobs behind it + a thin gold hairline along
  the top edge of the card + a "Premium Member" badge with a crown mark.
- **Usability features**, carried over from the standard friendly-login
  pattern so premium doesn't mean less accessible:
  - Floating labels that stay visible after typing
  - Inline ✓ / ! validity marks on the email field
  - Live password strength meter (top tier lands on gold)
  - Caps Lock warning while typing the password
  - Submit button disabled until the form is actually valid
  - `aria-live` regions on all hints/errors for screen readers
  - Visible gold focus rings for keyboard navigation
  - `prefers-reduced-motion` respected (background animation turns off)

## Quick start

1. Copy `premium-login.html` into your project (rename if you like).
2. Re-skin by editing the `:root` custom properties at the top of the
   `<style>` block — `--purple-deep`, `--purple-mid`, `--purple-glow`,
   `--gold`, `--gold-bright` control the whole palette.
3. Swap the placeholder `<div class="login-card__logo">` for your real
   logo (keep the gold gradient behind it, or replace entirely).
4. Wire up real authentication: open `handleSubmit()` near the bottom of
   the `<script>` tag and replace the demo `setTimeout` with the
   commented-out `fetch()` example directly above it. On a failed login,
   set `formBanner.textContent` and add the `.show` class — it already
   announces itself to screen readers via `role="alert"`.

## Fonts

Uses `Playfair Display` for the heading and `Inter` for body text. Both
fall back gracefully (Georgia / system sans) without a webfont link, but
for the intended look, add to `<head>`:

```html
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
```

## Browser support note

Uses `backdrop-filter` (for the glass effect) and `color-mix()`-free
translucent colors written directly in `rgba()`, so it's compatible with
all current major browsers, including slightly older ones. On browsers
without `backdrop-filter` support, the card still renders correctly —
just without the blur, as a solid tinted panel.
