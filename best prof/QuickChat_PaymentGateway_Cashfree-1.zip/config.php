<?php
// config.php — every value in here MUST be changed before you go live.
// This file is blocked from direct browser access by .htaccess, but it
// still sits in plain text on the server, so keep server access (FTP/
// control panel login) private, same as you would for any other host.

// ---------------------------------------------------------------------
// 1) MySQL — create a database in your InfinityFree control panel
//    (Control Panel -> MySQL Databases), then paste its details here.
//    InfinityFree DB hostnames are usually NOT "localhost" — copy the
//    exact hostname shown next to your database (something like
//    sqlXXX.infinityfree.com).
// ---------------------------------------------------------------------
define('DB_HOST', 'sqlXXX.infinityfree.com');
define('DB_NAME', 'if0_XXXXXXXX_quickchat_pay');
define('DB_USER', 'if0_XXXXXXXX');
define('DB_PASS', 'REPLACE_WITH_YOUR_DB_PASSWORD');

// ---------------------------------------------------------------------
// 2) Cashfree — from https://merchant.cashfree.com -> Developers -> API Keys.
//    CASHFREE_ENV is set to 'production' below, so paste your
//    PRODUCTION Client ID/Secret here (switch the dashboard's mode
//    toggle to Live/Production before copying them — sandbox and
//    production keys are different pairs and are not interchangeable).
//    Never put the client SECRET in any file the browser can load
//    directly — only server-side files here use it.
// ---------------------------------------------------------------------
define('CASHFREE_ENV', 'production'); // 'sandbox' or 'production'
define('CASHFREE_CLIENT_ID', 'REPLACE_WITH_YOUR_CLIENT_ID');
define('CASHFREE_CLIENT_SECRET', 'REPLACE_WITH_YOUR_CLIENT_SECRET');
define('CASHFREE_API_VERSION', '2023-08-01');

// Merchant Dashboard -> Developers -> Webhooks -> Add Endpoint on the
// Cashfree dashboard.
//   Webhook URL: https://yourpaymentsite.example/webhook.php
//   Event:       PAYMENT_SUCCESS_WEBHOOK
// Cashfree signs webhooks with your CLIENT SECRET (not a separate
// webhook secret) — see webhook.php for how that's used. Sandbox and
// production each need their own webhook set up in the matching mode.

// ---------------------------------------------------------------------
// 3) Shared secret with the main QuickChat app. Generate a long random
//    string (e.g. run  php -r "echo bin2hex(random_bytes(32));"  once,
//    anywhere PHP is available) and paste the SAME value here and in
//    the main app's common.php (PAYMENT_GATEWAY_SECRET). This is what
//    stops a random visitor from calling verify_token.php directly.
// ---------------------------------------------------------------------
define('APP_SHARED_SECRET', 'REPLACE_WITH_A_LONG_RANDOM_STRING');

// ---------------------------------------------------------------------
// 4) The offer. Amount is in RUPEES (decimal — Cashfree's order_amount
//    is a plain rupee value, not paise), so 1.00 = ₹1. CASHFREE_ENV is
//    'production' now, so this is a REAL price real buyers will pay —
//    left at ₹1 exactly as it was in testing. Change it here if that
//    was only ever meant to be a sandbox/test amount.
// ---------------------------------------------------------------------
define('OFFER_AMOUNT_INR', 1.00);        // ₹1
define('OFFER_CURRENCY', 'INR');
define('OFFER_DURATION_DAYS', 10);
define('OFFER_LABEL', 'QuickChat Super Access — 10 days');

// ---------------------------------------------------------------------
// Safety net: in production mode, refuse to run at all if any
// placeholder value from above is still in place. Without this, a
// forgotten REPLACE_WITH_... would either crash with a confusing DB
// error or — worse — silently accept a real payment against a
// misconfigured gateway. Every endpoint requires this file first, so
// this check runs before any of them can do anything.
// ---------------------------------------------------------------------
function assert_production_ready() {
    if (CASHFREE_ENV !== 'production') return;
    $placeholders = [
        'DB_HOST' => DB_HOST, 'DB_NAME' => DB_NAME, 'DB_USER' => DB_USER, 'DB_PASS' => DB_PASS,
        'CASHFREE_CLIENT_ID' => CASHFREE_CLIENT_ID, 'CASHFREE_CLIENT_SECRET' => CASHFREE_CLIENT_SECRET,
        'APP_SHARED_SECRET' => APP_SHARED_SECRET,
    ];
    $bad = [];
    foreach ($placeholders as $name => $value) {
        if ($value === '' || strpos($value, 'REPLACE_WITH') !== false || strpos($value, 'XXXX') !== false) {
            $bad[] = $name;
        }
    }
    if (strlen(APP_SHARED_SECRET) < 32) $bad[] = 'APP_SHARED_SECRET (too short — regenerate with random_bytes)';
    if (!$bad) return;

    http_response_code(500);
    header('Content-Type: text/plain');
    echo "This payment gateway is set to CASHFREE_ENV = 'production' but still has "
        . "placeholder values in config.php for: " . implode(', ', $bad) . ". "
        . "Refusing to run rather than risk taking a payment against a broken setup. "
        . "Fill in real values, or set CASHFREE_ENV back to 'sandbox' while you finish testing.";
    exit;
}
assert_production_ready();

// ---------------------------------------------------------------------
// Everything below this line is plumbing, not configuration.
// ---------------------------------------------------------------------
$GLOBALS['dataDir'] = __DIR__ . '/data'; // used by firewall.php for rate-limit/IP-block storage
require_once __DIR__ . '/firewall.php';
require_once __DIR__ . '/db.php';
