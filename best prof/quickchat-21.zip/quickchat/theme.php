<?php
// theme.php — lets a super user set the ROOM'S wallpaper/background and
// the glow color used for their own messages. This is room-wide and
// visible to everyone in the room — only a super user can change it,
// nobody else can override it locally.

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
$token = isset($body['token']) ? $body['token'] : '';

$session = get_session($token);
if (!$session) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Session expired or invalid. Please rejoin.']);
    exit;
}
if ($session['role'] !== 'super') {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Only a super user can change the room theme.']);
    exit;
}

$room = $session['room'];
$config = read_config($room);
if (!$config) $config = default_config();

function clean_css_value($val) {
    $val = trim((string)$val);
    $val = str_ireplace(['javascript:', '<', '>', '{', '}', ';'], '', $val);
    // Plain image URLs get auto-wrapped into a full CSS background value.
    if (preg_match('#^https?://#i', $val)) {
        $val = "url('" . str_replace("'", '%27', $val) . "') center/cover no-repeat fixed";
    }
    return mb_substr($val, 0, 400);
}

if (array_key_exists('background', $body)) {
    $config['roomTheme']['background'] = clean_css_value($body['background']);
}
if (array_key_exists('glowColor', $body)) {
    $config['roomTheme']['glowColor'] = clean_css_value($body['glowColor']);
}

write_config($room, $config);

echo json_encode(['ok' => true, 'roomTheme' => $config['roomTheme']]);
