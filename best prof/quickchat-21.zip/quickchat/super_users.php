<?php
// super_users.php — accounts for the "Super User" login.
//
// Super users can:
//   - Log into ANY room from the Super Login tab (no PIN needed)
//   - Upload any file type (only a small server-safety blocklist applies —
//     see the $dangerousExtensions list in upload.php)
//   - Change the room's background theme and their own message glow color
//   - Their messages always show a special glowing border in chat
//
// SECURITY NOTE: passwords below are stored in plain text for
// simplicity. Anyone with server file access could read them. Don't
// reuse these passwords anywhere else, and keep this file safe.
//
// FORMAT: 'username' => ['password', 'DefaultDisplayName']
// The display name is used in chat if the person doesn't type a
// custom one on the Super Login screen.

return [
    'xbot' => ['#123xbot', '09'],

    // ---- Add more super users below by copying this format ----
    // 'anotherUsername' => ['anotherPassword', 'DisplayName'],
    // 'thirdUsername'   => ['thirdPassword', 'DisplayName2'],
];
