<?php
// rooms.php — lists every room that exists (running or past) for the
// super-user room browser. Requires a valid super "master" token
// (issued by auth.php action=super_login).

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$masterToken = isset($_GET['masterToken']) ? $_GET['masterToken'] : '';
$master = get_session($masterToken);

if (!$master || $master['role'] !== 'super_master') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Your super login expired. Please log in again.']);
    exit;
}

echo json_encode(['ok' => true, 'rooms' => list_rooms()]);
