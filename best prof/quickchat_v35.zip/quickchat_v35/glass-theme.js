/**
 * Quick Chat v35 — glass-theme.js
 *
 * Glass UI theme system.
 * Persists the selected theme (Nocturne / Aurora / Ember / Frost / Default)
 * via localStorage. The theme-switch control lives inside the hamburger
 * drawer (☰) — NOT floating at the top of any page.
 *
 * Loaded at the end of <body> so DOM is guaranteed ready.
 */

(function initGlassTheme() {
  'use strict';

  const STORAGE_KEY = 'qc_glass_theme';
  const LIGHT_KEY   = 'qc_light_mode';

  /**
   * Apply a glass theme palette (or revert to default dark/light).
   * @param {string} theme  One of: 'nocturne' | 'aurora' | 'ember' | 'frost' | ''
   */
  function applyGlassTheme(theme) {
    if (theme) {
      document.body.setAttribute('data-theme', theme);
      // Glass palette is the sole colour authority — suppress dark/light class
      document.body.classList.remove('light-mode');
    } else {
      document.body.removeAttribute('data-theme');
      // Restore the user's saved dark / light preference
      if (localStorage.getItem(LIGHT_KEY) === '1') {
        document.body.classList.add('light-mode');
      }
    }

    localStorage.setItem(STORAGE_KEY, theme || '');
    syncButtons(theme || '');
  }

  /**
   * Mark the matching pill as active, clear the rest.
   * @param {string} active  The active theme key (may be '').
   */
  function syncButtons(active) {
    document.querySelectorAll('.glass-theme-btn').forEach(function (btn) {
      var match = (btn.dataset.theme || '') === active;
      btn.classList.toggle('active', match);
      btn.setAttribute('aria-selected', match ? 'true' : 'false');
    });
  }

  // -----------------------------------------------------------------
  // Event delegation — works even if the drawer hasn't been opened yet
  // -----------------------------------------------------------------
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('.glass-theme-btn');
    if (!btn) return;
    applyGlassTheme(btn.dataset.theme || '');
  });

  // -----------------------------------------------------------------
  // Restore on page load
  // -----------------------------------------------------------------
  var saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    // Saved glass theme — apply immediately (avoids flash of default colours)
    applyGlassTheme(saved);
  } else {
    // No glass theme: sync buttons to show 'Default' as active
    syncButtons('');
  }

})();
