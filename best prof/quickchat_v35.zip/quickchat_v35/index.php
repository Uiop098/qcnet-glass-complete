<?php
/**
 * Quick Chat v35 — index.php
 *
 * Main entry point. Serves the single-page chat application.
 * Glass UI styling lives in glass-theme.css.
 * Glass theme-switching logic lives in glass-theme.js.
 *
 * The theme-switch control (Nocturne / Aurora / Ember / Frost / Default)
 * is accessible via the hamburger menu (☰) — NOT placed at the top of
 * any page, which would obscure content and be visually intrusive.
 */

// Cache-bust asset URLs on each new deploy.
// Bump this string when you update glass-theme.css or glass-theme.js.
define('ASSET_VER', '35.0');

// Send basic security headers before any output.
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: same-origin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
<title>Quick Chat</title>

<!-- Glass UI fonts: Sora (display) · Inter (body) · JetBrains Mono (labels/code) -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700;800&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

<!-- All styles: v34 base + Glass UI theme system -->
<link rel="stylesheet" href="glass-theme.css?v=<?= ASSET_VER ?>">
</head>

</head>
<body>

<!-- Glass UI ambient blobs (hidden when no glass theme is active) -->
<div class="glass-blob" style="top:-10%; left:-10%;"></div>
<div class="glass-blob b2"></div>

<div id="loadingBar"></div>

<div id="setup">
  <h2>Quick Chat</h2>
  <p class="sub">Join as a member, host, or super user.</p>

  <div class="login-card" id="loginCard">
    <div class="tabs">
      <button class="tab-btn active" data-tab="member">Join Chat</button>
      <button class="tab-btn" data-tab="host">Host Login</button>
      <button class="tab-btn super-tab" data-tab="super">✨ Super Login</button>
    </div>

    <!-- MEMBER JOIN -->
    <div class="form-panel active" id="panel-member">
      <input id="memberRoom" placeholder="Room name (e.g. raj-room-1)" />
      <input id="memberPin" placeholder="Room PIN" inputmode="numeric" />
      <input id="memberName" placeholder="Your name" />
      <input id="memberEncKey" type="password" placeholder="Encryption key (only if this room uses one)" />
      <label class="hint" style="display:flex;align-items:center;gap:6px;cursor:pointer;">
        <input type="checkbox" id="memberRemember" /> Remember me on this device
      </label>
      <button class="action-btn" id="memberJoinBtn">Join Chat</button>
      <div class="hint">Ask the host for the room name and PIN. If the room is encrypted, ask for that key too — otherwise leave it blank.</div>
      <div class="error-text" id="memberError"></div>
    </div>

    <!-- HOST LOGIN -->
    <div class="form-panel" id="panel-host">
      <input id="hostRoom" placeholder="Room name" />
      <input id="hostPassword" type="password" placeholder="Host password" />
      <div class="capslock-warning" id="hostCapsWarning">⚠ Caps Lock is on</div>
      <input id="hostNewPin" placeholder="Set / change room PIN (optional)" inputmode="numeric" />
      <input id="hostEncKey" type="password" placeholder="Encryption key (only if this room uses one)" />
      <label class="hint" style="display:flex;align-items:center;gap:6px;cursor:pointer;">
        <input type="checkbox" id="hostRemember" /> Remember me on this device
      </label>
      <button class="action-btn" id="hostLoginBtn">Login as Host</button>
      <div class="hint">First login for a new room sets this as the host password. Being host doesn't automatically give you the encryption key — enter it above if you know it, or unlock it later from the chat.</div>
      <div class="error-text" id="hostError"></div>
    </div>

    <!-- SUPER LOGIN (step 1) -->
    <div class="form-panel" id="panel-super">
      <div class="premium-badge">👑 Premium Access</div>
      <h3>Super Access</h3>
      <div class="sub">Elevated controls across every room.</div>
      <input id="superUsername" placeholder="Super username" />
      <input id="superPassword" type="password" placeholder="Super password" />
      <div class="capslock-warning" id="superCapsWarning">⚠ Caps Lock is on</div>
      <button class="action-btn" id="superLoginBtn">Login</button>
      <div class="error-text" id="superError"></div>
    </div>
  </div>

  <!-- SUPER ROOM BROWSER (step 2) -->
  <div id="roomBrowser" style="display:none">
    <h3>🗂️ Rooms</h3>
    <div id="roomList"></div>
    <div id="createRoomBlock">
      <div class="hint" style="margin-top:0">Create / join a new room</div>
      <input id="newRoomName" placeholder="New room name" />
      <input id="superDisplayName" placeholder="Display name (optional)" />
      <input id="superEncKey" type="password" placeholder="Encryption key (only if the room you're joining uses one)" />
      <div class="row-inline">
        <button id="createRoomSuperBtn">Join as Super</button>
        <button id="createRoomHostBtn">Join as Host (anon)</button>
      </div>
    </div>
  </div>
</div>

<div id="chat-wrap">
  <header>
    <div>
      <div class="title" id="roomTitle"></div>
      <div class="me" id="meLabel"></div>
    </div>
    <div class="btns">
      <button class="hdr-btn" id="leaveBtn">Leave</button>
      <button class="hdr-btn" id="menuBtn" aria-label="Menu">☰</button>
    </div>
  </header>

  <div id="menuOverlay"></div>
  <div id="menuDrawer">
    <div class="menu-header">
      <span>Menu</span>
      <button id="menuCloseBtn" aria-label="Close menu">✕</button>
    </div>

    <div class="menu-section">
      <button class="menu-item" id="refreshMenuBtn"><span id="refreshIcon">🔄</span> Refresh chat</button>
      <button class="menu-item" id="themeToggleBtn">🌓 Toggle light / dark</button>
      <button class="menu-item" id="encKeyBtn" style="display:none">🔒 Encryption key</button>
      <button class="menu-item" id="manageBtn" style="display:none">⚙️ Manage room</button>
      <button class="menu-item" id="themeBtn" style="display:none">🎨 Room theme</button>
      <button class="menu-item" id="clearBtn" style="display:none">🗑️ Clear chat</button>
    </div>

    <div class="menu-section">
      <div class="menu-label">View</div>
      <div class="view-toggle" id="viewModeToggle">
        <button class="view-opt active" data-view="auto">Auto</button>
        <button class="view-opt" data-view="desktop">Desktop</button>
        <button class="view-opt" data-view="mobile">Mobile</button>
      </div>
      <label class="menu-check">
        <input type="checkbox" id="compactModeToggle" /> Compact message spacing
      </label>
    </div>

    <div class="menu-section">
      <div class="menu-label">UI Theme</div>
      <div class="glass-theme-switch" role="tablist" aria-label="UI colour theme">
        <div class="theme-pill-row">
          <button class="glass-theme-btn" data-theme="nocturne" style="--dot:#8b5cf6" role="tab" aria-selected="false">
            <span class="dot"></span>Nocturne
          </button>
          <button class="glass-theme-btn" data-theme="aurora" style="--dot:#2dd4bf" role="tab" aria-selected="false">
            <span class="dot"></span>Aurora
          </button>
        </div>
        <div class="theme-pill-row">
          <button class="glass-theme-btn" data-theme="ember" style="--dot:#ff8a4c" role="tab" aria-selected="false">
            <span class="dot"></span>Ember
          </button>
          <button class="glass-theme-btn" data-theme="frost" style="--dot:#2f6fd6" role="tab" aria-selected="false">
            <span class="dot"></span>Frost
          </button>
        </div>
        <div class="theme-pill-row">
          <button class="glass-theme-btn" data-theme="" role="tab" aria-selected="false" style="--dot:#9aa0a6; flex:1;">
            <span class="dot"></span>Default (dark/light)
          </button>
        </div>
      </div>
    </div>
  </div>

  <div id="pinnedBar" style="display:none"></div>
  <div id="mutedBanner"></div>
  <div id="encKeyBar">
    <span>🔒 This room is encrypted.</span>
    <input id="encKeyInput" type="password" placeholder="Enter the room's encryption key" />
    <button id="encKeyUnlockBtn">Unlock</button>
    <button id="encKeyDismissBtn">✕</button>
  </div>

  <div id="panels">
    <div class="panel-block" id="titleBlock" style="display:none">
      <h4>Room title</h4>
      <input id="titleInput" placeholder="e.g. 🎮 Game Night" />
      <button class="full-btn" id="saveTitleBtn">Save title</button>
    </div>

    <div class="panel-block" id="presenceBlock" style="display:none">
      <h4>People in this room</h4>
      <div id="presenceList"></div>
    </div>

    <div class="panel-block" id="bannedBlock" style="display:none">
      <h4>Banned users</h4>
      <div id="bannedList"></div>
      <h4 style="margin-top:12px">Blocked IPs (this room)</h4>
      <div id="bannedIpList"></div>
    </div>

    <div class="panel-block" id="fileReqBlock" style="display:none">
      <h4>📨 Member file uploads</h4>
      <div class="toggle-row">
        <span class="toggle-label">Require approval before sending</span>
        <label class="toggle-switch">
          <input type="checkbox" id="fileApprovalToggle">
          <span class="slider"></span>
        </label>
      </div>
      <div id="fileReqList" style="margin-top:8px"></div>
    </div>

    <div class="panel-block" id="extraUploadsBlock" style="display:none">
      <h4>📎 Extended file uploads</h4>
      <div class="hint" id="extraUploadsStatus" style="margin-top:0">Checking status…</div>
      <div class="toggle-row">
        <span class="toggle-label">Enabled</span>
        <label class="toggle-switch">
          <input type="checkbox" id="extraUploadsToggle">
          <span class="slider"></span>
        </label>
      </div>
      <label class="menu-check">
        <input type="checkbox" id="extraUploadsAllowAll" /> Allow all extra types below (except server-executable types, still always blocked)
      </label>
      <div class="preset-row" id="extraUploadsExtList"></div>
      <div class="row-inline" style="margin-top:8px">
        <input id="extraUploadsMinutes" type="number" min="0" step="1" placeholder="Minutes (0 = no timer)" style="width:160px" />
        <button class="full-btn" id="extraUploadsSaveBtn">Save</button>
      </div>
      <div class="hint" style="margin-top:6px" id="extraUploadsHint">
        Lets hosts and members upload the extra file types checked above,
        on top of the normal allowed list — server-executable types like
        .php/.exe stay blocked regardless. Optional timer auto-turns this
        off after N minutes; leave at 0 to keep it on until a super user
        turns it off here. Super only.
      </div>
    </div>

    <div class="panel-block" id="hostResetBlock" style="display:none">
      <h4>Host control</h4>
      <button class="full-btn danger-btn" id="resetHostBtn">Reset host password</button>
      <div class="hint" style="margin-top:6px">Clears the current host password — the next host login sets a new one.</div>
    </div>

    <div class="panel-block" id="exportBlock" style="display:none">
      <h4>⬇️ Export chat history</h4>
      <div class="export-row">
        <button class="full-btn" id="exportTxtBtn">.txt</button>
        <button class="full-btn" id="exportJsonBtn">.json</button>
      </div>
      <div class="hint" style="margin-top:6px">
        Encrypted messages export as their locked ciphertext, not plain text.
      </div>
    </div>

    <div class="panel-block" id="encAdminBlock" style="display:none">
      <h4>🔒 End-to-end message encryption</h4>
      <div class="hint" style="margin-top:0" id="encStatusText">Checking status…</div>
      <input id="encKeySetInput" type="password" placeholder="New encryption key" />
      <div class="row-inline">
        <button id="encEnableBtn">Enable / set key</button>
        <button id="encDisableBtn" class="danger-btn">Disable</button>
      </div>
      <div class="hint" style="margin-top:6px">
        This is a separate secret from the room PIN. Only message text is
        encrypted; files are not. Changing the key makes older encrypted
        messages unreadable.
        The server always keeps a copy of this key that a verified
        super-user session can recover — super users have permanent,
        automatic read access to this room's messages and there is no
        way to turn that off. Everyone else (members, host) still needs
        the actual key to read message text.
      </div>
    </div>

    <div class="panel-block" id="themeBlock" style="display:none">
      <h4>🎭 App style — applies to everyone here</h4>
      <select id="uiSkinSelect"></select>
      <div class="hint" style="margin-top:4px">Changes bubble shapes, buttons, and effects for the whole room. "Default" leaves everyone's own dark/light choice as-is.</div>

      <h4 style="margin-top:14px">🖼️ Room wallpaper — applies to everyone here</h4>
      <input id="themeColorInput" type="color" value="#0f1115" />
      <input id="themeUrlInput" placeholder="or paste an image URL" />
      <div class="row-inline">
        <button id="applyColorBtn">Use color</button>
        <button id="applyUrlBtn">Use URL</button>
      </div>
      <input type="file" id="wallpaperFileInput" accept="image/*" style="display:none" />
      <button class="full-btn" id="uploadWallpaperBtn">Upload image from device</button>
      <div class="preset-row" id="presetSwatches"></div>
      <div class="preset-row" id="presetWallpapers"></div>
      <button class="full-btn" id="resetWallpaperBtn" style="background:#3a2a5c">Reset room wallpaper</button>

      <h4 style="margin-top:14px">✨ Your premium message glow</h4>
      <input id="glowColorInput" type="color" value="#d4af37" />
      <button class="full-btn" id="applyGlowBtn">Set my glow color</button>
      <div class="hint" style="margin-top:4px">Leave unset for the default animated rainbow glow.</div>
    </div>
  </div>

  <div id="typingIndicator"></div>
  <div id="messages"></div>
  <div id="uploadProgress" class="transfer-bar">
    <div class="transfer-label"><span id="uploadProgressLabel">Uploading…</span><span id="uploadProgressPct">0%</span></div>
    <div class="transfer-track"><div class="transfer-fill" id="uploadProgressFill"></div></div>
  </div>
  <div id="downloadProgress" class="transfer-bar">
    <div class="transfer-label"><span id="downloadProgressLabel">Downloading…</span><span id="downloadProgressPct">0%</span></div>
    <div class="transfer-track"><div class="transfer-fill" id="downloadProgressFill"></div></div>
  </div>
  <div id="status"></div>
  <div id="replyPreview" style="display:none"></div>
  <div id="voiceRecordBar">
    <span class="rec-dot"></span>
    <span>Recording voice message…</span>
    <span class="rec-time" id="voiceRecTime">0:00</span>
    <button id="voiceCancelBtn">Cancel</button>
    <button id="voiceStopBtn">■ Stop &amp; send</button>
  </div>
  <div id="input-row">
    <button id="attachBtn" title="Attach file">📎</button>
    <input type="file" id="fileInput" style="display:none"
      accept=".jpg,.jpeg,.png,.gif,.webp,.svg,.bmp,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.rtf,.mp3,.wav,.ogg,.m4a,.aac,.mp4,.webm,.mov,.mkv,.avi,.zip,.rar,.7z" />
    <button id="voiceBtn" title="Record a voice message">🎤</button>
    <textarea id="textInput" placeholder="Type a message, paste code, or try /help… (Enter = new line, tap Send to send)" rows="1"></textarea>
    <button id="sendBtn">Send</button>
  </div>
</div>

<script>
const API_URL = 'api.php';
const UPLOAD_URL = 'upload.php';
const AUTH_URL = 'auth.php';
const KICK_URL = 'kick.php';
const MUTE_URL = 'mute.php';
const ADMIN_URL = 'admin.php';
const ROOMS_URL = 'rooms.php';
const EDIT_URL = 'edit.php';
const READ_URL = 'read.php';
const LINKPREVIEW_URL = 'linkpreview.php';
const EXPORT_URL = 'export.php';
const DOWNLOAD_URL = 'download.php';
const POLL_INTERVAL_MS = 2000;

let room = "", me = "", role = "", token = "";
let masterToken = "";
let pollTimer = null;
let typingPollTimer = null;
let lastId = 0;
let renderedIds = new Set(); // guards against duplicate rendering
let messageElements = new Map(); // id -> DOM element, for in-place reaction/pin updates
let isMuted = false;
let replyingTo = null; // {id, user, text}
let unreadCount = 0;
let originalTitle = document.title;

// ---------- Encryption state (all client-side; server only ever sees ciphertext + a non-secret salt) ----------
const ENC_PREFIX = 'encv1:';
let roomEncEnabled = false;
let roomEncSalt = null;
let roomEncKey = null;       // CryptoKey, in-memory only
let encPromptShown = false;  // only auto-show the unlock bar once per room-enter

let latestReadReceipts = []; // [{user, lastReadId}] from the last fetchAll/poll
let lastReportedReadId = 0;  // highest id we've told the server we've read
const linkPreviewCache = new Map(); // url -> preview object (or null), avoids refetching
const linkPreviewRequested = new Set(); // msgId set, avoids duplicate in-flight requests

let mediaRecorder = null;
let recordedChunks = [];
let recordingStartMs = 0;
let recordingTimer = null;
let recordingStream = null;

const setupEl = document.getElementById('setup');
const chatWrap = document.getElementById('chat-wrap');
const messagesEl = document.getElementById('messages');
const roomTitleEl = document.getElementById('roomTitle');
const meLabel = document.getElementById('meLabel');
const statusEl = document.getElementById('status');
const uploadProgressEl = document.getElementById('uploadProgress');
const uploadProgressLabelEl = document.getElementById('uploadProgressLabel');
const uploadProgressPctEl = document.getElementById('uploadProgressPct');
const uploadProgressFillEl = document.getElementById('uploadProgressFill');
const downloadProgressEl = document.getElementById('downloadProgress');
const downloadProgressLabelEl = document.getElementById('downloadProgressLabel');
const downloadProgressPctEl = document.getElementById('downloadProgressPct');
const downloadProgressFillEl = document.getElementById('downloadProgressFill');
const fileInput = document.getElementById('fileInput');
const panelsEl = document.getElementById('panels');
const presenceBlock = document.getElementById('presenceBlock');
const presenceList = document.getElementById('presenceList');
const bannedBlock = document.getElementById('bannedBlock');
const bannedList = document.getElementById('bannedList');
const bannedIpList = document.getElementById('bannedIpList');
const fileReqBlock = document.getElementById('fileReqBlock');
const fileReqList = document.getElementById('fileReqList');
const fileApprovalToggle = document.getElementById('fileApprovalToggle');
const extraUploadsBlock = document.getElementById('extraUploadsBlock');
const extraUploadsStatus = document.getElementById('extraUploadsStatus');
const extraUploadsToggle = document.getElementById('extraUploadsToggle');
const extraUploadsAllowAll = document.getElementById('extraUploadsAllowAll');
const extraUploadsExtList = document.getElementById('extraUploadsExtList');
const extraUploadsMinutes = document.getElementById('extraUploadsMinutes');
const extraUploadsSaveBtn = document.getElementById('extraUploadsSaveBtn');
const extraUploadsHint = document.getElementById('extraUploadsHint');
// Keep this list in sync with extra_upload_catalog() in common.php.
const EXTRA_UPLOAD_CATALOG = [
  'psd', 'ai', 'eps', 'indd',
  'apk', 'ipa', 'dmg', 'iso', 'deb', 'rpm',
  'epub', 'mobi',
  'ttf', 'otf', 'woff', 'woff2',
  'torrent', 'sqlite', 'dwg', 'blend',
];
let extraUploadsState = { enabled: false, expiresAt: 0, allowAll: false, extensions: [] };
const hostResetBlock = document.getElementById('hostResetBlock');
const themeBlock = document.getElementById('themeBlock');
const titleBlock = document.getElementById('titleBlock');
const mutedBanner = document.getElementById('mutedBanner');
const roomBrowser = document.getElementById('roomBrowser');
const roomList = document.getElementById('roomList');
const encAdminBlock = document.getElementById('encAdminBlock');
const encKeyBar = document.getElementById('encKeyBar');
const encKeyBtn = document.getElementById('encKeyBtn');
const exportBlock = document.getElementById('exportBlock');
const voiceBtn = document.getElementById('voiceBtn');
const voiceRecordBar = document.getElementById('voiceRecordBar');
const voiceRecTime = document.getElementById('voiceRecTime');

// ---------- Hamburger menu drawer ----------
const menuBtn = document.getElementById('menuBtn');
const menuDrawer = document.getElementById('menuDrawer');
const menuOverlay = document.getElementById('menuOverlay');
function openMenu() { menuDrawer.classList.add('open'); menuOverlay.classList.add('open'); }
function closeMenu() { menuDrawer.classList.remove('open'); menuOverlay.classList.remove('open'); }
menuBtn.addEventListener('click', openMenu);
document.getElementById('menuCloseBtn').addEventListener('click', closeMenu);
menuOverlay.addEventListener('click', closeMenu);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });

document.getElementById('refreshMenuBtn').addEventListener('click', async () => {
  const icon = document.getElementById('refreshIcon');
  icon.classList.add('spin');
  await fetchAll();
  icon.classList.remove('spin');
});

// ---------- Desktop / mobile view detection (with manual override) ----------
function applyViewMode() {
  const stored = localStorage.getItem('qc_view_mode') || 'auto';
  const mode = stored === 'auto' ? (window.innerWidth >= 900 ? 'desktop' : 'mobile') : stored;
  document.body.classList.toggle('desktop-view', mode === 'desktop');
  document.body.classList.toggle('mobile-view', mode === 'mobile');
}
document.querySelectorAll('.view-opt').forEach(btn => {
  if (btn.dataset.view === (localStorage.getItem('qc_view_mode') || 'auto')) {
    document.querySelectorAll('.view-opt').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  }
  btn.addEventListener('click', () => {
    document.querySelectorAll('.view-opt').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    localStorage.setItem('qc_view_mode', btn.dataset.view);
    applyViewMode();
  });
});
window.addEventListener('resize', () => {
  if ((localStorage.getItem('qc_view_mode') || 'auto') === 'auto') applyViewMode();
});
applyViewMode();

// ---------- Compact message spacing ----------
const compactModeToggle = document.getElementById('compactModeToggle');
compactModeToggle.checked = localStorage.getItem('qc_compact') === '1';
document.body.classList.toggle('compact-mode', compactModeToggle.checked);
compactModeToggle.addEventListener('change', () => {
  document.body.classList.toggle('compact-mode', compactModeToggle.checked);
  localStorage.setItem('qc_compact', compactModeToggle.checked ? '1' : '0');
});

// ---------- Encryption helpers (Web Crypto: PBKDF2 -> AES-256-GCM) ----------
function bufToB64(buf) {
  const bytes = new Uint8Array(buf);
  let binary = '';
  const chunkSize = 0x8000; // avoid "too many arguments" on large buffers
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}
function b64ToBuf(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}
async function deriveRoomKey(passphrase, saltB64) {
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey('raw', enc.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: b64ToBuf(saltB64), iterations: 150000, hash: 'SHA-256' },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}
async function encryptText(key, plaintext) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const enc = new TextEncoder();
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(plaintext));
  return ENC_PREFIX + bufToB64(iv) + ':' + bufToB64(ct);
}
async function decryptText(key, envelope) {
  const parts = envelope.slice(ENC_PREFIX.length).split(':');
  if (parts.length !== 2) throw new Error('bad envelope');
  const iv = b64ToBuf(parts[0]);
  const ct = b64ToBuf(parts[1]);
  const plainBuf = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ct);
  return new TextDecoder().decode(plainBuf);
}
function isEncryptedEnvelope(text) {
  return typeof text === 'string' && text.indexOf(ENC_PREFIX) === 0;
}
function encKeyCacheName() { return 'qc_enckey_' + room; }
function cacheRoomPassphrase(passphrase) {
  try { sessionStorage.setItem(encKeyCacheName(), passphrase); } catch (e) { /* ignore */ }
}
function getCachedRoomPassphrase() {
  try { return sessionStorage.getItem(encKeyCacheName()); } catch (e) { return null; }
}
function clearCachedRoomPassphrase() {
  try { sessionStorage.removeItem(encKeyCacheName()); } catch (e) { /* ignore */ }
}

// Decrypts a message's text (and its reply-to snippet, if any) in place.
// Leaves plain text untouched. On missing/wrong key or a corrupt/truncated
// envelope, replaces the text with a locked placeholder instead of throwing.
async function decorateMessageText(m) {
  if (!m) return m;
  if (isEncryptedEnvelope(m.text)) {
    if (roomEncKey) {
      try {
        m.text = await decryptText(roomEncKey, m.text);
      } catch (e) {
        m.text = '🔒 Encrypted message';
        m._locked = true;
      }
    } else {
      m.text = '🔒 Encrypted message';
      m._locked = true;
    }
  }
  if (m.replyTo && isEncryptedEnvelope(m.replyTo.text)) {
    if (roomEncKey) {
      try {
        m.replyTo.text = await decryptText(roomEncKey, m.replyTo.text);
      } catch (e) {
        m.replyTo.text = '🔒 Encrypted message';
      }
    } else {
      m.replyTo.text = '🔒 Encrypted message';
    }
  }
  return m;
}

function updateEncKeyBtn() {
  if (!roomEncEnabled) { encKeyBtn.style.display = 'none'; return; }
  encKeyBtn.style.display = 'flex';
  encKeyBtn.textContent = roomEncKey ? '🔓 Key' : '🔒 Key';
}

function updateEncAdminUi() {
  const statusEl2 = document.getElementById('encStatusText');
  if (!statusEl2) return;
  statusEl2.textContent = roomEncEnabled
    ? '🔒 Encryption is ON for this room.'
    : '🔓 Encryption is OFF — messages are stored as plain text.';
  document.getElementById('encDisableBtn').style.display = roomEncEnabled ? 'inline-block' : 'none';
}

// Applies encEnabled/encSalt from a fetchAll/poll response. For a super
// user, tries the server-auto-recovered passphrase first (no prompt at
// all). Otherwise tries a cached passphrase silently, and — only the
// first time per room-enter — shows the unlock bar if still locked.
async function syncEncryptionState(encEnabled, encSalt, superRecoveredKey) {
  roomEncEnabled = !!encEnabled;
  roomEncSalt = encSalt || null;

  if (!roomEncEnabled) {
    roomEncKey = null;
    encKeyBar.style.display = 'none';
    updateEncKeyBtn();
    return;
  }

  if (!roomEncKey && superRecoveredKey) {
    try {
      roomEncKey = await deriveRoomKey(superRecoveredKey, roomEncSalt);
      cacheRoomPassphrase(superRecoveredKey);
      encPromptShown = true; // never nag a super user who was auto-unlocked
    } catch (e) { /* ignore, fall through to normal flow below */ }
  }

  if (!roomEncKey) {
    const cached = getCachedRoomPassphrase();
    if (cached) {
      try { roomEncKey = await deriveRoomKey(cached, roomEncSalt); } catch (e) { /* ignore */ }
    }
  }

  updateEncKeyBtn();
  if (!roomEncKey && !encPromptShown) {
    encPromptShown = true;
    encKeyBar.style.display = 'flex';
  }
}

document.getElementById('encKeyUnlockBtn').addEventListener('click', async () => {
  const pass = document.getElementById('encKeyInput').value;
  if (!pass) return;
  try {
    roomEncKey = await deriveRoomKey(pass, roomEncSalt);
    cacheRoomPassphrase(pass);
    document.getElementById('encKeyInput').value = '';
    encKeyBar.style.display = 'none';
    updateEncKeyBtn();
    await fetchAll(); // re-render with the new key applied
  } catch (e) {
    alert('Could not unlock with that key.');
  }
});
document.getElementById('encKeyDismissBtn').addEventListener('click', () => {
  encKeyBar.style.display = 'none';
});
encKeyBtn.addEventListener('click', () => {
  closeMenu();
  encKeyBar.style.display = encKeyBar.style.display === 'none' ? 'flex' : 'none';
});

// ---------- Tabs ----------
// Caps Lock warning on password fields (from the friendly-login template).
function wireCapsLockWarning(inputId, warningId) {
  const input = document.getElementById(inputId);
  const warning = document.getElementById(warningId);
  if (!input || !warning) return;
  const check = (e) => {
    const on = e.getModifierState && e.getModifierState('CapsLock');
    warning.classList.toggle('show', !!on);
  };
  input.addEventListener('keyup', check);
  input.addEventListener('keydown', check);
  input.addEventListener('blur', () => warning.classList.remove('show'));
}
wireCapsLockWarning('hostPassword', 'hostCapsWarning');
wireCapsLockWarning('superPassword', 'superCapsWarning');

document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.form-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('panel-' + btn.dataset.tab).classList.add('active');
    roomBrowser.style.display = 'none';
    setupEl.classList.toggle('tab-super', btn.dataset.tab === 'super');
  });
});

function setStatus(text) { statusEl.textContent = text; }
function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}
// Chat files no longer have a working direct URL (files/ is locked
// down server-side) — every <img>/<audio>/<video> src and every
// download link has to go through download.php with the current
// session attached. rawFileUrl is exactly the message's stored
// fileUrl (e.g. "files/abc12/name.ext"); forceDownload=true always
// prompts a save dialog instead of rendering inline.
function chatFileUrl(rawFileUrl, originalName, forceDownload) {
  const params = new URLSearchParams({ token, room, path: rawFileUrl });
  if (originalName) params.set('name', originalName);
  if (forceDownload) params.set('download', '1');
  return `${DOWNLOAD_URL}?${params.toString()}`;
}
// Cosmetic only: labels a file as sent while the room's encryption
// toggle was on. The file's own bytes are never encrypted — only
// message text is (see MESSAGE ENCRYPTION in README) — so the wording
// and tooltip here deliberately say "sent in an encrypted room" rather
// than "encrypted file", to avoid implying a protection the file
// doesn't actually have.
function makeEncBadge(m) {
  if (!m.sentWhileEncrypted) return null;
  const badge = document.createElement('div');
  badge.className = 'enc-badge';
  badge.textContent = '🔒 sent in encrypted room';
  badge.title = 'This room\'s encryption was on when this file was sent. Only message text is actually encrypted — the file itself is not.';
  return badge;
}
function iconForCategory(cat, ext) {
  if (cat === 'file') {
    if (['zip','rar','7z'].includes(ext)) return '🗜️';
    if (ext === 'pdf') return '📕';
    if (['doc','docx'].includes(ext)) return '📄';
    if (['xls','xlsx','csv'].includes(ext)) return '📊';
    if (['ppt','pptx'].includes(ext)) return '📽️';
    return '📁';
  }
  if (cat === 'code') {
    if (['html','htm'].includes(ext)) return '🌐';
    if (['css','scss'].includes(ext)) return '🎨';
    if (['js','ts','jsx','tsx'].includes(ext)) return '📜';
    if (['json','xml','yml','yaml'].includes(ext)) return '🗂️';
    if (ext === 'md') return '📝';
    if (ext === 'sql') return '🗄️';
    if (['txt','log'].includes(ext)) return '📄';
    return '💻';
  }
  return '📁';
}
function formatDate(ms) {
  if (!ms) return '—';
  const d = new Date(ms);
  return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
}

// ---------- Theme: dark/light is personal & local; wallpaper + glow are room-wide, super-controlled ----------
const THEME_PRESETS = [
  { name: 'Midnight', bg: '#0f1115' },
  { name: 'Ocean', bg: '#0b2038' },
  { name: 'Forest', bg: '#0e2418' },
  { name: 'Plum', bg: '#1a1030' },
  { name: 'Rose', bg: '#2a0f1c' },
  { name: 'Slate', bg: '#1c1f26' },
];
const WALLPAPER_PRESETS = [
  { name: 'Aurora', css: "linear-gradient(135deg, #0f1115, #1a1030, #0b2038)" },
  { name: 'Sunset', css: "linear-gradient(135deg, #2a0f1c, #4a1f24, #2a1f0f)" },
  { name: 'Emerald', css: "linear-gradient(135deg, #0e2418, #0b2038)" },
  { name: 'Gold', css: "linear-gradient(135deg, #1a1030, #3a2a10)" },
];

// 11 UI "skins" — a super user can apply one room-wide. Palettes are
// carried over from the ui-templates theme set (skeuomorphism,
// minimalism, flat-design, bauhaus, bold-typography, neumorphism,
// glassmorphism, motion, illustration, dark-mode, monochromatic),
// re-mapped onto this app's existing CSS variables (--bg/--panel/
// --panel2/--border/--text/--muted/--accent) so no markup changes are
// needed — only the variable values (and a body class for skin-specific
// extras like blur/shadow/animation) change.
const UI_SKINS = {
  skeuomorphism: { vars: { '--bg':'#d9cdb8','--panel':'#efe6d6','--panel2':'#e2d5bd','--border':'#b8a887','--text':'#3b2f22','--muted':'#8a7a63','--accent':'#7a4d2e' }, radius: '16px' },
  minimalism: { vars: { '--bg':'#ffffff','--panel':'#ffffff','--panel2':'#fafafa','--border':'#ececec','--text':'#111111','--muted':'#9a9a9a','--accent':'#111111' }, radius: '2px' },
  flat: { vars: { '--bg':'#ecf0f1','--panel':'#2c3e50','--panel2':'#ffffff','--border':'#dfe6e9','--text':'#2c3e50','--muted':'#7f8c8d','--accent':'#2980b9' }, radius: '6px' },
  bauhaus: { vars: { '--bg':'#f5f2ea','--panel':'#ffffff','--panel2':'#f5f2ea','--border':'#101010','--text':'#101010','--muted':'#555555','--accent':'#d6372c' }, radius: '0px' },
  bold: { vars: { '--bg':'#fafafa','--panel':'#ffffff','--panel2':'#f0f0f0','--border':'#e5e5e5','--text':'#0a0a0a','--muted':'#a0a0a0','--accent':'#0a0a0a' }, radius: '4px' },
  neumorphism: { vars: { '--bg':'#e3e8ee','--panel':'#e3e8ee','--panel2':'#e3e8ee','--border':'#e3e8ee','--text':'#33404e','--muted':'#8b98a8','--accent':'#5b6b7c' }, radius: '20px' },
  glassmorphism: { vars: { '--bg':'#241a3a','--panel':'rgba(255,255,255,0.14)','--panel2':'rgba(255,255,255,0.10)','--border':'rgba(255,255,255,0.35)','--text':'#ffffff','--muted':'rgba(255,255,255,0.7)','--accent':'#6c3bff' }, radius: '22px' },
  motion: { vars: { '--bg':'#14141f','--panel':'#1c1c2b','--panel2':'#23233a','--border':'#2e2e46','--text':'#f2f2fb','--muted':'#9797b3','--accent':'#7f5af0' }, radius: '18px' },
  illustration: { vars: { '--bg':'#fff6ea','--panel':'#fffaf1','--panel2':'#fdf0dc','--border':'#f3ddb8','--text':'#3d2b1f','--muted':'#a08c76','--accent':'#ff8c42' }, radius: '28px' },
  darkmode: { vars: { '--bg':'#0e0e12','--panel':'#17171d','--panel2':'#1f1f27','--border':'#26262f','--text':'#eaeaf0','--muted':'#8b8b98','--accent':'#6c8bff' }, radius: '16px' },
  monochromatic: { vars: { '--bg':'#e8f3f3','--panel':'#f7fdfd','--panel2':'#dcecec','--border':'#c3dbdb','--text':'#0c2727','--muted':'#5c7373','--accent':'#0f5c5c' }, radius: '14px' },
};
const UI_SKIN_LABELS = {
  '': 'Default', skeuomorphism: 'Skeuomorphism', minimalism: 'Minimalism', flat: 'Flat Design',
  bauhaus: 'Bauhaus', bold: 'Bold Typography', neumorphism: 'Neumorphism', glassmorphism: 'Glassmorphism',
  motion: 'Animation / Motion', illustration: 'Illustration', darkmode: 'Dark Mode', monochromatic: 'Monochromatic',
};

let roomGlowColor = ''; // set by the room's theme.glowColor, applied to ALL super messages in this room
let currentUiSkin = '';

function applyUiSkin(skinName) {
  currentUiSkin = skinName || '';
  document.body.classList.forEach(c => { if (c.startsWith('skin-')) document.body.classList.remove(c); });
  // Clear any previously-set skin variables first so switching back to
  // "Default" (or dark/light mode) fully restores the normal palette.
  ['--bg','--panel','--panel2','--border','--text','--muted','--accent'].forEach(v => document.body.style.removeProperty(v));
  document.body.style.removeProperty('--radius-skin');

  const skin = UI_SKINS[currentUiSkin];
  if (!skin) return;
  document.body.classList.add('skin-' + currentUiSkin);
  Object.entries(skin.vars).forEach(([k, v]) => document.body.style.setProperty(k, v));
  if (skin.radius) document.body.style.setProperty('--radius-skin', skin.radius);
}

function applyRoomBackground(value) {
  document.body.style.background = value || '';
  document.body.style.backgroundSize = 'cover';
  document.body.style.backgroundPosition = 'center';
  document.body.style.backgroundAttachment = 'fixed';
}

function applyRoomTheme(theme) {
  if (!theme) return;
  applyRoomBackground(theme.background);
  roomGlowColor = theme.glowColor || '';
  document.querySelectorAll('.super-msg').forEach(applyGlowToElement);
  if ((theme.uiSkin || '') !== currentUiSkin) applyUiSkin(theme.uiSkin || '');
  const sel = document.getElementById('uiSkinSelect');
  if (sel && sel.value !== (theme.uiSkin || '')) sel.value = theme.uiSkin || '';
}

function applyGlowToElement(el) {
  if (roomGlowColor) {
    el.classList.add('custom-glow');
    el.style.setProperty('--glow-color', roomGlowColor);
  } else {
    el.classList.remove('custom-glow');
  }
}

document.getElementById('themeToggleBtn').addEventListener('click', () => {
  // When a glass theme is active, toggle clears it back to default dark/light
  if (document.body.hasAttribute('data-theme')) {
    document.body.removeAttribute('data-theme');
    localStorage.setItem('qc_glass_theme', '');
  }
  document.body.classList.toggle('light-mode');
  localStorage.setItem('qc_light_mode', document.body.classList.contains('light-mode') ? '1' : '0');
});

function renderPresets() {
  const swatchWrap = document.getElementById('presetSwatches');
  const wallWrap = document.getElementById('presetWallpapers');
  swatchWrap.innerHTML = '';
  wallWrap.innerHTML = '';
  THEME_PRESETS.forEach(p => {
    const sw = document.createElement('div');
    sw.className = 'preset-swatch';
    sw.style.background = p.bg;
    sw.title = p.name;
    sw.addEventListener('click', () => setRoomTheme({ background: p.bg }));
    swatchWrap.appendChild(sw);
  });
  WALLPAPER_PRESETS.forEach(p => {
    const sw = document.createElement('div');
    sw.className = 'preset-wallpaper';
    sw.style.background = p.css;
    sw.title = p.name;
    sw.addEventListener('click', () => setRoomTheme({ background: p.css }));
    wallWrap.appendChild(sw);
  });
}

async function setRoomTheme(fields) {
  try {
    const res = await fetch('theme.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, ...fields }),
    });
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (data.ok) applyRoomTheme(data.roomTheme);
    else alert('Failed: ' + (data.error || 'unknown error'));
  } catch (e) { alert('Could not reach server.'); }
}

document.getElementById('applyColorBtn').addEventListener('click', () => {
  setRoomTheme({ background: document.getElementById('themeColorInput').value });
});
document.getElementById('applyUrlBtn').addEventListener('click', () => {
  const url = document.getElementById('themeUrlInput').value.trim();
  if (!url) return;
  setRoomTheme({ background: url });
});
document.getElementById('uploadWallpaperBtn').addEventListener('click', () => {
  document.getElementById('wallpaperFileInput').click();
});
document.getElementById('wallpaperFileInput').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const formData = new FormData();
  formData.append('token', token);
  formData.append('file', file);
  try {
    const res = await fetch('wallpaper_upload.php', { method: 'POST', body: formData });
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (data.ok) applyRoomTheme(data.roomTheme);
    else alert('Upload failed: ' + (data.error || 'unknown error'));
  } catch (e) { alert('Upload failed — check connection.'); }
  fileInputWallpaperReset();
});
function fileInputWallpaperReset() { document.getElementById('wallpaperFileInput').value = ''; }
document.getElementById('resetWallpaperBtn').addEventListener('click', () => setRoomTheme({ background: '' }));
document.getElementById('applyGlowBtn').addEventListener('click', () => {
  setRoomTheme({ glowColor: document.getElementById('glowColorInput').value });
});

// Populate the "App style" dropdown once at load.
(function populateUiSkinSelect() {
  const sel = document.getElementById('uiSkinSelect');
  Object.keys(UI_SKIN_LABELS).forEach(key => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = UI_SKIN_LABELS[key];
    sel.appendChild(opt);
  });
  sel.addEventListener('change', () => setRoomTheme({ uiSkin: sel.value }));
})();

// ---------- Message rendering ----------
// Wraps @mentions in a highlighted span. Only single-token handles are
// matched (letters/digits/._-) since display names may contain spaces
// and we can't tell where a mention "ends" otherwise — the common case
// for @mentions in every major chat app is a single-token handle anyway.
function renderMentionHtml(text) {
  const escaped = escapeHtml(text);
  const meToken = me ? me.split(' ')[0].toLowerCase() : '';
  return escaped.replace(/@([A-Za-z0-9_.\-]{1,40})/g, (full, name) => {
    const isMe = meToken && name.toLowerCase() === meToken;
    return `<span class="mention${isMe ? ' mention-me' : ''}">@${name}</span>`;
  });
}
function messageMentionsMe(text) {
  if (!text || !me) return false;
  const meToken = me.split(' ')[0].toLowerCase();
  if (!meToken) return false;
  const re = /@([A-Za-z0-9_.\-]{1,40})/g;
  let match;
  while ((match = re.exec(text))) {
    if (match[1].toLowerCase() === meToken) return true;
  }
  return false;
}

function firstUrlInText(text) {
  if (!text) return null;
  const m = text.match(/https?:\/\/[^\s<>"]+/i);
  return m ? m[0].replace(/[.,)\]!?]+$/, '') : null;
}
async function fetchLinkPreview(url) {
  if (linkPreviewCache.has(url)) return linkPreviewCache.get(url);
  try {
    const res = await fetch(`${LINKPREVIEW_URL}?token=${encodeURIComponent(token)}&url=${encodeURIComponent(url)}`);
    const data = await res.json();
    const preview = (data.ok && data.preview) ? data.preview : null;
    linkPreviewCache.set(url, preview);
    return preview;
  } catch (e) {
    linkPreviewCache.set(url, null);
    return null;
  }
}
function buildLinkPreviewCard(preview) {
  const a = document.createElement('a');
  a.href = preview.url;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  a.className = 'link-preview-card';
  if (preview.image) {
    const img = document.createElement('img');
    img.src = preview.image;
    img.alt = '';
    a.appendChild(img);
  }
  const body = document.createElement('div');
  body.className = 'lp-body';
  if (preview.siteName) {
    const site = document.createElement('div');
    site.className = 'lp-site';
    site.textContent = preview.siteName;
    body.appendChild(site);
  }
  if (preview.title) {
    const title = document.createElement('div');
    title.className = 'lp-title';
    title.textContent = preview.title;
    body.appendChild(title);
  }
  if (preview.description) {
    const desc = document.createElement('div');
    desc.className = 'lp-desc';
    desc.textContent = preview.description;
    body.appendChild(desc);
  }
  a.appendChild(body);
  return a;
}
function attachLinkPreview(container, m) {
  if (m._locked || !m.text || m.text.includes('\n')) return;
  const url = firstUrlInText(m.text);
  if (!url) return;
  const placeholder = document.createElement('div');
  container.appendChild(placeholder);
  fetchLinkPreview(url).then(preview => {
    if (preview) placeholder.replaceWith(buildLinkPreviewCard(preview));
    else placeholder.remove();
  });
}

function buildMessageContent(m) {
  const container = document.createElement('div');
  container.className = 'msg-content';
  if (m.replyTo) {
    const quote = document.createElement('div');
    quote.className = 'quoted-block';
    const who = document.createElement('b');
    who.textContent = m.replyTo.user === me ? 'You' : m.replyTo.user;
    const snippet = document.createElement('span');
    snippet.textContent = m.replyTo.text;
    quote.appendChild(who);
    quote.appendChild(snippet);
    container.appendChild(quote);
  }
  if (m.text) {
    if (m.text.includes('\n')) {
      // Multi-line content (code, logs, etc.) — real code box: no
      // wrapping/cutting, horizontal scroll for long lines, own copy button.
      const block = document.createElement('div');
      block.className = 'code-block';
      const pre = document.createElement('pre');
      const code = document.createElement('code');
      code.textContent = m.text;
      pre.appendChild(code);
      const codeCopyBtn = document.createElement('button');
      codeCopyBtn.className = 'code-copy-btn';
      codeCopyBtn.textContent = '📋 Copy';
      codeCopyBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        copyToClipboard(m.text, codeCopyBtn);
      });
      block.appendChild(pre);
      block.appendChild(codeCopyBtn);
      container.appendChild(block);
    } else {
      const textDiv = document.createElement('div');
      textDiv.className = 'msg-text';
      textDiv.innerHTML = m._locked ? escapeHtml(m.text) : renderMentionHtml(m.text);
      container.appendChild(textDiv);
    }
  }
  attachLinkPreview(container, m);
  if (m.type === 'file') {
    const previewUrl = chatFileUrl(m.fileUrl, m.fileName, false);
    const downloadUrl = chatFileUrl(m.fileUrl, m.fileName, true);
    if (m.fileCategory === 'image') {
      const wrap = document.createElement('div');
      wrap.className = 'media-wrap';
      const img = document.createElement('img');
      img.src = previewUrl;
      img.className = 'chat-image';
      img.alt = m.fileName || 'image';
      img.addEventListener('click', () => {
        // SVG is XML and can carry a <script> — safe inside this <img>
        // (browsers never execute scripts from image-context SVGs) but
        // opening it as its own tab makes it a live, script-capable
        // document. Route SVGs through a forced download instead so a
        // click never navigates to a directly-rendered SVG; every other
        // image format has no such risk and opens normally.
        if ((m.fileExt || '').toLowerCase() === 'svg') {
          downloadFileWithProgress(downloadUrl, m.fileName || 'image.svg');
        } else {
          window.open(previewUrl, '_blank');
        }
      });
      const dlBtn = document.createElement('button');
      dlBtn.className = 'dl-btn';
      dlBtn.title = 'Download';
      dlBtn.textContent = '⬇️';
      dlBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        downloadFileWithProgress(downloadUrl, m.fileName || 'image');
      });
      wrap.appendChild(img);
      wrap.appendChild(dlBtn);
      container.appendChild(wrap);
      const imgBadge = makeEncBadge(m);
      if (imgBadge) container.appendChild(imgBadge);
    } else if (m.fileCategory === 'audio' || m.fileCategory === 'video') {
      const row = document.createElement('div');
      row.className = 'av-dl-row';
      const media = document.createElement(m.fileCategory === 'audio' ? 'audio' : 'video');
      media.controls = true;
      media.src = previewUrl;
      media.style.flex = '1';
      media.style.minWidth = '0';
      const dlBtn = document.createElement('button');
      dlBtn.className = 'dl-btn-inline';
      dlBtn.textContent = '⬇️ Save';
      dlBtn.addEventListener('click', () => downloadFileWithProgress(downloadUrl, m.fileName || ('file.' + (m.fileExt || ''))));
      row.appendChild(media);
      row.appendChild(dlBtn);
      container.appendChild(row);
      const avBadge = makeEncBadge(m);
      if (avBadge) container.appendChild(avBadge);
    } else if (m.fileCategory === 'code') {
      const row = document.createElement('div');
      row.className = 'av-dl-row';
      const viewBtn = document.createElement('button');
      viewBtn.type = 'button';
      viewBtn.className = 'file-card';
      viewBtn.style.flex = '1';
      viewBtn.addEventListener('click', () => openCodeViewer(previewUrl, m.fileName || 'file.txt', downloadUrl));
      const icon = document.createElement('div');
      icon.className = 'icon';
      icon.textContent = iconForCategory('code', m.fileExt);
      const info = document.createElement('div');
      info.className = 'info';
      const fname = document.createElement('div');
      fname.className = 'fname';
      fname.textContent = m.fileName || 'file';
      const fsize = document.createElement('div');
      fsize.className = 'fsize';
      fsize.textContent = formatSize(m.fileSize || 0) + ' · tap to view';
      info.appendChild(fname);
      info.appendChild(fsize);
      viewBtn.appendChild(icon);
      viewBtn.appendChild(info);
      const codeDlBtn = document.createElement('button');
      codeDlBtn.className = 'dl-btn-inline';
      codeDlBtn.textContent = '⬇️';
      codeDlBtn.addEventListener('click', () => downloadFileWithProgress(downloadUrl, m.fileName || 'file.txt'));
      row.appendChild(viewBtn);
      row.appendChild(codeDlBtn);
      container.appendChild(row);
      const codeBadge = makeEncBadge(m);
      if (codeBadge) container.appendChild(codeBadge);
    } else {
      const link = document.createElement('button');
      link.type = 'button';
      link.className = 'file-card';
      link.addEventListener('click', () => downloadFileWithProgress(downloadUrl, m.fileName || 'file'));
      const icon = document.createElement('div');
      icon.className = 'icon';
      icon.textContent = iconForCategory(m.fileCategory, m.fileExt);
      const info = document.createElement('div');
      info.className = 'info';
      const fname = document.createElement('div');
      fname.className = 'fname';
      fname.textContent = m.fileName || 'file';
      const fsize = document.createElement('div');
      fsize.className = 'fsize';
      fsize.textContent = formatSize(m.fileSize || 0);
      info.appendChild(fname);
      info.appendChild(fsize);
      link.appendChild(icon);
      link.appendChild(info);
      container.appendChild(link);
      const fileBadge = makeEncBadge(m);
      if (fileBadge) container.appendChild(fileBadge);
    }
  }
  return container;
}

function appendMessage(m) {
  if (!m || !m.id) return;
  if (renderedIds.has(m.id)) return; // duplicate-message fix
  renderedIds.add(m.id);

  const div = document.createElement('div');
  let cls = 'msg ';
  if (m.role === 'super') {
    cls += (m.user === me ? 'mine ' : 'theirs ') + 'super-msg';
  } else if (m.role === 'host') {
    cls += (m.user === me ? 'mine ' : 'theirs ') + 'host-msg';
  } else {
    cls += (m.user === me ? 'mine' : 'theirs');
  }
  if (m._locked) cls += ' locked-msg';
  div.className = cls;
  div.dataset.msgId = m.id;
  if (m.role === 'super') applyGlowToElement(div);

  const authorDiv = document.createElement('div');
  authorDiv.className = 'author';
  let label = m.user === me ? 'You' : m.user;
  if (m.role === 'super') label = '👑 ' + label;
  else if (m.role === 'host') label = '🛡️ ' + label;
  const nameSpan = document.createElement('span');
  nameSpan.textContent = label;
  authorDiv.appendChild(nameSpan);

  if (m.edited) {
    const editedTag = document.createElement('span');
    editedTag.className = 'edited-tag';
    editedTag.textContent = '(edited)';
    authorDiv.appendChild(editedTag);
  }

  const actions = document.createElement('div');
  actions.className = 'msg-actions';

  if (m.text && !m.text.includes('\n')) {
    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-btn';
    copyBtn.textContent = '📋 Copy';
    copyBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      copyToClipboard(m.text, copyBtn);
    });
    actions.appendChild(copyBtn);
  }

  const replyBtn = document.createElement('button');
  replyBtn.className = 'copy-btn';
  replyBtn.textContent = '↩️';
  replyBtn.title = 'Reply';
  replyBtn.addEventListener('click', (e) => { e.stopPropagation(); startReply(m); });
  actions.appendChild(replyBtn);

  if (m.user === me && (!m.type || m.type === 'text') && !m._locked) {
    const editBtn = document.createElement('button');
    editBtn.className = 'copy-btn';
    editBtn.textContent = '✏️';
    editBtn.title = 'Edit';
    editBtn.addEventListener('click', (e) => { e.stopPropagation(); startEditMessage(m); });
    actions.appendChild(editBtn);
  }

  if (role === 'super') {
    const pinBtn = document.createElement('button');
    pinBtn.className = 'copy-btn';
    pinBtn.textContent = '📌';
    pinBtn.title = 'Pin this message';
    pinBtn.addEventListener('click', (e) => { e.stopPropagation(); pinMessage(m.id); });
    actions.appendChild(pinBtn);
  }

  authorDiv.appendChild(actions);
  div.appendChild(authorDiv);
  div.appendChild(buildMessageContent(m));

  const reactionRow = document.createElement('div');
  reactionRow.className = 'reaction-row';
  div.appendChild(reactionRow);
  const picker = document.createElement('div');
  picker.className = 'reaction-picker';
  const reactToggle = document.createElement('button');
  reactToggle.className = 'react-toggle-btn';
  reactToggle.textContent = '😊 React';
  reactToggle.addEventListener('click', (e) => { e.stopPropagation(); picker.classList.toggle('open'); });
  ['👍', '❤️', '😂', '😮', '😢', '🔥'].forEach(emoji => {
    const pbtn = document.createElement('button');
    pbtn.textContent = emoji;
    pbtn.addEventListener('click', (e) => { e.stopPropagation(); react(m.id, emoji); picker.classList.remove('open'); });
    picker.appendChild(pbtn);
  });
  div.appendChild(reactToggle);
  div.appendChild(picker);
  renderReactions(reactionRow, m.reactions || {});

  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  messageElements.set(m.id, div);
  if (m.id > lastId) lastId = m.id;

  // Sound + tab-title notification for incoming messages from others.
  // A message that @mentions me gets this treatment even while the tab
  // is visible (that's the whole point of a mention); other messages
  // only notify while the tab is hidden.
  const mentionsMe = m.user !== me && messageMentionsMe(m.text);
  if (mentionsMe) {
    div.classList.add('highlight-mention');
    unreadCount++;
    document.title = `(${unreadCount}) ${originalTitle}`;
    playNotificationSound();
  } else if (m.user !== me && document.hidden) {
    unreadCount++;
    document.title = `(${unreadCount}) ${originalTitle}`;
    playNotificationSound();
  }
}

function renderReactions(rowEl, reactions) {
  rowEl.innerHTML = '';
  Object.keys(reactions || {}).forEach(emoji => {
    const users = reactions[emoji];
    if (!users || !users.length) return;
    const pill = document.createElement('div');
    pill.className = 'reaction-pill' + (users.includes(me) ? ' mine' : '');
    pill.textContent = emoji + ' ' + users.length;
    pill.title = users.join(', ');
    pill.addEventListener('click', () => react(parseInt(rowEl.parentElement.dataset.msgId, 10), emoji));
    rowEl.appendChild(pill);
  });
}

async function react(messageId, emoji) {
  try {
    const res = await fetch('react.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, messageId, emoji }),
    });
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (data.ok) {
      const el = messageElements.get(messageId);
      if (el) renderReactions(el.querySelector('.reaction-row'), data.message.reactions || {});
    }
  } catch (e) { /* silent */ }
}

function startReply(m) {
  replyingTo = { id: m.id, user: m.user, text: m.text || (m.type === 'file' ? '📎 ' + (m.fileName || 'file') : '') };
  const bar = document.getElementById('replyPreview');
  bar.style.display = 'flex';
  bar.innerHTML = '';
  const textDiv = document.createElement('div');
  textDiv.className = 'rp-text';
  const b = document.createElement('b');
  b.textContent = 'Replying to ' + (m.user === me ? 'yourself' : m.user) + ': ';
  textDiv.appendChild(b);
  textDiv.appendChild(document.createTextNode(replyingTo.text.slice(0, 80)));
  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = '✕';
  cancelBtn.addEventListener('click', cancelReply);
  bar.appendChild(textDiv);
  bar.appendChild(cancelBtn);
  document.getElementById('textInput').focus();
}
function cancelReply() {
  replyingTo = null;
  document.getElementById('replyPreview').style.display = 'none';
}

function startEditMessage(m) {
  const el = messageElements.get(m.id);
  if (!el) return;
  const contentEl = el.querySelector('.msg-content');
  if (!contentEl) return;

  const box = document.createElement('div');
  box.className = 'edit-box';
  const ta = document.createElement('textarea');
  ta.value = m.text || '';
  const actionsRow = document.createElement('div');
  actionsRow.className = 'edit-actions';
  const saveBtn = document.createElement('button');
  saveBtn.className = 'edit-save';
  saveBtn.textContent = 'Save';
  const cancelBtn = document.createElement('button');
  cancelBtn.className = 'edit-cancel';
  cancelBtn.textContent = 'Cancel';
  actionsRow.appendChild(saveBtn);
  actionsRow.appendChild(cancelBtn);
  box.appendChild(ta);
  box.appendChild(actionsRow);
  contentEl.replaceWith(box);
  ta.focus();
  ta.setSelectionRange(ta.value.length, ta.value.length);

  cancelBtn.addEventListener('click', () => box.replaceWith(buildMessageContent(m)));

  saveBtn.addEventListener('click', async () => {
    const newText = ta.value.trim();
    if (!newText) { alert('Message cannot be empty.'); return; }
    try {
      const outgoingText = roomEncEnabled ? await encryptText(roomEncKey, newText) : newText;
      const res = await fetch(EDIT_URL, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, messageId: m.id, text: outgoingText }),
      });
      const data = await res.json();
      if (!res.ok) { await handleAuthError(data); return; }
      if (!data.ok) { alert('Failed to edit: ' + (data.error || 'unknown error')); return; }
      m.text = newText; // we already have the plaintext locally
      m.edited = true;
      box.replaceWith(buildMessageContent(m));
      const authorDiv = el.querySelector('.author');
      if (authorDiv && !authorDiv.querySelector('.edited-tag')) {
        const tag = document.createElement('span');
        tag.className = 'edited-tag';
        tag.textContent = '(edited)';
        authorDiv.insertBefore(tag, authorDiv.querySelector('.msg-actions'));
      }
    } catch (e) { alert('Could not reach server.'); }
  });
}

async function pinMessage(messageId) {
  try {
    const res = await fetch('admin.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, action: 'pin_message', messageId }),
    });
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (!data.ok) alert('Failed to pin: ' + (data.error || 'unknown error'));
  } catch (e) { alert('Could not reach server.'); }
}

function renderPinnedBar(pinned) {
  const bar = document.getElementById('pinnedBar');
  if (!pinned) { bar.style.display = 'none'; return; }
  bar.style.display = 'flex';
  bar.innerHTML = '';
  const textDiv = document.createElement('div');
  textDiv.className = 'pin-text';
  textDiv.textContent = '📌 ' + pinned.user + ': ' + (pinned.text || '(file)');
  bar.appendChild(textDiv);
  if (role === 'super') {
    const unpinBtn = document.createElement('button');
    unpinBtn.textContent = 'Unpin';
    unpinBtn.addEventListener('click', async () => {
      try {
        const res = await fetch('admin.php', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token, action: 'unpin_message' }),
        });
        const data = await res.json();
        if (data.ok) renderPinnedBar(null);
      } catch (e) { /* silent */ }
    });
    bar.appendChild(unpinBtn);
  }
}

function renderTyping(names) {
  const el = document.getElementById('typingIndicator');
  if (!names || !names.length) { el.textContent = ''; return; }
  if (names.length === 1) el.textContent = names[0] + ' is typing…';
  else el.textContent = names.join(', ') + ' are typing…';
}

let audioCtx = null;
function playNotificationSound() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, audioCtx.currentTime);
    gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.35);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.35);
  } catch (e) { /* audio not available, ignore */ }
}

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    unreadCount = 0;
    document.title = originalTitle;
    if (lastId > lastReportedReadId) reportRead(lastId);
  }
});

// ---------- Read receipts ----------
async function reportRead(messageId) {
  if (!token || messageId <= lastReportedReadId) return;
  lastReportedReadId = messageId;
  try {
    await fetch(READ_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, messageId }),
    });
  } catch (e) { /* silent — best effort */ }
}

// Shows "Seen by ..." under the most recent message I sent, based on
// everyone else's reported lastReadId (Signal/WhatsApp pattern).
function renderSeenBy() {
  document.querySelectorAll('.seen-by').forEach(el => el.remove());
  if (!latestReadReceipts || !latestReadReceipts.length) return;
  let lastMineId = 0;
  let lastMineEl = null;
  messageElements.forEach((el, id) => {
    if (el.classList.contains('mine') && id > lastMineId) { lastMineId = id; lastMineEl = el; }
  });
  if (!lastMineEl || !lastMineId) return;
  const seenNames = latestReadReceipts.filter(r => r.lastReadId >= lastMineId).map(r => r.user);
  if (!seenNames.length) return;
  const div = document.createElement('div');
  div.className = 'seen-by';
  div.textContent = '✓✓ Seen by ' + seenNames.join(', ');
  lastMineEl.appendChild(div);
}

async function sendTypingHeartbeat() {
  const text = document.getElementById('textInput').value;
  if (!text.trim() || !token) return;
  try {
    await fetch('typing.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    });
  } catch (e) { /* silent */ }
}

function copyToClipboard(text, btnEl) {
  const done = () => {
    if (!btnEl) return;
    const original = btnEl.textContent;
    btnEl.textContent = '✓ Copied';
    btnEl.classList.add('copied');
    setTimeout(() => { btnEl.textContent = original; btnEl.classList.remove('copied'); }, 1500);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}

function fallbackCopy(text, done) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); } catch (e) { alert('Could not copy automatically — please select and copy manually.'); }
  document.body.removeChild(ta);
}

function renderPresence(list) {
  if (!list) return;
  presenceList.innerHTML = '';
  list.forEach(p => {
    if (p.name === me) return;
    const row = document.createElement('div');
    row.className = 'presence-row';
    const label = document.createElement('span');
    const roleIcon = p.role === 'super' ? '👑 ' : (p.role === 'host' ? '🛡️ ' : '');
    label.textContent = roleIcon + p.name;
    row.appendChild(label);
    if (role === 'host' || role === 'super') {
      const btns = document.createElement('div');
      btns.className = 'row-btns';
      const muteBtn = document.createElement('button');
      muteBtn.className = 'mini-btn mute';
      muteBtn.textContent = 'Mute';
      muteBtn.addEventListener('click', () => muteUser(p.name));
      const kickBtn = document.createElement('button');
      kickBtn.className = 'mini-btn kick';
      kickBtn.textContent = 'Kick';
      kickBtn.addEventListener('click', () => kickUser(p.name));
      btns.appendChild(muteBtn);
      btns.appendChild(kickBtn);
      if (role === 'super' && p.ip) {
        const blockBtn = document.createElement('button');
        blockBtn.className = 'mini-btn kick';
        blockBtn.textContent = 'Block IP';
        blockBtn.title = p.ip;
        blockBtn.addEventListener('click', () => blockIp(p.ip, p.name));
        btns.appendChild(blockBtn);
      }
      row.appendChild(btns);
    }
    presenceList.appendChild(row);
  });
  if (!presenceList.children.length) {
    presenceList.innerHTML = '<div style="opacity:0.5;font-size:12px">No one else here right now.</div>';
  }
}

function renderBanned(list) {
  if (!list) return;
  bannedList.innerHTML = '';
  list.forEach(b => {
    const row = document.createElement('div');
    row.className = 'banned-row';
    const label = document.createElement('span');
    label.textContent = b.user;
    row.appendChild(label);
    const unbanBtn = document.createElement('button');
    unbanBtn.className = 'mini-btn unban';
    unbanBtn.textContent = 'Unban';
    unbanBtn.addEventListener('click', () => unbanUser(b.user));
    row.appendChild(unbanBtn);
    bannedList.appendChild(row);
  });
  if (!bannedList.children.length) {
    bannedList.innerHTML = '<div style="opacity:0.5;font-size:12px">No one banned.</div>';
  }
}

function renderBannedIps(list) {
  if (!list) return;
  bannedIpList.innerHTML = '';
  list.forEach(b => {
    const row = document.createElement('div');
    row.className = 'banned-row';
    const label = document.createElement('span');
    label.textContent = b.ip;
    row.appendChild(label);
    const unblockBtn = document.createElement('button');
    unblockBtn.className = 'mini-btn unban';
    unblockBtn.textContent = 'Unblock';
    unblockBtn.addEventListener('click', () => unblockIp(b.ip));
    row.appendChild(unblockBtn);
    bannedIpList.appendChild(row);
  });
  if (!bannedIpList.children.length) {
    bannedIpList.innerHTML = '<div style="opacity:0.5;font-size:12px">No IPs blocked in this room.</div>';
  }
}

// null until the first poll response arrives, so that first response
// can silently establish the baseline instead of toasting for every
// request that was already pending before this session started.
let knownFileRequestIds = null;

function updateFileApprovalToggle(enabled) {
  // Setting .checked directly (not via user interaction) does not
  // fire the 'change' listener below, so this can't loop back into
  // calling the API again.
  fileApprovalToggle.checked = !!enabled;
}

// Builds the extra-extension checkboxes once. Re-used across updates —
// only their .checked state and disabled state change afterward.
let extraUploadsChecklistBuilt = false;
function ensureExtraUploadsChecklist() {
  if (extraUploadsChecklistBuilt) return;
  extraUploadsExtList.innerHTML = '';
  EXTRA_UPLOAD_CATALOG.forEach(ext => {
    const label = document.createElement('label');
    label.className = 'menu-check';
    label.style.marginRight = '10px';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.value = ext;
    cb.className = 'extraUploadExtCb';
    label.appendChild(cb);
    label.appendChild(document.createTextNode(' .' + ext));
    extraUploadsExtList.appendChild(label);
  });
  extraUploadsChecklistBuilt = true;
}

// Reflects current server state in the panel (for host/super, who can
// both SEE this block) and updates every client's accept attribute so
// the file picker doesn't hide types the server will actually take.
function updateExtraUploadsUI(state) {
  if (!state) return;
  extraUploadsState = state;
  ensureExtraUploadsChecklist();

  const now = Date.now();
  const active = !!state.enabled && (!state.expiresAt || state.expiresAt > now);

  // Only re-paint the controls from server state if the panel isn't the
  // one currently being edited (role !== 'super' is always read-only
  // here, so always safe to sync for host/members).
  if (role !== 'super') {
    extraUploadsToggle.checked = active;
    extraUploadsAllowAll.checked = !!state.allowAll;
    extraUploadsExtList.querySelectorAll('.extraUploadExtCb').forEach(cb => {
      cb.checked = (state.extensions || []).includes(cb.value);
      cb.disabled = true;
    });
    extraUploadsToggle.disabled = true;
    extraUploadsAllowAll.disabled = true;
    extraUploadsMinutes.disabled = true;
    extraUploadsSaveBtn.style.display = 'none';
    extraUploadsHint.textContent = 'Only a super user can change this — ask them to enable it here if you need to send an extra file type.';
  }

  if (active) {
    const types = state.allowAll ? 'all extra types' : ((state.extensions || []).map(e => '.' + e).join(', ') || 'none selected');
    const timeLeft = state.expiresAt ? (' — turns off in ' + Math.max(1, Math.ceil((state.expiresAt - now) / 60000)) + ' min') : ' — no timer, on until turned off';
    extraUploadsStatus.textContent = '✅ Active: ' + types + timeLeft;
  } else {
    extraUploadsStatus.textContent = 'Off — hosts/members are limited to the normal file type list.';
  }

  // Broaden (or restore) the member/host file-picker's accept filter so
  // it doesn't hide extra types the server will now actually accept.
  // upload.php is the real gatekeeper either way — this is just so the
  // OS file picker doesn't get in the way.
  if (role !== 'super' && fileInput) {
    if (active) {
      const extra = state.allowAll ? EXTRA_UPLOAD_CATALOG : (state.extensions || []);
      const base = 'jpg,jpeg,png,gif,webp,svg,bmp,pdf,doc,docx,xls,xlsx,ppt,pptx,txt,csv,rtf,mp3,wav,ogg,m4a,aac,mp4,webm,mov,mkv,avi,zip,rar,7z';
      fileInput.setAttribute('accept', '.' + base.split(',').concat(extra).join(',.'));
    } else {
      fileInput.setAttribute('accept', '.jpg,.jpeg,.png,.gif,.webp,.svg,.bmp,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.rtf,.mp3,.wav,.ogg,.m4a,.aac,.mp4,.webm,.mov,.mkv,.avi,.zip,.rar,.7z');
    }
  }
}

async function saveExtraUploads() {
  ensureExtraUploadsChecklist();
  const extensions = Array.from(extraUploadsExtList.querySelectorAll('.extraUploadExtCb'))
    .filter(cb => cb.checked)
    .map(cb => cb.value);
  const minutes = Math.max(0, parseInt(extraUploadsMinutes.value, 10) || 0);
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token, action: 'set_extra_uploads',
        enabled: extraUploadsToggle.checked,
        allowAll: extraUploadsAllowAll.checked,
        extensions, minutes,
      }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) { alert(data.error || 'Could not save.'); return; }
    updateExtraUploadsUI(data.extraUploads);
  } catch (e) { alert('Could not reach server.'); }
}

function renderFileRequests(list) {
  if (!list) return; // non-admin — block is hidden anyway
  const currentIds = new Set(list.map(r => r.id));
  if (knownFileRequestIds === null) {
    knownFileRequestIds = currentIds;
  } else {
    for (const r of list) {
      if (!knownFileRequestIds.has(r.id)) {
        showRequestToast('📨 ' + r.user + ' wants to send: ' + (r.fileName || 'a file'));
      }
    }
    knownFileRequestIds = currentIds;
  }

  fileReqList.innerHTML = '';
  list.forEach(r => {
    const card = document.createElement('div');
    card.className = 'file-req-card';
    const info = document.createElement('div');
    info.className = 'info';
    const fname = document.createElement('div');
    fname.className = 'fname';
    fname.textContent = r.fileName || 'file';
    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.textContent = r.user + ' · ' + formatSize(r.fileSize || 0);
    info.appendChild(fname);
    info.appendChild(meta);
    const approveBtn = document.createElement('button');
    approveBtn.className = 'approve-btn';
    approveBtn.textContent = 'Approve';
    approveBtn.addEventListener('click', () => resolveFileRequest(r.id, 'approve_file_request'));
    const denyBtn = document.createElement('button');
    denyBtn.className = 'deny-btn';
    denyBtn.textContent = 'Deny';
    denyBtn.addEventListener('click', () => resolveFileRequest(r.id, 'deny_file_request'));
    card.appendChild(info);
    card.appendChild(approveBtn);
    card.appendChild(denyBtn);
    fileReqList.appendChild(card);
  });
  if (!fileReqList.children.length) {
    fileReqList.innerHTML = '<div style="opacity:0.5;font-size:12px">No pending requests.</div>';
  }
}

async function resolveFileRequest(requestId, action) {
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, action, requestId }),
    });
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (!data.ok) { alert('Failed: ' + (data.error || 'unknown error')); return; }
    await poll();
  } catch (e) { alert('Could not reach server.'); }
}

let requestToastTimer = null;
function showRequestToast(text) {
  let toast = document.getElementById('reqToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'reqToast';
    toast.className = 'req-toast';
    document.body.appendChild(toast);
  }
  toast.textContent = text;
  // Reflow before adding the class so the fade-in transition reliably
  // replays even if a toast is already showing.
  toast.classList.remove('show');
  void toast.offsetWidth;
  toast.classList.add('show');
  clearTimeout(requestToastTimer);
  requestToastTimer = setTimeout(() => toast.classList.remove('show'), 4000);
}

fileApprovalToggle.addEventListener('change', async () => {
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, action: 'set_file_approval', enabled: fileApprovalToggle.checked }),
    });
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (!data.ok) {
      alert('Failed: ' + (data.error || 'unknown error'));
      fileApprovalToggle.checked = !fileApprovalToggle.checked; // revert on failure
    }
  } catch (e) {
    alert('Could not reach server.');
    fileApprovalToggle.checked = !fileApprovalToggle.checked;
  }
});

extraUploadsSaveBtn.addEventListener('click', saveExtraUploads);

async function kickUser(targetUser) {
  if (!confirm('Remove ' + targetUser + ' from this chat?')) return;
  try {
    const res = await fetch(KICK_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, targetUser }),
    });
    const data = await res.json();
    if (!data.ok) alert('Could not remove user: ' + (data.error || 'unknown error'));
  } catch (e) { alert('Could not reach server.'); }
}

async function blockIp(ip, targetUser) {
  const minutesStr = prompt('Block ' + targetUser + '\'s IP (' + ip + ') site-wide for how many minutes? (0 = permanent, until manually unblocked)', '60');
  if (minutesStr === null) return;
  const minutes = parseFloat(minutesStr);
  if (isNaN(minutes) || minutes < 0) { alert('Enter a number of minutes, or 0 for permanent.'); return; }
  const reason = prompt('Reason (optional, visible to other super users):', '') || '';
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, action: 'block_ip', ip, reason, durationSeconds: Math.round(minutes * 60) }),
    });
    const data = await res.json();
    if (!res.ok) { const handled = await handleAuthError(data); if (!handled) alert('Could not block IP: ' + (data.error || data.message || 'unknown error')); return; }
    if (data.ok) alert('Blocked ' + ip + '.');
    else alert('Could not block IP: ' + (data.error || 'unknown error'));
  } catch (e) { alert('Could not reach server.'); }
}

async function muteUser(targetUser) {
  const minutesStr = prompt('Mute ' + targetUser + ' for how many minutes? (0 to unmute)', '5');
  if (minutesStr === null) return;
  const minutes = parseFloat(minutesStr);
  if (isNaN(minutes)) return;
  try {
    const res = await fetch(MUTE_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, targetUser, minutes }),
    });
    const data = await res.json();
    if (!data.ok) alert('Could not mute user: ' + (data.error || 'unknown error'));
  } catch (e) { alert('Could not reach server.'); }
}

async function unbanUser(targetUser) {
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, action: 'unban', targetUser }),
    });
    const data = await res.json();
    if (data.ok) await fetchAll();
    else alert('Could not unban: ' + (data.error || 'unknown error'));
  } catch (e) { alert('Could not reach server.'); }
}

async function unblockIp(ip) {
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, action: 'unban_ip', ip }),
    });
    const data = await res.json();
    if (data.ok) await fetchAll();
    else alert('Could not unblock: ' + (data.error || 'unknown error'));
  } catch (e) { alert('Could not reach server.'); }
}

// ---------- Remember-me (auto-login) helpers ----------
// Stored in localStorage (survives browser restarts), unlike qc_session
// which lives in sessionStorage (cleared when the tab closes). Only one
// remembered login is kept at a time, matching the single-session model
// the app already uses.
function saveRememberToken(rememberToken) {
  if (!rememberToken) return;
  localStorage.setItem('qc_remember', rememberToken);
}
function clearRememberToken() {
  localStorage.removeItem('qc_remember');
}
async function revokeRememberToken() {
  const t = localStorage.getItem('qc_remember');
  if (!t) return;
  clearRememberToken();
  try {
    await fetch(AUTH_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'remember_logout', rememberToken: t }),
    });
  } catch (e) { /* best effort — token is already gone client-side */ }
}

function forceLogout(message, alsoForgetDevice) {
  clearInterval(pollTimer);
  clearInterval(typingPollTimer);
  sessionStorage.removeItem('qc_session');
  // Only wipe the long-lived remember-me token on an explicit Leave/ban,
  // never on a plain short-session expiry — that case should instead
  // fall through to the remember_login retry in tryAutoRejoin().
  if (alsoForgetDevice) revokeRememberToken();
  chatWrap.style.display = 'none';
  setupEl.style.display = 'flex';
  messagesEl.innerHTML = '';
  lastId = 0;
  renderedIds = new Set();
  messageElements = new Map();
  replyingTo = null;
  unreadCount = 0;
  document.title = originalTitle;
  document.body.style.background = '';
  roomEncEnabled = false;
  roomEncSalt = null;
  roomEncKey = null;
  encPromptShown = false;
  encKeyBar.style.display = 'none';
  encKeyBtn.style.display = 'none';
  latestReadReceipts = [];
  lastReportedReadId = 0;
  if (message) alert(message);
}

async function handleAuthError(data) {
  if (data && data.error === 'banned') { forceLogout(data.message || 'You have been removed from this chat by the host.', true); return true; }
  if (data && data.error === 'invalid_session') { forceLogout('Your session expired. Please log in again.', false); return true; }
  return false;
}

function updateMutedBanner(remainingMs) {
  isMuted = remainingMs > 0;
  if (isMuted) {
    mutedBanner.style.display = 'block';
    mutedBanner.textContent = '🔇 You are muted for ' + Math.ceil(remainingMs / 1000) + 's';
  } else {
    mutedBanner.style.display = 'none';
  }
}

function applyRecentSync(recentSync) {
  if (!recentSync) return;
  recentSync.forEach(entry => {
    const el = messageElements.get(entry.id);
    if (el) renderReactions(el.querySelector('.reaction-row'), entry.reactions || {});
  });
}

async function fetchAll() {
  const loadingBar = document.getElementById('loadingBar');
  loadingBar.classList.add('active');
  try {
    const res = await fetch(`${API_URL}?room=${encodeURIComponent(room)}&token=${encodeURIComponent(token)}`);
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (data.ok) {
      await syncEncryptionState(data.encEnabled, data.encSalt, data.superRecoveredKey);
      messagesEl.innerHTML = '';
      lastId = 0;
      renderedIds = new Set();
      messageElements = new Map();
      for (const m of data.messages) { await decorateMessageText(m); appendMessage(m); }
      roomTitleEl.textContent = data.title ? data.title : ('Room: ' + room);
      renderPresence(data.presence);
      renderBanned(data.bannedUsers);
      renderBannedIps(data.bannedIps);
      renderFileRequests(data.fileRequests);
      updateFileApprovalToggle(data.requireFileApproval);
      updateExtraUploadsUI(data.extraUploads);
      applyRoomTheme(data.roomTheme);
      if (data.pinnedMessage) await decorateMessageText(data.pinnedMessage);
      renderPinnedBar(data.pinnedMessage);
      renderTyping(data.typingUsers);
      updateEncAdminUi();
      if (data.you) updateMutedBanner(data.you.mutedRemainingMs || 0);
      latestReadReceipts = data.readReceipts || [];
      renderSeenBy();
      if (!document.hidden && lastId > lastReportedReadId) reportRead(lastId);
      setStatus('Connected');
    } else {
      setStatus('Error loading messages');
    }
  } catch (e) { setStatus('Cannot reach server — check hosting/URL'); }
  finally { loadingBar.classList.remove('active'); }
}

async function poll() {
  try {
    const res = await fetch(`${API_URL}?room=${encodeURIComponent(room)}&token=${encodeURIComponent(token)}&since=${lastId}`);
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (data.ok) {
      await syncEncryptionState(data.encEnabled, data.encSalt, data.superRecoveredKey);
      for (const m of data.messages) { await decorateMessageText(m); appendMessage(m); }
      roomTitleEl.textContent = data.title ? data.title : ('Room: ' + room);
      renderPresence(data.presence);
      renderBanned(data.bannedUsers);
      renderBannedIps(data.bannedIps);
      renderFileRequests(data.fileRequests);
      updateFileApprovalToggle(data.requireFileApproval);
      updateExtraUploadsUI(data.extraUploads);
      applyRoomTheme(data.roomTheme);
      if (data.pinnedMessage) await decorateMessageText(data.pinnedMessage);
      renderPinnedBar(data.pinnedMessage);
      renderTyping(data.typingUsers);
      applyRecentSync(data.recentSync);
      updateEncAdminUi();
      if (data.you) updateMutedBanner(data.you.mutedRemainingMs || 0);
      latestReadReceipts = data.readReceipts || [];
      renderSeenBy();
      if (!document.hidden && lastId > lastReportedReadId) reportRead(lastId);
    }
    setStatus('Connected');
  } catch (e) { setStatus('Connection lost, retrying…'); }
}

function enterChat(sessionData) {
  token = sessionData.token;
  role = sessionData.role;
  me = sessionData.user;
  room = sessionData.room;

  sessionStorage.setItem('qc_session', JSON.stringify({ token, role, user: me, room }));

  setupEl.style.display = 'none';
  chatWrap.style.display = 'flex';
  meLabel.textContent = 'You are: ' + me + ' (' + (role === 'super' ? 'Super User' : role === 'host' ? 'Host' : 'Member') + ')';

  const isAdmin = (role === 'host' || role === 'super');
  document.getElementById('clearBtn').style.display = isAdmin ? 'flex' : 'none';
  document.getElementById('manageBtn').style.display = isAdmin ? 'flex' : 'none';
  document.getElementById('themeBtn').style.display = (role === 'super') ? 'flex' : 'none';
  hostResetBlock.style.display = 'none';
  presenceBlock.style.display = 'none';
  bannedBlock.style.display = 'none';
  fileReqBlock.style.display = 'none';
  extraUploadsBlock.style.display = 'none';
  titleBlock.style.display = 'none';
  themeBlock.style.display = 'none';
  encAdminBlock.style.display = 'none';
  exportBlock.style.display = 'none';
  knownFileRequestIds = null; // re-baseline so we don't toast for requests that already existed before this session
  panelsEl.classList.remove('open');

  // Extended-uploads controls are super-only to edit; host/members can
  // still see the block (it's in the shared Manage room panel) but only
  // read the current status — see updateExtraUploadsUI().
  extraUploadsChecklistBuilt = false;
  ensureExtraUploadsChecklist();
  if (role === 'super') {
    extraUploadsToggle.disabled = false;
    extraUploadsAllowAll.disabled = false;
    extraUploadsMinutes.disabled = false;
    extraUploadsExtList.querySelectorAll('.extraUploadExtCb').forEach(cb => cb.disabled = false);
    extraUploadsSaveBtn.style.display = '';
    extraUploadsHint.textContent = 'Lets hosts and members upload the extra file types checked above, on top of the normal allowed list — server-executable types like .php/.exe stay blocked regardless. Optional timer auto-turns this off after N minutes; leave at 0 to keep it on until you turn it off here.';
  }

  roomEncEnabled = false;
  roomEncSalt = null;
  roomEncKey = null;
  encPromptShown = false;
  encKeyBar.style.display = 'none';
  encKeyBtn.style.display = 'none';

  // If the person already typed the room's encryption key on the login
  // screen, cache it now — BEFORE fetchAll() runs — so if the room turns
  // out to be encrypted, the key gets derived automatically instead of
  // showing the unlock prompt.
  if (sessionData.encKey) {
    cacheRoomPassphrase(sessionData.encKey);
    encPromptShown = true; // we already have it; don't nag with the bar
  }

  if (role === 'super') fileInput.removeAttribute('accept');

  if (localStorage.getItem('qc_light_mode') === '1') document.body.classList.add('light-mode');
  renderPresets();
  fetchAll();
  pollTimer = setInterval(poll, POLL_INTERVAL_MS);
  typingPollTimer = setInterval(sendTypingHeartbeat, 2500);
}

// ---------- Login handlers ----------
document.getElementById('memberJoinBtn').addEventListener('click', async () => {
  const r = document.getElementById('memberRoom').value.trim();
  const pin = document.getElementById('memberPin').value.trim();
  const n = document.getElementById('memberName').value.trim();
  const encKey = document.getElementById('memberEncKey').value;
  const errEl = document.getElementById('memberError');
  errEl.textContent = '';
  if (!r || !pin || !n) { errEl.textContent = 'Please fill in all fields.'; return; }
  const remember = document.getElementById('memberRemember').checked;
  try {
    const res = await fetch(AUTH_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'member', room: r, pin, username: n, remember }),
    });
    const data = await res.json();
    if (data.ok) {
      saveRememberToken(data.rememberToken);
      enterChat({ token: data.token, role: data.role, user: data.user, room: data.room, encKey: encKey || null });
    }
    else errEl.textContent = data.error || 'Failed to join.';
  } catch (e) { errEl.textContent = 'Could not reach server.'; }
});

document.getElementById('hostLoginBtn').addEventListener('click', async () => {
  const r = document.getElementById('hostRoom').value.trim();
  const pw = document.getElementById('hostPassword').value;
  const newPin = document.getElementById('hostNewPin').value.trim();
  const encKey = document.getElementById('hostEncKey').value;
  const errEl = document.getElementById('hostError');
  errEl.textContent = '';
  if (!r || !pw) { errEl.textContent = 'Room and host password are required.'; return; }
  const remember = document.getElementById('hostRemember').checked;
  try {
    const res = await fetch(AUTH_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'host', room: r, hostPassword: pw, newPin, remember }),
    });
    const data = await res.json();
    if (data.ok) {
      if (!data.pinIsSet) errEl.textContent = 'Logged in — set a PIN above so members can join.';
      saveRememberToken(data.rememberToken);
      enterChat({ token: data.token, role: data.role, user: data.user, room: data.room, encKey: encKey || null });
    } else {
      errEl.textContent = data.error || 'Failed to log in.';
    }
  } catch (e) { errEl.textContent = 'Could not reach server.'; }
});

// Super step 1: credentials -> master token -> show room browser
document.getElementById('superLoginBtn').addEventListener('click', async () => {
  const su = document.getElementById('superUsername').value.trim();
  const sp = document.getElementById('superPassword').value;
  const errEl = document.getElementById('superError');
  errEl.textContent = '';
  if (!su || !sp) { errEl.textContent = 'Username and password are required.'; return; }
  try {
    const res = await fetch(AUTH_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'super_login', superUsername: su, superPassword: sp }),
    });
    const data = await res.json();
    if (data.ok) {
      masterToken = data.masterToken;
      document.getElementById('superDisplayName').value = data.defaultDisplayName || '';
      await loadRoomBrowser();
    } else {
      errEl.textContent = data.error || 'Login failed.';
    }
  } catch (e) { errEl.textContent = 'Could not reach server.'; }
});

async function loadRoomBrowser() {
  document.querySelectorAll('.form-panel').forEach(p => p.classList.remove('active'));
  roomBrowser.style.display = 'block';
  roomList.innerHTML = 'Loading rooms…';
  try {
    const res = await fetch(`${ROOMS_URL}?masterToken=${encodeURIComponent(masterToken)}`);
    const data = await res.json();
    if (!data.ok) { roomList.innerHTML = '<div class="error-text">' + (data.error || 'Failed to load rooms.') + '</div>'; return; }
    if (!data.rooms.length) { roomList.innerHTML = '<div class="hint">No rooms exist yet — create one below.</div>'; return; }
    roomList.innerHTML = '';
    data.rooms.forEach(r => {
      const card = document.createElement('div');
      card.className = 'room-card';
      const activeNames = (r.activeUsers || []).map(u => u.name).join(', ') || 'no one active';
      card.innerHTML = `
        <div class="rc-title">${escapeHtml(r.title)}</div>
        <div class="rc-meta">
          🛡️ Host set: ${r.hostSet ? 'Yes' : 'No'} &nbsp;•&nbsp; 🔑 PIN set: ${r.pinSet ? 'Yes' : 'No'} &nbsp;•&nbsp; 🔒 Encrypted: ${r.encEnabled ? 'Yes' : 'No'}<br/>
          👥 Active now: ${escapeHtml(activeNames)}<br/>
          📅 Created: ${formatDate(r.createdAt)}<br/>
          🕓 Last activity: ${formatDate(r.lastActivity)} &nbsp;•&nbsp; 💬 ${r.messageCount} messages<br/>
          🚫 Banned users: ${r.bannedUserCount} &nbsp;•&nbsp; 🌐 Blocked IPs: ${r.bannedIpCount}
        </div>
      `;
      const btnRow = document.createElement('div');
      btnRow.className = 'rc-btns';
      const joinSuperBtn = document.createElement('button');
      joinSuperBtn.className = 'btn-join-super';
      joinSuperBtn.textContent = '👑 Join as Super';
      joinSuperBtn.addEventListener('click', () => superJoinRoom(r.room, false));
      const joinHostBtn = document.createElement('button');
      joinHostBtn.className = 'btn-join-host';
      joinHostBtn.textContent = '🕵️ Join as Host (anon)';
      joinHostBtn.addEventListener('click', () => superJoinRoom(r.room, true));
      btnRow.appendChild(joinSuperBtn);
      btnRow.appendChild(joinHostBtn);
      card.appendChild(btnRow);

      const mgmtRow = document.createElement('div');
      mgmtRow.className = 'rc-btns';
      const pwBtn = document.createElement('button');
      pwBtn.className = 'btn-join-host';
      pwBtn.textContent = '🔑 Set new password';
      pwBtn.addEventListener('click', () => roomManageAction(r.room, 'set_host_password'));
      const pinBtn = document.createElement('button');
      pinBtn.className = 'btn-join-host';
      pinBtn.textContent = '🔢 Set new PIN';
      pinBtn.addEventListener('click', () => roomManageAction(r.room, 'set_pin'));
      const delBtn = document.createElement('button');
      delBtn.className = 'danger-btn';
      delBtn.textContent = '🗑️ Delete room';
      delBtn.addEventListener('click', () => roomManageAction(r.room, 'delete_room'));
      mgmtRow.appendChild(pwBtn);
      mgmtRow.appendChild(pinBtn);
      mgmtRow.appendChild(delBtn);
      card.appendChild(mgmtRow);

      roomList.appendChild(card);
    });
  } catch (e) {
    roomList.innerHTML = '<div class="error-text">Could not reach server.</div>';
  }
}

// Passwords are stored hashed server-side and can never be "shown" —
// this always sets a NEW password/PIN rather than revealing the old
// one, which is the safe equivalent of what's being asked for.
async function roomManageAction(roomName, action) {
  let payload = { masterToken, room: roomName, action };

  if (action === 'set_host_password') {
    const pw = prompt('Set a new host password for "' + roomName + '":');
    if (pw === null) return;
    if (pw.trim().length < 4) { alert('Password must be at least 4 characters.'); return; }
    payload.newPassword = pw.trim();
  } else if (action === 'set_pin') {
    const pin = prompt('Set a new PIN for "' + roomName + '":');
    if (pin === null) return;
    if (!pin.trim()) { alert('PIN cannot be empty.'); return; }
    payload.newPin = pin.trim();
  } else if (action === 'delete_room') {
    if (!confirm('Permanently delete room "' + roomName + '"? This removes all messages, files, and settings — this cannot be undone.')) return;
  }

  try {
    const res = await fetch(ROOMS_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!data.ok) { alert('Failed: ' + (data.error || 'unknown error')); return; }
    if (action === 'set_host_password' || action === 'set_pin') alert(data.message || 'Updated.');
    await loadRoomBrowser();
  } catch (e) { alert('Could not reach server.'); }
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str == null ? '' : str;
  return d.innerHTML;
}

async function superJoinRoom(roomName, asHost) {
  const dn = document.getElementById('superDisplayName').value.trim();
  const encKey = document.getElementById('superEncKey').value;
  try {
    const res = await fetch(AUTH_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'super_join', masterToken, room: roomName, displayName: dn, asHost }),
    });
    const data = await res.json();
    if (data.ok) enterChat({ token: data.token, role: data.role, user: data.user, room: data.room, encKey: encKey || null });
    else alert(data.error || 'Failed to join.');
  } catch (e) { alert('Could not reach server.'); }
}

document.getElementById('createRoomSuperBtn').addEventListener('click', () => {
  const name = document.getElementById('newRoomName').value.trim();
  if (!name) { alert('Enter a room name.'); return; }
  superJoinRoom(name, false);
});
document.getElementById('createRoomHostBtn').addEventListener('click', () => {
  const name = document.getElementById('newRoomName').value.trim();
  if (!name) { alert('Enter a room name.'); return; }
  superJoinRoom(name, true);
});

// ---------- Slash commands ----------
// Turns typed admin actions into commands instead of only button clicks.
// Returns true if the text was a recognized command (and was handled —
// so it should NOT also be sent as a chat message). An unrecognized
// "/word" falls through and is sent as normal text.
async function tryHandleSlashCommand(text) {
  const parts = text.trim().split(/\s+/);
  const cmd = parts[0].toLowerCase();
  const isAdmin = role === 'host' || role === 'super';

  if (cmd === '/help') {
    alert(
      'Slash commands:\n' +
      '/clear — clear the chat (host/super)\n' +
      '/mute @user [minutes] — mute someone, default 5 min (host/super)\n' +
      '/unmute @user — remove a mute (host/super)\n' +
      '/kick @user — remove someone from the room (host/super)\n' +
      '/pin — pin the message you\'re replying to (super)'
    );
    return true;
  }

  if (cmd === '/clear') {
    if (!isAdmin) { alert('Only the host or a super user can clear the chat.'); return true; }
    if (confirm('Clear all messages and files in this room?')) {
      try {
        const res = await fetch(`${API_URL}?room=${encodeURIComponent(room)}&token=${encodeURIComponent(token)}`, { method: 'DELETE' });
        const data = await res.json();
        if (!res.ok) { await handleAuthError(data); return true; }
        await fetchAll();
      } catch (e) { alert('Could not reach server.'); }
    }
    return true;
  }

  if (cmd === '/mute' || cmd === '/unmute') {
    if (!isAdmin) { alert('Only the host or a super user can mute people.'); return true; }
    const target = parts[1] ? parts[1].replace(/^@/, '') : '';
    if (!target) { alert('Usage: ' + cmd + ' @username' + (cmd === '/mute' ? ' [minutes]' : '')); return true; }
    const minutes = cmd === '/unmute' ? 0 : (parts[2] ? parseFloat(parts[2]) : 5);
    try {
      const res = await fetch(MUTE_URL, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, targetUser: target, minutes: isNaN(minutes) ? 5 : minutes }),
      });
      const data = await res.json();
      if (!data.ok) alert('Failed: ' + (data.error || 'unknown error'));
    } catch (e) { alert('Could not reach server.'); }
    return true;
  }

  if (cmd === '/kick') {
    if (!isAdmin) { alert('Only the host or a super user can remove people.'); return true; }
    const target = parts[1] ? parts[1].replace(/^@/, '') : '';
    if (!target) { alert('Usage: /kick @username'); return true; }
    if (!confirm('Remove ' + target + ' from this chat?')) return true;
    try {
      const res = await fetch(KICK_URL, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, targetUser: target }),
      });
      const data = await res.json();
      if (!data.ok) alert('Could not remove user: ' + (data.error || 'unknown error'));
    } catch (e) { alert('Could not reach server.'); }
    return true;
  }

  if (cmd === '/pin') {
    if (role !== 'super') { alert('Only a super user can pin messages.'); return true; }
    if (!replyingTo) { alert('Reply to the message you want to pin, then send /pin.'); return true; }
    await pinMessage(replyingTo.id);
    cancelReply();
    return true;
  }

  return false; // not a recognized command — send as normal text
}

// ---------- Messaging ----------
async function sendMessage() {
  const input = document.getElementById('textInput');
  const text = input.value.trim();
  if (!text) return;
  if (text.startsWith('/')) {
    const handled = await tryHandleSlashCommand(text);
    if (handled) { input.value = ''; input.style.height = 'auto'; return; }
  }
  if (isMuted) { alert('You are currently muted.'); return; }
  if (roomEncEnabled && !roomEncKey) {
    alert('This room is encrypted — enter the room key first (tap 🔒 Key in the header).');
    encKeyBar.style.display = 'flex';
    return;
  }
  input.value = '';
  input.style.height = 'auto';
  const replyToId = replyingTo ? replyingTo.id : undefined;
  cancelReply();
  try {
    const outgoingText = roomEncEnabled ? await encryptText(roomEncKey, text) : text;
    const res = await fetch(API_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ room, token, text: outgoingText, replyTo: replyToId }),
    });
    const data = await res.json();
    if (!res.ok) {
      if (data.error === 'muted') { updateMutedBanner(data.mutedRemainingMs || 0); alert(data.message); return; }
      await handleAuthError(data);
      return;
    }
    if (data.ok) {
      data.message.text = text; // we already have the plaintext locally — skip a redundant decrypt round-trip
      appendMessage(data.message);
    } else {
      alert('Failed to send: ' + (data.error || 'unknown error'));
    }
  } catch (e) { alert('Failed to send — check connection.'); }
}

function uploadFile(file, isVoice) {
  const formData = new FormData();
  formData.append('room', room);
  formData.append('token', token);
  formData.append('file', file);
  if (isVoice) formData.append('kind', 'voice');
  if (replyingTo) formData.append('replyTo', replyingTo.id);
  cancelReply();

  uploadProgressEl.classList.remove('error');
  uploadProgressEl.style.display = 'block';
  uploadProgressLabelEl.textContent = 'Uploading ' + file.name + '…';
  uploadProgressPctEl.textContent = '0%';
  uploadProgressFillEl.style.width = '0%';

  // XMLHttpRequest, not fetch — fetch has no reliable, widely-supported
  // way to report request (upload) progress; XHR's upload.onprogress
  // is the standard mechanism every browser (including desktop Edge/
  // Chrome/Firefox on Windows) supports for this.
  return new Promise((resolve) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', UPLOAD_URL);
    xhr.upload.onprogress = (e) => {
      if (!e.lengthComputable) return;
      const pct = Math.round((e.loaded / e.total) * 100);
      uploadProgressFillEl.style.width = pct + '%';
      uploadProgressPctEl.textContent = pct + '%';
    };
    xhr.onload = async () => {
      let data;
      try { data = JSON.parse(xhr.responseText); } catch (e) { data = null; }
      if (xhr.status < 200 || xhr.status >= 300 || !data) {
        if (data && data.error === 'muted') {
          updateMutedBanner(data.mutedRemainingMs || 0);
          alert(data.message);
        } else if (data) {
          await handleAuthError(data);
        } else {
          alert('Upload failed — check connection.');
        }
      } else if (data.ok && data.pending) {
        showRequestToast('📨 Sent to the host for approval: ' + (data.request && data.request.fileName || file.name));
      } else if (data.ok) {
        appendMessage(data.message);
      } else {
        alert('Upload failed: ' + (data.error || 'unknown error'));
      }
      uploadProgressEl.style.display = 'none';
      resolve();
    };
    xhr.onerror = () => {
      uploadProgressEl.classList.add('error');
      uploadProgressLabelEl.textContent = 'Upload failed';
      setTimeout(() => { uploadProgressEl.style.display = 'none'; }, 2000);
      resolve();
    };
    xhr.send(formData);
  });
}

// Fetches a chat file with visible progress, then saves it via a
// Blob + temporary link — this is what gives an explicit "Download"
// action its own in-app progress bar, instead of leaving it to
// whatever (often invisible) download UI the browser provides. Works
// the same in any desktop browser (Windows, macOS, Linux) since it's
// plain Fetch/Blob — nothing OS-specific.
async function downloadFileWithProgress(url, filename) {
  downloadProgressEl.classList.remove('error');
  downloadProgressEl.style.display = 'block';
  downloadProgressLabelEl.textContent = 'Downloading ' + filename + '…';
  downloadProgressPctEl.textContent = '0%';
  downloadProgressFillEl.style.width = '0%';
  try {
    const res = await fetch(url);
    if (!res.ok) {
      let data = null;
      try { data = await res.json(); } catch (e) {}
      await handleAuthError(data || { error: 'download_failed' });
      throw new Error('download failed');
    }
    const total = parseInt(res.headers.get('Content-Length') || '0', 10);
    const reader = res.body.getReader();
    const chunks = [];
    let received = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      received += value.length;
      if (total) {
        const pct = Math.round((received / total) * 100);
        downloadProgressFillEl.style.width = pct + '%';
        downloadProgressPctEl.textContent = pct + '%';
      } else {
        downloadProgressPctEl.textContent = formatSize(received);
      }
    }
    const blob = new Blob(chunks);
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 4000);
    downloadProgressEl.style.display = 'none';
  } catch (e) {
    downloadProgressEl.classList.add('error');
    downloadProgressLabelEl.textContent = 'Download failed';
    setTimeout(() => { downloadProgressEl.style.display = 'none'; }, 2000);
  }
}

const CODE_VIEW_MAX_BYTES = 1.5 * 1024 * 1024; // beyond this, offer download instead of rendering every line

// Fetches a text/code file's content and shows it in a read-only,
// line-numbered viewer — used for the code/txt category's "View"
// button. Always fetches through download.php like everything else,
// so it's still subject to the same session/room checks; the file's
// Content-Type is always text/plain server-side (see
// safe_download_mime() in common.php) regardless of its extension, so
// nothing rendered here can turn into a live script.
async function openCodeViewer(url, filename, downloadUrl) {
  const backdrop = document.createElement('div');
  backdrop.className = 'code-modal-backdrop';
  const modal = document.createElement('div');
  modal.className = 'code-modal';
  const header = document.createElement('div');
  header.className = 'code-modal-header';
  const fname = document.createElement('div');
  fname.className = 'fname';
  fname.textContent = filename;
  const dlBtn = document.createElement('button');
  dlBtn.textContent = '⬇️';
  dlBtn.title = 'Download';
  dlBtn.addEventListener('click', () => downloadFileWithProgress(downloadUrl, filename));
  const copyBtn = document.createElement('button');
  copyBtn.textContent = 'Copy';
  const closeBtn = document.createElement('button');
  closeBtn.textContent = 'Close';
  header.appendChild(fname);
  header.appendChild(copyBtn);
  header.appendChild(dlBtn);
  header.appendChild(closeBtn);
  const body = document.createElement('div');
  body.className = 'code-modal-body';
  body.textContent = 'Loading…';
  modal.appendChild(header);
  modal.appendChild(body);
  backdrop.appendChild(modal);
  document.body.appendChild(backdrop);

  const close = () => backdrop.remove();
  closeBtn.addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });

  let fullText = '';
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error('fetch failed');
    const blob = await res.blob();
    let displayBlob = blob;
    let truncated = false;
    if (blob.size > CODE_VIEW_MAX_BYTES) {
      displayBlob = blob.slice(0, CODE_VIEW_MAX_BYTES);
      truncated = true;
    }
    fullText = await displayBlob.text();
    const lines = fullText.split('\n');
    const table = document.createElement('table');
    lines.forEach((line, i) => {
      const row = document.createElement('tr');
      const lnCell = document.createElement('td');
      lnCell.className = 'ln';
      lnCell.textContent = String(i + 1);
      const codeCell = document.createElement('td');
      codeCell.className = 'code-line';
      codeCell.textContent = line.length ? line : ' ';
      row.appendChild(lnCell);
      row.appendChild(codeCell);
      table.appendChild(row);
    });
    body.textContent = '';
    body.appendChild(table);
    if (truncated) {
      const note = document.createElement('div');
      note.className = 'code-modal-note';
      note.textContent = `Showing the first ${formatSize(CODE_VIEW_MAX_BYTES)} of a larger file — download it to see the rest.`;
      modal.appendChild(note);
    }
  } catch (e) {
    body.textContent = '';
    const note = document.createElement('div');
    note.className = 'code-modal-note';
    note.textContent = 'Could not load this file.';
    body.appendChild(note);
  }

  copyBtn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(fullText);
      copyBtn.textContent = 'Copied!';
      setTimeout(() => { copyBtn.textContent = 'Copy'; }, 1500);
    } catch (e) { /* clipboard permission denied — silently ignore */ }
  });
}

document.getElementById('sendBtn').addEventListener('click', sendMessage);
// Enter always just makes a new line now — only the Send button sends.
// (Auto-sending on Enter was breaking code entry: every line of code
// would fire a send.) Use Ctrl+Enter / Cmd+Enter as a quick-send shortcut.
document.getElementById('textInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
    e.preventDefault();
    sendMessage();
  }
});
document.getElementById('textInput').addEventListener('input', (e) => {
  e.target.style.height = 'auto';
  e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px';
});
document.getElementById('attachBtn').addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', () => {
  if (fileInput.files && fileInput.files[0]) { uploadFile(fileInput.files[0]); fileInput.value = ''; }
});

// ---------- Voice messages ----------
let voiceCancelled = false;

function stopRecordingUi() {
  clearInterval(recordingTimer);
  recordingTimer = null;
  voiceRecordBar.style.display = 'none';
  voiceBtn.classList.remove('recording');
  if (recordingStream) {
    recordingStream.getTracks().forEach(t => t.stop());
    recordingStream = null;
  }
}

voiceBtn.addEventListener('click', async () => {
  if (mediaRecorder && mediaRecorder.state === 'recording') return; // already recording
  if (isMuted) { alert('You are currently muted.'); return; }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) {
    alert('Voice recording is not supported in this browser.');
    return;
  }
  try {
    recordingStream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch (e) {
    alert('Could not access the microphone. Check your browser/site permissions.');
    return;
  }

  recordedChunks = [];
  voiceCancelled = false;
  let mimeType = '';
  for (const candidate of ['audio/webm', 'audio/mp4', 'audio/ogg']) {
    if (MediaRecorder.isTypeSupported(candidate)) { mimeType = candidate; break; }
  }
  try {
    mediaRecorder = mimeType ? new MediaRecorder(recordingStream, { mimeType }) : new MediaRecorder(recordingStream);
  } catch (e) {
    alert('Voice recording is not supported in this browser.');
    recordingStream.getTracks().forEach(t => t.stop());
    recordingStream = null;
    return;
  }

  mediaRecorder.addEventListener('dataavailable', (e) => {
    if (e.data && e.data.size > 0) recordedChunks.push(e.data);
  });
  mediaRecorder.addEventListener('stop', async () => {
    const mt = (mediaRecorder && mediaRecorder.mimeType) ? mediaRecorder.mimeType.split(';')[0] : 'audio/webm';
    stopRecordingUi();
    const chunks = recordedChunks;
    recordedChunks = [];
    if (voiceCancelled || chunks.length === 0) { voiceCancelled = false; return; }
    const blob = new Blob(chunks, { type: mt });
    const ext = mt.includes('mp4') ? 'm4a' : mt.includes('ogg') ? 'ogg' : 'webm';
    const file = new File([blob], 'voice_' + Date.now() + '.' + ext, { type: mt });
    await uploadFile(file, true);
  });

  mediaRecorder.start();
  recordingStartMs = Date.now();
  voiceBtn.classList.add('recording');
  voiceRecordBar.style.display = 'flex';
  voiceRecTime.textContent = '0:00';
  recordingTimer = setInterval(() => {
    const secs = Math.floor((Date.now() - recordingStartMs) / 1000);
    const mins = Math.floor(secs / 60);
    voiceRecTime.textContent = mins + ':' + String(secs % 60).padStart(2, '0');
    if (secs >= 300) { voiceCancelled = false; mediaRecorder.stop(); } // 5 min safety cap
  }, 250);
});

document.getElementById('voiceCancelBtn').addEventListener('click', () => {
  voiceCancelled = true;
  if (mediaRecorder && mediaRecorder.state === 'recording') mediaRecorder.stop();
  else stopRecordingUi();
});
document.getElementById('voiceStopBtn').addEventListener('click', () => {
  voiceCancelled = false;
  if (mediaRecorder && mediaRecorder.state === 'recording') mediaRecorder.stop();
});

document.getElementById('clearBtn').addEventListener('click', async () => {
  closeMenu();
  if (confirm('Clear all messages and files in this room?')) {
    const res = await fetch(`${API_URL}?room=${encodeURIComponent(room)}&token=${encodeURIComponent(token)}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    await fetchAll();
  }
});

document.getElementById('manageBtn').addEventListener('click', () => {
  closeMenu();
  const willOpen = presenceBlock.style.display === 'none';
  presenceBlock.style.display = willOpen ? 'block' : 'none';
  bannedBlock.style.display = willOpen ? 'block' : 'none';
  fileReqBlock.style.display = willOpen ? 'block' : 'none';
  extraUploadsBlock.style.display = willOpen ? 'block' : 'none';
  titleBlock.style.display = willOpen ? 'block' : 'none';
  hostResetBlock.style.display = (willOpen && role === 'super') ? 'block' : 'none';
  encAdminBlock.style.display = willOpen ? 'block' : 'none';
  exportBlock.style.display = willOpen ? 'block' : 'none';
  themeBlock.style.display = 'none';
  if (willOpen) updateEncAdminUi();
  if (willOpen) updateExtraUploadsUI(extraUploadsState);
  panelsEl.classList.toggle('open', willOpen);
});

document.getElementById('themeBtn').addEventListener('click', () => {
  closeMenu();
  const willOpen = themeBlock.style.display === 'none';
  themeBlock.style.display = willOpen ? 'block' : 'none';
  presenceBlock.style.display = 'none';
  bannedBlock.style.display = 'none';
  fileReqBlock.style.display = 'none';
  extraUploadsBlock.style.display = 'none';
  titleBlock.style.display = 'none';
  hostResetBlock.style.display = 'none';
  encAdminBlock.style.display = 'none';
  exportBlock.style.display = 'none';
  panelsEl.classList.toggle('open', willOpen);
});

document.getElementById('exportTxtBtn').addEventListener('click', () => {
  window.open(`${EXPORT_URL}?token=${encodeURIComponent(token)}&format=txt`, '_blank');
});
document.getElementById('exportJsonBtn').addEventListener('click', () => {
  window.open(`${EXPORT_URL}?token=${encodeURIComponent(token)}&format=json`, '_blank');
});

document.getElementById('encEnableBtn').addEventListener('click', async () => {
  const pass = document.getElementById('encKeySetInput').value;
  if (!pass || pass.length < 4) { alert('Enter a key with at least 4 characters.'); return; }
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        // super users can always auto-unlock rooms; no per-room opt-out,
        // so the passphrase is always escrowed for them.
        token, action: 'set_encryption', enabled: true,
        passphrase: pass,
      }),
    });
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (!data.ok) { alert('Failed: ' + (data.error || 'unknown error')); return; }
    roomEncEnabled = true;
    roomEncSalt = data.encSalt;
    roomEncKey = await deriveRoomKey(pass, roomEncSalt);
    cacheRoomPassphrase(pass);
    document.getElementById('encKeySetInput').value = '';
    encPromptShown = true; // we just set it ourselves, no need to prompt
    updateEncKeyBtn();
    updateEncAdminUi();
    await fetchAll();
  } catch (e) { alert('Could not reach server.'); }
});

document.getElementById('encDisableBtn').addEventListener('click', async () => {
  if (!confirm('Disable encryption for this room? Future messages will be stored as plain text; already-encrypted messages will stay locked without the old key.')) return;
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, action: 'set_encryption', enabled: false }),
    });
    const data = await res.json();
    if (!res.ok) { await handleAuthError(data); return; }
    if (!data.ok) { alert('Failed: ' + (data.error || 'unknown error')); return; }
    roomEncEnabled = false;
    roomEncKey = null;
    clearCachedRoomPassphrase();
    updateEncKeyBtn();
    updateEncAdminUi();
    await fetchAll();
  } catch (e) { alert('Could not reach server.'); }
});

document.getElementById('saveTitleBtn').addEventListener('click', async () => {
  const title = document.getElementById('titleInput').value.trim();
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, action: 'set_title', title }),
    });
    const data = await res.json();
    if (data.ok) roomTitleEl.textContent = data.title || ('Room: ' + room);
    else alert('Failed: ' + (data.error || 'unknown error'));
  } catch (e) { alert('Could not reach server.'); }
});

document.getElementById('resetHostBtn').addEventListener('click', async () => {
  if (!confirm('Reset the host password for this room? The current host will be logged out and whoever logs in next as host sets a new password.')) return;
  try {
    const res = await fetch(ADMIN_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, action: 'reset_host_password' }),
    });
    const data = await res.json();
    alert(data.ok ? data.message : ('Failed: ' + (data.error || 'unknown error')));
  } catch (e) { alert('Could not reach server.'); }
});

document.getElementById('leaveBtn').addEventListener('click', () => forceLogout(null, true));

// ---------- Auto-rejoin on reload / auto-login on return visit ----------
(async function tryAutoRejoin() {
  // 1. Same-tab reload: sessionStorage still has a live session — cheapest path.
  const saved = sessionStorage.getItem('qc_session');
  if (saved) {
    try {
      const s = JSON.parse(saved);
      if (s.token && s.room && s.user && s.role) {
        enterChat({ token: s.token, role: s.role, user: s.user, room: s.room });
        return;
      }
    } catch (e) { /* fall through to remember-me */ }
  }

  // 2. New tab / browser restart: no session, but a remember-me token
  // may still be valid (30-day TTL vs. the 6-hour session).
  const rememberToken = localStorage.getItem('qc_remember');
  if (!rememberToken) return;
  try {
    const res = await fetch(AUTH_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'remember_login', rememberToken }),
    });
    const data = await res.json();
    if (data.ok) {
      saveRememberToken(data.rememberToken); // rotated — overwrite stored copy
      enterChat({ token: data.token, role: data.role, user: data.user, room: data.room });
    } else {
      clearRememberToken(); // expired or invalid — don't keep retrying it
    }
  } catch (e) { /* offline or server unreachable — just show the login screen */ }
})();

// Apply saved light/dark preference even on the login screen
if (localStorage.getItem('qc_light_mode') === '1') document.body.classList.add('light-mode');

</script>

<!-- Glass UI theme-switching: Nocturne / Aurora / Ember / Frost / Default.
     Loaded last so DOM (and the hamburger drawer's pill buttons) exist.
     The theme-switch control is inside the hamburger drawer — not at page top. -->
<script src="glass-theme.js?v=<?= ASSET_VER ?>"></script>
</body>
</html>
