# Login Page Templates

Two single-file, self-contained login pages — copy either one straight
into a project and it works with no build step. Both share the exact
same form logic (validation, password toggle, submit flow), so you can
swap one for the other without touching any JavaScript.

```
login-templates/
├── normal-login.html    ← clean, minimal, easy to re-skin
├── premium-login.html   ← glassmorphism + gold accent, premium feel
└── README.md
```

## Which one to use

- **`normal-login.html`** — a standard, no-frills sign-in card. Light
  background, one accent color, simple checkbox + link row. Built to
  need almost no changes: update the six values in the `:root` block at
  the top of the `<style>` tag (brand color, background, text color) and
  you're done.

- **`premium-login.html`** — same form, dressed up for a premium /
  paid-tier product. Built from three of the UI template styles:
  **Glassmorphism** (frosted card with `backdrop-filter: blur()`),
  **Animation/Motion** (slow-drifting gradient glow behind the card), and
  a **gold accent** used sparingly (badge, logo, button, links) so it
  reads as premium without turning the whole page gold. Includes a
  "Premium Access" badge, a toggle-switch instead of a checkbox, and a
  social sign-in row.

## Quick start

1. Copy whichever file you need into your project (or both — see
   "Using both together" below).
2. Rename it if you like, e.g. `login.html`.
3. Update the brand values at the top of the `<style>` block:

   ```css
   :root {
     --brand: #2563eb;   /* normal-login.html */
     /* or */
     --gold: #d4af37;    /* premium-login.html */
   }
   ```
4. Replace the placeholder `<div class="login-card__logo">` with your
   actual logo `<img>` if you have one.
5. Wire up real authentication: find `handleSubmit()` near the bottom of
   the `<script>` tag and replace the commented-out `setTimeout` demo
   block with a real `fetch()` call to your auth endpoint. Both files
   have the exact same function, with the real-request example already
   sketched out in a comment.

## Using both together (normal + premium tiers)

If your product has both free and premium users, the simplest approach
is to keep both files and route to the right one based on the user's
plan — e.g. `/login` → `normal-login.html`, `/login?tier=premium` (or a
plan flag from your backend) → `premium-login.html`. Since the JS logic
and form field IDs (`email`, `password`, `remember`, `loginForm`) are
identical in both files, your submit-handling code doesn't need to know
which template rendered it.

## What's included in the shared logic

- **Email validation** — simple pattern check for user-facing feedback;
  always re-validate on the server too.
- **Password validation** — minimum 8 characters, with the error message
  clearing live as soon as the user fixes it.
- **Show/hide password toggle**.
- **Submit flow** — disables the button and shows a spinner while
  "submitting," so users get immediate feedback and can't double-submit.

## Notes

- No external dependencies or build tools — open directly in a browser.
- `premium-login.html` references `Playfair Display` and `Inter` as the
  display/body fonts; without a webfont link they'll fall back to
  Georgia/system sans, which still looks fine. Add a Google Fonts
  `<link>` in `<head>` if you want the exact intended type pairing.
- Both templates respect `prefers-reduced-motion` — the premium
  template's background animation turns off automatically for users
  who've requested reduced motion.
