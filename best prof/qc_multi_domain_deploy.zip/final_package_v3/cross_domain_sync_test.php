<?php
// =============================================================================
// cross_domain_sync_test.php — ACTIVE multi-domain sync test
// =============================================================================
// Unlike db_production_audit.php (read-only, checked existing real data),
// this ACTIVELY exercises the cross-domain file-link mechanism for real:
//
//   STEP A (run this file on DOMAIN A — the "origin"):
//     Creates a real test file on THIS domain's local disk, registers it
//     via register_file_link() (the exact function upload.php uses for
//     real code/text uploads), and prints the resulting token.
//
//   STEP B (take that token, run this file on DOMAIN B or C — the
//     "reader" — passing it as ?token=... in the URL):
//     Calls resolve_file_link() to confirm the shared database can see
//     the row Domain A just wrote, confirms THIS domain correctly
//     recognizes it does NOT own the file (different domain), then
//     calls fetch_remote_file_bytes() — the EXACT function
//     download.php's real code path uses — to fetch the actual file
//     content from Domain A's download_internal.php and prints
//     whether the bytes came back correctly and matched.
//
// This is the test that was missing: db_production_audit.php could only
// confirm the DATABASE ROW exists across domains (since they share one
// DB, that part was never really in question) — it could NOT confirm
// the actual SERVER-TO-SERVER FETCH between two real, independently
// hosted domains actually works, since that requires two real domains
// to test between, which didn't exist until now.
//
// Uses a throwaway test file + row, cleaned up automatically at the end
// of Step B (or manually — see the cleanup note below if Step B is
// never run).
//
// DELETE FROM ALL DOMAINS once this passes.
// =============================================================================

header('Content-Type: application/json');
require_once __DIR__ . '/file_links.php';

$action = isset($_GET['action']) ? $_GET['action'] : (isset($_GET['token']) ? 'read' : 'write');

// =============================================================================
// STEP A — WRITE (run on the ORIGIN domain, no token in the URL)
// =============================================================================
if ($action === 'write') {
    if (!defined('THIS_DOMAIN') || THIS_DOMAIN === 'https://example.com') {
        echo json_encode(['ok' => false, 'step' => 'write', 'error' => 'THIS_DOMAIN is not set in db_config.php on this domain — cannot register a cross-domain link without it.']);
        exit;
    }

    $testContent = "Cross-domain sync test\nWritten by: " . THIS_DOMAIN . "\nAt: " . date('Y-m-d H:i:s') . "\nRandom marker: " . bin2hex(random_bytes(8)) . "\n";
    $filesDir = $GLOBALS['filesDir'] ?? (__DIR__ . '/files');
    $testDir = $filesDir . '/__cross_domain_test__';
    if (!is_dir($testDir)) @mkdir($testDir, 0755, true);
    $testFileName = 'sync_test_' . bin2hex(random_bytes(4)) . '.txt';
    $testPath = $testDir . '/' . $testFileName;

    if (@file_put_contents($testPath, $testContent) === false) {
        echo json_encode(['ok' => false, 'step' => 'write', 'error' => 'Could not write the test file to local disk on this domain — check file permissions on the files/ directory.']);
        exit;
    }

    try {
        $token = register_file_link($testPath, $testFileName, strlen($testContent), 'text/plain', null);
    } catch (Throwable $e) {
        echo json_encode(['ok' => false, 'step' => 'write', 'error' => 'register_file_link() failed: ' . $e->getMessage()]);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'step' => 'write',
        'origin_domain' => THIS_DOMAIN,
        'test_file_path' => $testPath,
        'expected_content_marker' => trim($testContent),
        'token' => $token,
        'next_step' => 'Copy this token. Upload this SAME file to a DIFFERENT domain (one sharing the same database), then visit: that-domain.com/cross_domain_sync_test.php?token=' . urlencode($token),
    ], JSON_PRETTY_PRINT);
    exit;
}

// =============================================================================
// STEP B — READ (run on a DIFFERENT domain, passing ?token=... from Step A)
// =============================================================================
if ($action === 'read') {
    $token = isset($_GET['token']) ? $_GET['token'] : '';
    if ($token === '') {
        echo json_encode(['ok' => false, 'step' => 'read', 'error' => 'No token provided.']);
        exit;
    }

    $result = ['ok' => false, 'step' => 'read', 'checks' => []];

    // Check 1: can this domain resolve the token via the shared database at all?
    $link = resolve_file_link($token);
    if (!$link) {
        $result['checks']['resolve_file_link'] = 'FAILED — token did not resolve to any row. Either FILE_LINK_SECRET differs between domains (must be IDENTICAL), or the row was never created, or it was already cleaned up.';
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit;
    }
    $result['checks']['resolve_file_link'] = 'ok — found the row, origin domain: ' . $link['domain'];

    // Check 2: does THIS domain correctly recognize it's NOT the owner?
    $isThisDomain = defined('THIS_DOMAIN') && rtrim($link['domain'], '/') === rtrim(THIS_DOMAIN, '/');
    if ($isThisDomain) {
        $result['checks']['domain_check'] = 'This IS the origin domain — re-run this on a DIFFERENT domain than the one you ran the write step on, to actually test the cross-domain path.';
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit;
    }
    $result['checks']['domain_check'] = 'ok — this domain (' . (defined('THIS_DOMAIN') ? THIS_DOMAIN : '?') . ') correctly recognizes the file belongs to ' . $link['domain'];

    // Check 3: the actual cross-domain fetch — the real mechanism
    // download.php uses in production, exercised here directly.
    $bytes = fetch_remote_file_bytes($link['domain'], $token);
    if ($bytes === null) {
        $result['checks']['fetch_remote_file_bytes'] = 'FAILED — could not reach ' . $link['domain'] . '/download_internal.php from this domain. Check: is download_internal.php actually uploaded there? Does this server allow outbound cURL to other domains (some hosts restrict this)? Check your PHP error log on THIS domain for the specific cURL error.';
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit;
    }
    $result['checks']['fetch_remote_file_bytes'] = 'ok — received ' . strlen($bytes) . ' bytes from ' . $link['domain'];
    $result['fetched_content'] = $bytes;

    $result['ok'] = true;
    $result['summary'] = 'Cross-domain sync CONFIRMED WORKING: this domain successfully fetched a real file from ' . $link['domain'] . " over the internet, server-to-server, using the shared database + encrypted link token.\nCompare 'fetched_content' above against the 'expected_content_marker' from Step A's output — they should match exactly.";

    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'Unknown action.']);
