<?php
// =============================================================================
// db_common.php — SQL-backed storage layer (Stage 2)
// =============================================================================
// Drop-in replacement for the file-based storage functions in common.php:
// read_config, write_config, read_messages, write_messages, append_message,
// find_message, next_message_id, delete_room, list_rooms, create_session,
// get_session, read_sessions/write_sessions.
//
// EVERY function here has the EXACT SAME NAME AND SIGNATURE as its
// file-based counterpart in common.php. This is the whole point: the
// ~100 other functions in common.php (ban_user, mute_user, create_poll,
// touch_presence, etc.) only ever receive a $config array, mutate it in
// memory, and rely on the CALLER to read/write it — they never touch
// disk or the database directly. So none of those, and none of
// admin.php/api.php/auth.php/etc., need to change AT ALL. Only which
// file gets require_once'd changes.
//
// HOW TO SWITCH THIS ON:
//   In common.php, find and DELETE (or comment out) these functions:
//     read_config, write_config, read_messages, write_messages,
//     append_message, find_message, next_message_id, delete_room,
//     list_rooms, read_sessions, write_sessions, create_session,
//     get_session
//   Then add this line AFTER common.php's own require_once (this file
//   depends on default_config() and active_presence(), both defined in
//   common.php — it must load second, not first):
//     require_once __DIR__ . '/db_common.php';
//   That's the entire migration for the code side. See migrate.php
//   (Stage 4) for moving your EXISTING JSON data into these tables —
//   don't flip this on in production before running that, or your
//   current rooms/messages/sessions will appear empty.
//
//   Also run sql/schema_stage2.sql once before deploying this file —
//   it adds a `username` column to `sessions` that auth.php's
//   super_login flow needs (discovered while building this file; not
//   in the original Stage 1 schema.sql).
// =============================================================================

require_once __DIR__ . '/db.php';

// ---------------------------------------------------------------------------
// Rooms — read_config() / write_config() / list_rooms() / delete_room()
// ---------------------------------------------------------------------------

// Columns stored as real, indexed table columns. Everything else in
// default_config() lives in extra_json instead — see schema.sql's
// comment on the rooms table for why (normalizing all 30+ nested
// fields into their own tables would be a much larger rewrite for
// little real gain, since they're always read/written as a unit
// alongside the room anyway).
const ROOM_REAL_COLUMNS = [
    'pinHash' => 'pin_hash',
    'hostPasswordHash' => 'host_password_hash',
    'title' => 'title',
    'createdAt' => 'created_at',
    'lastActivity' => 'last_activity',
    'encEnabled' => 'enc_enabled',
    'encSalt' => 'enc_salt',
    'encSuperRecovery' => 'enc_super_recovery',
    'isPremium' => 'is_premium',
    'premiumOwner' => 'premium_owner',
    'premiumTier' => 'premium_tier',
    'pinnedMessageId' => 'pinned_message_id',
];

// Looks up a room's internal numeric id from its slug — nearly every
// function below needs this first, since messages/presence are keyed
// by room_id (a real foreign key), not the room name string.
function db_room_id($room) {
    $row = db_one('SELECT id FROM rooms WHERE room = ?', [$room]);
    return $row ? (int)$row['id'] : null;
}

// Rebuilds the exact same associative array shape default_config()
// callers already expect, merging the real columns back in with
// whatever's in extra_json — so read_config()'s return value is
// byte-for-byte the same shape whether it came from a file or a row.
function db_row_to_config($row) {
    if (!$row) return null;
    $extra = json_decode($row['extra_json'] ?? '{}', true);
    if (!is_array($extra)) $extra = [];
    $config = array_merge(default_config(), $extra);
    foreach (ROOM_REAL_COLUMNS as $jsonKey => $col) {
        if (!array_key_exists($col, $row)) continue;
        $val = $row[$col];
        // MySQL returns TINYINT(1) as '0'/'1' strings via PDO — cast
        // booleans back so callers doing `if ($config['encEnabled'])`
        // get the same truthy/falsy behavior as the old JSON version.
        if (in_array($jsonKey, ['encEnabled', 'isPremium'], true)) $val = (bool)$val;
        if ($val !== null && in_array($jsonKey, ['createdAt', 'lastActivity', 'pinnedMessageId'], true)) $val = (int)$val;
        $config[$jsonKey] = $val;
    }
    $config['__room_id'] = (int)$row['id']; // internal use only (messages/presence lookups) — never read by existing code, so safe to add
    return $config;
}

function read_config($room) {
    $row = db_one('SELECT * FROM rooms WHERE room = ?', [$room]);
    return db_row_to_config($row);
}

function write_config($room, $config) {
    $now = now_ms();
    $existingId = db_room_id($room);

    // Split $config into the real columns + everything else (extra_json)
    $extra = $config;
    $colValues = [];
    foreach (ROOM_REAL_COLUMNS as $jsonKey => $col) {
        $colValues[$col] = $config[$jsonKey] ?? null;
        unset($extra[$jsonKey]);
    }
    unset($extra['__room_id']); // internal marker, never persisted
    $extraJson = json_encode($extra, JSON_UNESCAPED_UNICODE);

    if ($existingId === null) {
        // INSERT — new room
        $cols = array_merge(['room', 'extra_json'], array_keys($colValues));
        $placeholders = implode(', ', array_fill(0, count($cols), '?'));
        $values = array_merge([$room, $extraJson], array_values($colValues));
        // created_at must always be set on first insert
        if (empty($colValues['created_at'])) {
            $idx = array_search('created_at', $cols);
            if ($idx !== false) $values[$idx] = $now;
        }
        db_insert('INSERT INTO rooms (' . implode(', ', $cols) . ') VALUES (' . $placeholders . ')', $values);
        return true;
    }

    // UPDATE — existing room
    $setClauses = ['extra_json = ?'];
    $values = [$extraJson];
    foreach ($colValues as $col => $val) {
        $setClauses[] = "$col = ?";
        $values[] = $val;
    }
    $values[] = $existingId;
    db_exec('UPDATE rooms SET ' . implode(', ', $setClauses) . ' WHERE id = ?', $values);
    return true;
}

function list_rooms() {
    // ORDER BY removed here — sorting happens after the loop below,
    // matching the original file-based version exactly (sort by
    // lastActivity ?? createdAt, not by the raw column, since a room
    // with no lastActivity yet should sort by its createdAt instead).
    $rows = db_all('SELECT * FROM rooms');
    $out = [];
    foreach ($rows as $row) {
        $config = db_row_to_config($row);
        $slug = $row['room'];

        // Auto-cleanup — same check the file-based version ran inline,
        // skipping (and deleting) a room whose autoCleanupDays
        // threshold has passed.
        if (room_auto_cleanup_if_due($slug, $config)) continue;

        // Still exclude anything already marked pending-delete (the
        // manual "Delete room" undo-window flow, separate from
        // auto-cleanup above) — same behavior as before.
        if ($row['pending_delete_at'] !== null) continue;

        $msgCount = (int)(db_one('SELECT COUNT(*) as c FROM messages WHERE room_id = ?', [$row['id']])['c'] ?? 0);

        $out[] = [
            'room' => $slug,
            'title' => $config['title'] !== '' ? $config['title'] : $slug,
            'createdAt' => $config['createdAt'],
            'lastActivity' => $config['lastActivity'],
            'hostSet' => !empty($config['hostPasswordHash']),
            'pinSet' => !empty($config['pinHash']),
            'encEnabled' => !empty($config['encEnabled']),
            'activeUsers' => active_presence($config),
            'messageCount' => $msgCount,
            'bannedUserCount' => count($config['bannedUsers'] ?? []),
            'bannedIpCount' => count($config['bannedIps'] ?? []),
            'pendingDeleteAt' => $row['pending_delete_at'] !== null ? (int)$row['pending_delete_at'] : null,
        ];
    }
    usort($out, function ($a, $b) {
        $at = $a['lastActivity'] ?? $a['createdAt'] ?? 0;
        $bt = $b['lastActivity'] ?? $b['createdAt'] ?? 0;
        return $bt <=> $at;
    });
    return $out;
}

function delete_room($room) {
    // Uploaded files, remember-me tokens, and sessions for this room
    // still live outside the database (local disk / other tables the
    // schema doesn't cover) and need the SAME manual cleanup the
    // original file-based delete_room() did — only the room row +
    // messages themselves move to the database (messages cascade
    // automatically via the FK in schema.sql; files/tokens do not,
    // since they're not represented as rows here at all).
    $slug = safe_room_name($room);

    $dir = $GLOBALS['filesDir'] . '/' . $slug;
    if (is_dir($dir)) {
        $items = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($items as $item) {
            $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
        }
        @rmdir($dir);
    }

    // Remember tokens are still file-based (read_remember_tokens() /
    // write_remember_tokens() in common.php were not part of Stage 2 —
    // out of scope for this pass, called here as-is).
    if (function_exists('read_remember_tokens') && function_exists('write_remember_tokens')) {
        $tokens = read_remember_tokens();
        $changed = false;
        foreach ($tokens as $t => $tok) {
            if (isset($tok['room']) && $tok['room'] === $slug) { unset($tokens[$t]); $changed = true; }
        }
        if ($changed) write_remember_tokens($tokens);
    }

    // Sessions for this room — same DELETE the old version did via
    // read_sessions()/write_sessions(), done directly here instead
    // since it's a straightforward single query against the real table.
    db_exec('DELETE FROM sessions WHERE room = ?', [$slug]);

    // Finally, the room row itself — cascades to its messages
    // automatically via the FK in schema.sql.
    return db_exec('DELETE FROM rooms WHERE room = ?', [$room]) > 0;
}

function mark_room_pending_delete($room) {
    if (db_room_id($room) === null) return false;
    return db_exec('UPDATE rooms SET pending_delete_at = ? WHERE room = ?', [now_ms(), $room]) > 0;
}

function undo_room_delete($room) {
    $row = db_one('SELECT pending_delete_at FROM rooms WHERE room = ?', [$room]);
    if (!$row || $row['pending_delete_at'] === null) return false;
    return db_exec('UPDATE rooms SET pending_delete_at = NULL WHERE room = ?', [$room]) > 0;
}

function sweep_pending_deletes() {
    // Matches the old grace-period window used by the file-based
    // version — uses the same $GLOBALS['undoDeleteGraceMs'] (set in
    // common.php) rather than a hardcoded number, so this can never
    // silently drift out of sync if that value is ever changed.
    $graceMs = $GLOBALS['undoDeleteGraceMs'] ?? 10000;
    $cutoff = now_ms() - $graceMs;
    $rows = db_all('SELECT room FROM rooms WHERE pending_delete_at IS NOT NULL AND pending_delete_at < ?', [$cutoff]);
    foreach ($rows as $row) {
        delete_room($row['room']);
    }
}

// ---------------------------------------------------------------------------
// Messages — read_messages() / write_messages() / append_message() /
// find_message() / next_message_id()
// ---------------------------------------------------------------------------

function db_message_row_to_array($row) {
    return [
        'id' => (int)$row['local_id'],
        'user' => $row['user'],
        'role' => $row['role'],
        'type' => $row['type'],
        'text' => $row['text'],
        'fileUrl' => $row['file_url'],
        'fileName' => $row['file_name'],
        'fileSize' => $row['file_size'] !== null ? (int)$row['file_size'] : null,
        'fileCategory' => $row['file_category'],
        'fileExt' => $row['file_ext'],
        'isVoiceMessage' => (bool)($row['is_voice_message'] ?? false),
        'sentWhileEncrypted' => (bool)($row['sent_while_encrypted'] ?? false),
        'stickerId' => $row['sticker_id'],
        'stickerEmoji' => $row['sticker_emoji'],
        'pollId' => $row['poll_id'],
        'replyTo' => $row['reply_to_json'] ? json_decode($row['reply_to_json'], true) : null,
        'reactions' => $row['reactions_json'] ? json_decode($row['reactions_json'], true) : [],
        'edited' => (bool)$row['edited'],
        'editedAt' => $row['edited_at'] !== null ? (int)$row['edited_at'] : null,
        'deleted' => (bool)$row['deleted'],
        'ts' => (int)$row['ts'],
        'expiresAt' => $row['expires_at'] !== null ? (int)$row['expires_at'] : null,
    ];
}

// read_messages() previously returned the WHOLE room's message array
// (after purge_expired() dropped expired ones) — every caller that
// used this expects that same full-array shape back, so this keeps
// doing that rather than adding pagination, to avoid touching every
// call site. The real performance win here is still substantial: a
// single indexed SELECT instead of parsing a room's entire JSON file
// on every single request that touches messages at all.
//
// IMPORTANT — found on closer comparison against the real
// purge_expired(): there are TWO separate expiry mechanisms, not one.
//   1. expires_at column — per-message, used for scheduled/self-destruct
//      messages (already handled below).
//   2. A GLOBAL 24-hour blanket expiry ($GLOBALS['messageExpirySeconds'])
//      applied to EVERY message regardless of expires_at, PLUS deleting
//      the actual uploaded file from disk for any expired file-type
//      message. A first draft of this function only handled #1 and
//      completely missed #2 — every message in every room would have
//      stayed forever instead of aging out after 24 hours, and expired
//      file uploads would never have been cleaned up from disk.
// Runs both expiry mechanisms for a room — shared by every read
// variant below so history-window/since-based reads get the exact
// same expiry behavior as the original full read_messages(), not a
// weaker or different version of it.
function purge_expired_messages_for_room($roomId) {
    $now = now_ms();

    // #1 — per-message expiry (scheduled/self-destruct)
    db_exec('DELETE FROM messages WHERE room_id = ? AND expires_at IS NOT NULL AND expires_at < ?', [$roomId, $now]);

    // #2 — global blanket expiry, with file cleanup for expired
    // file-type messages, matching purge_expired()'s exact behavior.
    $expiryMs = ($GLOBALS['messageExpirySeconds'] ?? 86400) * 1000;
    $cutoffTs = $now - $expiryMs;
    $expiredFiles = db_all(
        "SELECT file_url FROM messages WHERE room_id = ? AND ts < ? AND type = 'file' AND file_url IS NOT NULL",
        [$roomId, $cutoffTs]
    );
    foreach ($expiredFiles as $row) {
        $path = __DIR__ . '/' . ltrim($row['file_url'], '/');
        if (is_file($path)) @unlink($path);
    }
    db_exec('DELETE FROM messages WHERE room_id = ? AND ts < ?', [$roomId, $cutoffTs]);
}

function read_messages($room) {
    $roomId = db_room_id($room);
    if ($roomId === null) return [];
    purge_expired_messages_for_room($roomId);
    $rows = db_all('SELECT * FROM messages WHERE room_id = ? ORDER BY local_id ASC', [$roomId]);
    return array_map('db_message_row_to_array', $rows);
}

// Poll-cycle read — every client polls every ~2.5s asking "anything
// newer than the last message id I have?" The original code answered
// this by calling read_messages() (reading and parsing the ENTIRE room
// history every single poll) and filtering in PHP afterward — fine on
// a small file, but it means poll cost grows with total room history
// forever, not with how much is actually new. This does the filtering
// in the SQL query itself instead, so a poll on a room with 50,000
// messages costs the same as one with 50.
function read_messages_since($room, $sinceId) {
    $roomId = db_room_id($room);
    if ($roomId === null) return [];
    purge_expired_messages_for_room($roomId);
    $rows = db_all('SELECT * FROM messages WHERE room_id = ? AND local_id > ? ORDER BY local_id ASC', [$roomId, $sinceId]);
    return array_map('db_message_row_to_array', $rows);
}

// Windowed history read for the WhatsApp-style "load older messages"
// feature. $beforeTs is exclusive (strictly older than this timestamp,
// ms epoch) — pass now_ms() for the initial "last hour" load, or the
// oldest ts already shown for "load the next hour back". Returns
// messages newest-first (caller prepends them to the top of the chat,
// which is the natural order for a "load older" scroll action), plus
// whether anything OLDER than this window still exists (so the
// frontend knows whether to show "no past chat" or let the user keep
// scrolling up for more).
function read_messages_window($room, $beforeTs, $windowMs) {
    $roomId = db_room_id($room);
    if ($roomId === null) return ['messages' => [], 'hasMore' => false];
    purge_expired_messages_for_room($roomId);
    $afterTs = $beforeTs - $windowMs;
    $rows = db_all(
        'SELECT * FROM messages WHERE room_id = ? AND ts < ? AND ts >= ? ORDER BY local_id DESC',
        [$roomId, $beforeTs, $afterTs]
    );
    $hasMoreRow = db_one('SELECT 1 as x FROM messages WHERE room_id = ? AND ts < ? LIMIT 1', [$roomId, $afterTs]);
    return [
        'messages' => array_reverse(array_map('db_message_row_to_array', $rows)), // oldest-first within the window, matching read_messages()'s own ordering convention
        'hasMore' => $hasMoreRow !== null,
    ];
}


// write_messages() previously took the WHOLE array and rewrote the
// file (also trimming to maxMessages). With a real table, individual
// inserts/updates (append_message, edit_message, toggle_reaction) are
// what actually change a row — this function is kept only for any
// remaining caller that replaces the entire array wholesale (e.g.
// clear_users_messages' bulk-delete path), implemented as a full
// replace to preserve that exact semantic.
function write_messages($room, $messages) {
    $roomId = db_room_id($room);
    if ($roomId === null) return false;
    db_transaction(function () use ($roomId, $messages) {
        db_exec('DELETE FROM messages WHERE room_id = ?', [$roomId]);
        foreach ($messages as $m) {
            db_insert_message_row($roomId, $m);
        }
    });
    // maxMessages trimming — same cap the old version enforced
    $max = $GLOBALS['maxMessages'] ?? 0;
    if ($max > 0) {
        $count = db_one('SELECT COUNT(*) as c FROM messages WHERE room_id = ?', [$roomId])['c'];
        if ($count > $max) {
            $excess = $count - $max;
            db_exec(
                'DELETE FROM messages WHERE room_id = ? ORDER BY local_id ASC LIMIT ?',
                [$roomId, $excess]
            );
        }
    }
    return true;
}

function db_insert_message_row($roomId, $m) {
    return db_insert(
        'INSERT INTO messages (room_id, local_id, user, role, type, text, file_url, file_name, file_size, file_category, file_ext, is_voice_message, sent_while_encrypted, sticker_id, sticker_emoji, poll_id, reply_to_json, reactions_json, edited, deleted, ts, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
            $roomId,
            $m['id'],
            $m['user'],
            $m['role'] ?? 'member',
            $m['type'] ?? 'text',
            $m['text'] ?? null,
            $m['fileUrl'] ?? null,
            $m['fileName'] ?? null,
            $m['fileSize'] ?? null,
            $m['fileCategory'] ?? null,
            $m['fileExt'] ?? null,
            !empty($m['isVoiceMessage']) ? 1 : 0,
            !empty($m['sentWhileEncrypted']) ? 1 : 0,
            $m['stickerId'] ?? null,
            $m['stickerEmoji'] ?? null,
            $m['pollId'] ?? null,
            isset($m['replyTo']) ? json_encode($m['replyTo'], JSON_UNESCAPED_UNICODE) : null,
            isset($m['reactions']) ? json_encode($m['reactions'], JSON_UNESCAPED_UNICODE) : json_encode([]),
            !empty($m['edited']) ? 1 : 0,
            !empty($m['deleted']) ? 1 : 0,
            $m['ts'] ?? now_ms(),
            $m['expiresAt'] ?? null,
        ]
    );
}

function next_message_id($messages) {
    // Kept for signature compatibility with any remaining caller, but
    // append_message() below no longer needs this — MySQL's own
    // auto-increment-per-room tracking (via MAX(local_id)+1, computed
    // inside the same transaction as the insert) replaces the old
    // "compute max of the in-memory array" approach, which is safe here
    // since it's still per-room, never global.
    $max = 0;
    foreach ($messages as $m) { if ($m['id'] > $max) $max = $m['id']; }
    return $max + 1;
}

function append_message($room, $msg) {
    $roomId = db_room_id($room);
    if ($roomId === null) return null;
    return db_transaction(function () use ($roomId, $msg, $room) {
        $row = db_one('SELECT COALESCE(MAX(local_id), 0) + 1 as next_id FROM messages WHERE room_id = ? FOR UPDATE', [$roomId]);
        $nextId = (int)$row['next_id'];
        $msg['id'] = $nextId;
        $msg['ts'] = $msg['ts'] ?? now_ms();
        db_insert_message_row($roomId, $msg);
        db_exec('UPDATE rooms SET last_activity = ? WHERE id = ?', [now_ms(), $roomId]);
        return $msg;
    });
}

function find_message($room, $id) {
    $roomId = db_room_id($room);
    if ($roomId === null) return null;
    $row = db_one('SELECT * FROM messages WHERE room_id = ? AND local_id = ?', [$roomId, $id]);
    return $row ? db_message_row_to_array($row) : null;
}

// Edits a message's text in place, but only if $username is the original
// sender (case-insensitive) — host/super do NOT get a bypass here, this
// is purely "edit your own message" like Discord/Slack. Returns the
// updated message array on success, the STRING 'too_late' if the
// 30-second edit window has passed, or null if not found / not the
// owner / not a text message (deliberately the same null for all three
// — the original comment: "don't leak which id existed").
// Return-type contract matches common.php's real edit_message() exactly
// — a first draft of this file used a completely different
// ['error'=>...]/['ok'=>true,...] shape, which every caller checking
// for the string 'too_late' or a bare null would have silently broken
// against.
function edit_message($room, $id, $username, $newText) {
    $roomId = db_room_id($room);
    if ($roomId === null) return null;
    $msg = find_message($room, $id);
    if (!$msg) return null;
    if (strtolower($msg['user']) !== strtolower($username)) return null;
    if ($msg['type'] !== 'text') return null;
    $ageMs = now_ms() - $msg['ts'];
    if ($ageMs > 30000) return 'too_late';
    $editedAt = now_ms();
    db_exec('UPDATE messages SET text = ?, edited = 1, edited_at = ? WHERE room_id = ? AND local_id = ?', [$newText, $editedAt, $roomId, $id]);
    return find_message($room, $id);
}

// Toggles $username's reaction with $emoji on a message. A user can only
// have ONE active reaction per message across ALL emojis — picking a
// new emoji replaces their old one; picking the SAME emoji again
// removes it (true toggle-off). A first draft of this file treated
// each emoji bucket independently, letting one user react with several
// different emojis at once on the same message — not what the original
// file-based version did.
function toggle_reaction($room, $messageId, $username, $emoji) {
    $roomId = db_room_id($room);
    if ($roomId === null) return null;
    return db_transaction(function () use ($roomId, $room, $messageId, $username, $emoji) {
        $row = db_one('SELECT reactions_json FROM messages WHERE room_id = ? AND local_id = ? FOR UPDATE', [$roomId, $messageId]);
        if (!$row) return null;
        $reactions = $row['reactions_json'] ? json_decode($row['reactions_json'], true) : [];
        if (!is_array($reactions)) $reactions = [];
        $userLower = strtolower($username);

        $hadThisEmoji = isset($reactions[$emoji]) && in_array($username, $reactions[$emoji], true);

        // Remove this user from EVERY emoji bucket first — this is what
        // enforces "only one active reaction per message."
        foreach ($reactions as $e => $users) {
            $reactions[$e] = array_values(array_filter($users, function ($u) use ($userLower) {
                return strtolower($u) !== $userLower;
            }));
            if (empty($reactions[$e])) unset($reactions[$e]);
        }

        // Re-add only if they weren't already reacting with this exact
        // emoji (i.e. this call was a toggle-off, not a switch).
        if (!$hadThisEmoji) {
            if (!isset($reactions[$emoji])) $reactions[$emoji] = [];
            $reactions[$emoji][] = $username; // original case preserved, matching the file-based version (only the comparison above is lowercased)
        }

        db_exec('UPDATE messages SET reactions_json = ? WHERE room_id = ? AND local_id = ?', [json_encode($reactions, JSON_UNESCAPED_UNICODE), $roomId, $messageId]);
        return find_message($room, $messageId);
    });
}

// Matches the file-based version exactly: case-insensitive substring
// match against text AND fileName, most-recent-first, capped at
// $limit, and — importantly — SKIPS any message whose text starts
// with 'encv1:' (an encrypted envelope the server can't read the
// contents of, so it can't honestly claim to have searched it). A
// first draft of this file used a SQL LIKE with no such exclusion and
// didn't search fileName at all.
function search_messages($room, $query, $limit = 50) {
    $query = trim((string)$query);
    if ($query === '') return [];
    $roomId = db_room_id($room);
    if ($roomId === null) return [];
    $lowerQuery = mb_strtolower($query);
    // Pull candidates most-recent-first and filter in PHP (not pure
    // SQL LIKE) so the encv1: exclusion and the "search fileName too"
    // behavior match the original exactly — a wider LIMIT than the
    // final result count accounts for rows this loop will skip.
    $rows = db_all('SELECT * FROM messages WHERE room_id = ? ORDER BY local_id DESC LIMIT ?', [$roomId, max($limit * 4, 200)]);
    $results = [];
    foreach ($rows as $row) {
        if (count($results) >= $limit) break;
        $haystack = ($row['text'] ?? '') . ' ' . ($row['file_name'] ?? '');
        if (strpos($row['text'] ?? '', 'encv1:') === 0) continue;
        if (mb_strpos(mb_strtolower($haystack), $lowerQuery) !== false) {
            $results[] = db_message_row_to_array($row);
        }
    }
    return $results;
}

// Deletes this user's messages in the room AND their uploaded files
// from disk (matching the file-based version, which unlinked the
// actual file for any type='file' message being removed) — a first
// draft of this file only deleted the database rows, which would have
// left every one of that user's uploaded files as permanent orphans
// on disk with nothing ever cleaning them up.
function clear_users_messages($room, $username) {
    $roomId = db_room_id($room);
    if ($roomId === null) return 0;
    $uname = strtolower(trim($username));
    $rows = db_all("SELECT local_id, type, file_url FROM messages WHERE room_id = ? AND LOWER(user) = ?", [$roomId, $uname]);
    foreach ($rows as $row) {
        if ($row['type'] === 'file' && !empty($row['file_url'])) {
            $path = __DIR__ . '/' . ltrim($row['file_url'], '/');
            if (is_file($path)) @unlink($path);
        }
    }
    return db_exec("DELETE FROM messages WHERE room_id = ? AND LOWER(user) = ?", [$roomId, $uname]);
}

// ---------------------------------------------------------------------------
// Sessions — create_session() / get_session() / read_sessions() /
// write_sessions() / remove_sessions_for_user() / remove_host_sessions()
// ---------------------------------------------------------------------------
// Rewritten to match the ORIGINAL file-based semantics exactly, after
// finding real discrepancies on close comparison against common.php:
//   - expires is stored/compared in SECONDS (time()), not milliseconds
//     (now_ms()) — the first draft of this file used ms throughout,
//     which would have made every session look expired (or never
//     expire) depending on which direction the mismatch went.
//   - $GLOBALS['sessionTtlSeconds'] is the real global name (6 hours),
//     not a nonexistent 'sessionTtlMs'.
//   - get_session() SLIDES the expiry forward on every successful read
//     (an active session never times out while in use) — the first
//     draft never did this at all.
//   - remove_host_sessions() only removes role 'host', not 'host' OR
//     'super' — the first draft incorrectly included 'super' too.
//   - room comparisons use safe_room_name($room) on the input, matching
//     what the file-based version normalized against.
// ---------------------------------------------------------------------------

function create_session($room, $user, $role) {
    $token = bin2hex(random_bytes(16));
    $now = time();
    $roomSlug = ($room === $GLOBALS['MASTER_ROOM']) ? $GLOBALS['MASTER_ROOM'] : safe_room_name($room);
    db_insert(
        'INSERT INTO sessions (token, room, user, role, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?)',
        [$token, $roomSlug, $user, $role, $now, $now + $GLOBALS['sessionTtlSeconds']]
    );
    return $token;
}

// read_sessions()/write_sessions() — auth.php's super_login flow reads
// the whole sessions collection as a raw associative array
// (token => {room, user, role, tier, username, expires, ...}), patches
// in extra fields (tier, username) AFTER create_session() already ran,
// and writes the whole thing back — bypassing create_session()/
// get_session() entirely for that one step. These two functions exist
// so that bypass-the-clean-API pattern keeps working unchanged.
function read_sessions() {
    $rows = db_all('SELECT * FROM sessions');
    $out = [];
    $now = time();
    foreach ($rows as $row) {
        // Matches the file version's own lazy-cleanup behavior (expired
        // entries were skipped/dropped when the whole file was re-read
        // and re-written) — expired rows are deleted here rather than
        // included in the returned array.
        if ((int)$row['expires_at'] < $now) {
            db_exec('DELETE FROM sessions WHERE token = ?', [$row['token']]);
            continue;
        }
        $out[$row['token']] = [
            'room' => $row['room'],
            'user' => $row['user'],
            'role' => $row['role'],
            'tier' => $row['tier'],
            'username' => $row['username'],
            'expires' => (int)$row['expires_at'],
        ];
    }
    return $out;
}

function write_sessions($sessions) {
    // Whole-collection overwrite, matching the old file-based semantic
    // exactly: auth.php reads the full set, mutates one entry's tier/
    // username, and calls this to persist ALL of them back — including
    // entries it never touched.
    db_transaction(function () use ($sessions) {
        db_exec('DELETE FROM sessions');
        foreach ($sessions as $token => $s) {
            db_insert(
                'INSERT INTO sessions (token, room, user, role, tier, username, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $token,
                    $s['room'],
                    $s['user'],
                    $s['role'],
                    $s['tier'] ?? null,
                    $s['username'] ?? null,
                    $s['createdAt'] ?? time(),
                    $s['expires'] ?? (time() + $GLOBALS['sessionTtlSeconds']),
                ]
            );
        }
    });
    return true;
}

function get_session($token) {
    if (!$token) return null;
    $row = db_one('SELECT * FROM sessions WHERE token = ?', [$token]);
    if (!$row) return null;
    $now = time();
    if ((int)$row['expires_at'] < $now) {
        db_exec('DELETE FROM sessions WHERE token = ?', [$token]);
        return null;
    }
    // Sliding expiry — an active session never times out while in use,
    // matching the original file-based get_session() exactly.
    $newExpires = $now + $GLOBALS['sessionTtlSeconds'];
    db_exec('UPDATE sessions SET expires_at = ? WHERE token = ?', [$newExpires, $token]);
    return [
        'room' => $row['room'],
        'user' => $row['user'],
        'role' => $row['role'],
        'tier' => $row['tier'] ?? null,
        'username' => $row['username'] ?? null,
        'expires' => $newExpires,
    ];
}

function remove_sessions_for_user($room, $username) {
    $room = safe_room_name($room);
    $uname = strtolower(trim($username));
    return db_exec(
        'DELETE FROM sessions WHERE room = ? AND LOWER(user) = ?',
        [$room, $uname]
    );
}

function remove_host_sessions($room) {
    // Only role 'host' — NOT 'super' too (the original file-based
    // version explicitly excludes super sessions from this cleanup).
    $room = safe_room_name($room);
    return db_exec("DELETE FROM sessions WHERE room = ? AND role = 'host'", [$room]);
}
