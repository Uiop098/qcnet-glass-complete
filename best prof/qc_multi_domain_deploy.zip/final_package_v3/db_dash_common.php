<?php
// =============================================================================
// db_dash_common.php — SQL-backed replacement for get_secure_table() /
// save_secure_table() (Stage 2, dashboard side)
// =============================================================================
// dash_crypto.php's get_secure_table($path) / save_secure_table($path, $data)
// are called with 20+ different file paths across dash_*.php — users.json,
// payments.json, products.json, tenants.json, master.json, and many more,
// one per tenant folder. Every call site treats the return value as a
// plain associative array and never cares WHERE it's actually stored.
//
// This file keeps that exact interface (same function names, same
// $path argument used as-is — including tenant folder paths — as the
// lookup key) but backs it with the `secure_tables` table instead of a
// file on disk.
//
// IMPORTANT — encryption key change, not just storage location:
// the original dash_crypto.php auto-generates a random DASH_ENC_KEY
// once per deployment (data_dash/sys_key.php) — meaning every domain
// currently has its OWN independent key. That's fine for isolated
// per-domain files, but breaks the moment this data is shared: if
// siteA encrypts a row with its own key and siteB reads the same row
// from the shared database, siteB's different key can't decrypt it.
// So this file defines its OWN dash_encrypt_data()/dash_decrypt_data()
// using DASH_ENC_KEY_SHARED from db_config.php instead — a single key
// you set once and copy to every domain's config, exactly like
// FILE_LINK_SECRET. The original per-domain sys_key.php path is no
// longer used once this file is active.
//
// HOW TO SWITCH THIS ON:
//   Add DASH_ENC_KEY_SHARED to every domain's db_config.php (see
//   db_config.example.php — generate one 64-char hex value, use the
//   SAME one everywhere, exactly like FILE_LINK_SECRET).
//   In each of the 8 files that currently have:
//     require_once __DIR__ . '/dash_crypto.php';
//   change that single line to:
//     require_once __DIR__ . '/db_dash_common.php';
//   That's it for those 8 files — no other line needs to change,
//   since this file provides dash_encrypt_data()/dash_decrypt_data()/
//   get_secure_table()/save_secure_table() under the same names.
//   dash_crypto.php itself is no longer loaded at all once this swap
//   is made, so its old auto-generated per-domain key stops being used
//   automatically — no separate edit needed there.
//   Run sql/schema.sql (the secure_tables table is appended at the end
//   of that file) before deploying this.
// =============================================================================

require_once __DIR__ . '/db.php';

if (!defined('DASH_ENC_KEY_SHARED') || DASH_ENC_KEY_SHARED === 'CHANGE_ME_TO_A_RANDOM_64_CHAR_HEX_STRING_SHARED_ACROSS_ALL_DOMAINS') {
    http_response_code(500);
    die(json_encode([
        'ok' => false,
        'error' => 'dash_enc_key_missing',
        'message' => 'DASH_ENC_KEY_SHARED is not set in db_config.php. Generate one random value and use it on every domain — see db_config.example.php.',
    ]));
}
define('DASH_ENC_KEY', hex2bin(DASH_ENC_KEY_SHARED));

// Identical logic to the original dash_crypto.php versions — only the
// key source changed (DASH_ENC_KEY is now derived from the shared
// config above, not a per-domain auto-generated file).
function dash_encrypt_data($data) {
    $json = json_encode($data, JSON_PRETTY_PRINT);
    $iv = openssl_random_pseudo_bytes(16);
    return base64_encode($iv . openssl_encrypt($json, 'aes-256-cbc', DASH_ENC_KEY, OPENSSL_RAW_DATA, $iv));
}

function dash_decrypt_data($content) {
    if (!$content) return [];
    $content = trim($content);
    if ($content === '') return [];
    if ($content[0] === '[' || $content[0] === '{') return json_decode($content, true) ?: [];
    $raw = base64_decode($content, true);
    if ($raw && strlen($raw) > 16) {
        $iv = substr($raw, 0, 16);
        $cipher = substr($raw, 16);
        $decrypted = openssl_decrypt($cipher, 'aes-256-cbc', DASH_ENC_KEY, OPENSSL_RAW_DATA, $iv);
        if ($decrypted) return json_decode($decrypted, true) ?: [];
    }
    return [];
}

function get_secure_table($path) {
    $row = db_one('SELECT data_encrypted FROM secure_tables WHERE path_key = ?', [$path]);
    if (!$row) return [];
    return dash_decrypt_data($row['data_encrypted']);
}

function save_secure_table($path, $data) {
    $encrypted = dash_encrypt_data($data);
    $now = now_ms();
    // INSERT ... ON DUPLICATE KEY UPDATE — single round trip, no need
    // to SELECT-then-decide-insert-or-update separately. path_key being
    // the PRIMARY KEY is what makes this atomic and race-safe when two
    // requests (potentially from different domains, since this table
    // is shared) write the same path at nearly the same time.
    db_exec(
        'INSERT INTO secure_tables (path_key, data_encrypted, updated_at) VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE data_encrypted = VALUES(data_encrypted), updated_at = VALUES(updated_at)',
        [$path, $encrypted, $now]
    );
    return true;
}
