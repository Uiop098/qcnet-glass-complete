<?php
$GLOBALS['dataDir'] = __DIR__ . '/data';
$GLOBALS['filesDir'] = __DIR__ . '/files';
$GLOBALS['maxMessages'] = 3000;
$GLOBALS['messageExpirySeconds'] = 24 * 60 * 60; // REVERTED TO 24 HOURS AS REQUESTED
$GLOBALS['sessionTtlSeconds'] = 6 * 60 * 60; 
$GLOBALS['presenceWindowMs'] = 10000; 
$GLOBALS['MASTER_ROOM'] = '__super_master__'; 
$GLOBALS['linkPreviewCacheSeconds'] = 6 * 60 * 60; 
$GLOBALS['messageEditWindowSeconds'] = null; 

if (!defined('SUPER_MASTER_SECRET')) { define('SUPER_MASTER_SECRET', 'CHANGE-ME-a8f3k2m9x7q1w5e0r4t6y8u2i0o3p9-CHANGE-ME'); }
require_once __DIR__ . '/firewall.php';

if (is_ip_blocked(get_client_ip())) {
    http_response_code(403); header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'blocked', 'message' => 'Your connection has been blocked from this site.']); exit;
}

if (!is_dir($GLOBALS['dataDir'])) { mkdir($GLOBALS['dataDir'], 0755, true); }
if (!is_dir($GLOBALS['filesDir'])) { mkdir($GLOBALS['filesDir'], 0755, true); }
$dataHtaccess = $GLOBALS['dataDir'] . '/.htaccess';
if (!file_exists($dataHtaccess)) { @file_put_contents($dataHtaccess, "Require all denied\n"); }
$filesHtaccessExpected = "Require all denied\nHeader set Content-Disposition \"attachment\"\n";
$filesHtaccess = $GLOBALS['filesDir'] . '/.htaccess';
if (!file_exists($filesHtaccess) || file_get_contents($filesHtaccess) !== $filesHtaccessExpected) { @file_put_contents($filesHtaccess, $filesHtaccessExpected); }

function now_ms() { return round(microtime(true) * 1000); }
function safe_room_name($room) { $room = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$room); return substr($room, 0, 64) ?: 'default'; }
function room_file($room) { return $GLOBALS['dataDir'] . '/room_' . safe_room_name($room) . '.json'; }
function room_config_file($room) { return $GLOBALS['dataDir'] . '/config_' . safe_room_name($room) . '.json'; }
function sessions_file() { return $GLOBALS['dataDir'] . '/sessions.json'; }
function remember_tokens_file() { return $GLOBALS['dataDir'] . '/remember_tokens.json'; }
function room_files_dir($room) { $dir = $GLOBALS['filesDir'] . '/' . safe_room_name($room); if (!is_dir($dir)) mkdir($dir, 0755, true); return $dir; }

function ext_mime_candidates($ext) { return []; } 
function safe_download_mime($ext) { return 'application/octet-stream'; }
function verify_file_format($path, $ext) { return true; }
function code_and_text_exts() { return []; }
function looks_like_safe_text($path) { return true; }
function room_wallpapers_dir($room) { return room_files_dir($room) . '/wallpapers'; }

function read_json_file($path) {
    if (!file_exists($path)) return null;
    $fp = fopen($path, 'r'); if (!$fp) return null;
    flock($fp, LOCK_SH); $content = stream_get_contents($fp); flock($fp, LOCK_UN); fclose($fp);
    return json_decode($content, true);
}
function write_json_file($path, $data) {
    $fp = fopen($path, 'c+'); if (!$fp) return false;
    flock($fp, LOCK_EX); ftruncate($fp, 0); rewind($fp); fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE)); fflush($fp); flock($fp, LOCK_UN); fclose($fp);
    return true;
}

function super_credentials_file() { return $GLOBALS['dataDir'] . '/super_credentials.json'; }
function read_super_credentials() {
    $data = read_json_file(super_credentials_file());
    if (!is_array($data)) $data = [];
    $master_file = __DIR__ . '/data_dash/master.json';
    if (file_exists($master_file)) {
        $masters = json_decode(@file_get_contents($master_file), true);
        if (is_array($masters)) { foreach ($masters as $u => $m) { $data[$u] = ['passwordHash' => $m['password_hash'], 'displayName' => 'Master Admin']; } }
    }
    $tenants_file = __DIR__ . '/data_dash/tenants.json';
    if (file_exists($tenants_file)) {
        $tenants = json_decode(@file_get_contents($tenants_file), true);
        if (is_array($tenants)) { foreach ($tenants as $u => $t) { $data[$u] = ['passwordHash' => $t['password_hash'], 'displayName' => $t['name'] ?? $u]; } }
    }
    return $data;
}
function write_super_credentials($store) { return write_json_file(super_credentials_file(), $store); }
function is_super_account_active($entry) { if (empty($entry['expiresAt'])) return true; return now_ms() < $entry['expiresAt']; }

function default_config() { return ['bannedUsers'=>[], 'bannedIps'=>[], 'userIps'=>[], 'mutedUsers'=>[], 'presence'=>[], 'encEnabled'=>false, 'fileRequests'=>[], 'extraUploads'=>[], 'bannedWords'=>[], 'scheduledMessages'=>[], 'polls'=>[], 'reports'=>[], 'coHosts'=>[], 'coSupers'=>[]]; }
function read_config($room) { $d = read_json_file(room_config_file($room)); return $d ? array_merge(default_config(), $d) : null; }
function write_config($room, $config) { return write_json_file(room_config_file($room), $config); }
function purge_expired($room, $messages) {
    $expiryMs = $GLOBALS['messageExpirySeconds'] * 1000; $nowMs = now_ms(); $changed = false; $kept = [];
    foreach ($messages as $m) {
        if (($nowMs - ($m['ts'] ?? 0)) > $expiryMs) { $changed = true; if (isset($m['fileUrl'])) @unlink(__DIR__ . '/' . ltrim($m['fileUrl'], '/')); } else { $kept[] = $m; }
    }
    if ($changed) write_messages($room, $kept); return $kept;
}
function read_messages($room) { return purge_expired($room, read_json_file(room_file($room)) ?: []); }
function write_messages($room, $messages) { if (count($messages) > $GLOBALS['maxMessages']) $messages = array_slice($messages, -$GLOBALS['maxMessages']); return write_json_file(room_file($room), $messages); }
function get_client_ip() { return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; }
?>