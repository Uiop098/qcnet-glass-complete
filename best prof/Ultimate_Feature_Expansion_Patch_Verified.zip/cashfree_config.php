<?php
define('CF_APP_ID', 'TEST_YOUR_CASHFREE_APP_ID');          
define('CF_SECRET_KEY', 'TEST_YOUR_CASHFREE_SECRET_KEY');  
define('CF_ENV', 'PROD');                                  
define('CF_API_VERSION', '2023-08-01');
define('PANEL_PRICE_INR', 1.00);                           

function cf_base_url() {
    return (CF_ENV === 'PROD') ? 'https://api.cashfree.com/pg' : 'https://sandbox.cashfree.com/pg';
}
?>