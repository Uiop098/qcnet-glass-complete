<?php
require_once __DIR__ . '/../includes/require_login.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$order_id = $_POST['razorpay_order_id'] ?? '';
$payment_id = $_POST['razorpay_payment_id'] ?? '';
$signature = $_POST['razorpay_signature'] ?? '';

if (!$order_id || !$payment_id || !$signature) {
    echo json_encode(['success' => false, 'error' => 'Missing payment data']);
    exit;
}

// Verify signature: expected_signature = HMAC_SHA256(order_id + "|" + payment_id, key_secret)
$expected_signature = hash_hmac('sha256', $order_id . '|' . $payment_id, RAZORPAY_KEY_SECRET);

if (!hash_equals($expected_signature, $signature)) {
    // Mark as failed
    $stmt = $conn->prepare("UPDATE payments SET status = 'failed', payment_id = ? WHERE order_id = ?");
    $stmt->bind_param("ss", $payment_id, $order_id);
    $stmt->execute();

    echo json_encode(['success' => false, 'error' => 'Signature verification failed']);
    exit;
}

// Signature valid - mark payment successful
$stmt = $conn->prepare("UPDATE payments SET status = 'success', payment_id = ? WHERE order_id = ? AND user_id = ?");
$stmt->bind_param("ssi", $payment_id, $order_id, $_SESSION['user_id']);
$stmt->execute();

// Upgrade user - extend from now, or from current expiry if still active
$stmt = $conn->prepare("SELECT membership_expires_at FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

$base_time = time();
if ($row['membership_expires_at'] !== null && strtotime($row['membership_expires_at']) > $base_time) {
    $base_time = strtotime($row['membership_expires_at']); // extend existing membership
}
$new_expiry = date('Y-m-d H:i:s', $base_time + (MEMBERSHIP_DURATION_DAYS * 86400));

$stmt = $conn->prepare("UPDATE users SET membership_status = 'super_user', membership_expires_at = ? WHERE id = ?");
$stmt->bind_param("si", $new_expiry, $_SESSION['user_id']);
$stmt->execute();

echo json_encode(['success' => true, 'expires_at' => $new_expiry]);
