<?php
require_once __DIR__ . '/../includes/require_login.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$amount_paise = MEMBERSHIP_PRICE_INR * 100; // Razorpay uses paise
$receipt = 'qc_' . $_SESSION['user_id'] . '_' . time();

$payload = json_encode([
    'amount' => $amount_paise,
    'currency' => 'INR',
    'receipt' => $receipt,
]);

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_USERPWD => RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET,
    CURLOPT_TIMEOUT => 15,
]);
$response = curl_exec($ch);
$curl_error = curl_error($ch);
curl_close($ch);

if ($curl_error) {
    // InfinityFree free tier sometimes blocks outbound cURL.
    // If this fires, check the InfinityFree forum / consider a paid plan.
    echo json_encode(['success' => false, 'error' => 'Connection to Razorpay failed: ' . $curl_error]);
    exit;
}

$order = json_decode($response, true);

if (!isset($order['id'])) {
    echo json_encode(['success' => false, 'error' => 'Could not create order', 'raw' => $order]);
    exit;
}

// Log the pending order
$stmt = $conn->prepare("INSERT INTO payments (user_id, gateway, order_id, amount, status) VALUES (?, 'razorpay', ?, ?, 'created')");
$amount_rupees = MEMBERSHIP_PRICE_INR;
$stmt->bind_param("isd", $_SESSION['user_id'], $order['id'], $amount_rupees);
$stmt->execute();

echo json_encode([
    'success' => true,
    'order_id' => $order['id'],
    'amount' => $amount_paise,
    'key' => RAZORPAY_KEY_ID,
]);
