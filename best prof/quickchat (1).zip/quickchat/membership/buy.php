<?php
require_once __DIR__ . '/../includes/require_login.php';
require_once __DIR__ . '/../config/db.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>Buy Super User - Quick Chat</title>
  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
  <style>
    body { font-family: sans-serif; max-width: 500px; margin: 40px auto; text-align: center; }
    #payBtn { padding: 12px 24px; font-size: 16px; background: #b8860b; color: white; border: none; border-radius: 6px; cursor: pointer; }
    #status { margin-top: 15px; }
  </style>
</head>
<body>
  <h2>Become a Super User</h2>
  <p>₹<?= MEMBERSHIP_PRICE_INR ?> for <?= MEMBERSHIP_DURATION_DAYS ?> days of Super User perks.</p>
  <button id="payBtn">Pay with Razorpay</button>
  <div id="status"></div>
  <p><a href="../chat/index.php">&larr; Back to chat</a></p>

  <script>
    document.getElementById('payBtn').addEventListener('click', async () => {
      const statusEl = document.getElementById('status');
      statusEl.innerText = 'Creating order...';

      const orderRes = await fetch('create_order.php', { method: 'POST' });
      const order = await orderRes.json();

      if (!order.success) {
        statusEl.innerText = 'Error: ' + order.error;
        return;
      }

      const options = {
        key: order.key,
        amount: order.amount,
        currency: 'INR',
        name: 'Quick Chat',
        description: 'Super User Membership',
        order_id: order.order_id,
        handler: async function (response) {
          statusEl.innerText = 'Verifying payment...';
          const verifyRes = await fetch('verify_payment.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams(response).toString()
          });
          const result = await verifyRes.json();
          if (result.success) {
            statusEl.innerText = 'Success! Super User until ' + result.expires_at;
            setTimeout(() => window.location.href = '../chat/index.php', 1500);
          } else {
            statusEl.innerText = 'Verification failed: ' + result.error;
          }
        },
        theme: { color: '#b8860b' }
      };

      const rzp = new Razorpay(options);
      rzp.open();
    });
  </script>
</body>
</html>
