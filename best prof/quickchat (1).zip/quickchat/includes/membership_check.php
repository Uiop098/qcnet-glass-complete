<?php
// Call this AFTER db.php and require_login.php are included,
// and after $_SESSION['user_id'] is confirmed to exist.
// No cron jobs on InfinityFree's free tier, so we check on every page load instead.

$stmt = $conn->prepare("SELECT membership_status, membership_expires_at FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$is_super_user = false;

if ($user && $user['membership_status'] === 'super_user') {
    if ($user['membership_expires_at'] !== null && strtotime($user['membership_expires_at']) < time()) {
        // Expired - downgrade
        $downgrade = $conn->prepare("UPDATE users SET membership_status = 'free', membership_expires_at = NULL WHERE id = ?");
        $downgrade->bind_param("i", $_SESSION['user_id']);
        $downgrade->execute();
        $is_super_user = false;
    } else {
        $is_super_user = true;
    }
}
