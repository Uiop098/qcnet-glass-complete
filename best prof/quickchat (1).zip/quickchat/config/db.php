<?php
// ============================================
// Fill these in with YOUR InfinityFree details.
// Find them in: Control Panel > MySQL Databases
// ============================================
$DB_HOST = "sqlXXX.infinityfree.com";      // your MySQL hostname
$DB_USER = "epiz_XXXXXXXX_username";       // your MySQL username
$DB_PASS = "your_password";                 // same as your hosting account password
$DB_NAME = "epiz_XXXXXXXX_dbname";         // your database name

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Razorpay keys (get from https://dashboard.razorpay.com/app/keys)
define('RAZORPAY_KEY_ID', 'rzp_test_XXXXXXXXXX');
define('RAZORPAY_KEY_SECRET', 'your_razorpay_secret');

// Membership price and duration
define('MEMBERSHIP_PRICE_INR', 199);       // amount in rupees
define('MEMBERSHIP_DURATION_DAYS', 30);
