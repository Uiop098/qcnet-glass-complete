<?php
require_once __DIR__ . '/../includes/require_login.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/membership_check.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>Quick Chat</title>
  <style>
    body { font-family: sans-serif; max-width: 600px; margin: 20px auto; }
    #messages { border: 1px solid #ccc; height: 350px; overflow-y: auto; padding: 10px; }
    .msg { margin-bottom: 8px; }
    .super { color: #b8860b; font-weight: bold; }
    #msgForm { display: flex; gap: 8px; margin-top: 10px; }
    #msgInput { flex: 1; }
  </style>
</head>
<body>
  <h2>Quick Chat</h2>
  <p>
    Logged in as <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>
    <?php if ($is_super_user): ?>
      <span class="super">★ Super User</span>
    <?php else: ?>
      — <a href="../membership/buy.php">Upgrade to Super User</a>
    <?php endif; ?>
    | <a href="../auth/logout.php">Logout</a>
  </p>

  <div id="messages"></div>

  <form id="msgForm">
    <input type="text" id="msgInput" placeholder="Type a message..." required>
    <button type="submit">Send</button>
  </form>

  <script>
    async function loadMessages() {
      const res = await fetch('get_messages.php');
      const data = await res.json();
      const box = document.getElementById('messages');
      box.innerHTML = data.map(m => `
        <div class="msg">
          <span class="${m.membership_status === 'super_user' ? 'super' : ''}">${m.username}${m.membership_status === 'super_user' ? ' ★' : ''}:</span>
          ${escapeHtml(m.message)}
        </div>
      `).join('');
      box.scrollTop = box.scrollHeight;
    }

    function escapeHtml(str) {
      const div = document.createElement('div');
      div.innerText = str;
      return div.innerHTML;
    }

    document.getElementById('msgForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const input = document.getElementById('msgInput');
      const message = input.value.trim();
      if (!message) return;

      await fetch('send_message.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'message=' + encodeURIComponent(message)
      });
      input.value = '';
      loadMessages();
    });

    loadMessages();
    setInterval(loadMessages, 3000); // poll every 3s
  </script>
</body>
</html>
