<?php
require_once __DIR__ . '/../includes/require_login.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$message = trim($_POST['message'] ?? '');

if ($message === '') {
    echo json_encode(['success' => false, 'error' => 'Empty message']);
    exit;
}

// Example super_user perk: allow longer messages
require_once __DIR__ . '/../includes/membership_check.php';
$max_length = $is_super_user ? 2000 : 300;

if (strlen($message) > $max_length) {
    echo json_encode(['success' => false, 'error' => "Message too long (max $max_length chars)"]);
    exit;
}

$stmt = $conn->prepare("INSERT INTO messages (user_id, message) VALUES (?, ?)");
$stmt->bind_param("is", $_SESSION['user_id'], $message);
$stmt->execute();

echo json_encode(['success' => true]);
