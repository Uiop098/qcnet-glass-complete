<?php
require_once __DIR__ . '/../includes/require_login.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$sql = "SELECT m.id, m.message, m.created_at, u.username, u.membership_status
        FROM messages m
        JOIN users u ON u.id = m.user_id
        ORDER BY m.id DESC
        LIMIT 50";

$result = $conn->query($sql);
$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

echo json_encode(array_reverse($messages));
