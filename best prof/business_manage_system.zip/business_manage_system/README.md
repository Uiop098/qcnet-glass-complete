# Business Manage System — Authentication & Two-Factor Verification

This project implements the Phase 1 authentication system from your
`BizManage — Complete Multi-Method Authentication Master Plan`:

- Email + password registration and login
- Email verification (6-digit OTP)
- Password reset (single-use, expiring HTTPS token link)
- TOTP two-factor authentication (Google Authenticator, Microsoft
  Authenticator, 2FAS, etc.) with QR + manual setup key
- Backup/recovery codes (10 per user, one-time use, regenerable)
- Secure PHP sessions (HttpOnly, Secure, SameSite, regenerated on
  privilege change)
- CSRF protection on every state-changing request
- Rate limiting on login, OTP, TOTP, backup-code, and reset endpoints
- Audit log of every security-relevant action
- No PHP `mail()`, no cron dependency — safe for InfinityFree-style
  free hosting as described in the plan document

OAuth providers (Google/Microsoft/GitHub/etc.) and full RBAC are
**not** implemented yet — `user_identities`, `roles`, `permissions`
tables from the plan are left for Phase 2/3. The `users.business_id`
column gives you tenant isolation from day one.

## Folder layout

```
app/
  config/        database.php, auth-config.php  (fill in before deploying)
  core/          session, csrf, auth guard, rate-limit, crypto, totp, audit, otp
  services/      EmailService.php (PHPMailer + external SMTP)
api/
  auth/          13 JSON endpoints (register, login, verify-email, 2FA, etc.)
database/
  schema.sql     full MySQL schema — import this first
public/
  *.php          the actual pages (login, register, dashboard, settings-security...)
  assets/        auth.css + per-page JS
  legacy-dashboard/   your previously bundled dashboard/payment/theme files,
                       kept as-is and separate — not wired into the new auth
                       system yet (see "Connecting the dashboard" below)
```

## Setup

1. **Database.** Import `database/schema.sql` (phpMyAdmin or `mysql <
   schema.sql`). Then run:
   ```sql
   INSERT INTO businesses (name) VALUES ('My Business');
   ```
   and note the `id` it gets — that's the "Business ID" the login/register
   forms ask for.

2. **Config.** Edit `app/config/database.php` with your DB host/name/user/
   password, and `app/config/auth-config.php` with:
   - `APP_URL` (your real HTTPS domain — used in reset-password links)
   - `TOTP_ENCRYPTION_KEY_B64` — generate with:
     ```
     php -r "echo base64_encode(random_bytes(32));"
     ```
   - `SMTP_HOST` / `SMTP_PORT` / `SMTP_USERNAME` / `SMTP_PASSWORD` /
     `SMTP_FROM_EMAIL` — an external SMTP provider (Gmail, Zoho, etc.).
     Until this is set, emails are written to the PHP error log instead
     of sent, so you can test locally without SMTP.

3. **Email library.** `composer require phpmailer/phpmailer` locally,
   then upload the `vendor/` folder alongside `app/` (most free hosts,
   including InfinityFree, can't run Composer directly).

4. **Deploy.** Upload the whole project to your host's web root (e.g.
   `htdocs/`), pointing your web server's document root at `public/`
   (or, if that's not possible, at least make sure `app/`, `api/`, and
   `database/` are **not** web-accessible — only `public/` should be).

5. **HTTPS.** Required — never run login, OTP, or reset flows over
   plain HTTP.

## Testing the flow

1. Visit `/register.php`, sign up with the Business ID from step 1.
2. Check the PHP error log (or your inbox, once SMTP is configured)
   for the verification code, enter it at `/verify-email.php`.
3. Sign in at `/login.php`.
4. Go to `/settings-security.php` → **Enable 2FA with an authenticator
   app** → scan the QR (or enter the key manually) → enter the 6-digit
   code to confirm → save the 10 backup codes shown once.
5. Sign out, sign back in — you'll now be sent to `/two-factor.php`
   for the second step. "Use a backup code" is the recovery path if
   the authenticator app is unavailable.

## Connecting the dashboard

`public/legacy-dashboard/` holds the dashboard, payment/tenant, and
shared glass-theme files from your earlier bundle, untouched. They
aren't wired into this login system yet — `dashboard.php` in the new
auth flow is a fresh, minimal landing page. To connect them:

- Have the legacy dashboard pages call `requireAuth()` (from
  `app/core/auth.php`) at the top, the same way the new
  `dashboard.php` does, instead of whatever session check they use
  today.
- Swap in `currentUserId()` / `currentBusinessId()` wherever those
  files look up "who's logged in."
- The `dash_auth.php` / `dash_firewall.php` files in that folder have
  their own login logic — decide whether to replace them with this
  system or keep them separate; wiring both together isn't done
  automatically since that touches business logic specific to your
  dashboard.

## Security notes

- Every password comparison uses `password_verify()` (bcrypt) —
  never edit these to use `==`/`===` on raw strings.
- TOTP secrets are stored encrypted (AES-256-GCM) — never logged,
  never returned by any API after enrollment.
- Generic error messages are used everywhere an attacker could
  otherwise enumerate valid emails or accounts.
- `display_errors` is off in `api/_bootstrap.php` — flip it on only
  temporarily while debugging, never in production.

## What's still Phase 2/3 (from the master plan, not built here)

- Google / Microsoft / GitHub / Apple / Facebook / Discord login
- Passkeys / WebAuthn
- SMS OTP
- Full RBAC (roles/permissions tables) and admin-side 2FA reset
- Session management UI (view/revoke active sessions)
