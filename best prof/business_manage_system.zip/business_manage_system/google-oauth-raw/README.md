# google-oauth-raw

A single-file, dependency-free Google OAuth 2.0 client for PHP. No
Composer, no SDK, no JWT library -- just `curl` and `json`, both built
into PHP by default. Copy `GoogleOAuth.php` into any project.

## Setup

1. [Google Cloud Console](https://console.cloud.google.com/) → APIs &
   Services → Credentials → **Create Credentials** → **OAuth client ID**
   → Application type: **Web application**.
2. Under **Authorized redirect URIs**, add the exact URL of your
   callback page (e.g. `https://yourdomain.com/google-callback.php`).
   This must match exactly what you pass as `$redirectUri` below.
3. If this is the project's first OAuth client, you'll be asked to
   configure the **OAuth consent screen** first (app name, support
   email, and — while testing — your own account under "Test users").
4. Copy the **Client ID** and **Client Secret** it gives you.

## Usage

```php
require 'GoogleOAuth.php';
session_start();

$google = new GoogleOAuth('YOUR_CLIENT_ID', 'YOUR_CLIENT_SECRET', 'https://yourdomain.com/google-callback.php');

// -- login.php: send the user to Google --
$state = bin2hex(random_bytes(16));
$_SESSION['oauth_state'] = $state;
header('Location: ' . $google->buildAuthUrl($state));
exit;

// -- google-callback.php: handle the return trip --
if (($_GET['state'] ?? '') !== ($_SESSION['oauth_state'] ?? '')) {
    throw new RuntimeException('State mismatch -- possible CSRF, abort.');
}

try {
    $profile = $google->handleCallback($_GET['code']);
    // ['sub' => '...', 'email' => '...', 'email_verified' => true, 'name' => '...', 'picture' => '...']
} catch (RuntimeException $e) {
    // Google login failed -- show an error, don't log the user in.
}
```

`$profile['sub']` is Google's permanent, unique ID for that user —
use it (not the email) as your lookup key when deciding whether this
is a returning user or a new signup, since emails can change but
`sub` never does.

## What this does NOT do

- Doesn't touch your database or sessions — that's your integration
  code's job (see `business_manage_system/api/auth/google-callback.php`
  in this project for a full worked example: linking to an existing
  account by email, creating a new account, and handing off to
  existing 2FA if the account has it enabled).
- Doesn't handle Microsoft/GitHub/Facebook/etc. — same pattern applies,
  each provider just has different endpoint URLs and scopes.
