<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/auth-config.php';

/**
 * Sends an email via PHPMailer + external SMTP (composer require phpmailer/phpmailer,
 * then upload vendor/ if the host cannot run Composer -- see README).
 *
 * Never build this around PHP mail(); many hosts (InfinityFree included) restrict it.
 * Until SMTP_HOST is configured, this logs to error_log() instead of sending, so local
 * development still works -- do not leave that fallback active in production.
 */
function sendAppEmail(string $toEmail, string $subject, string $body): bool
{
    $autoload = __DIR__ . '/../../vendor/autoload.php';

    if (SMTP_HOST === 'REPLACE_ME' || !file_exists($autoload)) {
        error_log("[email:not-sent - configure SMTP_HOST] to={$toEmail} subject={$subject}");
        return true;
    }

    require_once $autoload;

    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = SMTP_PORT;

        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($toEmail);
        $mail->Subject = $subject;
        $mail->Body = $body;

        $mail->send();

        return true;
    } catch (Throwable $e) {
        error_log('[email:error] ' . $e->getMessage());

        return false;
    }
}

function sendOtpEmail(string $toEmail, string $otp, string $purpose): bool
{
    $subjects = [
        'email_verification' => 'Verify your ' . APP_NAME . ' account',
        'password_reset' => 'Your ' . APP_NAME . ' password reset code',
    ];

    $subject = $subjects[$purpose] ?? (APP_NAME . ' verification code');
    $body = "Your verification code is: {$otp}\nThis code expires in " . EMAIL_OTP_TTL_MINUTES . ' minutes.'
        . "\n\nIf you did not request this, you can ignore this email.";

    return sendAppEmail($toEmail, $subject, $body);
}
