<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/auth-config.php';

/**
 * AES-256-GCM authenticated encryption for TOTP secrets at rest.
 * Stored value = base64(iv[12] . tag[16] . ciphertext).
 */
function encryptSecret(string $plaintext): string
{
    $key = base64_decode(TOTP_ENCRYPTION_KEY_B64);
    $iv = random_bytes(12);
    $tag = '';

    $ciphertext = openssl_encrypt($plaintext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);

    if ($ciphertext === false) {
        throw new RuntimeException('Unable to encrypt secret.');
    }

    return base64_encode($iv . $tag . $ciphertext);
}

function decryptSecret(string $stored): string
{
    $key = base64_decode(TOTP_ENCRYPTION_KEY_B64);
    $raw = base64_decode($stored);

    $iv = substr($raw, 0, 12);
    $tag = substr($raw, 12, 16);
    $ciphertext = substr($raw, 28);

    $plaintext = openssl_decrypt($ciphertext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);

    if ($plaintext === false) {
        throw new RuntimeException('Unable to decrypt secret.');
    }

    return $plaintext;
}
