<?php
declare(strict_types=1);

function writeAudit(
    PDO $pdo,
    int $businessId,
    ?int $actorUserId,
    ?int $targetUserId,
    string $action,
    string $summary,
    array $metadata = []
): void {
    $stmt = $pdo->prepare('
        INSERT INTO audit_logs
            (business_id, actor_user_id, target_user_id, action, summary, metadata_json, ip_address, user_agent, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ');

    $stmt->execute([
        $businessId,
        $actorUserId,
        $targetUserId,
        $action,
        $summary,
        json_encode($metadata, JSON_UNESCAPED_UNICODE),
        $_SERVER['REMOTE_ADDR'] ?? null,
        substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
    ]);
}
