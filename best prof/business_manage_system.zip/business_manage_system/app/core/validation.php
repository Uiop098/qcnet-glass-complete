<?php
declare(strict_types=1);

function cleanText(string $value, int $max): string
{
    $value = trim($value);

    if (mb_strlen($value) > $max) {
        throw new InvalidArgumentException('Value is too long.');
    }

    return $value;
}

function normalizeEmail(string $email): string
{
    return mb_strtolower(trim($email));
}

function isValidEmail(string $email): bool
{
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

function isValidOtp(string $otp): bool
{
    return (bool) preg_match('/^\d{6}$/', $otp);
}
