<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/auth-config.php';

function base32Encode(string $input): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';

    foreach (str_split($input) as $char) {
        $bits .= str_pad(decbin(ord($char)), 8, '0', STR_PAD_LEFT);
    }

    $output = '';
    foreach (str_split($bits, 5) as $chunk) {
        $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
        $output .= $alphabet[bindec($chunk)];
    }

    return $output;
}

function base32Decode(string $input): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $input = strtoupper($input);

    $buffer = 0;
    $bitsLeft = 0;
    $result = '';

    foreach (str_split($input) as $char) {
        if ($char === '=' || $char === ' ') {
            continue;
        }

        $value = strpos($alphabet, $char);

        if ($value === false) {
            throw new InvalidArgumentException('Invalid Base32 data');
        }

        $buffer = ($buffer << 5) | $value;
        $bitsLeft += 5;

        if ($bitsLeft >= 8) {
            $bitsLeft -= 8;
            $result .= chr(($buffer >> $bitsLeft) & 0xFF);
            $buffer &= (1 << $bitsLeft) - 1;
        }
    }

    return $result;
}

function generateTotpSecret(int $bytes = 20): string
{
    return base32Encode(random_bytes($bytes));
}

function totpUri(string $secret, string label): string
{
    return sprintf(
        'otpauth://totp/%s:%s?secret=%s&issuer=%s',
        rawurlencode(APP_NAME),
        rawurlencode($label),
        $secret,
        rawurlencode(APP_NAME)
    );
}

function totpCodeAt(string $secretBase32, int $timeStep): string
{
    $key = base32Decode($secretBase32);
    $counter = pack('N*', 0, $timeStep);

    $hash = hash_hmac('sha1', $counter, $key, true);
    $offset = ord($hash[19]) & 0x0F;

    $binary =
        ((ord($hash[$offset]) & 0x7F) << 24) |
        ((ord($hash[$offset + 1]) & 0xFF) << 16) |
        ((ord($hash[$offset + 2]) & 0xFF) << 8) |
        (ord($hash[$offset + 3]) & 0xFF);

    return str_pad((string) ($binary % 1000000), 6, '0', STR_PAD_LEFT);
}

/**
 * Verifies a submitted TOTP code, allowing +/-1 time step (30s) of clock skew.
 */
function verifyTotpCode(string $secretBase32, string $code, int $windowSteps = 1): bool
{
    if (!preg_match('/^\d{6}$/', $code)) {
        return false;
    }

    $currentStep = (int) floor(time() / 30);

    for ($i = -$windowSteps; $i <= $windowSteps; $i++) {
        if (hash_equals(totpCodeAt($secretBase32, $currentStep + $i), $code)) {
            return true;
        }
    }

    return false;
}
