<?php
declare(strict_types=1);

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/response.php';

function requireAuth(): void
{
    startSecureSession();

    if (empty($_SESSION['user_id']) || ($_SESSION['auth_stage'] ?? '') !== 'full') {
        header('Location: /login.php');
        exit;
    }
}

function requireApiAuth(): void
{
    startSecureSession();

    if (empty($_SESSION['user_id']) || ($_SESSION['auth_stage'] ?? '') !== 'full') {
        jsonResponse(['success' => false, 'message' => 'Not authenticated.'], 401);
    }
}

function currentUserId(): int
{
    return (int) ($_SESSION['user_id'] ?? 0);
}

function currentBusinessId(): int
{
    return (int) ($_SESSION['business_id'] ?? 0);
}

function generateBackupCodes(int $count = 10): array
{
    $codes = [];

    for ($i = 0; $i < $count; $i++) {
        $codes[] = strtoupper(bin2hex(random_bytes(2))) . '-' . strtoupper(bin2hex(random_bytes(2)));
    }

    return $codes;
}

/**
 * Shared "user is fully authenticated by password/OAuth, now check 2FA"
 * step -- used by both password login and Google login so a 2FA-enabled
 * account can't skip its second factor just by using a different sign-in
 * method. Returns ['next' => '2fa'] if a 2FA challenge is now pending, or
 * ['next' => 'full'] once the session is fully authenticated.
 *
 * @return array{next:string}
 */
function beginPostCredentialSession(PDO $pdo, array $user): array
{
    $totpStmt = $pdo->prepare('SELECT totp_enabled FROM user_2fa WHERE user_id = ?');
    $totpStmt->execute([$user['id']]);
    $totpRow = $totpStmt->fetch();
    $totpEnabled = $totpRow && (int) $totpRow['totp_enabled'] === 1;

    if ($totpEnabled) {
        $_SESSION['auth_stage'] = '2fa_pending';
        $_SESSION['pending_user_id'] = (int) $user['id'];
        $_SESSION['pending_business_id'] = (int) $user['business_id'];
        $_SESSION['pending_expires'] = time() + 300;

        return ['next' => '2fa'];
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['business_id'] = (int) $user['business_id'];
    $_SESSION['auth_stage'] = 'full';

    $pdo->prepare('UPDATE users SET last_login_at = NOW(), last_login_ip = ?, updated_at = NOW() WHERE id = ?')
        ->execute([$_SERVER['REMOTE_ADDR'] ?? null, $user['id']]);

    return ['next' => 'full'];
}
