<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/response.php';

/**
 * Fixed-window rate limiter backed by MySQL. Returns true if the request is
 * still within the allowed number of attempts for this window.
 */
function checkRateLimit(string $key, string $action, int $maxAttempts, int $windowSeconds): bool
{
    $pdo = db();

    $bucketStart = date('Y-m-d H:i:s', time() - (time() % $windowSeconds));

    $pdo->prepare('
        INSERT INTO rate_limits (rate_key, action, window_start, attempts)
        VALUES (?, ?, ?, 1)
        ON DUPLICATE KEY UPDATE attempts = attempts + 1
    ')->execute([$key, $action, $bucketStart]);

    $stmt = $pdo->prepare('
        SELECT attempts FROM rate_limits
        WHERE rate_key = ? AND action = ? AND window_start = ?
    ');
    $stmt->execute([$key, $action, $bucketStart]);
    $attempts = (int) ($stmt->fetchColumn() ?: 0);

    return $attempts <= $maxAttempts;
}

function requireRateLimit(string $key, string $action, int $maxAttempts, int $windowSeconds): void
{
    if (!checkRateLimit($key, $action, $maxAttempts, $windowSeconds)) {
        jsonResponse(['success' => false, 'message' => 'Too many attempts. Please try again later.'], 429);
    }
}
