<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/auth-config.php';
require_once __DIR__ . '/../services/EmailService.php';

function createEmailOtp(PDO $pdo, ?int $userId, string $email, string $purpose): void
{
    $pdo->prepare('
        UPDATE email_otps SET used_at = NOW()
        WHERE email = ? AND purpose = ? AND used_at IS NULL
    ')->execute([$email, $purpose]);

    $otp = (string) random_int(100000, 999999);
    $hash = password_hash($otp, PASSWORD_DEFAULT);
    $ttl = EMAIL_OTP_TTL_MINUTES;
    $maxAttempts = EMAIL_OTP_MAX_ATTEMPTS;

    $stmt = $pdo->prepare("
        INSERT INTO email_otps (user_id, email, purpose, otp_hash, expires_at, attempts, max_attempts, created_at)
        VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL {$ttl} MINUTE), 0, {$maxAttempts}, NOW())
    ");
    $stmt->execute([$userId, $email, $purpose, $hash]);

    // Never log the plaintext OTP outside of sendOtpEmail's own dev-mode fallback.
    sendOtpEmail($email, $otp, $purpose);
}

/**
 * Returns 'ok' | 'invalid' | 'expired' | 'locked'
 */
function verifyEmailOtp(PDO $pdo, string $email, string $purpose, string $code): string
{
    $stmt = $pdo->prepare('
        SELECT * FROM email_otps
        WHERE email = ? AND purpose = ? AND used_at IS NULL
        ORDER BY created_at DESC LIMIT 1
    ');
    $stmt->execute([$email, $purpose]);
    $row = $stmt->fetch();

    if (!$row) {
        return 'invalid';
    }

    if (strtotime($row['expires_at']) < time()) {
        return 'expired';
    }

    if ((int) $row['attempts'] >= (int) $row['max_attempts']) {
        return 'locked';
    }

    $pdo->prepare('UPDATE email_otps SET attempts = attempts + 1 WHERE id = ?')->execute([$row['id']]);

    if (!password_verify($code, $row['otp_hash'])) {
        return 'invalid';
    }

    $pdo->prepare('UPDATE email_otps SET used_at = NOW() WHERE id = ?')->execute([$row['id']]);

    return 'ok';
}
