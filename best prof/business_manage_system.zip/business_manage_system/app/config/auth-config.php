<?php
declare(strict_types=1);

const APP_NAME = 'Business Manage System';
const APP_URL = 'https://REPLACE_ME.example.com';

// 32 raw bytes, base64-encoded. Generate with:
// php -r "echo base64_encode(random_bytes(32));"
const TOTP_ENCRYPTION_KEY_B64 = 'REPLACE_ME_BASE64_32_BYTES';

// SMTP is required -- do not rely on PHP mail() (many hosts, incl. InfinityFree, restrict it).
const SMTP_HOST = 'REPLACE_ME';
const SMTP_PORT = 587;
const SMTP_USERNAME = 'REPLACE_ME';
const SMTP_PASSWORD = 'REPLACE_ME';
const SMTP_FROM_EMAIL = 'no-reply@example.com';
const SMTP_FROM_NAME = APP_NAME;

const EMAIL_OTP_TTL_MINUTES = 10;
const EMAIL_OTP_MAX_ATTEMPTS = 5;
const PASSWORD_RESET_TTL_MINUTES = 30;
const TOTP_ENROLLMENT_TTL_MINUTES = 10;
