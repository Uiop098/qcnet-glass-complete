<?php
declare(strict_types=1);

// From Google Cloud Console -> APIs & Services -> Credentials.
// See /google-oauth-raw/README.md for the full setup walkthrough.
const GOOGLE_CLIENT_ID = 'REPLACE_ME.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = 'REPLACE_ME';
const GOOGLE_REDIRECT_URI = 'https://REPLACE_ME.example.com/api/auth/google-callback.php';
