<?php
declare(strict_types=1);

function db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = getenv('DB_HOST') ?: 'REPLACE_ME_DB_HOST';
    $name = getenv('DB_NAME') ?: 'REPLACE_ME_DB_NAME';
    $user = getenv('DB_USER') ?: 'REPLACE_ME_DB_USER';
    $pass = getenv('DB_PASS') ?: 'REPLACE_ME_DB_PASSWORD';

    $dsn = "mysql:host={$host};dbname={$name};charset=utf8mb4";

    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    return $pdo;
}
