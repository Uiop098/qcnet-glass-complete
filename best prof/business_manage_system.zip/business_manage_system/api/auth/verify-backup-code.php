<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

requireCsrf();

if (($_SESSION['auth_stage'] ?? '') !== '2fa_pending' || empty($_SESSION['pending_user_id'])) {
    jsonResponse(['success' => false, 'message' => 'No pending sign-in.'], 401);
}

$userId = (int) $_SESSION['pending_user_id'];
$businessId = (int) $_SESSION['pending_business_id'];
$code = strtoupper(trim((string) ($_POST['code'] ?? '')));

requireRateLimit('backup|' . $userId, 'verify_backup_code', 8, 300);

$pdo = db();
$stmt = $pdo->prepare('SELECT id, code_hash FROM backup_codes WHERE user_id = ? AND used_at IS NULL');
$stmt->execute([$userId]);
$rows = $stmt->fetchAll();

$matched = null;
foreach ($rows as $row) {
    if (password_verify($code, $row['code_hash'])) {
        $matched = $row;
        break;
    }
}

if (!$matched) {
    writeAudit($pdo, $businessId, $userId, $userId, 'security.backup_code_failed', 'Backup code verification failed', []);
    jsonResponse(['success' => false, 'message' => 'Invalid backup code.'], 422);
}

$pdo->prepare('UPDATE backup_codes SET used_at = NOW() WHERE id = ?')->execute([$matched['id']]);

unset($_SESSION['pending_user_id'], $_SESSION['pending_business_id'], $_SESSION['pending_expires']);
session_regenerate_id(true);

$_SESSION['user_id'] = $userId;
$_SESSION['business_id'] = $businessId;
$_SESSION['auth_stage'] = 'full';

writeAudit($pdo, $businessId, $userId, $userId, 'security.backup_code_used', 'Signed in with a backup code', []);

jsonResponse(['success' => true, 'redirect' => '/dashboard.php']);
