<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

requireApiAuth();
requireCsrf();

$userId = currentUserId();
$businessId = currentBusinessId();
$code = trim((string) ($_POST['code'] ?? ''));

requireRateLimit('totp_setup|' . $userId, 'verify_totp_setup', 10, 600);

$pdo = db();
$stmt = $pdo->prepare('SELECT secret_encrypted FROM totp_enrollments WHERE user_id = ? AND expires_at > NOW()');
$stmt->execute([$userId]);
$row = $stmt->fetch();

if (!$row) {
    jsonResponse(['success' => false, 'message' => 'Setup expired. Start again.'], 422);
}

$secret = decryptSecret($row['secret_encrypted']);

if (!verifyTotpCode($secret, $code)) {
    jsonResponse(['success' => false, 'message' => 'Invalid code. Check your authenticator app and try again.'], 422);
}

$backupCodes = generateBackupCodes();
$backupHashes = array_map(static fn ($c) => password_hash($c, PASSWORD_DEFAULT), $backupCodes);

$pdo->beginTransaction();

try {
    $pdo->prepare('
        INSERT INTO user_2fa (user_id, totp_enabled, totp_secret_encrypted, totp_enabled_at, created_at, updated_at)
        VALUES (?, 1, ?, NOW(), NOW(), NOW())
        ON DUPLICATE KEY UPDATE totp_enabled = 1, totp_secret_encrypted = VALUES(totp_secret_encrypted),
            totp_enabled_at = NOW(), updated_at = NOW()
    ')->execute([$userId, $row['secret_encrypted']]);

    $pdo->prepare('DELETE FROM backup_codes WHERE user_id = ? AND used_at IS NULL')->execute([$userId]);

    $insertCode = $pdo->prepare('INSERT INTO backup_codes (user_id, code_hash, created_at) VALUES (?, ?, NOW())');
    foreach ($backupHashes as $hash) {
        $insertCode->execute([$userId, $hash]);
    }

    $pdo->prepare('DELETE FROM totp_enrollments WHERE user_id = ?')->execute([$userId]);

    writeAudit($pdo, $businessId, $userId, $userId, 'security.2fa_enabled', 'Two-factor authentication enabled', []);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('[totp-setup:error] ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Something went wrong enabling 2FA.'], 500);
}

jsonResponse(['success' => true, 'backup_codes' => $backupCodes]);
