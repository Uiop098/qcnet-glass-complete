<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

requireRateLimit($_SERVER['REMOTE_ADDR'] ?? 'unknown', 'register', 10, 3600);

$fullName = cleanText((string) ($_POST['full_name'] ?? ''), 120);
$email = normalizeEmail((string) ($_POST['email'] ?? ''));
$password = (string) ($_POST['password'] ?? '');
$businessId = (int) ($_POST['business_id'] ?? 0);

if ($fullName === '' || !isValidEmail($email) || strlen($password) < 8 || $businessId <= 0) {
    jsonResponse(['success' => false, 'message' => 'Please check your details and try again.'], 422);
}

$pdo = db();

$stmt = $pdo->prepare('SELECT id FROM users WHERE business_id = ? AND email_normalized = ?');
$stmt->execute([$businessId, $email]);

if ($stmt->fetch()) {
    // Do not reveal whether the account already exists.
    jsonResponse(['success' => true, 'message' => 'If this email can be registered, a verification code has been sent.']);
}

$passwordHash = password_hash($password, PASSWORD_DEFAULT);
$publicId = bin2hex(random_bytes(8));

$pdo->beginTransaction();

try {
    $stmt = $pdo->prepare('
        INSERT INTO users (business_id, public_id, full_name, email, email_normalized, password_hash, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ');
    $stmt->execute([$businessId, $publicId, $fullName, $email, $email, $passwordHash, 'pending']);

    $userId = (int) $pdo->lastInsertId();

    createEmailOtp($pdo, $userId, $email, 'email_verification');

    writeAudit($pdo, $businessId, null, $userId, 'auth.registered', 'New account registered', []);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('[register:error] ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Something went wrong. Please try again.'], 500);
}

jsonResponse(['success' => true, 'message' => 'Account created. Check your email for a verification code.']);
