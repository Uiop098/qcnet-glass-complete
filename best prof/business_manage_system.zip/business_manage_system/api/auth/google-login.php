<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
require_once __DIR__ . '/../../app/config/oauth-config.php';
require_once __DIR__ . '/../../app/core/GoogleOAuth.php';

$businessId = (int) ($_GET['business_id'] ?? 0);

if ($businessId <= 0) {
    http_response_code(422);
    echo 'A Business ID is required before continuing with Google.';
    exit;
}

if (GOOGLE_CLIENT_ID === 'REPLACE_ME.apps.googleusercontent.com') {
    http_response_code(500);
    echo 'Google sign-in is not configured yet -- set GOOGLE_CLIENT_ID/SECRET in app/config/oauth-config.php.';
    exit;
}

$state = bin2hex(random_bytes(16));
$_SESSION['oauth_state'] = $state;
$_SESSION['oauth_business_id'] = $businessId;

$google = new GoogleOAuth(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI);

header('Location: ' . $google->buildAuthUrl($state));
exit;
