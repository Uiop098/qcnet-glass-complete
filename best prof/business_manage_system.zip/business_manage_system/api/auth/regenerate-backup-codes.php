<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

requireApiAuth();
requireCsrf();

$userId = currentUserId();
$businessId = currentBusinessId();
$password = (string) ($_POST['password'] ?? '');

$pdo = db();
$stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
$stmt->execute([$userId]);
$hash = $stmt->fetchColumn();

if (!$hash || !password_verify($password, $hash)) {
    jsonResponse(['success' => false, 'message' => 'Please confirm your password to continue.'], 403);
}

$totpStmt = $pdo->prepare('SELECT totp_enabled FROM user_2fa WHERE user_id = ?');
$totpStmt->execute([$userId]);

if ((int) $totpStmt->fetchColumn() !== 1) {
    jsonResponse(['success' => false, 'message' => 'Enable two-factor authentication first.'], 422);
}

$codes = generateBackupCodes();
$hashes = array_map(static fn ($c) => password_hash($c, PASSWORD_DEFAULT), $codes);

$pdo->beginTransaction();

try {
    $pdo->prepare('DELETE FROM backup_codes WHERE user_id = ? AND used_at IS NULL')->execute([$userId]);

    $insert = $pdo->prepare('INSERT INTO backup_codes (user_id, code_hash, created_at) VALUES (?, ?, NOW())');
    foreach ($hashes as $h) {
        $insert->execute([$userId, $h]);
    }

    writeAudit($pdo, $businessId, $userId, $userId, 'security.backup_codes_generated', 'Backup codes regenerated', []);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    jsonResponse(['success' => false, 'message' => 'Something went wrong.'], 500);
}

jsonResponse(['success' => true, 'backup_codes' => $codes]);
