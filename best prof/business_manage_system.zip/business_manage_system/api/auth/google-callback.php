<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';
require_once __DIR__ . '/../../app/config/oauth-config.php';
require_once __DIR__ . '/../../app/core/GoogleOAuth.php';

function failToLogin(string $reason): never
{
    error_log('[google-login:error] ' . $reason);
    header('Location: /login.php?oauth_error=1');
    exit;
}

$state = (string) ($_GET['state'] ?? '');
$code = (string) ($_GET['code'] ?? '');

if ($state === '' || $code === '' || $state !== ($_SESSION['oauth_state'] ?? '')) {
    failToLogin('state mismatch or missing code');
}

$businessId = (int) ($_SESSION['oauth_business_id'] ?? 0);
unset($_SESSION['oauth_state'], $_SESSION['oauth_business_id']);

if ($businessId <= 0) {
    failToLogin('no pending business_id in session');
}

$google = new GoogleOAuth(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI);

try {
    $profile = $google->handleCallback($code);
} catch (Throwable $e) {
    failToLogin($e->getMessage());
}

if (!$profile['email_verified']) {
    failToLogin('Google email not verified for ' . $profile['email']);
}

$pdo = db();
$email = normalizeEmail($profile['email']);

// 1. Already linked? Log straight in.
$stmt = $pdo->prepare('
    SELECT u.* FROM users u
    JOIN user_identities ui ON ui.user_id = u.id
    WHERE ui.provider = "google" AND ui.provider_subject = ? AND u.business_id = ?
');
$stmt->execute([$profile['sub'], $businessId]);
$user = $stmt->fetch();

$pdo->beginTransaction();

try {
    if (!$user) {
        // 2. Existing account with this email in this business? Link it
        //    (safe to auto-link since Google has already verified the email).
        $stmt = $pdo->prepare('SELECT * FROM users WHERE business_id = ? AND email_normalized = ?');
        $stmt->execute([$businessId, $email]);
        $user = $stmt->fetch();

        if ($user) {
            writeAudit($pdo, $businessId, (int) $user['id'], (int) $user['id'], 'auth.google_linked', 'Linked Google account to existing user', []);
        } else {
            // 3. New user entirely -- create the account. No password_hash;
            //    this account can only sign in via Google unless they later
            //    set a password through a "add a password" flow (not built).
            $publicId = bin2hex(random_bytes(8));
            $fullName = $profile['name'] !== '' ? $profile['name'] : $email;

            $stmt = $pdo->prepare('
                INSERT INTO users (business_id, public_id, full_name, email, email_normalized, password_hash, status, email_verified_at, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, NULL, "active", NOW(), NOW(), NOW())
            ');
            $stmt->execute([$businessId, $publicId, $fullName, $profile['email'], $email]);

            $userId = (int) $pdo->lastInsertId();
            $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
            $stmt->execute([$userId]);
            $user = $stmt->fetch();

            writeAudit($pdo, $businessId, (int) $user['id'], (int) $user['id'], 'auth.registered', 'Account created via Google sign-in', []);
        }

        $pdo->prepare('
            INSERT INTO user_identities (user_id, provider, provider_subject, provider_email, created_at, last_login_at)
            VALUES (?, "google", ?, ?, NOW(), NOW())
        ')->execute([$user['id'], $profile['sub'], $profile['email']]);
    } else {
        $pdo->prepare('
            UPDATE user_identities SET last_login_at = NOW(), provider_email = ?
            WHERE provider = "google" AND provider_subject = ?
        ')->execute([$profile['email'], $profile['sub']]);
    }

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    failToLogin('db error: ' . $e->getMessage());
}

if ($user['status'] !== 'active') {
    failToLogin('account not active: ' . $user['id']);
}

$outcome = beginPostCredentialSession($pdo, $user);

if ($outcome['next'] === '2fa') {
    header('Location: /two-factor.php');
    exit;
}

writeAudit($pdo, $businessId, (int) $user['id'], (int) $user['id'], 'auth.login_success', 'User logged in via Google', []);

header('Location: /dashboard.php');
exit;
