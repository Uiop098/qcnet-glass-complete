<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

requireCsrf();

if (($_SESSION['auth_stage'] ?? '') !== '2fa_pending' || empty($_SESSION['pending_user_id'])) {
    jsonResponse(['success' => false, 'message' => 'No pending sign-in.'], 401);
}

if (($_SESSION['pending_expires'] ?? 0) < time()) {
    unset($_SESSION['pending_user_id'], $_SESSION['pending_business_id'], $_SESSION['pending_expires'], $_SESSION['auth_stage']);
    jsonResponse(['success' => false, 'message' => 'Sign-in expired. Please log in again.'], 401);
}

$code = trim((string) ($_POST['code'] ?? ''));
$userId = (int) $_SESSION['pending_user_id'];
$businessId = (int) $_SESSION['pending_business_id'];

requireRateLimit('totp|' . $userId, 'verify_totp', 8, 300);

$pdo = db();
$stmt = $pdo->prepare('SELECT totp_secret_encrypted FROM user_2fa WHERE user_id = ? AND totp_enabled = 1');
$stmt->execute([$userId]);
$row = $stmt->fetch();

if (!$row || !verifyTotpCode(decryptSecret($row['totp_secret_encrypted']), $code)) {
    writeAudit($pdo, $businessId, $userId, $userId, 'security.totp_failed', 'TOTP verification failed', []);
    jsonResponse(['success' => false, 'message' => 'Invalid code.'], 422);
}

unset($_SESSION['pending_user_id'], $_SESSION['pending_business_id'], $_SESSION['pending_expires']);
session_regenerate_id(true);

$_SESSION['user_id'] = $userId;
$_SESSION['business_id'] = $businessId;
$_SESSION['auth_stage'] = 'full';

$pdo->prepare('UPDATE users SET last_login_at = NOW(), last_login_ip = ?, updated_at = NOW() WHERE id = ?')
    ->execute([$_SERVER['REMOTE_ADDR'] ?? null, $userId]);

writeAudit($pdo, $businessId, $userId, $userId, 'auth.login_success', 'User completed 2FA login', []);

jsonResponse(['success' => true, 'redirect' => '/dashboard.php']);
