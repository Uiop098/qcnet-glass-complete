<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$email = normalizeEmail((string) ($_POST['email'] ?? ''));
$code = trim((string) ($_POST['code'] ?? ''));

if (!isValidEmail($email) || !isValidOtp($code)) {
    jsonResponse(['success' => false, 'message' => 'Please enter a valid 6-digit code.'], 422);
}

requireRateLimit($email, 'verify_email_otp', 10, 600);

$pdo = db();
$result = verifyEmailOtp($pdo, $email, 'email_verification', $code);

if ($result !== 'ok') {
    $messages = [
        'invalid' => 'That code is not correct.',
        'expired' => 'That code has expired. Request a new one.',
        'locked' => 'Too many attempts. Request a new code.',
    ];
    jsonResponse(['success' => false, 'message' => $messages[$result] ?? 'Verification failed.'], 422);
}

$pdo->prepare("UPDATE users SET email_verified_at = NOW(), status = 'active', updated_at = NOW() WHERE email_normalized = ? AND status = 'pending'")
    ->execute([$email]);

$stmt = $pdo->prepare('SELECT id, business_id FROM users WHERE email_normalized = ?');
$stmt->execute([$email]);
$u = $stmt->fetch();

if ($u) {
    writeAudit($pdo, (int) $u['business_id'], (int) $u['id'], (int) $u['id'], 'auth.email_verified', 'Email verified', []);
}

jsonResponse(['success' => true, 'message' => 'Email verified. You can now sign in.']);
