<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

requireApiAuth();
requireCsrf();

$userId = currentUserId();
$businessId = currentBusinessId();

$pdo = db();
$secret = generateTotpSecret();
$encrypted = encryptSecret($secret);
$ttl = TOTP_ENROLLMENT_TTL_MINUTES;

$pdo->prepare('DELETE FROM totp_enrollments WHERE user_id = ?')->execute([$userId]);

$pdo->prepare("
    INSERT INTO totp_enrollments (user_id, secret_encrypted, expires_at, created_at)
    VALUES (?, ?, DATE_ADD(NOW(), INTERVAL {$ttl} MINUTE), NOW())
")->execute([$userId, $encrypted]);

$stmt = $pdo->prepare('SELECT email FROM users WHERE id = ?');
$stmt->execute([$userId]);
$email = (string) $stmt->fetchColumn();

writeAudit($pdo, $businessId, $userId, $userId, 'security.totp_enrollment_started', 'Started authenticator app setup', []);

jsonResponse([
    'success' => true,
    'secret' => $secret,
    'otpauth_uri' => totpUri($secret, $email),
]);
