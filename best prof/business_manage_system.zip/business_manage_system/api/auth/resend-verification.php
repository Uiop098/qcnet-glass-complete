<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$email = normalizeEmail((string) ($_POST['email'] ?? ''));

if (!isValidEmail($email)) {
    jsonResponse(['success' => false, 'message' => 'Please enter a valid email.'], 422);
}

requireRateLimit($email, 'resend_verification', 5, 3600);

$pdo = db();
$stmt = $pdo->prepare("SELECT id FROM users WHERE email_normalized = ? AND status = 'pending'");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user) {
    createEmailOtp($pdo, (int) $user['id'], $email, 'email_verification');
}

// Same response regardless -- never reveal whether the account exists.
jsonResponse(['success' => true, 'message' => 'If a pending account matches that email, a new code has been sent.']);
