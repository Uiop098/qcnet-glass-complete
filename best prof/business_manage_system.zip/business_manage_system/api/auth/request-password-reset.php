<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$email = normalizeEmail((string) ($_POST['email'] ?? ''));

if (!isValidEmail($email)) {
    jsonResponse(['success' => false, 'message' => 'Please enter a valid email.'], 422);
}

requireRateLimit($email . '|' . ($_SERVER['REMOTE_ADDR'] ?? ''), 'password_reset_request', 5, 3600);

$pdo = db();
$stmt = $pdo->prepare("SELECT id, business_id FROM users WHERE email_normalized = ? AND status = 'active'");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user) {
    $token = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $token);
    $ttl = PASSWORD_RESET_TTL_MINUTES;

    $pdo->prepare('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL')
        ->execute([$user['id']]);

    $pdo->prepare("
        INSERT INTO password_resets (user_id, token_hash, expires_at, created_at)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL {$ttl} MINUTE), NOW())
    ")->execute([$user['id'], $tokenHash]);

    $resetUrl = rtrim(APP_URL, '/') . '/reset-password.php?token=' . $token;
    sendAppEmail(
        $email,
        'Reset your ' . APP_NAME . ' password',
        "Reset your password: {$resetUrl}\nThis link expires in {$ttl} minutes.\n\nIf you did not request this, you can ignore this email."
    );

    writeAudit($pdo, (int) $user['business_id'], (int) $user['id'], (int) $user['id'], 'auth.password_reset_requested', 'Password reset requested', []);
}

// Same response whether or not the account exists -- never reveal that.
jsonResponse(['success' => true, 'message' => 'If an account matches that email, reset instructions have been sent.']);
