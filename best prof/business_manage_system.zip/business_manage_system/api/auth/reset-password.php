<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$token = (string) ($_POST['token'] ?? '');
$newPassword = (string) ($_POST['password'] ?? '');

if ($token === '' || strlen($newPassword) < 8) {
    jsonResponse(['success' => false, 'message' => 'Invalid request.'], 422);
}

$tokenHash = hash('sha256', $token);

$pdo = db();
$stmt = $pdo->prepare('
    SELECT pr.id, pr.user_id, u.business_id
    FROM password_resets pr
    JOIN users u ON u.id = pr.user_id
    WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > NOW()
');
$stmt->execute([$tokenHash]);
$row = $stmt->fetch();

if (!$row) {
    jsonResponse(['success' => false, 'message' => 'This reset link is invalid or has expired.'], 422);
}

$pdo->beginTransaction();

try {
    $pdo->prepare('UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?')
        ->execute([password_hash($newPassword, PASSWORD_DEFAULT), $row['user_id']]);

    $pdo->prepare('UPDATE password_resets SET used_at = NOW() WHERE id = ?')->execute([$row['id']]);

    $pdo->prepare('UPDATE user_sessions SET revoked_at = NOW() WHERE user_id = ? AND revoked_at IS NULL')
        ->execute([$row['user_id']]);

    writeAudit($pdo, (int) $row['business_id'], (int) $row['user_id'], (int) $row['user_id'], 'auth.password_reset', 'Password reset completed', []);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    jsonResponse(['success' => false, 'message' => 'Something went wrong.'], 500);
}

jsonResponse(['success' => true, 'message' => 'Password updated. You can now sign in.']);
