<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

requireApiAuth();
requireCsrf();

$userId = currentUserId();
$businessId = currentBusinessId();
$password = (string) ($_POST['password'] ?? '');

$pdo = db();
$stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
$stmt->execute([$userId]);
$hash = $stmt->fetchColumn();

if (!$hash || !password_verify($password, $hash)) {
    jsonResponse(['success' => false, 'message' => 'Please confirm your password to continue.'], 403);
}

$pdo->beginTransaction();

try {
    $pdo->prepare('UPDATE user_2fa SET totp_enabled = 0, totp_secret_encrypted = NULL, updated_at = NOW() WHERE user_id = ?')
        ->execute([$userId]);
    $pdo->prepare('DELETE FROM backup_codes WHERE user_id = ?')->execute([$userId]);

    writeAudit($pdo, $businessId, $userId, $userId, 'security.2fa_disabled', 'Two-factor authentication disabled', []);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    jsonResponse(['success' => false, 'message' => 'Something went wrong.'], 500);
}

jsonResponse(['success' => true, 'message' => 'Two-factor authentication disabled.']);
