<?php
declare(strict_types=1);

require_once __DIR__ . '/../_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

requireCsrf();

$email = normalizeEmail((string) ($_POST['email'] ?? ''));
$password = (string) ($_POST['password'] ?? '');
$businessId = (int) ($_POST['business_id'] ?? 0);

if (!isValidEmail($email) || $password === '' || $businessId <= 0) {
    jsonResponse(['success' => false, 'message' => 'Invalid email or password.'], 422);
}

requireRateLimit($email . '|' . ($_SERVER['REMOTE_ADDR'] ?? ''), 'login', 10, 900);

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM users WHERE business_id = ? AND email_normalized = ?');
$stmt->execute([$businessId, $email]);
$user = $stmt->fetch();

if (!$user || !$user['password_hash'] || !password_verify($password, $user['password_hash'])) {
    // Generic message -- never reveal whether the email exists.
    jsonResponse(['success' => false, 'message' => 'Invalid email or password.'], 401);
}

if ($user['status'] !== 'active') {
    jsonResponse(['success' => false, 'message' => 'This account is not active yet.'], 403);
}

$outcome = beginPostCredentialSession($pdo, $user);

if ($outcome['next'] === '2fa') {
    jsonResponse(['success' => true, 'next' => '2fa']);
}

writeAudit($pdo, (int) $user['business_id'], (int) $user['id'], (int) $user['id'], 'auth.login_success', 'User logged in', []);

jsonResponse(['success' => true, 'redirect' => '/dashboard.php']);
