<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0'); // Keep off in production. Flip on only while diagnosing.

require_once __DIR__ . '/../app/config/database.php';
require_once __DIR__ . '/../app/config/auth-config.php';
require_once __DIR__ . '/../app/core/session.php';
require_once __DIR__ . '/../app/core/response.php';
require_once __DIR__ . '/../app/core/csrf.php';
require_once __DIR__ . '/../app/core/validation.php';
require_once __DIR__ . '/../app/core/audit.php';
require_once __DIR__ . '/../app/core/rate-limit.php';
require_once __DIR__ . '/../app/core/crypto.php';
require_once __DIR__ . '/../app/core/totp.php';
require_once __DIR__ . '/../app/core/auth.php';
require_once __DIR__ . '/../app/core/otp.php';
require_once __DIR__ . '/../app/services/EmailService.php';

startSecureSession();

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Cache-Control: no-store, private');
