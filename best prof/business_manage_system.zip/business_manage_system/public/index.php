<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/core/session.php';
startSecureSession();

if (!empty($_SESSION['user_id']) && ($_SESSION['auth_stage'] ?? '') === 'full') {
    header('Location: /dashboard.php');
} else {
    header('Location: /login.php');
}
exit;
