<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/config/auth-config.php';
require_once __DIR__ . '/../app/core/session.php';
require_once __DIR__ . '/../app/core/csrf.php';
startSecureSession();

if (($_SESSION['auth_stage'] ?? '') !== '2fa_pending') {
    header('Location: /login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Two-factor authentication — <?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body>
<div class="auth-shell">
  <section class="security-card glass">
    <h1>Two-factor authentication</h1>
    <p>Enter the 6-digit code from your authenticator app.</p>

    <form id="totpForm">
      <label>Authentication code
        <input id="totpCode" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required>
      </label>
      <button type="submit">Verify</button>
    </form>

    <form id="backupForm" style="display:none;">
      <label>Backup code
        <input name="code" autocomplete="one-time-code" placeholder="ABCD-EFGH" required>
      </label>
      <button type="submit">Verify with backup code</button>
    </form>

    <button type="button" id="useBackupCode" style="margin-top:10px;">Use a backup code</button>
    <button type="button" id="backToTotp" style="display:none; margin-top:10px;">Back to authenticator code</button>

    <div id="formMsg" class="msg"></div>

    <div class="links">
      <a href="/login.php">Back to sign in</a>
    </div>
  </section>
</div>
<script>window.APP_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;</script>
<script src="/assets/js/helpers.js"></script>
<script src="/assets/js/totp.js"></script>
</body>
</html>
