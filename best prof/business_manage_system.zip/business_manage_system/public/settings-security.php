<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/config/database.php';
require_once __DIR__ . '/../app/config/auth-config.php';
require_once __DIR__ . '/../app/core/session.php';
require_once __DIR__ . '/../app/core/auth.php';
require_once __DIR__ . '/../app/core/csrf.php';

requireAuth();

$pdo = db();
$stmt = $pdo->prepare('SELECT totp_enabled FROM user_2fa WHERE user_id = ?');
$stmt->execute([currentUserId()]);
$totpEnabled = (int) ($stmt->fetchColumn() ?: 0) === 1;

$countStmt = $pdo->prepare('SELECT COUNT(*) FROM backup_codes WHERE user_id = ? AND used_at IS NULL');
$countStmt->execute([currentUserId()]);
$backupCount = (int) $countStmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Security — <?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="stylesheet" href="/assets/css/auth.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
</head>
<body>
<div class="auth-shell" style="align-items:flex-start; padding-top:40px;">
  <div style="width:min(560px,100%);">

    <section class="security-card glass">
      <h2>Two-Factor Authentication</h2>

      <div class="status-row">
        <span class="label">Status</span>
        <span class="badge <?= $totpEnabled ? 'on' : 'off' ?>"><?= $totpEnabled ? 'Enabled' : 'Not enabled' ?></span>
      </div>

      <?php if ($totpEnabled): ?>
        <div class="status-row">
          <span class="label">Backup codes remaining</span>
          <span><?= (int) $backupCount ?></span>
        </div>

        <form id="regenForm" style="margin-top:16px;">
          <label>Confirm password to regenerate backup codes
            <input type="password" name="password" autocomplete="current-password" required>
          </label>
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
          <button type="submit">Regenerate backup codes</button>
        </form>

        <div id="regenCodesPanel" style="display:none; margin-top:14px;">
          <p>Save these somewhere safe -- each one only works once, and they won't be shown again.</p>
          <div id="regenCodesList" class="backup-codes"></div>
        </div>

        <form id="disableTotpForm" style="margin-top:20px;">
          <label>Confirm password to disable 2FA
            <input type="password" name="password" autocomplete="current-password" required>
          </label>
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
          <button type="submit" style="background:rgba(255,107,107,.14); border-color:rgba(255,107,107,.35);">Disable 2FA</button>
        </form>

      <?php else: ?>
        <button type="button" id="enableTotpBtn" style="margin-top:16px;">Enable 2FA with an authenticator app</button>

        <div id="totpSetupPanel" style="display:none; margin-top:18px;">
          <p>Scan this QR code with Google Authenticator, Microsoft Authenticator, 2FAS, or a similar app.</p>
          <div class="qr-wrap" id="totpQr"></div>
          <p>Or enter the setup key manually:</p>
          <code class="manual-secret" id="manualSecret"></code>

          <form id="totpSetupForm">
            <label>Enter the 6-digit code from your app
              <input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required>
            </label>
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
            <button type="submit">Verify & Enable</button>
          </form>
          <div id="setupMsg" class="msg"></div>
        </div>

        <div id="backupCodesPanel" style="display:none; margin-top:18px;">
          <h2 style="margin-bottom:6px;">Save your backup codes</h2>
          <p>Each code works once and lets you sign in if you lose access to your authenticator app. They will not be shown again.</p>
          <div id="backupCodesList" class="backup-codes"></div>
        </div>
      <?php endif; ?>
    </section>

    <div class="links" style="margin-top:10px;">
      <a href="/dashboard.php">Back to dashboard</a>
    </div>
  </div>
</div>
<script>window.APP_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;</script>
<script src="/assets/js/helpers.js"></script>
<script src="/assets/js/security.js"></script>
</body>
</html>
