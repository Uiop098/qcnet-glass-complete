<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/config/auth-config.php';
require_once __DIR__ . '/../app/core/session.php';
require_once __DIR__ . '/../app/core/csrf.php';
startSecureSession();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in — <?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body>
<div class="auth-shell">
  <section class="auth-card glass">
    <div class="brand"><?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></div>
    <h1>Welcome back</h1>
    <p>Sign in to continue.</p>

    <form id="loginForm" action="/api/auth/login.php" method="post">
      <label>Business ID
        <input type="number" name="business_id" min="1" required>
      </label>
      <label>Email
        <input type="email" name="email" autocomplete="username" required>
      </label>
      <label>Password
        <input type="password" name="password" autocomplete="current-password" required>
      </label>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
      <button type="submit">Sign In</button>
    </form>

    <?php if (isset($_GET['oauth_error'])): ?>
      <div class="msg show error">Google sign-in didn't go through. Please try again.</div>
    <?php endif; ?>

    <a class="oauth-button" id="googleBtn" href="#" aria-disabled="true">
      Continue with Google
    </a>
    <p style="color:var(--muted); font-size:.8rem; margin:6px 0 0;">Enter your Business ID above first.</p>

    <div id="formMsg" class="msg"></div>

    <div class="links">
      <a href="/forgot-password.php">Forgot password?</a> &middot;
      <a href="/register.php">Create account</a>
    </div>
  </section>
</div>
<script>window.APP_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;</script>
<script src="/assets/js/helpers.js"></script>
<script src="/assets/js/auth.js"></script>
<script>
(function () {
    const businessInput = document.querySelector('#loginForm input[name="business_id"]');
    const googleBtn = document.getElementById('googleBtn');

    function sync() {
        const id = (businessInput.value || '').trim();
        if (id) {
            googleBtn.href = '/api/auth/google-login.php?business_id=' + encodeURIComponent(id);
            googleBtn.removeAttribute('aria-disabled');
        } else {
            googleBtn.href = '#';
            googleBtn.setAttribute('aria-disabled', 'true');
        }
    }

    businessInput.addEventListener('input', sync);
    googleBtn.addEventListener('click', (e) => {
        if (googleBtn.getAttribute('aria-disabled') === 'true') {
            e.preventDefault();
            businessInput.focus();
        }
    });
    sync();
})();
</script>
</body>
</html>
