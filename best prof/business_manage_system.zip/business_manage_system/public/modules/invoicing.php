<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/config/database.php';
require_once __DIR__ . '/../../app/config/auth-config.php';
require_once __DIR__ . '/../../app/core/session.php';
require_once __DIR__ . '/../../app/core/auth.php';
require_once __DIR__ . '/../../app/core/csrf.php';

requireAuth();

$pdo = db();
$stmt = $pdo->prepare('SELECT full_name FROM users WHERE id = ?');
$stmt->execute([currentUserId()]);
$fullName = (string) ($stmt->fetchColumn() ?: '');
$userInitial = $fullName !== '' ? mb_strtoupper(mb_substr($fullName, 0, 1)) : '?';

$notifications = [];
$notifCount = 0;
$activeNav = 'invoicing';
$pageTitle = 'Invoicing';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?> — <?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="stylesheet" href="/assets/css/shell.css">
</head>
<body class="shell">
<div class="app-shell">
  <?php include __DIR__ . '/../partials/sidebar.php'; ?>
  <div>
    <?php include __DIR__ . '/../partials/topbar.php'; ?>
    <main class="content">
      <div class="tile" style="max-width:560px; margin: 40px auto; text-align:center; padding:40px 28px;">
        <div style="font-size:2.2rem; margin-bottom:10px;">&#129534;</div>
        <h2 style="margin:0 0 8px;">Invoicing</h2>
        <p style="color:var(--muted); margin:0 0 4px;">Create, send, and track invoices.</p>
        <p style="color:var(--muted); font-size:.85rem;">This module is on the roadmap and not built yet.</p>
      </div>
    </main>
  </div>
</div>
<form id="logoutForm" style="display:none;">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
</form>
<script>window.APP_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;</script>
<script src="/assets/js/helpers.js"></script>
<script src="/assets/js/shell.js"></script>
<script>
document.getElementById('logoutForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const { result } = await postJson('/api/auth/logout.php', e.target);
    location.href = result.redirect || '/login.php';
});
</script>
</body>
</html>
