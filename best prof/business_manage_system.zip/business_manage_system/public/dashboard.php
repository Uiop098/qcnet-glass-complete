<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/config/database.php';
require_once __DIR__ . '/../app/config/auth-config.php';
require_once __DIR__ . '/../app/core/session.php';
require_once __DIR__ . '/../app/core/auth.php';
require_once __DIR__ . '/../app/core/csrf.php';

requireAuth();

$pdo = db();

$stmt = $pdo->prepare('SELECT full_name, email FROM users WHERE id = ?');
$stmt->execute([currentUserId()]);
$user = $stmt->fetch();

$fullName = (string) ($user['full_name'] ?? '');
$userInitial = $fullName !== '' ? mb_strtoupper(mb_substr($fullName, 0, 1)) : '?';

// Real data: pulls from the audit log your auth system already writes to.
$activityStmt = $pdo->prepare('
    SELECT summary, created_at
    FROM audit_logs
    WHERE business_id = ?
    ORDER BY created_at DESC
    LIMIT 8
');
$activityStmt->execute([currentBusinessId()]);
$recentActivity = $activityStmt->fetchAll();

$notifications = array_slice($recentActivity, 0, 5);
$notifCount = count($notifications);

$activeNav = 'dashboard';
$pageTitle = 'Dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard — <?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="stylesheet" href="/assets/css/shell.css">
</head>
<body class="shell">
<div class="app-shell">
  <?php include __DIR__ . '/partials/sidebar.php'; ?>

  <div>
    <?php include __DIR__ . '/partials/topbar.php'; ?>

    <main class="content">
      <div class="bento">

        <!-- KPI cards -- static placeholders until a business module reports real numbers -->
        <div class="tile">
          <div class="kpi-label">Revenue this month</div>
          <div class="kpi-value">$0</div>
          <div class="kpi-delta">Connect Invoicing to populate this</div>
        </div>
        <div class="tile">
          <div class="kpi-label">Open invoices</div>
          <div class="kpi-value">0</div>
          <div class="kpi-delta">Connect Invoicing to populate this</div>
        </div>
        <div class="tile">
          <div class="kpi-label">Customers</div>
          <div class="kpi-value">0</div>
          <div class="kpi-delta">Connect CRM to populate this</div>
        </div>
        <div class="tile">
          <div class="kpi-label">Open tasks</div>
          <div class="kpi-value">0</div>
          <div class="kpi-delta">Connect Tasks to populate this</div>
        </div>

        <!-- Recent activity -- real data from audit_logs -->
        <div class="tile span-2">
          <h3>Recent activity</h3>
          <?php if ($recentActivity): ?>
            <?php foreach ($recentActivity as $a): ?>
              <div class="activity-item">
                <span class="dot"></span>
                <div>
                  <div><?= htmlspecialchars($a['summary'], ENT_QUOTES, 'UTF-8') ?></div>
                  <div class="meta"><?= htmlspecialchars($a['created_at'], ENT_QUOTES, 'UTF-8') ?></div>
                </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p style="color:var(--muted);">No activity yet.</p>
          <?php endif; ?>
        </div>

        <!-- Quick actions -->
        <div class="tile">
          <h3>Quick actions</h3>
          <div class="quick-actions">
            <a href="/modules/crm.php">&#128101; Add customer</a>
            <a href="/modules/invoicing.php">&#129534; Create invoice</a>
            <a href="/modules/tasks.php">&#9989; New task</a>
            <a href="/modules/team.php">&#9993; Invite teammate</a>
          </div>
        </div>

        <!-- Account -->
        <div class="tile">
          <h3>Your account</h3>
          <p style="margin:0 0 4px;"><?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?></p>
          <p style="margin:0 0 14px; color:var(--muted); font-size:.88rem;"><?= htmlspecialchars((string) ($user['email'] ?? ''), ENT_QUOTES, 'UTF-8') ?></p>
          <div class="quick-actions">
            <a href="/settings-security.php">&#128274; Security settings</a>
          </div>
        </div>

        <!-- Module previews -->
        <div class="tile soon-tile">
          <span class="badge-soon">Coming soon</span>
          <h3 style="margin:0;">CRM</h3>
          <p style="color:var(--muted); font-size:.88rem; margin:0;">Track customers, deals, and communication history.</p>
        </div>
        <div class="tile soon-tile">
          <span class="badge-soon">Coming soon</span>
          <h3 style="margin:0;">Invoicing</h3>
          <p style="color:var(--muted); font-size:.88rem; margin:0;">Create, send, and track invoices — wired to your existing payment API.</p>
        </div>
        <div class="tile soon-tile">
          <span class="badge-soon">Coming soon</span>
          <h3 style="margin:0;">Inventory</h3>
          <p style="color:var(--muted); font-size:.88rem; margin:0;">Stock levels, purchase orders, low-stock alerts.</p>
        </div>
        <div class="tile soon-tile">
          <span class="badge-soon">Coming soon</span>
          <h3 style="margin:0;">Tasks</h3>
          <p style="color:var(--muted); font-size:.88rem; margin:0;">Assign, track, and complete internal work.</p>
        </div>

      </div>
    </main>
  </div>
</div>

<form id="logoutForm" style="display:none;">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
</form>

<script>window.APP_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;</script>
<script src="/assets/js/helpers.js"></script>
<script src="/assets/js/shell.js"></script>
<script>
document.getElementById('logoutForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const { result } = await postJson('/api/auth/logout.php', e.target);
    location.href = result.redirect || '/login.php';
});
</script>
</body>
</html>
