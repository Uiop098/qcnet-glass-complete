function showMsg(el, text, type) {
    el.textContent = text;
    el.className = 'msg show ' + type;
}

async function postJson(url, formOrObject) {
    const body = formOrObject instanceof HTMLFormElement
        ? new FormData(formOrObject)
        : (() => {
            const fd = new FormData();
            Object.entries(formOrObject).forEach(([k, v]) => fd.append(k, v));
            return fd;
        })();

    const response = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'X-CSRF-Token': window.APP_CSRF_TOKEN || '' },
        body,
    });

    let result;
    try {
        result = await response.json();
    } catch (e) {
        result = { success: false, message: 'Unexpected server response.' };
    }

    return { ok: response.ok, result };
}
