document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('verifyForm');
    const msg = document.getElementById('formMsg');
    const codeInput = document.getElementById('code');
    const params = new URLSearchParams(location.search);
    const emailField = document.getElementById('email');

    if (emailField && params.get('email')) {
        emailField.value = params.get('email');
    }

    codeInput?.addEventListener('input', () => {
        codeInput.value = codeInput.value.replace(/\D/g, '').slice(0, 6);
    });

    form?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const button = form.querySelector('button[type="submit"]');
        button.disabled = true;

        try {
            const { ok, result } = await postJson(form.action, form);

            if (!ok || !result.success) {
                throw new Error(result.message || 'Verification failed.');
            }

            showMsg(msg, result.message, 'success');
            setTimeout(() => { location.href = '/login.php'; }, 1200);
        } catch (err) {
            showMsg(msg, err.message, 'error');
        } finally {
            button.disabled = false;
        }
    });

    document.getElementById('resendBtn')?.addEventListener('click', async () => {
        try {
            const { result } = await postJson('/api/auth/resend-verification.php', { email: emailField.value });
            showMsg(msg, result.message, 'success');
        } catch (err) {
            showMsg(msg, 'Could not resend code.', 'error');
        }
    });
});
