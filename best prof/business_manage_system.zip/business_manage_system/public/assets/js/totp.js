// Handles two-factor.php (login-time 2FA challenge).
document.addEventListener('DOMContentLoaded', () => {
    const totpForm = document.getElementById('totpForm');
    const backupForm = document.getElementById('backupForm');
    const msg = document.getElementById('formMsg');
    const totpInput = document.getElementById('totpCode');
    const useBackupBtn = document.getElementById('useBackupCode');
    const backBtn = document.getElementById('backToTotp');

    totpInput?.addEventListener('input', () => {
        totpInput.value = totpInput.value.replace(/\D/g, '').slice(0, 6);
    });

    totpForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const button = totpForm.querySelector('button[type="submit"]');
        button.disabled = true;

        try {
            const { ok, result } = await postJson('/api/auth/verify-totp.php', totpForm);

            if (!ok || !result.success) {
                throw new Error(result.message || 'Verification failed.');
            }

            location.href = result.redirect || '/dashboard.php';
        } catch (err) {
            showMsg(msg, err.message, 'error');
        } finally {
            button.disabled = false;
        }
    });

    backupForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const button = backupForm.querySelector('button[type="submit"]');
        button.disabled = true;

        try {
            const { ok, result } = await postJson('/api/auth/verify-backup-code.php', backupForm);

            if (!ok || !result.success) {
                throw new Error(result.message || 'Verification failed.');
            }

            location.href = result.redirect || '/dashboard.php';
        } catch (err) {
            showMsg(msg, err.message, 'error');
        } finally {
            button.disabled = false;
        }
    });

    useBackupBtn?.addEventListener('click', () => {
        totpForm.style.display = 'none';
        useBackupBtn.style.display = 'none';
        backupForm.style.display = 'block';
        backBtn.style.display = 'block';
    });

    backBtn?.addEventListener('click', () => {
        backupForm.style.display = 'none';
        backBtn.style.display = 'none';
        totpForm.style.display = 'block';
        useBackupBtn.style.display = 'block';
    });
});
