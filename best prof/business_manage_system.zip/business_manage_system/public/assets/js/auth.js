// Handles login.php and register.php forms.
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const msg = document.getElementById('formMsg');

    loginForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const button = loginForm.querySelector('button[type="submit"]');
        button.disabled = true;

        try {
            const { ok, result } = await postJson(loginForm.action, loginForm);

            if (!ok || !result.success) {
                throw new Error(result.message || 'Login failed.');
            }

            if (result.next === '2fa') {
                location.href = '/two-factor.php';
                return;
            }

            location.href = result.redirect || '/dashboard.php';
        } catch (err) {
            if (msg) showMsg(msg, err.message, 'error');
        } finally {
            button.disabled = false;
        }
    });

    const registerForm = document.getElementById('registerForm');

    registerForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const button = registerForm.querySelector('button[type="submit"]');
        button.disabled = true;

        try {
            const { ok, result } = await postJson(registerForm.action, registerForm);

            if (!ok || !result.success) {
                throw new Error(result.message || 'Registration failed.');
            }

            const email = encodeURIComponent(registerForm.email.value);
            location.href = '/verify-email.php?email=' + email;
        } catch (err) {
            if (msg) showMsg(msg, err.message, 'error');
        } finally {
            button.disabled = false;
        }
    });
});
