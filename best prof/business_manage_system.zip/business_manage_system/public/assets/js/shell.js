(function () {
    // ---- Theme toggle (persisted in localStorage; this is a real deployed
    // site, not an in-chat artifact, so localStorage is the right tool here) ----
    const root = document.documentElement;
    const stored = localStorage.getItem('bms-theme');
    const initial = stored || 'dark';
    root.setAttribute('data-theme', initial);

    function updateThemeIcon() {
        const btn = document.getElementById('themeToggle');
        if (!btn) return;
        btn.textContent = root.getAttribute('data-theme') === 'dark' ? '\u2600' : '\u263D';
    }
    updateThemeIcon();

    document.getElementById('themeToggle')?.addEventListener('click', () => {
        const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        root.setAttribute('data-theme', next);
        localStorage.setItem('bms-theme', next);
        updateThemeIcon();
    });

    // ---- Mobile sidebar ----
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebarBackdrop');

    function closeSidebar() {
        sidebar?.classList.remove('open');
        backdrop?.classList.remove('show');
    }

    document.getElementById('menuToggle')?.addEventListener('click', () => {
        sidebar?.classList.add('open');
        backdrop?.classList.add('show');
    });
    backdrop?.addEventListener('click', closeSidebar);

    // ---- Notification dropdown ----
    const notifBtn = document.getElementById('notifBtn');
    const notifPanel = document.getElementById('notifPanel');

    notifBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        notifPanel?.classList.toggle('open');
    });
    document.addEventListener('click', (e) => {
        if (notifPanel && !notifPanel.contains(e.target) && e.target !== notifBtn) {
            notifPanel.classList.remove('open');
        }
    });

    // ---- Command palette (Ctrl/Cmd+K) ----
    const cmdkBackdrop = document.getElementById('cmdkBackdrop');
    const cmdkInput = document.getElementById('cmdkInput');
    const cmdkResults = document.getElementById('cmdkResults');

    // Extend this list as real pages/actions get built.
    const commands = window.BMS_COMMANDS || [
        { label: 'Dashboard', hint: 'Go to', href: '/dashboard.php' },
        { label: 'CRM / Customers', hint: 'Go to', href: '/modules/crm.php' },
        { label: 'Invoicing', hint: 'Go to', href: '/modules/invoicing.php' },
        { label: 'Inventory', hint: 'Go to', href: '/modules/inventory.php' },
        { label: 'Tasks', hint: 'Go to', href: '/modules/tasks.php' },
        { label: 'Team', hint: 'Go to', href: '/modules/team.php' },
        { label: 'Security settings', hint: 'Go to', href: '/settings-security.php' },
        { label: 'Sign out', hint: 'Action', href: '#logout' },
    ];

    let activeIndex = 0;

    function renderResults(query) {
        const q = query.trim().toLowerCase();
        const filtered = commands.filter((c) => c.label.toLowerCase().includes(q));
        cmdkResults.innerHTML = '';
        activeIndex = 0;

        filtered.forEach((c, i) => {
            const el = document.createElement('div');
            el.className = 'cmdk-item' + (i === 0 ? ' active' : '');
            el.innerHTML = '<span>' + c.label + '</span><span class="cmdk-hint">' + c.hint + '</span>';
            el.addEventListener('click', () => go(c));
            cmdkResults.appendChild(el);
        });
    }

    function go(cmd) {
        closeCmdk();
        if (cmd.href === '#logout') {
            document.getElementById('logoutForm')?.requestSubmit();
            return;
        }
        location.href = cmd.href;
    }

    function openCmdk() {
        cmdkBackdrop.classList.add('open');
        cmdkInput.value = '';
        renderResults('');
        setTimeout(() => cmdkInput.focus(), 30);
    }

    function closeCmdk() {
        cmdkBackdrop.classList.remove('open');
    }

    document.getElementById('searchTrigger')?.addEventListener('click', openCmdk);
    cmdkBackdrop?.addEventListener('click', (e) => {
        if (e.target === cmdkBackdrop) closeCmdk();
    });

    cmdkInput?.addEventListener('input', () => renderResults(cmdkInput.value));

    document.addEventListener('keydown', (e) => {
        const isCmdK = (e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k';
        if (isCmdK) {
            e.preventDefault();
            cmdkBackdrop.classList.contains('open') ? closeCmdk() : openCmdk();
            return;
        }
        if (!cmdkBackdrop?.classList.contains('open')) return;

        const items = Array.from(cmdkResults.querySelectorAll('.cmdk-item'));
        if (e.key === 'Escape') { closeCmdk(); return; }
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            activeIndex = Math.min(activeIndex + 1, items.length - 1);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            activeIndex = Math.max(activeIndex - 1, 0);
        } else if (e.key === 'Enter') {
            items[activeIndex]?.dispatchEvent(new Event('click'));
            return;
        } else {
            return;
        }
        items.forEach((it, i) => it.classList.toggle('active', i === activeIndex));
        items[activeIndex]?.scrollIntoView({ block: 'nearest' });
    });
})();
