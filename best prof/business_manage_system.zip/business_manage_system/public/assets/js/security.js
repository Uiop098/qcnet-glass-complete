// Handles settings-security.php: enable/disable 2FA, backup codes.
document.addEventListener('DOMContentLoaded', () => {
    const enableBtn = document.getElementById('enableTotpBtn');
    const setupPanel = document.getElementById('totpSetupPanel');
    const qrWrap = document.getElementById('totpQr');
    const manualSecret = document.getElementById('manualSecret');
    const setupForm = document.getElementById('totpSetupForm');
    const setupMsg = document.getElementById('setupMsg');
    const backupCodesPanel = document.getElementById('backupCodesPanel');
    const backupCodesList = document.getElementById('backupCodesList');
    const disableForm = document.getElementById('disableTotpForm');
    const regenForm = document.getElementById('regenForm');
    const regenPanel = document.getElementById('regenCodesPanel');
    const regenList = document.getElementById('regenCodesList');

    function renderBackupCodes(container, codes) {
        container.innerHTML = '';
        codes.forEach((c) => {
            const el = document.createElement('code');
            el.textContent = c;
            container.appendChild(el);
        });
    }

    enableBtn?.addEventListener('click', async () => {
        enableBtn.disabled = true;
        try {
            const { ok, result } = await postJson('/api/auth/enable-totp.php', {});
            if (!ok || !result.success) throw new Error(result.message || 'Could not start setup.');

            setupPanel.style.display = 'block';
            manualSecret.textContent = result.secret;
            qrWrap.innerHTML = '';

            if (window.QRCode) {
                new QRCode(qrWrap, { text: result.otpauth_uri, width: 180, height: 180 });
            } else {
                qrWrap.textContent = 'Scan not available -- enter the key below manually.';
            }
        } catch (err) {
            alert(err.message);
        } finally {
            enableBtn.disabled = false;
        }
    });

    setupForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const button = setupForm.querySelector('button[type="submit"]');
        button.disabled = true;

        try {
            const { ok, result } = await postJson('/api/auth/verify-totp-setup.php', setupForm);
            if (!ok || !result.success) throw new Error(result.message || 'Verification failed.');

            setupPanel.style.display = 'none';
            backupCodesPanel.style.display = 'block';
            renderBackupCodes(backupCodesList, result.backup_codes);
        } catch (err) {
            setupMsg.textContent = err.message;
            setupMsg.className = 'msg show error';
        } finally {
            button.disabled = false;
        }
    });

    disableForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!confirm('Disable two-factor authentication?')) return;

        try {
            const { ok, result } = await postJson('/api/auth/disable-totp.php', disableForm);
            if (!ok || !result.success) throw new Error(result.message || 'Could not disable 2FA.');
            location.reload();
        } catch (err) {
            alert(err.message);
        }
    });

    regenForm?.addEventListener('submit', async (e) => {
        e.preventDefault();

        try {
            const { ok, result } = await postJson('/api/auth/regenerate-backup-codes.php', regenForm);
            if (!ok || !result.success) throw new Error(result.message || 'Could not regenerate codes.');

            regenPanel.style.display = 'block';
            renderBackupCodes(regenList, result.backup_codes);
        } catch (err) {
            alert(err.message);
        }
    });
});
