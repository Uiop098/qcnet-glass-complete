document.addEventListener('DOMContentLoaded', () => {
    const forgotForm = document.getElementById('forgotForm');
    const msg = document.getElementById('formMsg');

    forgotForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const button = forgotForm.querySelector('button[type="submit"]');
        button.disabled = true;

        try {
            const { result } = await postJson(forgotForm.action, forgotForm);
            showMsg(msg, result.message, 'success');
        } catch (err) {
            showMsg(msg, 'Something went wrong.', 'error');
        } finally {
            button.disabled = false;
        }
    });

    const resetForm = document.getElementById('resetForm');

    resetForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const button = resetForm.querySelector('button[type="submit"]');
        button.disabled = true;

        try {
            const { ok, result } = await postJson(resetForm.action, resetForm);

            if (!ok || !result.success) {
                throw new Error(result.message || 'Could not reset password.');
            }

            showMsg(msg, result.message, 'success');
            setTimeout(() => { location.href = '/login.php'; }, 1200);
        } catch (err) {
            showMsg(msg, err.message, 'error');
        } finally {
            button.disabled = false;
        }
    });
});
