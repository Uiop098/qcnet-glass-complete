<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/config/auth-config.php';
require_once __DIR__ . '/../app/core/session.php';
require_once __DIR__ . '/../app/core/csrf.php';
startSecureSession();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forgot password — <?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body>
<div class="auth-shell">
  <section class="auth-card glass">
    <div class="brand"><?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></div>
    <h1>Reset your password</h1>
    <p>We'll email you a link if the address matches an account.</p>

    <form id="forgotForm" action="/api/auth/request-password-reset.php" method="post">
      <label>Email
        <input type="email" name="email" autocomplete="username" required>
      </label>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
      <button type="submit">Send reset link</button>
    </form>

    <div id="formMsg" class="msg"></div>

    <div class="links">
      <a href="/login.php">Back to sign in</a>
    </div>
  </section>
</div>
<script>window.APP_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;</script>
<script src="/assets/js/helpers.js"></script>
<script src="/assets/js/reset.js"></script>
</body>
</html>
