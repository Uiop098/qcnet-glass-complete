<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/config/auth-config.php';
require_once __DIR__ . '/../app/core/session.php';
require_once __DIR__ . '/../app/core/csrf.php';
startSecureSession();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Create account — <?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body>
<div class="auth-shell">
  <section class="auth-card glass">
    <div class="brand"><?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></div>
    <h1>Create your account</h1>
    <p>Takes less than a minute.</p>

    <form id="registerForm" action="/api/auth/register.php" method="post">
      <label>Business ID
        <input type="number" name="business_id" min="1" required>
      </label>
      <label>Full name
        <input type="text" name="full_name" autocomplete="name" required>
      </label>
      <label>Email
        <input type="email" name="email" autocomplete="username" required>
      </label>
      <label>Password
        <input type="password" name="password" autocomplete="new-password" minlength="8" required>
      </label>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
      <button type="submit">Create Account</button>
    </form>

    <div id="formMsg" class="msg"></div>

    <div class="links">
      <a href="/login.php">Already have an account? Sign in</a>
    </div>
  </section>
</div>
<script>window.APP_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;</script>
<script src="/assets/js/helpers.js"></script>
<script src="/assets/js/auth.js"></script>
</body>
</html>
