<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/config/auth-config.php';
require_once __DIR__ . '/../app/core/session.php';
require_once __DIR__ . '/../app/core/csrf.php';
startSecureSession();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verify email — <?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="stylesheet" href="/assets/css/auth.css">
</head>
<body>
<div class="auth-shell">
  <section class="auth-card glass">
    <div class="brand"><?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></div>
    <h1>Verify your email</h1>
    <p>Enter the 6-digit code we emailed you.</p>

    <form id="verifyForm" action="/api/auth/verify-email.php" method="post">
      <label>Email
        <input type="email" id="email" name="email" autocomplete="username" required>
      </label>
      <label>Verification code
        <input type="text" id="code" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required>
      </label>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
      <button type="submit">Verify</button>
    </form>

    <button type="button" id="resendBtn" style="margin-top:10px;">Resend code</button>

    <div id="formMsg" class="msg"></div>

    <div class="links">
      <a href="/login.php">Back to sign in</a>
    </div>
  </section>
</div>
<script>window.APP_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;</script>
<script src="/assets/js/helpers.js"></script>
<script src="/assets/js/verify-email.js"></script>
</body>
</html>
