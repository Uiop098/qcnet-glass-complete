<?php
declare(strict_types=1);
// Expects $activeNav to be set by the including page (e.g. 'dashboard', 'crm', 'invoicing'...)
$activeNav = $activeNav ?? '';

function navLink(string $key, string $href, string $icon, string $label, string $active, bool $soon = false): void
{
    $isActive = $key === $active;
    echo '<a class="nav-link' . ($isActive ? ' active' : '') . '" href="' . htmlspecialchars($href, ENT_QUOTES) . '">';
    echo '<span class="icon">' . $icon . '</span><span>' . htmlspecialchars($label, ENT_QUOTES) . '</span>';
    if ($soon) {
        echo '<span class="soon">Soon</span>';
    }
    echo '</a>';
}
?>
<div class="sidebar-backdrop" id="sidebarBackdrop"></div>
<aside class="sidebar" id="sidebar">
  <div class="brand"><span class="dot"></span> <?= htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8') ?></div>

  <div class="nav-section">Overview</div>
  <?php navLink('dashboard', '/dashboard.php', '&#9635;', 'Dashboard', $activeNav); ?>

  <div class="nav-section">Business</div>
  <?php navLink('crm', '/modules/crm.php', '&#128101;', 'CRM / Customers', $activeNav, true); ?>
  <?php navLink('invoicing', '/modules/invoicing.php', '&#129534;', 'Invoicing', $activeNav, true); ?>
  <?php navLink('inventory', '/modules/inventory.php', '&#128230;', 'Inventory', $activeNav, true); ?>
  <?php navLink('tasks', '/modules/tasks.php', '&#9989;', 'Tasks', $activeNav, true); ?>

  <div class="nav-section">Workspace</div>
  <?php navLink('team', '/modules/team.php', '&#128100;', 'Team', $activeNav, true); ?>
  <?php navLink('security', '/settings-security.php', '&#128274;', 'Security', $activeNav); ?>

  <div class="nav-section" style="margin-top:auto;">&nbsp;</div>
</aside>
