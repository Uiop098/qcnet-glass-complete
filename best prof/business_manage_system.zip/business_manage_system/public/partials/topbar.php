<?php
declare(strict_types=1);
// Expects $pageTitle to be set by the including page.
$pageTitle = $pageTitle ?? 'Dashboard';
?>
<header class="topbar">
  <button class="icon-btn menu-toggle" id="menuToggle" type="button" aria-label="Open menu">&#9776;</button>

  <div class="search-trigger" id="searchTrigger">
    <span>&#128269;</span>
    <span>Search or jump to...</span>
    <kbd>Ctrl K</kbd>
  </div>

  <div class="topbar-right">
    <button class="icon-btn" id="themeToggle" type="button" aria-label="Toggle theme">&#9789;</button>

    <div class="dropdown-wrap">
      <button class="icon-btn" id="notifBtn" type="button" aria-label="Notifications" style="position:relative;">
        &#128276;
        <?php if (!empty($notifCount)): ?><span class="badge-dot"></span><?php endif; ?>
      </button>
      <div class="dropdown-panel" id="notifPanel">
        <div class="dp-title">Recent activity</div>
        <?php if (!empty($notifications)): ?>
          <?php foreach ($notifications as $n): ?>
            <div class="dp-item"><?= htmlspecialchars($n['summary'], ENT_QUOTES, 'UTF-8') ?></div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="dp-item" style="color:var(--muted);">Nothing yet.</div>
        <?php endif; ?>
      </div>
    </div>

    <div class="avatar"><?= htmlspecialchars($userInitial ?? '?', ENT_QUOTES, 'UTF-8') ?></div>
  </div>
</header>

<div class="cmdk-backdrop" id="cmdkBackdrop">
  <div class="cmdk-box">
    <input class="cmdk-input" id="cmdkInput" placeholder="Type a command or search...">
    <div class="cmdk-results" id="cmdkResults"></div>
  </div>
</div>
