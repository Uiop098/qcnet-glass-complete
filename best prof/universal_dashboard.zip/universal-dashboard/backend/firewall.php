<?php
// Simple PHP Web Protection & Firewall
session_start();

function sanitize_input($data) {
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            $data[$key] = sanitize_input($value);
        }
    } else {
        $data = htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
    }
    return $data;
}

$_GET = sanitize_input($_GET);
$_POST = sanitize_input($_POST);

$blocked_ips = ['192.168.1.100', '10.0.0.5'];
$user_ip = $_SERVER['REMOTE_ADDR'];

if (in_array($user_ip, $blocked_ips)) {
    header('HTTP/1.0 403 Forbidden');
    die(json_encode(["error" => "Access denied by firewall."]));
}
?>