<?php
require_once 'firewall.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$data_file = 'data/users.json';

if (!file_exists($data_file)) {
    file_put_contents($data_file, json_encode([]));
}

switch ($action) {
    case 'get_users':
        $users = json_decode(file_get_contents($data_file), true);
        echo json_encode(["status" => "success", "data" => $users]);
        break;
    case 'add_user':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $users = json_decode(file_get_contents($data_file), true) ?: [];
            $new_user = [
                "id" => uniqid(),
                "name" => $_POST['name'] ?? '',
                "email" => $_POST['email'] ?? '',
                "mobile" => $_POST['mobile'] ?? '',
                "address" => $_POST['address'] ?? ''
            ];
            $users[] = $new_user;
            file_put_contents($data_file, json_encode($users, JSON_PRETTY_PRINT));
            echo json_encode(["status" => "success", "message" => "User added locally."]);
        }
        break;
    default:
        echo json_encode(["status" => "error", "message" => "Invalid action."]);
        break;
}
?>