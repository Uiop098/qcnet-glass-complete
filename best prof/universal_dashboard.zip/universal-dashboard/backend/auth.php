<?php
require_once 'firewall.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$pending_file = 'data/pending_users.json';
$users_file = 'data/users.json';

foreach ([$pending_file, $users_file] as $file) {
    if (!file_exists($file)) file_put_contents($file, json_encode([]));
}

function cleanup_expired_tokens($file) {
    $pending = json_decode(file_get_contents($file), true) ?: [];
    $current_time = time();
    $active = array_filter($pending, function($user) use ($current_time) {
        return $user['expires_at'] > $current_time;
    });
    file_put_contents($file, json_encode($active, JSON_PRETTY_PRINT));
    return $active;
}

switch ($action) {
    case 'create_pending':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $pending = cleanup_expired_tokens($pending_file);
            $token = bin2hex(random_bytes(16));
            $expires_at = time() + (10 * 60);
            $pending[$token] = [
                "name" => $_POST['name'] ?? '',
                "dob" => $_POST['dob'] ?? '',
                "expires_at" => $expires_at
            ];
            file_put_contents($pending_file, json_encode($pending, JSON_PRETTY_PRINT));
            echo json_encode(["status" => "success", "token" => $token, "expires_in" => "10 minutes"]);
        }
        break;
    case 'complete_setup':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $pending = cleanup_expired_tokens($pending_file);
            $token = $_POST['token'] ?? '';
            $dob_attempt = $_POST['dob'] ?? '';
            
            if (!isset($pending[$token]) || $pending[$token]['dob'] !== $dob_attempt) {
                die(json_encode(["error" => "Invalid token, expired, or incorrect Birth Date."]));
            }
            
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            
            if (!preg_match('/^[a-zA-Z0-9]+$/', $username) || !preg_match('/^[a-zA-Z0-9]+$/', $password)) {
                die(json_encode(["error" => "Username and Password can only contain letters and numbers."]));
            }
            
            $users = json_decode(file_get_contents($users_file), true) ?: [];
            if (isset($users[$username])) {
                die(json_encode(["error" => "Username already taken."]));
            }
            
            $users[$username] = [
                "name" => $pending[$token]['name'],
                "dob" => $pending[$token]['dob'],
                "password_hash" => password_hash($password, PASSWORD_DEFAULT),
                "created_at" => time()
            ];
            
            file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
            unset($pending[$token]);
            file_put_contents($pending_file, json_encode($pending, JSON_PRETTY_PRINT));
            
            echo json_encode(["status" => "success", "message" => "Account created successfully. You may now log in."]);
        }
        break;
    default:
        echo json_encode(["error" => "Invalid endpoint."]);
        break;
}
?>