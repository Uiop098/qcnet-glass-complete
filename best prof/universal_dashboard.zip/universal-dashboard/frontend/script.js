const wallpapers = [
    'url("assets/default-wallpaper.jpg")',
    'url("assets/dark-abstract.jpg")',
    'url("assets/nature.jpg")'
];
let currentBg = 0;
function changeTheme() {
    currentBg = (currentBg + 1) % wallpapers.length;
    document.documentElement.style.setProperty('--bg-image', wallpapers[currentBg]);
}
async function loadUsers() {
    try {
        const response = await fetch('../backend/api.php?action=get_users');
        const data = await response.json();
        if (data.status === 'success') {
            let html = `<h3>User Management</h3>
                        <button onclick="alert('Add User Form Placeholder')">+ Add User</button>
                        <table>
                            <tr><th>Name</th><th>Email</th><th>Mobile</th><th>Address</th></tr>`;
            if (data.data && Array.isArray(data.data)) {
                data.data.forEach(user => {
                    html += `<tr><td>${user.name}</td><td>${user.email}</td><td>${user.mobile}</td><td>${user.address}</td></tr>`;
                });
            }
            html += `</table>`;
            document.getElementById('content-area').innerHTML = html;
        }
    } catch (error) {
        console.error("Error fetching data:", error);
    }
}
function loadSection(section) {
    if (section === 'users') loadUsers();
    else document.getElementById('content-area').innerHTML = `<p>Loading ${section} module...</p>`;
}
