<?php
// =============================================================================
// db.php — Shared multi-domain database connection layer
// =============================================================================
// Every domain deployment of this app includes an identical copy of this
// file, pointed at the SAME database via db_config.php (not committed —
// see db_config.example.php). That's the entire "sync" mechanism: there's
// no custom replication or API between domains, they just all read/write
// the same MySQL/MariaDB instance directly. Room names are NOT
// domain-prefixed (confirmed design — password is the security boundary),
// so this file has no concept of "which domain am I" baked into queries.
//
// This file provides ONLY the connection + a few low-level helpers.
// The actual read_config()/write_config()/append_message()/etc. functions
// that the rest of the app already calls are redefined in db_common.php
// (Stage 2) with IDENTICAL signatures to their old file-based versions in
// common.php, so admin.php/api.php/auth.php/etc. don't need to change at
// all — only which file gets require_once'd changes.
// =============================================================================

if (!file_exists(__DIR__ . '/db_config.php')) {
    http_response_code(500);
    die(json_encode([
        'ok' => false,
        'error' => 'db_config_missing',
        'message' => 'db_config.php was not found. Copy db_config.example.php to db_config.php and fill in your database credentials.',
    ]));
}
require_once __DIR__ . '/db_config.php';

// ---------------------------------------------------------------------------
// Connection (singleton — one PDO instance per request, reused by every
// function that needs it via db())
// ---------------------------------------------------------------------------
function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $requiredConstants = ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASS'];
    foreach ($requiredConstants as $c) {
        if (!defined($c)) {
            http_response_code(500);
            die(json_encode(['ok' => false, 'error' => 'db_config_incomplete', 'message' => "db_config.php is missing $c."]));
        }
    }

    $port = defined('DB_PORT') ? DB_PORT : 3306;
    $charset = 'utf8mb4';
    $dsn = "mysql:host=" . DB_HOST . ";port=$port;dbname=" . DB_NAME . ";charset=$charset";

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false, // real prepared statements — prevents SQL injection at the driver level, not just via escaping
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES $charset",
        ]);
    } catch (PDOException $e) {
        error_log('db() connection failed: ' . $e->getMessage());
        http_response_code(500);
        die(json_encode(['ok' => false, 'error' => 'db_connection_failed', 'message' => 'Could not connect to the database. Please try again shortly.']));
    }

    return $pdo;
}

// ---------------------------------------------------------------------------
// db_named($connectionName) — connects to one of the OPTIONAL additional
// databases defined in db_config.php's DB_CONNECTIONS array (see that
// file's "OPTIONAL: multiple joined databases" section). Completely
// separate from db() above — calling db() never touches this, and
// calling db_named() never touches the main shared connection. This
// exists as a ready slot for when per-domain/per-tenant databases are
// actually needed; until DB_CONNECTIONS is filled in, this simply
// returns null rather than fatally erroring, since "not configured yet"
// is the expected, normal state for this feature right now.
//
// Each named connection gets its own cached PDO instance (keyed by
// name), same singleton-per-request pattern as db() itself, so calling
// db_named('domainB') repeatedly in one request reuses the same
// connection rather than reconnecting each time.
function db_named(string $connectionName): ?PDO {
    static $pool = [];
    if (isset($pool[$connectionName])) return $pool[$connectionName];

    if (!defined('DB_CONNECTIONS') || !isset(DB_CONNECTIONS[$connectionName])) {
        // Not configured — this is the expected default state, not an
        // error condition worth logging noisily. Callers should check
        // for null and decide what "this extra database isn't set up
        // yet" means for their own feature.
        return null;
    }

    $cfg = DB_CONNECTIONS[$connectionName];
    $requiredKeys = ['host', 'name', 'user', 'pass'];
    foreach ($requiredKeys as $k) {
        if (!isset($cfg[$k])) {
            error_log("db_named('$connectionName'): DB_CONNECTIONS entry is missing '$k' — check db_config.php.");
            return null;
        }
    }

    $port = $cfg['port'] ?? 3306;
    $charset = 'utf8mb4';
    $dsn = "mysql:host={$cfg['host']};port=$port;dbname={$cfg['name']};charset=$charset";

    try {
        $pdo = new PDO($dsn, $cfg['user'], $cfg['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES $charset",
        ]);
    } catch (PDOException $e) {
        error_log("db_named('$connectionName') connection failed: " . $e->getMessage());
        return null;
    }

    $pool[$connectionName] = $pdo;
    return $pdo;
}

// Lists which additional named connections are actually configured
// right now — useful for a future admin panel or diagnostic to show
// "these are the extra databases currently wired up" without needing
// to read db_config.php directly.
function db_named_connections_configured(): array {
    if (!defined('DB_CONNECTIONS')) return [];
    return array_keys(DB_CONNECTIONS);
}

// ---------------------------------------------------------------------------
// Small query helpers — thin wrappers so callers don't repeat the same
// prepare/execute/fetch boilerplate everywhere. Every one of these uses a
// prepared statement with bound parameters, never string-concatenated SQL.
// ---------------------------------------------------------------------------

// Returns the first matching row as an associative array, or null.
function db_one(string $sql, array $params = []): ?array {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();
    return $row === false ? null : $row;
}

// Returns all matching rows as an array of associative arrays.
function db_all(string $sql, array $params = []): array {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

// Runs an INSERT/UPDATE/DELETE. Returns the number of affected rows.
function db_exec(string $sql, array $params = []): int {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->rowCount();
}

// Runs an INSERT and returns the new row's auto-increment id.
function db_insert(string $sql, array $params = []): int {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return (int)db()->lastInsertId();
}

// Wraps a callable in a transaction — commits on success, rolls back and
// re-throws on any exception. Use for any operation that touches more
// than one table and must be all-or-nothing (e.g. append_message()
// inserting a message AND bumping the room's last_activity).
function db_transaction(callable $fn) {
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $result = $fn();
        $pdo->commit();
        return $result;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// now_ms() already exists in common.php with this exact behavior — this
// duplicate only exists so db.php has zero dependency on common.php and
// can be tested/required standalone. db_common.php (Stage 2) will use
// common.php's version instead once both files are loaded together.
if (!function_exists('now_ms')) {
    function now_ms() { return (int) round(microtime(true) * 1000); }
}
