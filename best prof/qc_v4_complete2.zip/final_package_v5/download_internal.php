<?php
// =============================================================================
// download_internal.php — Stage 3: server-to-server file fetch
// =============================================================================
// Called ONLY by another domain's download.php (via
// fetch_remote_file_bytes() in file_links.php), never directly by a
// browser. Authentication here is deliberately different from every
// other endpoint in this app: there's no user session token, because
// the CALLER is a server, not a logged-in person. Instead, trust comes
// entirely from the encrypted link token itself — it can only have
// been minted by a domain that already has FILE_LINK_SECRET (i.e. one
// of this app's own deployments), and it can only resolve to a
// file_links row that a real upload already created. A random guessed
// token fails to decrypt; a tampered one fails the GCM auth check.
//
// This does NOT re-check room membership/bans/mute status — that
// already happened on the REQUESTING domain's download.php before it
// ever called this. This endpoint's only job is "does this token
// resolve to a real local file, if so stream its bytes" — it has no
// concept of who the end user is, by design.
// =============================================================================

require_once __DIR__ . '/file_links.php';
require_once __DIR__ . '/firewall.php'; // rate_limit_allow()/get_client_ip() — this endpoint has no session to key off, so IP-based limiting is the only throttle available to it

// Rate-limited like every other endpoint in this app, even though the
// caller here is another domain's server rather than a browser — an
// unthrottled server-to-server endpoint is still a real target for
// abuse (token-guessing attempts, or just load), and there's no
// legitimate reason a single origin server would need more than a
// generous burst of these in a short window.
if (!rate_limit_allow('download_internal', get_client_ip(), 120, 60)) {
    http_response_code(429);
    exit;
}

$token = isset($_GET['token']) ? $_GET['token'] : '';
if ($token === '') {
    http_response_code(400);
    exit;
}

$linkId = verify_file_link_token($token);
if ($linkId === null) {
    http_response_code(403); // invalid/tampered/forged token
    exit;
}

$row = db_one('SELECT * FROM file_links WHERE id = ?', [$linkId]);
if (!$row) {
    http_response_code(404);
    exit;
}

// This deployment must actually be the origin domain for this file —
// a token resolving here that claims a DIFFERENT origin_domain would
// mean either a misconfiguration or something unexpected; refuse
// rather than guess.
if (!defined('THIS_DOMAIN') || rtrim($row['origin_domain'], '/') !== rtrim(THIS_DOMAIN, '/')) {
    http_response_code(403);
    exit;
}

$realPath = realpath($row['local_path']);
$realFilesDir = realpath($GLOBALS['filesDir'] ?? (__DIR__ . '/files'));
if ($realPath === false || $realFilesDir === false || strpos($realPath, $realFilesDir . DIRECTORY_SEPARATOR) !== 0 || !is_file($realPath)) {
    http_response_code(404);
    exit;
}

header('Content-Type: application/octet-stream');
header('Content-Length: ' . filesize($realPath));
readfile($realPath);
