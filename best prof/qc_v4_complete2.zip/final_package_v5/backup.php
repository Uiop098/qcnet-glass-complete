<?php
// backup.php — v35, PART 3: "Auto-backup". Super-only, on-demand (no
// cron needed on shared hosting).
//
// STAGE 2 UPDATE: now exports a SQL dump of the live database (rooms,
// messages, sessions, dashboard tables) via build_database_backup_sql()
// in common.php, instead of zipping data/*.json — the JSON files are no
// longer where live data lives once Stage 2 is switched on. Restore
// with: mysql -u USER -p DATABASE_NAME < backup_file.sql
//
// If you haven't switched over to the database yet (common.php still
// has its file-based functions), this will fail cleanly with a clear
// message rather than silently producing an empty/wrong backup — see
// the db()-availability check inside build_database_backup_sql().

require_once __DIR__ . '/common.php';
require_once __DIR__ . '/db.php'; // needed for build_database_backup_sql()

$masterToken = isset($_GET['masterToken']) ? $_GET['masterToken'] : '';
$session = get_session($masterToken);
// Restricted to the still-active master super-login session itself (not a
// room-joined 'super' session, which any tenant admin can legitimately hold
// after verifying just one room's password) AND to master tier specifically.
// This used to accept any 'super' or 'super_master' role regardless of
// tier — meaning a tenant admin who'd verified their way into just one of
// their own rooms could download a full backup of every room on the
// server, across every other tenant too.
$isSuper = $session && $session['role'] === 'super_master' && ($session['tier'] ?? 'master') === 'master';

if (!$isSuper) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Only the default super admin can download a backup.']);
    exit;
}

if (!rate_limit_allow('backup', get_client_ip(), 5, 300)) {
    http_response_code(429);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'rate_limited', 'message' => 'Please wait before requesting another backup.']);
    exit;
}

$sqlPath = build_database_backup_sql();
if (!$sqlPath) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'Backup could not be created. If this deployment has not been switched over to the database yet (see db_common.php\'s header for that step), use the old JSON export instead, or check your PHP error log for the specific failure.']);
    exit;
}

$stamp = date('Ymd_His');
header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="quickchat_backup_' . $stamp . '.sql"');
header('Content-Length: ' . filesize($sqlPath));
readfile($sqlPath);
@unlink($sqlPath);
