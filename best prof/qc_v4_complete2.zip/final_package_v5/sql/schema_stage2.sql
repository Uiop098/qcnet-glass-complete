-- =============================================================================
-- schema_stage2.sql — additive schema changes for Stage 2
-- =============================================================================
-- Run this ONCE, after schema.sql, before deploying db_common.php.
-- Adds a `username` column to `sessions` that Stage 1's schema.sql didn't
-- include — discovered while building db_common.php: auth.php's
-- super_login flow reads the whole sessions table as a raw array,
-- patches in a `username` field (the raw login name, separate from
-- `user` which holds the display name) alongside `tier`, and writes it
-- straight back — see read_sessions()/write_sessions() in
-- db_common.php for why this bypass-the-clean-API pattern needs to be
-- preserved rather than rewriting auth.php itself.
--
-- Uses native "ADD COLUMN IF NOT EXISTS" (MySQL 8.0.29+ / MariaDB
-- 10.0.2+ — virtually all current hosting supports this) instead of a
-- stored procedure. Shared hosting (InfinityFree and similar) commonly
-- denies the CREATE ROUTINE / ALTER ROUTINE privilege a stored
-- procedure needs, even though the account can run plain ALTER TABLE
-- just fine — this version needs no elevated privileges at all.
-- =============================================================================

ALTER TABLE sessions ADD COLUMN IF NOT EXISTS username VARCHAR(190) NULL AFTER tier;

-- edit_message() sets an editedAt timestamp separate from the edited
-- flag (found on close comparison against common.php's real
-- edit_message() — not in the original schema.sql's messages table).
ALTER TABLE messages ADD COLUMN IF NOT EXISTS edited_at BIGINT UNSIGNED NULL AFTER edited;

-- Two message fields found missing during Stage 3 verification:
-- isVoiceMessage (distinguishes a recorded voice note from a regular
-- audio file upload) and sentWhileEncrypted (cosmetic label — was the
-- room's encryption toggle on when this file was sent). Neither was in
-- the original messages schema, so both were being silently dropped
-- on every file/voice upload once Stage 2 was switched on.
ALTER TABLE messages ADD COLUMN IF NOT EXISTS is_voice_message TINYINT(1) NOT NULL DEFAULT 0 AFTER file_ext;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS sent_while_encrypted TINYINT(1) NOT NULL DEFAULT 0 AFTER is_voice_message;

-- QR "scan to join" hard-cutoff support — a session created via a QR
-- join code (see qr_join.php, create_session()'s new 4th $extra param)
-- carries a non-sliding expiry tied to the code's own expiry, separate
-- from the session's normal sliding expires_at.
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS qr_join_expires BIGINT UNSIGNED NULL AFTER expires_at;
