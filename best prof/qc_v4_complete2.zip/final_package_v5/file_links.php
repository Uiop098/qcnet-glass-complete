<?php
// =============================================================================
// file_links.php — Stage 3: code/text file cross-domain access
// =============================================================================
// Scope: ONLY applies to fileCategory === 'code' uploads (the
// code_and_text_exts() extensions — .txt, .js, .py, .json, .md, etc.).
// Images, audio, video, and generic files are UNCHANGED — always saved
// to local disk and served exactly as before, never touching this
// table. This was a deliberate scope decision: code/text files are
// what's meant to be viewable/shareable across domains (see the
// tap-to-view popup in room.html); binary media has no such
// cross-domain need and stays put.
//
// Every code/text file, REGARDLESS OF SIZE, stays on LOCAL DISK on
// whichever domain received the upload — same files/<room>/ path as
// every other file type, nothing special there. What's new: a row is
// also added to file_links with an ENCRYPTED, SIGNED token pointing at
// that file. Any domain sharing this database can decrypt the token to
// learn which domain holds the file, then FETCH THE BYTES SERVER-SIDE
// from that domain's own download.php and stream them to the browser
// as its own response — so from the browser's point of view, it's one
// normal same-origin download/inline-view, no visible redirect, no
// separate domain ever shows up in the address bar or a network
// request the browser makes directly.
//
// Uses FILE_LINK_SECRET from db_config.php as the encryption key — the
// SAME value on every domain, so a token minted by one domain can be
// decrypted and verified by any other.
// =============================================================================

require_once __DIR__ . '/db.php';

function file_link_key_binary() {
    if (!defined('FILE_LINK_SECRET') || FILE_LINK_SECRET === 'CHANGE_ME_TO_A_RANDOM_64_CHAR_HEX_STRING_SHARED_ACROSS_ALL_DOMAINS') {
        throw new RuntimeException('FILE_LINK_SECRET is not set in db_config.php — cannot create/resolve cross-domain file links.');
    }
    return hex2bin(FILE_LINK_SECRET);
}

// Token format: base64url( iv . authTag . AES-256-GCM-ciphertext ) where
// the plaintext is JSON {linkId}. Encrypted (payload isn't readable
// without FILE_LINK_SECRET) AND signed (GCM's auth tag means a
// tampered/forged token fails to decrypt at all, rather than decrypting
// into garbage) — both protections requested during the original design
// conversation for this feature.

function make_file_link_token($linkId) {
    $key = file_link_key_binary();
    $payload = json_encode(['linkId' => $linkId]);
    $iv = openssl_random_pseudo_bytes(12); // GCM standard IV size
    $tag = '';
    $ciphertext = openssl_encrypt($payload, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
    if ($ciphertext === false) throw new RuntimeException('Link token encryption failed.');
    $raw = $iv . $tag . $ciphertext;
    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}

// Returns the linkId encoded in the token, or null if the token is
// invalid/tampered/forged.
function verify_file_link_token($token) {
    try {
        $key = file_link_key_binary();
        $raw = base64_decode(strtr($token, '-_', '+/'), true);
        if ($raw === false || strlen($raw) < 12 + 16) return null;
        $iv = substr($raw, 0, 12);
        $tag = substr($raw, 12, 16);
        $ciphertext = substr($raw, 28);
        $plaintext = openssl_decrypt($ciphertext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        if ($plaintext === false) return null;
        $payload = json_decode($plaintext, true);
        return is_array($payload) && isset($payload['linkId']) ? (int)$payload['linkId'] : null;
    } catch (Throwable $e) {
        return null;
    }
}

// Registers a code/text file that stays on THIS domain's local disk
// (identical save path to every other file type — see upload.php),
// returning the encrypted token any domain can later resolve back to
// this domain to fetch the actual bytes.
function register_file_link($localPath, $fileName, $fileSize, $mimeType, $roomId) {
    if (!defined('THIS_DOMAIN') || THIS_DOMAIN === 'https://example.com') {
        throw new RuntimeException('THIS_DOMAIN is not set in db_config.php — cannot register a cross-domain file link.');
    }
    $linkId = db_insert(
        'INSERT INTO file_links (link_token, origin_domain, local_path, file_name, file_size, mime_type, room_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        ['', THIS_DOMAIN, $localPath, $fileName, $fileSize, $mimeType, $roomId, now_ms()]
    );
    $token = make_file_link_token($linkId);
    db_exec('UPDATE file_links SET link_token = ? WHERE id = ?', [$token, $linkId]);
    return $token;
}

// Resolves a token to the file's metadata + which domain holds it.
// Does NOT fetch the bytes itself — see fetch_remote_file_bytes()
// below, called by download.php only when the resolved domain isn't
// this one.
function resolve_file_link($token) {
    $linkId = verify_file_link_token($token);
    if ($linkId === null) return null;
    $row = db_one('SELECT * FROM file_links WHERE id = ?', [$linkId]);
    if (!$row) return null;
    return [
        'domain' => $row['origin_domain'],
        'localPath' => $row['local_path'],
        'fileName' => $row['file_name'],
        'fileSize' => (int)$row['file_size'],
        'mimeType' => $row['mime_type'],
    ];
}

// Server-side fetch of another domain's file bytes — this is what
// makes the cross-domain access invisible to the browser. Called by
// download.php only when resolve_file_link() says the file lives on a
// DIFFERENT domain than the one currently handling the request; if it
// resolves to THIS domain, download.php just reads $row['localPath']
// directly instead (no HTTP round trip needed for that case).
//
// A short timeout keeps a slow/unreachable origin domain from hanging
// this request indefinitely — if it fails, the caller shows a normal
// "file not found" rather than the request stalling.
function fetch_remote_file_bytes($domain, $token) {
    $url = rtrim($domain, '/') . '/download_internal.php?token=' . urlencode($token);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 12,
        CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($err || $httpCode !== 200) {
        error_log("fetch_remote_file_bytes: failed fetching $url — HTTP $httpCode, $err");
        return null;
    }
    return $body;
}
