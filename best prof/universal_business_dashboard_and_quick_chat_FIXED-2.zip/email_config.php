<?php
// email_config.php — Resend API credentials for sending OTP verification
// emails. Fill these in before going live; until RESEND_API_KEY is set,
// send_otp_email() in email_otp.php will fail loudly instead of silently
// pretending to send (see the check there).
define('RESEND_API_KEY', 'YOUR_RESEND_API_KEY');          // re_xxxxxxxxxxxxxxxxxxxxxxxxx — from Resend Dashboard -> API Keys
define('RESEND_SENDER_EMAIL', 'noreply@yourdomain.com');   // must be on a domain verified in Resend (Dashboard -> Domains)
define('RESEND_SENDER_NAME', 'Your Business Dashboard');
?>
