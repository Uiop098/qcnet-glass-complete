<?php
// dashboard.php — v35, PART 2: "Simple dashboard" (analytics, admin-
// facing). Super-only endpoint aggregating stats across every room:
// total rooms, currently-active users, messages today, etc.

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$masterToken = isset($_GET['masterToken']) ? $_GET['masterToken'] : '';
$master = get_session($masterToken);
if (!$master || $master['role'] !== 'super_master') {
    // Also accept an already-joined super session token, for convenience.
    $session = get_session($masterToken);
    if (!$session || $session['role'] !== 'super') {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Your super login expired. Please log in again.']);
        exit;
    }
}

sweep_pending_deletes();
echo json_encode(['ok' => true, 'stats' => site_dashboard_stats()]);
