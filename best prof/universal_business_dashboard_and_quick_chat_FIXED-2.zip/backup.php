<?php
// backup.php — v35, PART 3: "Auto-backup". Super-only, on-demand (no
// cron needed on shared hosting): zips every room's config + message
// history JSON in data/ into one downloadable archive. Deliberately
// excludes files/ (uploaded attachments) — those can be large, and are
// already the least critical thing to protect against loss compared to
// the actual chat data/settings; download individual files as needed.

require_once __DIR__ . '/common.php';

$masterToken = isset($_GET['masterToken']) ? $_GET['masterToken'] : '';
$session = get_session($masterToken);
$isSuper = $session && in_array($session['role'], ['super', 'super_master'], true);

if (!$isSuper) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'invalid_session', 'message' => 'Only a super user can download a backup.']);
    exit;
}

if (!rate_limit_allow('backup', get_client_ip(), 5, 300)) {
    http_response_code(429);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'rate_limited', 'message' => 'Please wait before requesting another backup.']);
    exit;
}

$zipPath = build_data_backup_zip();
if (!$zipPath) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'Backup could not be created (the ZipArchive PHP extension may not be available on this host).']);
    exit;
}

$stamp = date('Ymd_His');
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="quickchat_backup_' . $stamp . '.zip"');
header('Content-Length: ' . filesize($zipPath));
readfile($zipPath);
@unlink($zipPath);
