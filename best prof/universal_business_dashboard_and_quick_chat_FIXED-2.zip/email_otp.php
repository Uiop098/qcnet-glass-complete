<?php
// email_otp.php — email ownership verification via a 6-digit OTP, sent
// through Resend's REST API (no Composer/SDK needed — plain cURL, works
// on InfinityFree). Used at three points: Dashboard client registration
// (complete_setup), Dashboard admin registration after payment
// (complete_admin_registration), and before starting a Cashfree payment
// (create_order) — see InfinityFree_Email_OTP_Plan.txt.
//
// Storage: one JSON file per (email, purpose) pair under
// data_dash/otp/, AES-256 encrypted at rest via dash_crypto.php (same as
// every other table in this app), containing only a password_hash() of
// the code — never the code itself. A short-lived separate "verified"
// marker file records that an email finished OTP verification for a given
// purpose, so the actual registration/payment endpoint can check it
// without re-plumbing the code through the request.
//
// This file is deliberately framework-free (no session dependency) so it
// can be required from any endpoint — dash_auth.php, payment_api.php,
// tenant_payment_api.php — alongside their existing dash_firewall.php /
// dash_crypto.php requires.

require_once __DIR__ . '/dash_crypto.php';
if (file_exists(__DIR__ . '/email_config.php')) require_once __DIR__ . '/email_config.php';

define('OTP_LENGTH', 6);
define('OTP_TTL_SECONDS', 10 * 60);      // 10 minutes
define('OTP_MAX_ATTEMPTS', 5);
define('OTP_RESEND_COOLDOWN', 60);       // seconds
define('OTP_VERIFIED_TTL_SECONDS', 20 * 60); // window to actually submit the form after verifying

function otp_dir() {
    $dir = __DIR__ . '/data_dash/otp';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}
function otp_key($email, $purpose) { return md5(strtolower(trim($email)) . '|' . $purpose); }
function otp_file($email, $purpose) { return otp_dir() . '/otp_' . otp_key($email, $purpose) . '.json'; }
function otp_verified_file($email, $purpose) { return otp_dir() . '/verified_' . otp_key($email, $purpose) . '.json'; }

function is_valid_email($email) { return filter_var($email, FILTER_VALIDATE_EMAIL) !== false; }

// Sends one email through Resend's REST API. Returns true/false; never
// throws, and never lets the API key or raw Resend response reach the caller.
function send_otp_email($email, $code) {
    if (!defined('RESEND_API_KEY') || RESEND_API_KEY === '' || RESEND_API_KEY === 'YOUR_RESEND_API_KEY') {
        error_log('send_otp_email: RESEND_API_KEY is not configured in email_config.php');
        return false;
    }
    $senderName = defined('RESEND_SENDER_NAME') ? RESEND_SENDER_NAME : 'Verification';
    $senderEmail = defined('RESEND_SENDER_EMAIL') ? RESEND_SENDER_EMAIL : 'noreply@example.com';
    $html = '<div style="font-family:sans-serif;max-width:420px;margin:0 auto;">'
        . '<h2 style="margin-bottom:4px;">Email Verification</h2>'
        . '<p>Your verification code is:</p>'
        . '<div style="font-size:28px;letter-spacing:6px;font-weight:700;background:#f4f4f7;padding:16px 0;text-align:center;border-radius:8px;">' . htmlspecialchars($code) . '</div>'
        . '<p style="color:#666;font-size:13px;margin-top:16px;">This code expires in 10 minutes. If you did not request this, you can ignore this email.</p>'
        . '</div>';
    $payload = [
        'from' => $senderName . ' <' . $senderEmail . '>',
        'to' => [$email],
        'subject' => 'Your verification code',
        'html' => $html,
    ];
    $ch = curl_init('https://api.resend.com/emails');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Authorization: Bearer ' . RESEND_API_KEY]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode < 200 || $httpCode >= 300) {
        error_log('send_otp_email: Resend API returned HTTP ' . $httpCode . ': ' . $response);
        return false;
    }
    return true;
}

// Generates, stores (hashed), and sends a new OTP for $email/$purpose.
// Returns ['status'=>'success'] or ['error'=>'...', 'cooldownRemaining'=>N].
function request_otp($email, $purpose) {
    if (!is_valid_email($email)) return ['error' => 'Enter a valid email address.'];
    $file = otp_file($email, $purpose);
    $existing = get_secure_table($file);
    $now = time();
    if (!empty($existing) && isset($existing['lastSent'])) {
        $remaining = OTP_RESEND_COOLDOWN - ($now - $existing['lastSent']);
        if ($remaining > 0) return ['error' => 'Please wait before requesting another code.', 'cooldownRemaining' => $remaining];
    }
    $code = sprintf('%0' . OTP_LENGTH . 'd', random_int(0, (10 ** OTP_LENGTH) - 1));
    $record = [
        'email' => strtolower(trim($email)),
        'purpose' => $purpose,
        'otpHash' => password_hash($code, PASSWORD_DEFAULT),
        'expires' => $now + OTP_TTL_SECONDS,
        'attempts' => 0,
        'lastSent' => $now,
    ];
    if (!send_otp_email($email, $code)) return ['error' => 'Could not send the verification email. Please try again shortly.'];
    save_secure_table($file, $record);
    return ['status' => 'success', 'expiresInSeconds' => OTP_TTL_SECONDS];
}

// Verifies a submitted code. On success, drops a short-lived "verified"
// marker (checked by is_email_verified()) and invalidates the OTP itself
// so it can't be reused.
function verify_otp($email, $purpose, $code) {
    $file = otp_file($email, $purpose);
    $record = get_secure_table($file);
    if (empty($record)) return ['error' => 'No verification code was requested for this email. Request one first.'];
    if (time() > ($record['expires'] ?? 0)) { @unlink($file); return ['error' => 'That code has expired. Request a new one.']; }
    if (($record['attempts'] ?? 0) >= OTP_MAX_ATTEMPTS) { @unlink($file); return ['error' => 'Too many incorrect attempts. Request a new code.']; }
    if (!password_verify((string)$code, $record['otpHash'])) {
        $record['attempts'] = ($record['attempts'] ?? 0) + 1;
        save_secure_table($file, $record);
        $remaining = OTP_MAX_ATTEMPTS - $record['attempts'];
        return ['error' => 'Incorrect code.' . ($remaining > 0 ? " {$remaining} attempt(s) left." : '')];
    }
    @unlink($file);
    save_secure_table(otp_verified_file($email, $purpose), ['email' => strtolower(trim($email)), 'purpose' => $purpose, 'verifiedAt' => time(), 'expires' => time() + OTP_VERIFIED_TTL_SECONDS]);
    return ['status' => 'success'];
}

// Checked by the actual registration/payment endpoint before proceeding.
// Consumes the marker on success (one registration/payment attempt per
// verification) so a stale "verified" state can't be reused indefinitely.
function is_email_verified($email, $purpose, $consume = true) {
    $file = otp_verified_file($email, $purpose);
    $record = get_secure_table($file);
    if (empty($record)) return false;
    if (strtolower(trim($email)) !== ($record['email'] ?? '')) return false;
    if (time() > ($record['expires'] ?? 0)) { @unlink($file); return false; }
    if ($consume) @unlink($file);
    return true;
}

// Thin HTTP action router — dash_auth.php-style — so setup_account.html,
// pay.html, etc. can call this file directly for send/verify without any
// of them needing their own duplicate OTP plumbing.
if (basename($_SERVER['SCRIPT_FILENAME']) === 'email_otp.php') {
    require_once __DIR__ . '/dash_firewall.php';
    header('Content-Type: application/json');
    $action = $_GET['action'] ?? '';
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); die(json_encode(['error' => 'Method not allowed.'])); }

    $email = trim($_POST['email'] ?? '');
    $purpose = trim($_POST['purpose'] ?? '');
    $allowedPurposes = ['user_register', 'admin_register', 'payment'];
    if (!in_array($purpose, $allowedPurposes, true)) { die(json_encode(['error' => 'Invalid verification context.'])); }

    if ($action === 'send_otp') {
        if (!rate_limit_allow('otp_send', get_client_ip(), 6, 600)) { http_response_code(429); die(json_encode(['error' => 'Too many requests. Please wait a few minutes.'])); }
        echo json_encode(request_otp($email, $purpose));
        exit;
    }
    if ($action === 'verify_otp') {
        if (!rate_limit_allow('otp_verify', get_client_ip(), 15, 600)) { http_response_code(429); die(json_encode(['error' => 'Too many attempts. Please wait a few minutes.'])); }
        $code = trim($_POST['code'] ?? '');
        echo json_encode(verify_otp($email, $purpose, $code));
        exit;
    }
    http_response_code(400); echo json_encode(['error' => 'Unknown action.']);
}
?>
