const wallpapers = [ 'none', 'url("assets/dark-abstract.jpg")', 'url("assets/nature.jpg")' ];
let currentBg = 0;
function changeTheme() {
    currentBg = (currentBg + 1) % wallpapers.length;
    document.documentElement.style.setProperty('--bg-image', wallpapers[currentBg]);
}
let businessData = { users: [], payments: [], reminders: [], links: [] };
let currentUserRole = 'user';

async function checkAuth() {
    try {
        const response = await fetch('dash_auth.php?action=check_auth');
        const data = await response.json();
        const isLoginPage = window.location.href.includes('dash_login.html');
        const isSetupPage = window.location.href.includes('dash_setup.html');
        const isAdminPage = window.location.href.includes('dash_admin.html');
        const isUserPage = window.location.href.includes('dash_user.html');
        
        if (data.status !== 'success') {
            if (!isLoginPage && !isSetupPage) window.location.href = 'dash_login.html';
        } else {
            currentUserRole = data.role;
            if (isLoginPage || isSetupPage) {
                window.location.href = data.role === 'admin' ? 'dash_admin.html' : 'dash_user.html';
            } else if (data.role === 'user' && isAdminPage) {
                window.location.href = 'dash_user.html';
            } else if (data.role === 'admin' && isUserPage) {
                window.location.href = 'dash_admin.html';
            } else {
                fetchDashboardData();
            }
        }
    } catch (e) { console.error("Auth check failed", e); }
}

async function submitLogin() {
    const role = document.getElementById('login-role').value;
    const user = document.getElementById('login-user').value;
    const pass = document.getElementById('login-pass').value;
    const msg = document.getElementById('login-msg');
    const form = new URLSearchParams();
    form.append('username', user); form.append('password', pass);
    const endpoint = role === 'admin' ? 'admin_login' : 'user_login';
    try {
        const res = await fetch('dash_auth.php?action=' + endpoint, { method: 'POST', body: form });
        const data = await res.json();
        if (data.status === 'success') { window.location.href = role === 'admin' ? 'dash_admin.html' : 'dash_user.html'; } 
        else { msg.style.color = '#ff6b6b'; msg.innerText = data.error; }
    } catch (e) { msg.innerText = 'Connection error.'; }
}

async function logout() { await fetch('dash_auth.php?action=logout'); window.location.href = 'dash_login.html'; }

async function fetchDashboardData() {
    try {
        const response = await fetch('dash_api.php?action=get_dashboard_data');
        const data = await response.json();
        if (data.status === 'success') {
            businessData = data;
            if(document.title.includes("Admin")) renderUI('users');
            if(document.title.includes("Customer")) renderUserUI('profile');
        } else if (data.error === 'Unauthorized access. Please log in.') { window.location.href = 'dash_login.html'; }
    } catch (e) { document.getElementById('content-area').innerHTML = "<p style='color:#ff6b6b'>Connection error.</p>"; }
}

async function generateToken() {
    const name = prompt("Enter User's Name:"); if (!name) return;
    const dob = prompt("Enter User's Date of Birth (YYYY-MM-DD):"); if (!dob) return;
    const form = new URLSearchParams(); form.append('name', name); form.append('dob', dob);
    try {
        const res = await fetch('dash_auth.php?action=create_pending', { method: 'POST', body: form });
        const data = await res.json();
        if (data.status === 'success') {
            navigator.clipboard.writeText(data.token);
            alert(`Token Generated & Copied to Clipboard!\n\nToken: ${data.token}\nExpires in: 10 mins`);
        } else alert(data.error);
    } catch(e) { alert("Error generating token."); }
}

function renderUI(module) {
    const area = document.getElementById('content-area');
    document.getElementById('module-title').innerText = module.toUpperCase();
    let html = `<div class="action-bar" style="display:flex; gap:10px; margin-bottom:15px; flex-wrap:wrap;">`;
    if (module === 'users') {
        html += `<button onclick="generateToken()" style="background: rgba(139, 92, 246, 0.5);">🔑 Gen Token (Copied)</button>`;
        html += `<input type="text" id="search-users" placeholder="Search by name, tags, notes..." onkeyup="filterUsers()" style="flex:1; min-width:200px; margin:0;">`;
    } else {
        html += `<button onclick="showAddForm('${module}')">+ Add New Record</button> `;
    }
    html += `</div><div class="table-container"><table id="data-table"><tr>`;
    
    if (module === 'users') {
        html += `<th>User / Contact</th><th>Tags</th><th>Admin Notes</th><th>Actions</th></tr>`;
        Object.keys(businessData.users).forEach(username => {
            let u = businessData.users[username];
            html += `<tr class="user-row" data-search="${(u.name+' '+username+' '+u.tags+' '+u.notes).toLowerCase()}">
                <td><b>${u.name||'--'}</b><br><span style="font-size:11px; color:#aaa;">@${username}<br>${u.mobile||'No Phone'}<br>${u.email||'No Email'}</span></td>
                <td><span style="background:rgba(74,222,128,0.2); padding:2px 6px; border-radius:4px; font-size:11px; color:#4ade80;">${u.tags||'None'}</span></td>
                <td style="font-size:12px; max-width:150px;">${u.notes||'--'}</td>
                <td><button onclick="editUser('${username}')" style="font-size:11px; padding:5px 8px;">Edit</button> <button onclick="deleteUser('${username}')" style="font-size:11px; padding:5px 8px; background:rgba(255,107,107,0.3); border-color:#ff6b6b; color:#ff6b6b;">Del</button></td></tr>`;
        });
    } else if (module === 'payments') {
        html += `<th>Client</th><th>Amount</th><th>Status</th><th>Date</th></tr>`;
        businessData.payments.forEach(p => html += `<tr><td>${p.client||'--'}</td><td>$${p.amount||'--'}</td><td>${p.status||'--'}</td><td>${p.date||'--'}</td></tr>`);
    } else if (module === 'reminders') {
        html += `<th>Task</th><th>Priority</th><th>Due Date</th></tr>`;
        businessData.reminders.forEach(r => html += `<tr><td>${r.task||'--'}</td><td>${r.priority||'--'}</td><td>${r.due||'--'}</td></tr>`);
    } else if (module === 'links') {
        html += `<th>Title</th><th>URL</th></tr>`;
        businessData.links.forEach(l => html += `<tr><td>${l.title||'--'}</td><td><a href="${l.url}" target="_blank" style="color:#4ade80">${l.url}</a></td></tr>`);
    }
    area.innerHTML = html + `</table></div>`;
}

function filterUsers() {
    let filter = document.getElementById("search-users").value.toLowerCase();
    let rows = document.querySelectorAll(".user-row");
    rows.forEach(row => { row.style.display = row.getAttribute('data-search').includes(filter) ? "" : "none"; });
}

function editUser(username) {
    const u = businessData.users[username];
    const area = document.getElementById('content-area');
    area.innerHTML = `<div class="glass-panel" style="padding:20px; max-width:400px; display:flex; flex-direction:column; gap:10px;">
        <h3 style="margin:0;">Edit User: @${username}</h3>
        <input type="text" id="eu-name" value="${u.name||''}" placeholder="Name">
        <input type="tel" id="eu-mob" value="${u.mobile||''}" placeholder="Mobile">
        <input type="email" id="eu-em" value="${u.email||''}" placeholder="Email">
        <input type="text" id="eu-add" value="${u.address||''}" placeholder="Address">
        <input type="text" id="eu-tag" value="${u.tags||''}" placeholder="Custom Tags (comma separated)">
        <textarea id="eu-note" placeholder="Admin Notes (Only visible to admin)" style="padding:10px; border-radius:5px; border:1px solid var(--glass-border); background:rgba(255,255,255,0.2); color:white; width:100%; box-sizing:border-box; font-family:inherit;">${u.notes||''}</textarea>
        <div style="display:flex; gap:10px;">
            <button onclick="saveUser('${username}')" style="flex:1; background:#4ade80; color:#1a1a2e; border:none; font-weight:bold;">Save Changes</button>
            <button onclick="renderUI('users')" style="flex:1; background:rgba(255,107,107,0.2); border-color:#ff6b6b; color:#ff6b6b;">Cancel</button>
        </div></div>`;
}

async function saveUser(username) {
    const form = new URLSearchParams();
    form.append('username', username);
    form.append('name', document.getElementById('eu-name').value);
    form.append('mobile', document.getElementById('eu-mob').value);
    form.append('email', document.getElementById('eu-em').value);
    form.append('address', document.getElementById('eu-add').value);
    form.append('tags', document.getElementById('eu-tag').value);
    form.append('notes', document.getElementById('eu-note').value);
    await fetch('dash_api.php?action=update_user', { method: 'POST', body: form });
    fetchDashboardData();
}

async function deleteUser(username) {
    if(confirm(`Are you sure you want to permanently delete user @${username}?`)) {
        const form = new URLSearchParams(); form.append('username', username);
        await fetch('dash_api.php?action=delete_user', { method: 'POST', body: form });
        fetchDashboardData();
    }
}

function renderUserUI(module) {
    const area = document.getElementById('content-area');
    document.getElementById('module-title').innerText = module.toUpperCase().replace('_', ' ');
    
    if (module === 'profile') {
        let p = businessData.my_profile;
        area.innerHTML = `<div class="glass-panel" style="padding:20px; max-width:400px;">
            <h3>My Profile Details</h3>
            <p><b>Name:</b> ${p.name||'--'}</p>
            <p><b>DOB:</b> ${p.dob||'--'}</p>
            <p><b>Mobile:</b> ${p.mobile||'--'}</p>
            <p><b>Email:</b> ${p.email||'--'}</p>
            <p><b>Address:</b> ${p.address||'--'}</p>
            <p style="font-size:11px; color:#aaa; margin-top:20px;">*Please contact your administrator to update these details.</p>
        </div>`;
        return;
    }

    let html = `<div class="table-container"><table id="data-table"><tr>`;
    if (module === 'my_payments') {
        html += `<th>Amount</th><th>Status</th><th>Date</th></tr>`;
        businessData.payments.forEach(p => html += `<tr><td>$${p.amount||'--'}</td><td>${p.status||'--'}</td><td>${p.date||'--'}</td></tr>`);
    } else if (module === 'reminders') {
        html += `<th>Task</th><th>Priority</th><th>Due Date</th></tr>`;
        businessData.reminders.forEach(r => html += `<tr><td>${r.task||'--'}</td><td>${r.priority||'--'}</td><td>${r.due||'--'}</td></tr>`);
    } else if (module === 'links') {
        html += `<th>Title</th><th>URL</th></tr>`;
        businessData.links.forEach(l => html += `<tr><td>${l.title||'--'}</td><td><a href="${l.url}" target="_blank" style="color:#4ade80">${l.url}</a></td></tr>`);
    }
    area.innerHTML = html + `</table></div>`;
}

async function submitForm(table) {
    const inputs = document.querySelectorAll('#add-form input, #add-form select');
    const formData = new URLSearchParams(); formData.append('table', table);
    inputs.forEach(input => formData.append(input.name, input.value));
    await fetch('dash_api.php?action=add_record', { method: 'POST', body: formData });
    fetchDashboardData();
}

function showAddForm(module) {
    const area = document.getElementById('content-area');
    let formHtml = `<div id="add-form" class="glass-panel" style="padding:20px; max-width:400px; display:flex; flex-direction:column; gap:10px;">`;
    if (module === 'payments') { formHtml += `<input type="text" name="client" placeholder="Client Username (Exact Match)"><input type="number" name="amount" placeholder="Amount"><select name="status"><option>Pending</option><option>Received</option></select><input type="date" name="date">`; } 
    else if (module === 'reminders') { formHtml += `<input type="text" name="task" placeholder="Task description"><select name="priority"><option>High</option><option>Normal</option></select><input type="date" name="due">`; } 
    else if (module === 'links') { formHtml += `<input type="text" name="title" placeholder="Link Title"><input type="url" name="url" placeholder="https://...">`; }
    formHtml += `<button onclick="submitForm('${module}')" style="background:#4ade80; color:#1a1a2e; border:none; font-weight:bold;">Save Record</button>`;
    formHtml += `<button onclick="renderUI('${module}')" style="background:transparent; border:1px solid #ff6b6b; color:#ff6b6b;">Cancel</button></div>`;
    area.innerHTML = formHtml;
}

if (!window.location.href.includes("gateway.html") && !window.location.href.includes("welcome.html") && !window.location.href.includes("pay.html")) {
    checkAuth();
}
