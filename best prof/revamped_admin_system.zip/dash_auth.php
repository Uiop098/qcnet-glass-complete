<?php
require_once 'dash_firewall.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'check_auth':
        if (isset($_SESSION['dash_admin'])) echo json_encode(["status" => "success", "role" => "admin", "user" => $_SESSION['dash_admin']]);
        elseif (isset($_SESSION['dash_user'])) echo json_encode(["status" => "success", "role" => "user", "user" => $_SESSION['dash_user']]);
        else echo json_encode(["error" => "Unauthorized"]);
        break;

    case 'admin_login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            
            // 1. Check Independent Master Admin Database (No dependency on QuickChat's 24hr wipe)
            $master_file = __DIR__ . '/data_dash/master.json';
            if (!file_exists($master_file)) {
                file_put_contents($master_file, json_encode([
                    "xbot" => ["password_hash" => password_hash("#123xbot", PASSWORD_DEFAULT)]
                ]));
            }
            $masters = json_decode(file_get_contents($master_file), true);
            if (isset($masters[$username]) && password_verify($password, $masters[$username]['password_hash'])) {
                $_SESSION['dash_admin'] = $username;
                $_SESSION['dash_tenant'] = 'main';
                die(json_encode(["status" => "success"]));
            }

            // 2. Check Custom Paid Admins (Tenants)
            $tenants = json_decode(@file_get_contents(__DIR__ . '/data_dash/tenants.json'), true) ?: [];
            if (isset($tenants[$username]) && password_verify($password, $tenants[$username]['password_hash'])) {
                $_SESSION['dash_admin'] = $username;
                $_SESSION['dash_tenant'] = $tenants[$username]['tenant_id'];
                die(json_encode(["status" => "success"]));
            }

            echo json_encode(["error" => "Invalid Administrator credentials."]);
        }
        break;

    case 'user_login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $all_dirs = array_merge([__DIR__ . '/data_dash'], glob(__DIR__ . '/data_dash/tenant_*', GLOB_ONLYDIR));
            foreach ($all_dirs as $dir) {
                $users = json_decode(@file_get_contents($dir . '/users.json'), true) ?: [];
                if (isset($users[$username]) && password_verify($password, $users[$username]['password_hash'])) {
                    $_SESSION['dash_user'] = $username;
                    $_SESSION['dash_tenant'] = basename($dir);
                    if ($_SESSION['dash_tenant'] === 'data_dash') $_SESSION['dash_tenant'] = 'main';
                    die(json_encode(["status" => "success"]));
                }
            }
            echo json_encode(["error" => "Invalid username or password."]);
        }
        break;

    case 'logout':
        session_destroy();
        echo json_encode(["status" => "success"]);
        break;

    case 'create_pending':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_SESSION['dash_admin'])) die(json_encode(["error" => "Unauthorized. Admin only."]));
            
            $tenant_id = $_SESSION['dash_tenant'] ?? 'main';
            $dir = ($tenant_id === 'main') ? __DIR__ . '/data_dash' : __DIR__ . '/data_dash/' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $tenant_id);
            if (!is_dir($dir)) @mkdir($dir, 0755, true);

            $pending_file = $dir . '/pending_users.json';
            $pending = json_decode(@file_get_contents($pending_file), true) ?: [];
            $current_time = time();
            $pending = array_filter($pending, function($u) use ($current_time) { return $u['expires_at'] > $current_time; });
            
            $token = substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8); // 8 Char Short Token
            $pending[$token] = [
                "name" => $_POST['name'] ?? '',
                "dob" => $_POST['dob'] ?? '',
                "expires_at" => $current_time + (10 * 60)
            ];
            file_put_contents($pending_file, json_encode($pending, JSON_PRETTY_PRINT));
            echo json_encode(["status" => "success", "token" => $token]);
        }
        break;

    case 'complete_setup':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = strtoupper(trim($_POST['token'] ?? ''));
            $dob_attempt = $_POST['dob'] ?? '';
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            if (!preg_match('/^[a-zA-Z0-9]+$/', $username) || !preg_match('/^[a-zA-Z0-9]+$/', $password)) {
                die(json_encode(["error" => "Username and Password can only contain letters and numbers."]));
            }

            $found_tenant_dir = null; $found_pending_data = null;
            $all_dirs = array_merge([__DIR__ . '/data_dash'], glob(__DIR__ . '/data_dash/tenant_*', GLOB_ONLYDIR));
            foreach ($all_dirs as $dir) {
                $p_file = $dir . '/pending_users.json';
                $pending = json_decode(@file_get_contents($p_file), true) ?: [];
                if (isset($pending[$token])) { $found_tenant_dir = $dir; $found_pending_data = $pending; break; }
            }

            if (!$found_tenant_dir || $found_pending_data[$token]['dob'] !== $dob_attempt || $found_pending_data[$token]['expires_at'] < time()) {
                die(json_encode(["error" => "Invalid token, expired, or incorrect Birth Date."]));
            }

            foreach ($all_dirs as $dir) {
                $u = json_decode(@file_get_contents($dir . '/users.json'), true) ?: [];
                if (isset($u[$username])) die(json_encode(["error" => "Username already taken."]));
            }

            $users_file = $found_tenant_dir . '/users.json';
            $users = json_decode(@file_get_contents($users_file), true) ?: [];
            
            $users[$username] = [
                "name" => $found_pending_data[$token]['name'],
                "dob" => $found_pending_data[$token]['dob'],
                "password_hash" => password_hash($password, PASSWORD_DEFAULT),
                "address" => "", "mobile" => "", "email" => "", "tags" => "", "notes" => "",
                "created_at" => time()
            ];
            file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
            unset($found_pending_data[$token]);
            file_put_contents($found_tenant_dir . '/pending_users.json', json_encode($found_pending_data, JSON_PRETTY_PRINT));
            echo json_encode(["status" => "success", "message" => "Account created successfully. You may now log in."]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Direct access is not allowed."]);
        break;
}
?>