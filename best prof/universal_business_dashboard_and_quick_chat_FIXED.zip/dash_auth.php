<?php
require_once 'dash_firewall.php';
require_once 'dash_crypto.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$temp_dir = __DIR__ . '/data_dash/temp';
if (!is_dir($temp_dir)) @mkdir($temp_dir, 0755, true);

foreach (glob($temp_dir . '/otp_*.json') as $otp_file) {
    $otp_data = json_decode(@file_get_contents($otp_file), true);
    if ($otp_data && time() > $otp_data['expires']) { @unlink($otp_file); }
}

switch ($action) {
    case 'check_auth':
        if (isset($_SESSION['dash_admin'])) echo json_encode(["status" => "success", "role" => "admin", "user" => $_SESSION['dash_admin']]);
        elseif (isset($_SESSION['dash_user'])) echo json_encode(["status" => "success", "role" => "user", "user" => $_SESSION['dash_user']]);
        else echo json_encode(["error" => "Unauthorized"]);
        break;
        
    case 'admin_login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ip = get_client_ip();
            if (!rate_limit_allow('dash_admin_login', $ip, 8, 600)) { http_response_code(429); die(json_encode(["error" => "Too many login attempts. Please wait a few minutes."])); }
            $username = $_POST['username'] ?? ''; $password = $_POST['password'] ?? '';
            $master_file = __DIR__ . '/data_dash/master.json';
            if (!file_exists($master_file)) save_secure_table($master_file, ["xbot" => ["password_hash" => password_hash("#123xbot", PASSWORD_DEFAULT)]]);
            $masters = get_secure_table($master_file);
            if (isset($masters[$username]) && password_verify($password, $masters[$username]['password_hash'])) {
                $_SESSION['dash_admin'] = $username; $_SESSION['dash_tenant'] = 'main'; die(json_encode(["status" => "success"]));
            }
            $tenants = get_secure_table(__DIR__ . '/data_dash/tenants.json');
            if (isset($tenants[$username]) && password_verify($password, $tenants[$username]['password_hash'])) {
                $_SESSION['dash_admin'] = $username; $_SESSION['dash_tenant'] = $tenants[$username]['tenant_id']; die(json_encode(["status" => "success"]));
            }
            echo json_encode(["error" => "Invalid Administrator credentials."]);
        }
        break;

    case 'user_login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!rate_limit_allow('dash_user_login', get_client_ip(), 10, 600)) { http_response_code(429); die(json_encode(["error" => "Too many login attempts. Please wait a few minutes."])); }
            $username = $_POST['username'] ?? ''; $password = $_POST['password'] ?? '';
            $all_dirs = array_merge([__DIR__ . '/data_dash'], glob(__DIR__ . '/data_dash/tenant_*', GLOB_ONLYDIR));
            foreach ($all_dirs as $dir) {
                $users = get_secure_table($dir . '/users.json');
                if (isset($users[$username]) && password_verify($password, $users[$username]['password_hash'])) {
                    $_SESSION['dash_user'] = $username; $_SESSION['dash_tenant'] = basename($dir);
                    if ($_SESSION['dash_tenant'] === 'data_dash') $_SESSION['dash_tenant'] = 'main';
                    die(json_encode(["status" => "success"]));
                }
            }
            echo json_encode(["error" => "Invalid username or password."]);
        }
        break;
        
    case 'forgot_password_step1':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!rate_limit_allow('dash_otp_request', get_client_ip(), 6, 600)) { http_response_code(429); die(json_encode(["error" => "Too many requests. Please wait a few minutes."])); }
            $email = strtolower(trim($_POST['email'] ?? '')); $dob = trim($_POST['dob'] ?? '');
            if (!$email || !$dob) die(json_encode(["error" => "Email and DOB required."]));
            
            $found_accounts = [];
            $all_dirs = array_merge([__DIR__ . '/data_dash'], glob(__DIR__ . '/data_dash/tenant_*', GLOB_ONLYDIR));
            foreach ($all_dirs as $dir) {
                $users = get_secure_table($dir . '/users.json');
                foreach ($users as $u => $data) {
                    if (strtolower($data['email'] ?? '') === $email && ($data['dob'] ?? '') === $dob) { $found_accounts[] = $u; }
                }
            }
            
            if (empty($found_accounts)) die(json_encode(["error" => "No matching accounts found for that Email and DOB."]));
            
            $otp_file = $temp_dir . '/otp_' . md5($email) . '.json';
            if (file_exists($otp_file)) {
                $existing = json_decode(file_get_contents($otp_file), true);
                if ($existing && time() < $existing['cooldown']) die(json_encode(["error" => "Please wait 5 minutes before requesting a new code."]));
            }
            
            // random_int() is CSPRNG-backed, unlike mt_rand() which is predictable
            // and unsuitable for anything security-sensitive like a reset code.
            $code = sprintf("%06d", random_int(100000, 999999));
            $otp_data = [ "code" => $code, "accounts" => $found_accounts, "expires" => time() + 180, "cooldown" => time() + 300, "attempts" => 0 ];
            file_put_contents($otp_file, json_encode($otp_data));
            
            $subject = "Your Dashboard Reset Code: " . $code;
            $msg = "Your 6-digit verification code is: $code \nIt expires in 3 minutes.";
            @mail($email, $subject, $msg, "From: noreply@" . $_SERVER['HTTP_HOST']);
            
            echo json_encode(["status" => "success", "message" => "A 6-digit code has been sent to your email. (Expires in 3 minutes)"]);
        }
        break;
        
    case 'forgot_password_step2':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // A 6-digit code is only 1,000,000 possibilities — with no attempt
            // limit, an attacker who knows the target's email could just script
            // through them inside the 3-minute window. Rate-limit by IP AND
            // lock the OTP itself out after 5 wrong guesses.
            if (!rate_limit_allow('dash_otp_verify', get_client_ip(), 15, 600)) { http_response_code(429); die(json_encode(["error" => "Too many attempts. Please wait a few minutes."])); }
            $email = strtolower(trim($_POST['email'] ?? '')); $code = trim($_POST['code'] ?? '');
            $otp_file = $temp_dir . '/otp_' . md5($email) . '.json';
            if (!file_exists($otp_file)) die(json_encode(["error" => "Code expired or not requested."]));
            $otp_data = json_decode(file_get_contents($otp_file), true);
            if (time() > $otp_data['expires']) { @unlink($otp_file); die(json_encode(["error" => "Code has expired. Request a new one."])); }
            if (($otp_data['attempts'] ?? 0) >= 5) { @unlink($otp_file); die(json_encode(["error" => "Too many incorrect attempts. Please request a new code."])); }
            if (!hash_equals($otp_data['code'], $code)) {
                $otp_data['attempts'] = ($otp_data['attempts'] ?? 0) + 1;
                file_put_contents($otp_file, json_encode($otp_data));
                die(json_encode(["error" => "Incorrect 6-digit code."]));
            }
            
            echo json_encode(["status" => "success", "accounts" => $otp_data['accounts']]);
        }
        break;

    case 'forgot_password_step3':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!rate_limit_allow('dash_otp_verify', get_client_ip(), 15, 600)) { http_response_code(429); die(json_encode(["error" => "Too many attempts. Please wait a few minutes."])); }
            $email = strtolower(trim($_POST['email'] ?? '')); $code = trim($_POST['code'] ?? '');
            $username = trim($_POST['username'] ?? ''); $new_pass = trim($_POST['new_password'] ?? '');
            
            $otp_file = $temp_dir . '/otp_' . md5($email) . '.json';
            if (!file_exists($otp_file)) die(json_encode(["error" => "Session expired."]));
            $otp_data = json_decode(file_get_contents($otp_file), true);
            if (time() > $otp_data['expires']) { @unlink($otp_file); die(json_encode(["error" => "Session expired."])); }
            if (($otp_data['attempts'] ?? 0) >= 5) { @unlink($otp_file); die(json_encode(["error" => "Too many incorrect attempts. Please request a new code."])); }
            if (!hash_equals($otp_data['code'], $code) || !in_array($username, $otp_data['accounts'])) {
                $otp_data['attempts'] = ($otp_data['attempts'] ?? 0) + 1;
                file_put_contents($otp_file, json_encode($otp_data));
                die(json_encode(["error" => "Invalid request."]));
            }
            
            if (strlen($new_pass) < 6) die(json_encode(["error" => "New password must be at least 6 characters."]));
            $updated = false;
            $all_dirs = array_merge([__DIR__ . '/data_dash'], glob(__DIR__ . '/data_dash/tenant_*', GLOB_ONLYDIR));
            foreach ($all_dirs as $dir) {
                $users = get_secure_table($dir . '/users.json');
                if (isset($users[$username])) {
                    $users[$username]['password_hash'] = password_hash($new_pass, PASSWORD_DEFAULT);
                    save_secure_table($dir . '/users.json', $users);
                    $updated = true; break;
                }
            }
            if ($updated) {
                @unlink($otp_file); echo json_encode(["status" => "success", "message" => "Password updated successfully. You may log in."]);
            } else die(json_encode(["error" => "Failed to update password."]));
        }
        break;

    case 'logout': session_destroy(); echo json_encode(["status" => "success"]); break;
    
    case 'create_pending':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_SESSION['dash_admin'])) die(json_encode(["error" => "Unauthorized. Admin only."]));
            $tenant_id = $_SESSION['dash_tenant'] ?? 'main';
            $dir = ($tenant_id === 'main') ? __DIR__ . '/data_dash' : __DIR__ . '/data_dash/' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $tenant_id);
            if (!is_dir($dir)) @mkdir($dir, 0755, true);
            $pending_file = $dir . '/pending_users.json'; $pending = get_secure_table($pending_file);
            $current_time = time(); $pending = array_filter($pending, function($u) use ($current_time) { return $u['expires_at'] > $current_time; });
            // str_shuffle() is mt_rand()-backed, not a CSPRNG. random_int() is.
            $alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; $token = '';
            for ($i = 0; $i < 8; $i++) { $token .= $alphabet[random_int(0, strlen($alphabet) - 1)]; }
            $pending[$token] = ["name" => $_POST['name'] ?? '', "dob" => $_POST['dob'] ?? '', "expires_at" => $current_time + (10 * 60)];
            save_secure_table($pending_file, $pending); echo json_encode(["status" => "success", "token" => $token]);
        }
        break;
        
    case 'complete_setup':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!rate_limit_allow('dash_complete_setup', get_client_ip(), 10, 600)) { http_response_code(429); die(json_encode(["error" => "Too many attempts. Please wait a few minutes."])); }
            $token = strtoupper(trim($_POST['token'] ?? '')); $dob_attempt = $_POST['dob'] ?? ''; $username = $_POST['username'] ?? ''; $password = $_POST['password'] ?? '';
            if (!preg_match('/^[a-zA-Z0-9]+$/', $username) || !preg_match('/^[a-zA-Z0-9]+$/', $password)) die(json_encode(["error" => "Username and Password can only contain letters and numbers."]));
            if (strlen($password) < 6) die(json_encode(["error" => "Password must be at least 6 characters."]));
            $found_tenant_dir = null; $found_pending_data = null;
            $all_dirs = array_merge([__DIR__ . '/data_dash'], glob(__DIR__ . '/data_dash/tenant_*', GLOB_ONLYDIR));
            foreach ($all_dirs as $dir) {
                $p_file = $dir . '/pending_users.json'; $pending = get_secure_table($p_file);
                if (isset($pending[$token])) { $found_tenant_dir = $dir; $found_pending_data = $pending; break; }
            }
            if (!$found_tenant_dir || $found_pending_data[$token]['dob'] !== $dob_attempt || $found_pending_data[$token]['expires_at'] < time()) die(json_encode(["error" => "Invalid token, expired, or incorrect Birth Date."]));
            foreach ($all_dirs as $dir) {
                $u = get_secure_table($dir . '/users.json');
                if (isset($u[$username])) die(json_encode(["error" => "Username already taken."]));
            }
            $users_file = $found_tenant_dir . '/users.json'; $users = get_secure_table($users_file);
            $users[$username] = [
                "name" => $found_pending_data[$token]['name'], "dob" => $found_pending_data[$token]['dob'], "password_hash" => password_hash($password, PASSWORD_DEFAULT),
                "address" => "", "mobile" => "", "email" => "", "tags" => "", "notes" => "", "admin_message" => "", "created_at" => time()
            ];
            save_secure_table($users_file, $users); unset($found_pending_data[$token]);
            save_secure_table($found_tenant_dir . '/pending_users.json', $found_pending_data);
            echo json_encode(["status" => "success", "message" => "Account created successfully. You may now log in."]);
        }
        break;
}
?>