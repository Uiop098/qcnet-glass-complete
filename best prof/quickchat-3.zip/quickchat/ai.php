<?php
// ai.php — sends a prompt to LLM7.io's free, anonymous OpenAI-compatible
// API and posts the reply back into the room as a message from
// "AI Assistant".
//
// No API key required for light/personal use (anonymous tier is
// documented at ~30 requests/minute per IP). If LLM7.io ever changes
// its policy or rate-limits you, this is the only file you'd need to
// update (see call_ai() below) — swap in another provider's endpoint.

require_once __DIR__ . '/common.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

if (!$body || empty($body['room']) || !isset($body['prompt']) || trim($body['prompt']) === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing room or prompt']);
    exit;
}

$room = $body['room'];
$prompt = trim(strip_tags($body['prompt']));
if (mb_strlen($prompt) > 2000) {
    $prompt = mb_substr($prompt, 0, 2000);
}

// Give the AI a little context: the last few messages in the room.
$history = read_messages($room);
$recent = array_slice($history, -8); // last 8 messages for context

$chatMessages = [
    ['role' => 'system', 'content' => 'You are a helpful assistant participating in a casual group chat. Keep replies concise and friendly.'],
];
foreach ($recent as $m) {
    if ($m['type'] === 'text' && !empty($m['text'])) {
        $role = ($m['user'] === 'AI Assistant') ? 'assistant' : 'user';
        $content = ($role === 'user') ? ($m['user'] . ': ' . $m['text']) : $m['text'];
        $chatMessages[] = ['role' => $role, 'content' => $content];
    }
}
$chatMessages[] = ['role' => 'user', 'content' => $prompt];

function call_ai($messages) {
    // LLM7.io — anonymous, OpenAI-compatible endpoint. No signup, no API
    // key needed for light/personal use (documented ~30 requests/minute
    // per IP on the anonymous tier).
    $url = 'https://api.llm7.io/v1/chat/completions';
    $payload = json_encode([
        'model' => 'gpt-4o-mini-2024-07-18',
        'messages' => $messages,
        'stream' => false,
    ]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer unused',
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 25);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($response === false || $httpCode >= 400) {
        return ['ok' => false, 'error' => 'AI request failed (HTTP ' . $httpCode . '): ' . $curlErr];
    }

    $decoded = json_decode($response, true);
    if (is_array($decoded) && isset($decoded['choices'][0]['message']['content'])) {
        return ['ok' => true, 'text' => trim($decoded['choices'][0]['message']['content'])];
    }

    if (is_string($response) && trim($response) !== '') {
        return ['ok' => true, 'text' => trim($response)];
    }

    return ['ok' => false, 'error' => 'Unexpected response from AI provider'];
}

$result = call_ai($chatMessages);

if (!$result['ok']) {
    http_response_code(502);
    echo json_encode(['ok' => false, 'error' => $result['error']]);
    exit;
}

$newMsg = append_message($room, [
    'type' => 'text',
    'user' => 'AI Assistant',
    'text' => $result['text'],
]);

echo json_encode(['ok' => true, 'message' => $newMsg]);
