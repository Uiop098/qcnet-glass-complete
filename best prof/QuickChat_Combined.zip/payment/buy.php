<?php
// payment/buy.php — this is what buy_redirect.php sends people to after
// they click "Buy Super Access" on the login page. Reaching this page
// directly (without going through buy_redirect.php first) shows a
// blocked message instead of the offer — see the session check below.
//
// Same-site session gate: buy_redirect.php sets $_SESSION['buy_access_until']
// right before redirecting here. No signed link, no second domain, no
// network call needed — it's all one PHP app now, so a native PHP
// session is enough.

require_once __DIR__ . '/../common.php'; // get_client_ip(), rate_limit_allow(), now_ms()
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

session_start();
$hasAccess = !empty($_SESSION['buy_access_until']) && $_SESSION['buy_access_until'] > now_ms();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>QuickChat Super Access</title>
<style>
  :root { --bg-a:#1b1030; --bg-b:#05040a; --accent:#b388ff; --text-hi:#f3eefc; --text-lo:#a89bc2; --border:rgba(255,255,255,0.14); }
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; font-family: 'Segoe UI', Roboto, sans-serif; color: var(--text-hi);
    background: radial-gradient(700px 600px at 85% 90%, #8b5cf6 0%, transparent 45%), linear-gradient(160deg, var(--bg-a), var(--bg-b));
    display: flex; align-items: center; justify-content: center; padding: 20px;
  }
  .card {
    width: 100%; max-width: 380px; background: rgba(139,92,246,0.10); border: 1px solid var(--border);
    border-radius: 22px; padding: 28px 24px; text-align: center; backdrop-filter: blur(18px);
  }
  .badge { display: inline-block; background: rgba(139,92,246,0.25); border: 1px solid var(--border); border-radius: 999px; padding: 5px 14px; font-size: 11px; letter-spacing: 0.05em; text-transform: uppercase; margin-bottom: 14px; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .price { font-size: 44px; font-weight: 800; margin: 14px 0 2px; }
  .price small { font-size: 16px; font-weight: 500; color: var(--text-lo); }
  .duration { font-size: 13px; color: var(--text-lo); margin-bottom: 20px; }
  ul { text-align: left; font-size: 13px; color: var(--text-lo); line-height: 1.9; padding-left: 20px; margin: 0 0 22px; }
  button.pay {
    width: 100%; border: none; border-radius: 999px; background: var(--accent); color: #14101f;
    font-weight: 700; font-size: 15px; padding: 14px; cursor: pointer;
  }
  button.pay:disabled { opacity: 0.6; cursor: not-allowed; }
  .fine-print { font-size: 10.5px; color: var(--text-lo); margin-top: 14px; line-height: 1.6; }
  .result { display: none; margin-top: 18px; padding: 16px; border-radius: 14px; background: rgba(255,255,255,0.06); border: 1px solid var(--border); text-align: left; }
  .result.show { display: block; }
  .result.error { border-color: #ff8a8a; }
  .token-box { font-family: monospace; font-size: 13px; word-break: break-all; background: rgba(0,0,0,0.3); padding: 10px; border-radius: 10px; margin: 10px 0; }
  .copy-btn { border: 1px solid var(--border); background: rgba(255,255,255,0.08); color: var(--text-hi); border-radius: 8px; padding: 7px 14px; font-size: 12px; cursor: pointer; }
</style>
</head>
<body>

<?php if (!$hasAccess): ?>

<div class="card">
  <div class="badge">Link required</div>
  <h1>This page isn't open directly</h1>
  <div class="fine-print">You need to come from QuickChat's login page. Go back and click "Buy Super Access" — it'll bring you straight back here.</div>
  <div class="fine-print"><a href="../login.html" style="color:var(--accent)">&larr; Back to QuickChat</a></div>
</div>

<?php else: ?>

<div class="card">
  <div class="badge">Limited-time offer</div>
  <h1>QuickChat Super Access</h1>
  <div class="price">₹<?= (int)(OFFER_AMOUNT_PAISE / 100) ?> <small>one-time</small></div>
  <div class="duration">Valid for <?= (int)OFFER_DURATION_DAYS ?> days from purchase</div>
  <ul>
    <li>Log into any QuickChat room without a PIN</li>
    <li>Upload any file type</li>
    <li>Custom room wallpaper &amp; message glow color</li>
    <li>Glowing "Super" badge in chat</li>
  </ul>
  <button class="pay" id="payBtn">Pay ₹<?= (int)(OFFER_AMOUNT_PAISE / 100) ?> &amp; Get Access</button>
  <div class="fine-print">You'll get a one-time access token after payment. Copy it into QuickChat's login screen under the "Redeem" tab to activate your account.</div>

  <div class="result" id="resultBox"></div>
</div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
const payBtn = document.getElementById('payBtn');
const resultBox = document.getElementById('resultBox');

function showResult(html, isError) {
  resultBox.innerHTML = html;
  resultBox.className = 'result show' + (isError ? ' error' : '');
}

payBtn.addEventListener('click', async () => {
  payBtn.disabled = true;
  payBtn.textContent = 'Starting…';
  try {
    const orderRes = await fetch('create_order.php', { method: 'POST' });
    const orderData = await orderRes.json();
    if (!orderRes.ok || !orderData.ok) {
      showResult((orderData.message || 'Could not start payment. Please try again.'), true);
      return;
    }

    const rzp = new Razorpay({
      key: orderData.keyId,
      amount: orderData.amount,
      currency: orderData.currency,
      order_id: orderData.orderId,
      name: 'QuickChat',
      description: orderData.label,
      theme: { color: '#8b5cf6' },
      handler: async function (response) {
        payBtn.textContent = 'Verifying payment…';
        try {
          const verifyRes = await fetch('verify_payment.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            }),
          });
          const verifyData = await verifyRes.json();
          if (!verifyRes.ok || !verifyData.ok) {
            showResult('Payment succeeded but verification failed. Contact support with payment ID: ' + response.razorpay_payment_id, true);
            return;
          }
          showResult(
            '<b>✅ Payment successful!</b>' +
            '<div class="token-box" id="tokenBox">' + verifyData.token + '</div>' +
            '<button class="copy-btn" id="copyBtn">Copy token</button>' +
            '<div class="fine-print">Paste this into QuickChat → Login → Redeem tab. Valid for ' + verifyData.durationDays + ' days from now.</div>' +
            '<div class="fine-print"><a href="../login.html" style="color:var(--accent)">Go to QuickChat login &rarr;</a></div>',
            false
          );
          document.getElementById('copyBtn').addEventListener('click', () => {
            navigator.clipboard.writeText(verifyData.token).then(() => {
              document.getElementById('copyBtn').textContent = 'Copied!';
            });
          });
        } catch (e) {
          showResult('Payment succeeded but we could not confirm it. Contact support with payment ID: ' + response.razorpay_payment_id, true);
        }
      },
      modal: {
        ondismiss: function () {
          payBtn.disabled = false;
          payBtn.textContent = 'Pay ₹<?= (int)(OFFER_AMOUNT_PAISE / 100) ?> & Get Access';
        },
      },
    });
    rzp.on('payment.failed', function (resp) {
      showResult('Payment failed: ' + (resp.error && resp.error.description ? resp.error.description : 'please try again.'), true);
      payBtn.disabled = false;
      payBtn.textContent = 'Pay ₹<?= (int)(OFFER_AMOUNT_PAISE / 100) ?> & Get Access';
    });
    rzp.open();
    payBtn.textContent = 'Pay ₹<?= (int)(OFFER_AMOUNT_PAISE / 100) ?> & Get Access';
  } catch (e) {
    showResult('Could not reach the payment server. Please try again.', true);
  } finally {
    payBtn.disabled = false;
  }
});
</script>

<?php endif; ?>

</body>
</html>
