<?php
// payment/create_order.php — called by buy.php right before opening
// Razorpay Checkout. Creates the order on Razorpay's side and a
// matching "pending" row here, so we have a place to attach the access
// token once payment succeeds.

require_once __DIR__ . '/../common.php'; // get_client_ip(), rate_limit_allow(), now_ms()
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') pg_json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);

session_start();
if (empty($_SESSION['buy_access_until']) || $_SESSION['buy_access_until'] <= now_ms()) {
    pg_json_out(['ok' => false, 'error' => 'no_access', 'message' => 'Your Buy session expired. Go back to QuickChat and click "Buy Super Access" again.'], 403);
}

$ip = get_client_ip();
if (!rate_limit_allow('create_order', $ip, 10, 600)) {
    pg_json_out(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many attempts — please wait a few minutes and try again.'], 429);
}

$receipt = 'qc_' . bin2hex(random_bytes(8));
$errorOut = null;
$order = razorpay_create_order(OFFER_AMOUNT_PAISE, OFFER_CURRENCY, $receipt, $errorOut);
if (!$order) {
    pg_json_out(['ok' => false, 'error' => 'order_failed', 'message' => $errorOut ?: 'Could not create order.'], 502);
}

$stmt = db()->prepare(
    'INSERT INTO tokens (token, razorpay_order_id, amount_paise, currency, duration_days, status, buyer_ip, created_at)
     VALUES (:token, :order_id, :amount, :currency, :duration, "pending", :ip, :now)'
);
// Placeholder token until payment is confirmed — verify_payment.php /
// webhook.php overwrite this with the real access token at that point.
$stmt->execute([
    'token' => 'pending_' . $order['id'],
    'order_id' => $order['id'],
    'amount' => OFFER_AMOUNT_PAISE,
    'currency' => OFFER_CURRENCY,
    'duration' => OFFER_DURATION_DAYS,
    'ip' => $ip,
    'now' => now_ms(),
]);

pg_json_out([
    'ok' => true,
    'orderId' => $order['id'],
    'amount' => OFFER_AMOUNT_PAISE,
    'currency' => OFFER_CURRENCY,
    'keyId' => RAZORPAY_KEY_ID,
    'label' => OFFER_LABEL,
]);
