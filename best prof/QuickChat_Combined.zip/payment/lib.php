<?php
// payment/lib.php — Razorpay + access-token helpers. Deliberately does
// NOT define now_ms(), get_client_ip(), or rate_limit_allow() — those
// already exist in ../common.php and ../firewall.php, which every file
// in this folder requires before this one, to avoid a fatal "cannot
// redeclare" error.

function generate_access_token() {
    return bin2hex(random_bytes(24)); // 48 hex chars
}

// Creates a Razorpay Order via their REST API. Uses file_get_contents +
// stream_context (not curl) — the same approach the rest of QuickChat
// already uses successfully for outbound calls (Tenor GIFs, translation)
// on InfinityFree, so it's a known-working pattern on this host. Returns
// the decoded order array, or null + $errorOut on failure.
function razorpay_create_order($amountPaise, $currency, $receipt, &$errorOut = null) {
    $payload = json_encode([
        'amount' => $amountPaise,
        'currency' => $currency,
        'receipt' => $receipt,
        'payment_capture' => 1, // auto-capture — no separate manual capture step needed
    ]);
    $auth = base64_encode(RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET);
    $ctx = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/json\r\nAuthorization: Basic $auth\r\n",
            'content' => $payload,
            'timeout' => 10,
            'ignore_errors' => true,
        ],
    ]);
    $result = @file_get_contents('https://api.razorpay.com/v1/orders', false, $ctx);
    if ($result === false) {
        $errorOut = 'Could not reach Razorpay (network error, or outbound HTTPS is blocked on this host).';
        return null;
    }
    $data = json_decode($result, true);
    if (!is_array($data) || isset($data['error'])) {
        $errorOut = isset($data['error']['description']) ? $data['error']['description'] : 'Razorpay returned an unexpected response.';
        return null;
    }
    return $data;
}

// Verifies the signature Razorpay Checkout sends back to the browser
// after a successful payment (order_id + payment_id + signature).
// Per Razorpay docs: expected = HMAC-SHA256(order_id + "|" + payment_id, key_secret)
function razorpay_verify_payment_signature($orderId, $paymentId, $signature) {
    $expected = hash_hmac('sha256', $orderId . '|' . $paymentId, RAZORPAY_KEY_SECRET);
    return hash_equals($expected, (string)$signature);
}

// Verifies a Razorpay WEBHOOK signature (different secret from the one
// above — the "Webhook Secret" set when you create the webhook).
function razorpay_verify_webhook_signature($rawBody, $signature) {
    $expected = hash_hmac('sha256', $rawBody, RAZORPAY_WEBHOOK_SECRET);
    return hash_equals($expected, (string)$signature);
}

function pg_json_out($arr, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($arr);
    exit;
}
