<?php
// payment/webhook.php — Razorpay calls this directly, server-to-server,
// when a payment is captured. This is the SOURCE OF TRUTH: unlike
// verify_payment.php (which depends on the buyer's browser successfully
// making one more request after paying), this fires even if they closed
// the tab, lost signal, or their bank redirect got interrupted. Point
// Razorpay's dashboard webhook at:
//   https://yourdomain.com/payment/webhook.php
// with event "payment.captured".
//
// Idempotent by design: if verify_payment.php already marked this order
// paid, this just confirms/no-ops instead of issuing a second token.

require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

$rawBody = file_get_contents('php://input');
$signature = isset($_SERVER['HTTP_X_RAZORPAY_SIGNATURE']) ? $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] : '';

if (!razorpay_verify_webhook_signature($rawBody, $signature)) {
    http_response_code(400);
    exit('bad signature');
}

$data = json_decode($rawBody, true);
$event = isset($data['event']) ? $data['event'] : '';

if ($event !== 'payment.captured') {
    http_response_code(200); // acknowledge everything else, we just don't act on it
    exit('ignored');
}

$payment = $data['payload']['payment']['entity'] ?? null;
if (!$payment || empty($payment['order_id']) || empty($payment['id'])) {
    http_response_code(200);
    exit('no payment entity');
}

$orderId = $payment['order_id'];
$paymentId = $payment['id'];

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM tokens WHERE razorpay_order_id = :order_id LIMIT 1');
$stmt->execute(['order_id' => $orderId]);
$row = $stmt->fetch();

if (!$row) {
    // Order not found — most likely create_order.php's insert didn't
    // happen (shouldn't occur in normal flow). Nothing safe to do.
    http_response_code(200);
    exit('unknown order');
}

if ($row['status'] === 'pending') {
    $accessToken = generate_access_token();
    $upd = $pdo->prepare(
        'UPDATE tokens SET token = :token, razorpay_payment_id = :payment_id, status = "paid", paid_at = :now
         WHERE razorpay_order_id = :order_id AND status = "pending"'
    );
    $upd->execute(['token' => $accessToken, 'payment_id' => $paymentId, 'now' => now_ms(), 'order_id' => $orderId]);
}

http_response_code(200);
echo 'ok';
