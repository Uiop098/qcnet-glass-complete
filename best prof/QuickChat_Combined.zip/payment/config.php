<?php
// payment/config.php — every value in here MUST be changed before you go
// live. Blocked from direct browser access by payment/.htaccess.
//
// This is now part of the SAME site as the rest of QuickChat (no more
// separate payment domain) — so it deliberately does NOT redefine
// get_client_ip()/rate_limit_allow()/now_ms(); those already exist in
// ../common.php and ../firewall.php, and every file in this folder is
// only ever reached through a request that already loaded those first.

// ---------------------------------------------------------------------
// 1) MySQL — create a database in your InfinityFree control panel
//    (Control Panel -> MySQL Databases), then paste its details here.
//    InfinityFree DB hostnames are usually NOT "localhost" — copy the
//    exact hostname shown next to your database (something like
//    sqlXXX.infinityfree.com).
// ---------------------------------------------------------------------
define('DB_HOST', 'sqlXXX.infinityfree.com');
define('DB_NAME', 'if0_XXXXXXXX_quickchat_pay');
define('DB_USER', 'if0_XXXXXXXX');
define('DB_PASS', 'REPLACE_WITH_YOUR_DB_PASSWORD');

// ---------------------------------------------------------------------
// 2) Razorpay — from https://dashboard.razorpay.com -> Settings -> API Keys.
//    Use TEST keys (rzp_test_...) while you're setting this up, switch
//    to LIVE keys (rzp_live_...) only once a real test payment has
//    worked end-to-end. Never put the key SECRET anywhere the browser
//    can load directly — only server-side files here use it.
// ---------------------------------------------------------------------
define('RAZORPAY_KEY_ID', 'rzp_test_XXXXXXXXXXXXXX');
define('RAZORPAY_KEY_SECRET', 'REPLACE_WITH_YOUR_KEY_SECRET');

// Settings -> Webhooks -> Add New Webhook on the Razorpay dashboard.
//   Webhook URL: https://yourdomain.com/payment/webhook.php
//   Active events: payment.captured
// Razorpay gives you a separate "Webhook Secret" when you create it —
// paste that (NOT the API key secret) here.
define('RAZORPAY_WEBHOOK_SECRET', 'REPLACE_WITH_YOUR_WEBHOOK_SECRET');

// ---------------------------------------------------------------------
// 3) The offer. Amount is in PAISE (Razorpay's smallest unit for INR),
//    so 100 = ₹1.00. This is deliberately a test/promo price — change
//    it once you're ready for a real price.
// ---------------------------------------------------------------------
define('OFFER_AMOUNT_PAISE', 100);       // ₹1
define('OFFER_CURRENCY', 'INR');
define('OFFER_DURATION_DAYS', 10);
define('OFFER_LABEL', 'QuickChat Super Access — 10 days');

require_once __DIR__ . '/db.php';
