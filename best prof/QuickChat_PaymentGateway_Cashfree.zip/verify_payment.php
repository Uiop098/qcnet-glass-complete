<?php
// verify_payment.php — Cashfree redirects the buyer's browser HERE after
// checkout (order_meta.return_url in create_order.php), with ?order_id=
// appended. A redirect happening is NOT proof of payment (the buyer
// could cancel and still land here) — we always ask Cashfree directly
// "did this order actually get paid?" before issuing a token.
//
// This is the FAST path for showing the token to the buyer immediately.
// webhook.php is the AUTHORITATIVE path (Cashfree's own server telling
// us directly) and exists as a fallback in case the browser closes/loses
// connection before this loads — see webhook.php for why both exist.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

$ip = get_client_ip();
$orderId = isset($_GET['order_id']) ? trim((string)$_GET['order_id']) : '';

function render_page($bodyHtml) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">'
        . '<title>QuickChat Super Access</title><style>'
        . ':root { --bg-a:#1b1030; --bg-b:#05040a; --accent:#b388ff; --text-hi:#f3eefc; --text-lo:#a89bc2; --border:rgba(255,255,255,0.14); }'
        . '* { box-sizing: border-box; } body { margin:0; min-height:100vh; font-family:"Segoe UI",Roboto,sans-serif; color:var(--text-hi);'
        . 'background: radial-gradient(700px 600px at 85% 90%, #8b5cf6 0%, transparent 45%), linear-gradient(160deg, var(--bg-a), var(--bg-b));'
        . 'display:flex; align-items:center; justify-content:center; padding:20px; }'
        . '.card { width:100%; max-width:380px; background:rgba(139,92,246,0.10); border:1px solid var(--border); border-radius:22px; padding:28px 24px; text-align:center; backdrop-filter:blur(18px); }'
        . 'h1 { font-size:20px; margin:0 0 14px; } .token-box { font-family:monospace; font-size:13px; word-break:break-all; background:rgba(0,0,0,0.3); padding:10px; border-radius:10px; margin:10px 0; }'
        . '.copy-btn, .refresh-btn { border:1px solid var(--border); background:rgba(255,255,255,0.08); color:var(--text-hi); border-radius:8px; padding:9px 16px; font-size:13px; cursor:pointer; text-decoration:none; display:inline-block; }'
        . '.fine-print { font-size:11.5px; color:var(--text-lo); margin-top:14px; line-height:1.6; }'
        . '.error { color:#ff8a8a; }'
        . '</style></head><body><div class="card">' . $bodyHtml . '</div></body></html>';
    exit;
}

if ($orderId === '') {
    render_page('<h1 class="error">Missing order</h1><p class="fine-print">No order reference was provided. If you just paid, check your email or contact support.</p>');
}
if (!rate_limit_allow('verify_payment', $ip, 30, 600)) {
    render_page('<h1 class="error">Too many attempts</h1><p class="fine-print">Please wait a few minutes and refresh this page.</p>');
}

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM tokens WHERE order_id = :order_id LIMIT 1');
$stmt->execute(['order_id' => $orderId]);
$row = $stmt->fetch();

if (!$row) {
    render_page('<h1 class="error">Order not found</h1><p class="fine-print">If you just paid, contact support with this order id: ' . htmlspecialchars($orderId) . '</p>');
}

// Already confirmed (e.g. the webhook beat us to it, or this is a
// page refresh) — just show the same token again.
if ($row['status'] !== 'pending') {
    render_page(
        '<h1>✅ Payment successful!</h1>'
        . '<div class="token-box" id="tokenBox">' . htmlspecialchars($row['token']) . '</div>'
        . '<button class="copy-btn" onclick="navigator.clipboard.writeText(\'' . htmlspecialchars($row['token'], ENT_QUOTES) . '\').then(()=>this.textContent=\'Copied!\')">Copy token</button>'
        . '<p class="fine-print">Paste this into QuickChat → Login → Redeem tab. Valid for ' . (int)$row['duration_days'] . ' days from purchase.</p>'
    );
}

// Ask Cashfree directly whether this order was actually paid. Payment
// capture is normally near-instant, but a couple of quick retries
// smooths over the small gap between "bank redirected the browser back"
// and "Cashfree's own systems finished recording it".
$paid = false;
$paymentId = null;
$errorOut = null;
for ($attempt = 0; $attempt < 3; $attempt++) {
    $payments = cashfree_fetch_order_payments($orderId, $errorOut);
    if (is_array($payments)) {
        foreach ($payments as $p) {
            if (isset($p['payment_status']) && $p['payment_status'] === 'SUCCESS') {
                $paid = true;
                $paymentId = $p['cf_payment_id'] ?? null;
                break 2;
            }
        }
    }
    if ($attempt < 2) sleep(2);
}

if (!$paid) {
    if ($errorOut) {
        render_page('<h1 class="error">Could not confirm payment</h1><p class="fine-print">' . htmlspecialchars($errorOut) . '</p><a class="refresh-btn" href="?order_id=' . urlencode($orderId) . '">Try again</a>');
    }
    render_page(
        '<h1>⏳ Still confirming…</h1>'
        . '<p class="fine-print">We have not received confirmation of your payment yet. If you completed the payment, this usually resolves within a minute — refresh this page. If it does not, no charge should have gone through.</p>'
        . '<a class="refresh-btn" href="?order_id=' . urlencode($orderId) . '">Refresh</a>'
    );
}

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare('SELECT * FROM tokens WHERE order_id = :order_id LIMIT 1 FOR UPDATE');
    $stmt->execute(['order_id' => $orderId]);
    $row = $stmt->fetch();

    if ($row['status'] === 'pending') {
        $accessToken = generate_access_token();
        $upd = $pdo->prepare('UPDATE tokens SET token = :token, payment_id = :payment_id, status = "paid", paid_at = :now WHERE order_id = :order_id AND status = "pending"');
        $upd->execute(['token' => $accessToken, 'payment_id' => $paymentId, 'now' => now_ms(), 'order_id' => $orderId]);
        $row['token'] = $accessToken;
    }
    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    render_page('<h1 class="error">Something went wrong</h1><p class="fine-print">Contact support with order id: ' . htmlspecialchars($orderId) . '</p>');
}

render_page(
    '<h1>✅ Payment successful!</h1>'
    . '<div class="token-box">' . htmlspecialchars($row['token']) . '</div>'
    . '<button class="copy-btn" onclick="navigator.clipboard.writeText(\'' . htmlspecialchars($row['token'], ENT_QUOTES) . '\').then(()=>this.textContent=\'Copied!\')">Copy token</button>'
    . '<p class="fine-print">Paste this into QuickChat → Login → Redeem tab. Valid for ' . (int)$row['duration_days'] . ' days from now.</p>'
);
