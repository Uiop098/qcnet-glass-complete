-- schema.sql — run this once in your InfinityFree control panel's
-- phpMyAdmin (open your database -> SQL tab -> paste this -> Go).
--
-- If you already created the OLDER version of this table (Razorpay
-- column names), drop it first: DROP TABLE tokens;  then run this.

CREATE TABLE IF NOT EXISTS tokens (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  token           VARCHAR(64)  NOT NULL,
  order_id        VARCHAR(64)  NOT NULL,
  payment_id      VARCHAR(64)  NULL,
  amount_inr      DECIMAL(10,2) NOT NULL,
  currency        VARCHAR(8)   NOT NULL DEFAULT 'INR',
  duration_days   INT UNSIGNED NOT NULL,
  status          ENUM('pending','paid','redeemed') NOT NULL DEFAULT 'pending',
  buyer_ip        VARCHAR(64)  NULL,
  created_at      BIGINT UNSIGNED NOT NULL,
  paid_at         BIGINT UNSIGNED NULL,
  redeemed_at     BIGINT UNSIGNED NULL,
  redeemed_by_app_ip VARCHAR(64) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_token (token),
  UNIQUE KEY uq_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
