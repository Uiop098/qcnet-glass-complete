<?php
// lib.php — small helpers shared by create_order.php, verify_payment.php,
// webhook.php, and verify_token.php.

function generate_access_token() {
    return bin2hex(random_bytes(24)); // 48 hex chars
}

function generate_order_id() {
    return 'qc_' . bin2hex(random_bytes(10));
}

function cashfree_api_base() {
    return CASHFREE_ENV === 'production'
        ? 'https://api.cashfree.com/pg'
        : 'https://sandbox.cashfree.com/pg';
}

// Every Cashfree REST call goes through this. Uses file_get_contents +
// stream_context (not curl) — the same approach the main QuickChat app
// already uses successfully for its own outbound calls (Tenor GIFs,
// translation) on InfinityFree, so it's a known-working pattern on this
// host. Returns the decoded response array, or null + $errorOut.
function cashfree_request($method, $path, $body = null, &$errorOut = null) {
    $headers = "Content-Type: application/json\r\n"
        . "x-client-id: " . CASHFREE_CLIENT_ID . "\r\n"
        . "x-client-secret: " . CASHFREE_CLIENT_SECRET . "\r\n"
        . "x-api-version: " . CASHFREE_API_VERSION . "\r\n";
    $opts = [
        'http' => [
            'method' => $method,
            'header' => $headers,
            'timeout' => 12,
            'ignore_errors' => true,
        ],
    ];
    if ($body !== null) $opts['http']['content'] = json_encode($body);
    $ctx = stream_context_create($opts);
    $result = @file_get_contents(cashfree_api_base() . $path, false, $ctx);
    if ($result === false) {
        $errorOut = 'Could not reach Cashfree (network error, or outbound HTTPS is blocked on this host).';
        return null;
    }
    $data = json_decode($result, true);
    if (!is_array($data)) {
        $errorOut = 'Cashfree returned an unexpected response.';
        return null;
    }
    // Cashfree error responses look like {"message": "...", "code": "...", "type": "..."} —
    // that exact trio only ever appears together on an error envelope.
    if (isset($data['message']) && isset($data['code']) && isset($data['type'])) {
        $errorOut = $data['message'];
        return null;
    }
    return $data;
}

function cashfree_create_order($orderId, $amountInr, $currency, $customerId, $customerPhone, $customerEmail, $returnUrl, &$errorOut = null) {
    $body = [
        'order_id' => $orderId,
        'order_amount' => (float)$amountInr,
        'order_currency' => $currency,
        'customer_details' => [
            'customer_id' => $customerId,
            'customer_phone' => $customerPhone,
            'customer_email' => $customerEmail,
        ],
        'order_meta' => [
            'return_url' => $returnUrl . (strpos($returnUrl, '?') !== false ? '&' : '?') . 'order_id={order_id}',
        ],
    ];
    return cashfree_request('POST', '/orders', $body, $errorOut);
}

// Fetches the order's own status (ACTIVE / PAID / EXPIRED / ...).
function cashfree_fetch_order($orderId, &$errorOut = null) {
    return cashfree_request('GET', '/orders/' . rawurlencode($orderId), null, $errorOut);
}

// Fetches every payment attempt against an order. We check THIS (not
// just order_status) because that's what actually confirms money moved
// — Cashfree's own integration guide recommends checking payment
// status here rather than trusting order_status alone after a redirect.
function cashfree_fetch_order_payments($orderId, &$errorOut = null) {
    return cashfree_request('GET', '/orders/' . rawurlencode($orderId) . '/payments', null, $errorOut);
}

// Cashfree signs webhooks as base64(HMAC-SHA256(timestamp + rawBody, client_secret)).
// Per Cashfree's docs this uses the CLIENT SECRET, not a separate
// webhook-specific secret. The raw, unmodified request body must be
// used — re-serializing the JSON (e.g. via json_encode after decoding)
// can reformat decimal amounts and break the signature.
function cashfree_verify_webhook_signature($rawBody, $timestamp, $signature) {
    if ($timestamp === '' || $signature === '') return false;
    // Reject stale/replayed webhooks (5 minute window).
    if (abs(time() - (int)$timestamp) > 300) return false;
    $expected = base64_encode(hash_hmac('sha256', $timestamp . $rawBody, CASHFREE_CLIENT_SECRET, true));
    return hash_equals($expected, (string)$signature);
}

function now_ms() {
    return (int) round(microtime(true) * 1000);
}

function json_out($arr, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($arr);
    exit;
}
