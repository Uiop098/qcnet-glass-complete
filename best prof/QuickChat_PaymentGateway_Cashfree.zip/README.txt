QuickChat Payment Gateway (Cashfree) — setup guide
====================================================

This is a SEPARATE site from the main QuickChat app. Deploy it on its
own InfinityFree (sub)domain, e.g. pay.yoursite.com or a fresh free
subdomain. It sells "Super Access" for QuickChat: buyer pays via
Cashfree, gets a one-time access token, pastes that token into
QuickChat's login page (Redeem tab) to create their own super account.

--------------------------------------------------------------------
1. Create the MySQL database (InfinityFree control panel)
--------------------------------------------------------------------
- Control Panel -> MySQL Databases -> create a new database.
- Note the hostname, database name, username, password shown there.
  The hostname is USUALLY something like sqlXXX.infinityfree.com —
  it is almost never "localhost" on InfinityFree.
- Open phpMyAdmin for that database (link is right there in the control
  panel) -> SQL tab -> paste the contents of schema.sql -> Go.

--------------------------------------------------------------------
2. Get your Cashfree keys
--------------------------------------------------------------------
- Sign up / log in at https://merchant.cashfree.com
- Developers -> API Keys -> make sure you're in TEST/SANDBOX mode
  (there's a mode switch, usually top-right) -> copy your Client ID
  and Client Secret.
- Developers -> Webhooks -> Add Endpoint:
    Endpoint URL: https://YOUR-PAYMENT-DOMAIN/webhook.php
    Event:        PAYMENT_SUCCESS_WEBHOOK
  Cashfree signs webhooks using your CLIENT SECRET (not a separate
  webhook secret) — see the comments in webhook.php / lib.php.
  Sandbox and Production webhooks are configured separately — you'll
  need to add this again under Production once you switch over.

--------------------------------------------------------------------
3. Fill in config.php
--------------------------------------------------------------------
Open config.php and replace every REPLACE_WITH_... placeholder with the
real values from steps 1 and 2, plus a shared secret for talking to
your main QuickChat app:

    php -r "echo bin2hex(random_bytes(32));"

Run that once anywhere PHP is available, copy the output into
APP_SHARED_SECRET here — and paste the SAME string into the main app's
common.php (PAYMENT_GATEWAY_SECRET constant). This is what stops
random visitors from calling verify_token.php directly.

Leave CASHFREE_ENV as 'sandbox' until testing works end-to-end (step 6).

--------------------------------------------------------------------
4. Upload
--------------------------------------------------------------------
Upload every file in this folder to your payment domain's web root,
keeping the folder structure as-is.

--------------------------------------------------------------------
5. Point the main app at this gateway
--------------------------------------------------------------------
In the main QuickChat app's common.php, set:
    PAYMENT_GATEWAY_URL    = 'https://YOUR-PAYMENT-DOMAIN/verify_token.php'
    PAYMENT_GATEWAY_SECRET = the same APP_SHARED_SECRET from step 3

Also update the "Buy Super Access" link on QuickChat's login page
(login.html, Redeem tab) to point at https://YOUR-PAYMENT-DOMAIN/

--------------------------------------------------------------------
6. Test it end-to-end BEFORE switching to production keys
--------------------------------------------------------------------
With CASHFREE_ENV = 'sandbox' and your sandbox keys, Cashfree's test
checkout accepts these values — no real money moves:
    Card:  4111 1111 1111 1111, any future expiry, any CVV, OTP 111000
    UPI:   testsuccess@gocash  (or use the "Simulate" success button
           Cashfree's sandbox checkout shows for UPI/netbanking)
- Visit your payment domain, enter a phone/email, pay ₹1 with the test
  card above.
- Confirm you land back on verify_payment.php with a token shown.
- Paste that token into QuickChat's login page -> Redeem tab -> confirm
  a super account gets created and you're logged in.
- Only after that works: switch config.php's CASHFREE_ENV to
  'production', swap in your production Client ID/Secret, and add the
  webhook again under Production mode in the Cashfree dashboard.

--------------------------------------------------------------------
Notes
--------------------------------------------------------------------
- The ₹1 / 10-day offer is set in config.php (OFFER_AMOUNT_INR,
  OFFER_DURATION_DAYS, OFFER_LABEL) — change these when you're ready
  to move off the test price. OFFER_AMOUNT_INR is a plain rupee value
  (e.g. 49.00 for ₹49), not paise.
- Every token is single-use: once redeemed by the main app, it can't
  be redeemed again, even if someone else gets hold of it after you.
- There are two independent ways a payment gets confirmed here:
  verify_payment.php (fires when the buyer's browser gets redirected
  back after paying) and webhook.php (fires from Cashfree's own
  servers regardless of what the buyer's browser does). Either one
  can be first — both are written to not issue a second token if the
  other already did.
- Outbound HTTPS (this gateway calling api.cashfree.com, and the main
  app calling this gateway) uses the same file_get_contents()-based
  approach the main QuickChat app already uses successfully for GIF
  search and translation — known to work on InfinityFree. If either
  side ever reports "could not reach" errors, that specific host may
  be blocking outbound HTTPS and you'd need to ask their support or
  move that piece to a host that allows it.
