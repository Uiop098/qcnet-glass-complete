<?php
// create_order.php — called by index.html right before opening Cashfree
// Checkout. Creates the order on Cashfree's side (which hands back a
// payment_session_id the browser needs to open checkout) and a matching
// "pending" row here, so we have a place to attach the access token
// once payment succeeds.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);

$ip = get_client_ip();
if (is_ip_blocked($ip)) json_out(['ok' => false, 'error' => 'blocked'], 403);
if (!rate_limit_allow('create_order', $ip, 10, 600)) {
    json_out(['ok' => false, 'error' => 'rate_limited', 'message' => 'Too many attempts — please wait a few minutes and try again.'], 429);
}

$body = json_decode(file_get_contents('php://input'), true);
$phone = preg_replace('/\D/', '', (string)($body['phone'] ?? ''));
$email = trim((string)($body['email'] ?? ''));

if (!preg_match('/^[6-9]\d{9}$/', $phone)) {
    json_out(['ok' => false, 'error' => 'Enter a valid 10-digit Indian mobile number.'], 400);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_out(['ok' => false, 'error' => 'Enter a valid email address.'], 400);
}

$orderId = generate_order_id();
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$returnUrl = $scheme . '://' . $_SERVER['HTTP_HOST'] . '/verify_payment.php';

$errorOut = null;
$order = cashfree_create_order(
    $orderId, OFFER_AMOUNT_INR, OFFER_CURRENCY,
    'cust_' . substr(hash('sha256', $phone), 0, 16), $phone, $email,
    $returnUrl, $errorOut
);
if (!$order || empty($order['payment_session_id'])) {
    json_out(['ok' => false, 'error' => $errorOut ?: 'Could not create order.'], 502);
}

$stmt = db()->prepare(
    'INSERT INTO tokens (token, order_id, amount_inr, currency, duration_days, status, buyer_ip, created_at)
     VALUES (:token, :order_id, :amount, :currency, :duration, "pending", :ip, :now)'
);
// Placeholder token until payment is confirmed — verify_payment.php /
// webhook.php overwrite this with the real access token at that point.
$stmt->execute([
    'token' => 'pending_' . $orderId,
    'order_id' => $orderId,
    'amount' => OFFER_AMOUNT_INR,
    'currency' => OFFER_CURRENCY,
    'duration' => OFFER_DURATION_DAYS,
    'ip' => $ip,
    'now' => now_ms(),
]);

json_out([
    'ok' => true,
    'orderId' => $orderId,
    'paymentSessionId' => $order['payment_session_id'],
    'environment' => CASHFREE_ENV,
]);
