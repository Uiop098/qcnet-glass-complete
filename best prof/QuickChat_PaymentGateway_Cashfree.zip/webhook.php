<?php
// webhook.php — Cashfree calls this directly, server-to-server, when a
// payment succeeds. This is the SOURCE OF TRUTH: unlike
// verify_payment.php (which depends on the buyer's browser successfully
// being redirected back after paying), this fires even if they closed
// the tab, lost signal, or the bank redirect got interrupted. Point
// Cashfree's dashboard webhook at this URL (Developers -> Webhooks)
// with event "PAYMENT_SUCCESS_WEBHOOK". Set this up separately for
// Sandbox and Production — they don't share webhook configuration.
//
// Idempotent by design: if verify_payment.php already marked this order
// paid, this just confirms/no-ops instead of issuing a second token.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

$rawBody = file_get_contents('php://input');
$signature = $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? '';
$timestamp = $_SERVER['HTTP_X_WEBHOOK_TIMESTAMP'] ?? '';

if (!cashfree_verify_webhook_signature($rawBody, $timestamp, $signature)) {
    http_response_code(400);
    exit('bad signature');
}

$data = json_decode($rawBody, true);
$type = $data['type'] ?? '';

if ($type !== 'PAYMENT_SUCCESS_WEBHOOK') {
    http_response_code(200); // acknowledge everything else, we just don't act on it
    exit('ignored');
}

$order = $data['data']['order'] ?? null;
$payment = $data['data']['payment'] ?? null;
if (!$order || !$payment || empty($order['order_id']) || ($payment['payment_status'] ?? '') !== 'SUCCESS') {
    http_response_code(200);
    exit('nothing to do');
}

$orderId = $order['order_id'];
$paymentId = $payment['cf_payment_id'] ?? null;

$pdo = db();
$stmt = $pdo->prepare('SELECT * FROM tokens WHERE order_id = :order_id LIMIT 1');
$stmt->execute(['order_id' => $orderId]);
$row = $stmt->fetch();

if (!$row) {
    // Order not found — most likely create_order.php's insert didn't
    // happen (shouldn't occur in normal flow). Nothing safe to do.
    http_response_code(200);
    exit('unknown order');
}

if ($row['status'] === 'pending') {
    $accessToken = generate_access_token();
    $upd = $pdo->prepare(
        'UPDATE tokens SET token = :token, payment_id = :payment_id, status = "paid", paid_at = :now
         WHERE order_id = :order_id AND status = "pending"'
    );
    $upd->execute(['token' => $accessToken, 'payment_id' => $paymentId, 'now' => now_ms(), 'order_id' => $orderId]);
}

http_response_code(200);
echo 'ok';
