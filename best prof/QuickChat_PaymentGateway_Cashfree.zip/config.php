<?php
// config.php — every value in here MUST be changed before you go live.
// This file is blocked from direct browser access by .htaccess, but it
// still sits in plain text on the server, so keep server access (FTP/
// control panel login) private, same as you would for any other host.

// ---------------------------------------------------------------------
// 1) MySQL — create a database in your InfinityFree control panel
//    (Control Panel -> MySQL Databases), then paste its details here.
//    InfinityFree DB hostnames are usually NOT "localhost" — copy the
//    exact hostname shown next to your database (something like
//    sqlXXX.infinityfree.com).
// ---------------------------------------------------------------------
define('DB_HOST', 'sqlXXX.infinityfree.com');
define('DB_NAME', 'if0_XXXXXXXX_quickchat_pay');
define('DB_USER', 'if0_XXXXXXXX');
define('DB_PASS', 'REPLACE_WITH_YOUR_DB_PASSWORD');

// ---------------------------------------------------------------------
// 2) Cashfree — from https://merchant.cashfree.com -> Developers -> API Keys.
//    Use SANDBOX keys while you're setting this up (CASHFREE_ENV below
//    controls which API + JS SDK mode is used), switch to production
//    keys only once a real test payment has worked end-to-end. Never
//    put the client SECRET in any file the browser can load directly —
//    only server-side files here use it.
// ---------------------------------------------------------------------
define('CASHFREE_ENV', 'sandbox'); // 'sandbox' or 'production'
define('CASHFREE_CLIENT_ID', 'REPLACE_WITH_YOUR_CLIENT_ID');
define('CASHFREE_CLIENT_SECRET', 'REPLACE_WITH_YOUR_CLIENT_SECRET');
define('CASHFREE_API_VERSION', '2023-08-01');

// Merchant Dashboard -> Developers -> Webhooks -> Add Endpoint on the
// Cashfree dashboard.
//   Webhook URL: https://yourpaymentsite.example/webhook.php
//   Event:       PAYMENT_SUCCESS_WEBHOOK
// Cashfree signs webhooks with your CLIENT SECRET (not a separate
// webhook secret) — see webhook.php for how that's used. Sandbox and
// production each need their own webhook set up in the matching mode.

// ---------------------------------------------------------------------
// 3) Shared secret with the main QuickChat app. Generate a long random
//    string (e.g. run  php -r "echo bin2hex(random_bytes(32));"  once,
//    anywhere PHP is available) and paste the SAME value here and in
//    the main app's common.php (PAYMENT_GATEWAY_SECRET). This is what
//    stops a random visitor from calling verify_token.php directly.
// ---------------------------------------------------------------------
define('APP_SHARED_SECRET', 'REPLACE_WITH_A_LONG_RANDOM_STRING');

// ---------------------------------------------------------------------
// 4) The offer. Amount is in RUPEES (decimal — Cashfree's order_amount
//    is a plain rupee value, not paise), so 1.00 = ₹1. This is
//    deliberately a test/promo price — change it once you're ready for
//    a real price.
// ---------------------------------------------------------------------
define('OFFER_AMOUNT_INR', 1.00);        // ₹1
define('OFFER_CURRENCY', 'INR');
define('OFFER_DURATION_DAYS', 10);
define('OFFER_LABEL', 'QuickChat Super Access — 10 days');

// ---------------------------------------------------------------------
// Everything below this line is plumbing, not configuration.
// ---------------------------------------------------------------------
$GLOBALS['dataDir'] = __DIR__ . '/data'; // used by firewall.php for rate-limit/IP-block storage
require_once __DIR__ . '/firewall.php';
require_once __DIR__ . '/db.php';
