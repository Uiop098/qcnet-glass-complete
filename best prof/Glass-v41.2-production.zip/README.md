# Universal Business Dashboard and QuickChat Glass v41.2

Pure PHP 8.1+ / PDO. No Laravel, React, or Node. InfinityFree compatible.

## What is in this zip

Upload the `public_html/` folder as the website root (htdocs / public_html).

```
public_html/
  gateway.html          Unified landing
  pay.html              Lifetime tenant checkout
  dashboard/            Login, admin, user portals
  chat/                 QuickChat rooms
  api/                  Auth, TOTP, CRM, payments, chat
  includes/             PDO bootstrap, TOTP
  setup.php             Schema + master seed (run once)
  config.php            Defaults
  config.local.php.example
  data/                 Writable (SQLite / logs) — Apache denied
  uploads/              Chat media, PHP execution denied
```

## Local preview

```bash
php public_html/setup.php
php -S 0.0.0.0:8080 -t public_html public_html/router.php
```

Open `/gateway.html`. Demo master: `master` / `Glassv41!Master`

## InfinityFree production

1. Upload everything inside `public_html/` into your hosting `htdocs` (or `public_html`).
2. Copy `config.local.php.example` to `config.local.php`.
3. Fill MySQL host, database, user, password from the InfinityFree panel.
4. Set `APP_KEY` to 32 random characters. Never reuse the sample key.
5. Visit `https://your-domain/setup.php` once.
6. Sign in as `master` / `Glassv41!Master` and change the password immediately.
7. Paste Cashfree App ID and Secret in Admin → Payments.
8. When live keys work, add this line to `config.local.php`:

```php
define('DEMO_PAYMENTS', false);
```

If `DEMO_PAYMENTS` stays true, checkout still provisions without calling Cashfree.

9. After setup, rename or delete `setup.php`.

`config.local.php` and `config.php` are blocked by `.htaccess`. Chat uploads cannot run PHP.

## Features

- Unified SSO: dashboard credentials work in QuickChat
- TOTP 2FA (Google Authenticator). One verification covers both apps
- Roles: Master (all data) → Admin (paid or invite token) → User
- Master mints one-time admin invite tokens
- User product payment increments the tenant admin PAID counter
- Embedded chat (hamburger). Admin DMs. Peer chat via token request / verify
- Dual Cashfree V3: global tenant sale + tenant product keys (AES-256-GCM)
- 24h chat purge on each request (no cron)
- Client AES-GCM (`v41:salt:payload`) before POST

## Limits (InfinityFree)

- PHP 8.1+, PDO MySQL, 50MB database
- No cron, no Composer, no Laravel
- Chat media max 500KB
- Chat poll interval 4 seconds
