# Glass v41.2 — production install

1. Upload this folder as your site root (InfinityFree `htdocs`).
2. Copy `config.local.php.example` to `config.local.php` and fill MySQL + `APP_KEY`.
3. Open `/setup.php` once.
4. Login `master` / `Glassv41!Master` and change the password.
5. Admin → Payments: paste Cashfree keys.
6. When live, add `define('DEMO_PAYMENTS', false);` to `config.local.php`.
7. Rename or delete `setup.php`.

Local preview:

```bash
php setup.php
php -S 0.0.0.0:8080 -t . router.php
```
