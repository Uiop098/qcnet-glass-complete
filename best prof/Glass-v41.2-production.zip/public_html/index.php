<?php
declare(strict_types=1);
header('Location: gateway.html', true, 302);
exit;
