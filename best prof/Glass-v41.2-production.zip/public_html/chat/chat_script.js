(() => {
  const { api, toast, $ } = window.UBD;

  const enc = {
    async keyFromPass(pass, saltB64) {
      const encd = new TextEncoder();
      const salt = saltB64 ? Uint8Array.from(atob(saltB64), (c) => c.charCodeAt(0)) : crypto.getRandomValues(new Uint8Array(16));
      const base = await crypto.subtle.importKey('raw', encd.encode(pass), 'PBKDF2', false, ['deriveKey']);
      const key = await crypto.subtle.deriveKey(
        { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
        base,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt', 'decrypt']
      );
      return { key, saltB64: btoa(String.fromCharCode(...salt)) };
    },
    async seal(plain, pass) {
      const { key, saltB64 } = await this.keyFromPass(pass);
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const buf = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(plain));
      const pack = new Uint8Array(iv.length + buf.byteLength);
      pack.set(iv, 0);
      pack.set(new Uint8Array(buf), 12);
      return 'v41:' + saltB64 + ':' + btoa(String.fromCharCode(...pack));
    },
    async open(blob, pass) {
      if (!blob || !blob.startsWith('v41:')) return blob;
      const [, saltB64, rest] = blob.split(':');
      const { key } = await this.keyFromPass(pass, saltB64);
      const raw = Uint8Array.from(atob(rest), (c) => c.charCodeAt(0));
      const iv = raw.slice(0, 12);
      const data = raw.slice(12);
      const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, data);
      return new TextDecoder().decode(plain);
    }
  };

  window.QC = { enc, api, toast, $ };
})();
