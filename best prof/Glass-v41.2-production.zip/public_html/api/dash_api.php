<?php
/**
 * CRUD for users, products, orders, tenants, and settings.
 */
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';
ensure_schema();
start_app_session();
rate_limit('dash', RATE_MAX_GENERIC);

$in = json_input();
$action = $_GET['action'] ?? ($in['action'] ?? '');
$u = current_user();

function tenant_scope(array $u): ?int
{
    $body = json_input();
    if ($u['role'] === 'master') {
        if (isset($_GET['tenant_id'])) {
            return (int) $_GET['tenant_id'];
        }
        if (isset($body['tenant_id'])) {
            return (int) $body['tenant_id'];
        }
        return $u['tenant_id'] !== null ? (int) $u['tenant_id'] : null;
    }
    return $u['tenant_id'] !== null ? (int) $u['tenant_id'] : null;
}

function stats_for(?int $tenantId): array
{
    $pdo = db();
    $where = $tenantId ? ' WHERE tenant_id = ' . (int) $tenantId : '';
    $users = (int) $pdo->query('SELECT COUNT(*) c FROM users' . $where)->fetch()['c'];
    $products = (int) $pdo->query('SELECT COUNT(*) c FROM products' . ($tenantId ? ' WHERE tenant_id = ' . (int) $tenantId : ''))->fetch()['c'];
    $orders = (int) $pdo->query('SELECT COUNT(*) c FROM orders' . $where)->fetch()['c'];
    $paid = $pdo->query("SELECT COALESCE(SUM(CAST(amount AS REAL)),0) s FROM orders WHERE status = 'PAID'" . ($tenantId ? ' AND tenant_id = ' . (int) $tenantId : ''))->fetch();
    $rooms = (int) $pdo->query('SELECT COUNT(*) c FROM chat_rooms' . ($tenantId ? ' WHERE tenant_id = ' . (int) $tenantId : ''))->fetch()['c'];
    $msgs = (int) $pdo->query('SELECT COUNT(*) c FROM chat_messages')->fetch()['c'];
    return [
        'users' => $users,
        'products' => $products,
        'orders' => $orders,
        'revenue' => number_format((float) ($paid['s'] ?? 0), 2, '.', ''),
        'rooms' => $rooms,
        'messages' => $msgs,
    ];
}

switch ($action) {
    case 'overview':
        $u = require_roles(['master', 'tenant_admin', 'user']);
        $tid = $u['role'] === 'user' ? ($u['tenant_id'] !== null ? (int) $u['tenant_id'] : 0) : tenant_scope($u);
        $recent = db()->prepare('SELECT id, amount, status, kind, created_at FROM orders ' . ($tid ? 'WHERE tenant_id = ?' : 'WHERE 1=1') . ' ORDER BY id DESC LIMIT 8');
        $tid ? $recent->execute([$tid]) : $recent->execute();
        $tenants = [];
        if ($u['role'] === 'master') {
            $tenants = db()->query('SELECT id, name, admin_username, payment_mode, created_at FROM tenants ORDER BY id DESC')->fetchAll();
        }
        ok([
            'stats' => stats_for($tid ?: null),
            'orders' => $recent->fetchAll(),
            'tenants' => $tenants,
            'user' => $u,
        ]);
        break;

    case 'users':
        $u = require_roles(['master', 'tenant_admin']);
        $tid = tenant_scope($u);
        $op = $in['op'] ?? $_GET['op'] ?? '';
        if ($op === 'create') {
            require_csrf();
            $username = sanitize_username((string) ($in['username'] ?? ''));
            $email = sanitize_email((string) ($in['email'] ?? ''));
            $password = (string) ($in['password'] ?? 'ChangeMe!23');
            $role = (string) ($in['role'] ?? 'user');
            if (!in_array($role, ['user', 'tenant_admin'], true) && $u['role'] !== 'master') {
                $role = 'user';
            }
            $assign = $tid ?: (int) ($in['tenant_id'] ?? 0) ?: null;
            db()->prepare('INSERT INTO users (tenant_id, role, username, password_hash, email, dob, status, paid, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$assign, $role, $username, password_hash($password, PASSWORD_BCRYPT), $email, (string) ($in['dob'] ?? '2000-01-01'), 'active', 0, now_sql()]);
            ok(['id' => (int) db()->lastInsertId()]);
        }
        if ($op === 'delete') {
            require_csrf();
            $id = (int) ($in['id'] ?? $_GET['id'] ?? 0);
            if ($id === (int) $u['id']) {
                fail('Cannot delete yourself');
            }
            $target = db()->prepare('SELECT id, role, tenant_id FROM users WHERE id = ?');
            $target->execute([$id]);
            $trow = $target->fetch();
            if (!$trow) {
                fail('User not found', 404);
            }
            if ($trow['role'] === 'master') {
                fail('Cannot delete the master administrator');
            }
            if ($u['role'] !== 'master' && (int) $trow['tenant_id'] !== (int) $tid) {
                fail('Insufficient permissions', 403);
            }
            $q = db()->prepare('DELETE FROM users WHERE id = ?' . ($u['role'] !== 'master' ? ' AND tenant_id = ?' : ''));
            $u['role'] !== 'master' ? $q->execute([$id, $tid]) : $q->execute([$id]);
            ok(['deleted' => true]);
        }
        if ($op === 'status') {
            require_csrf();
            $id = (int) ($in['id'] ?? 0);
            $status = (($in['status'] ?? 'active') === 'deactivated') ? 'deactivated' : 'active';
            if ($id === (int) $u['id']) {
                fail('Cannot deactivate yourself');
            }
            $sql = 'UPDATE users SET status = ? WHERE id = ?';
            $args = [$status, $id];
            if ($u['role'] !== 'master') {
                $sql .= ' AND tenant_id = ? AND role = ?';
                $args[] = $tid;
                $args[] = 'user';
            }
            db()->prepare($sql)->execute($args);
            ok(['updated' => true, 'status' => $status]);
        }
        $sql = 'SELECT id, tenant_id, role, username, email, dob, status, paid, totp_enabled, last_login_at, created_at FROM users';
        $args = [];
        if ($u['role'] !== 'master') {
            $sql .= ' WHERE tenant_id = ?';
            $args[] = $tid;
        }
        $sql .= ' ORDER BY id DESC LIMIT 200';
        $st = db()->prepare($sql);
        $st->execute($args);
        ok(['users' => $st->fetchAll()]);
        break;

    case 'products':
        $u = require_user();
        $tid = $u['role'] === 'master' ? (int) ($in['tenant_id'] ?? $_GET['tenant_id'] ?? $u['tenant_id'] ?? 0) : (int) $u['tenant_id'];
        $op = $in['op'] ?? $_GET['op'] ?? '';
        if ($op === 'create') {
            require_csrf();
            require_roles(['master', 'tenant_admin']);
            $name = trim((string) ($in['name'] ?? ''));
            $price = number_format((float) ($in['price'] ?? 0), 2, '.', '');
            $desc = substr(trim((string) ($in['description'] ?? '')), 0, 500);
            if ($name === '' || (float) $price <= 0) {
                fail('Name and positive price required');
            }
            db()->prepare('INSERT INTO products (tenant_id, name, price, description, created_at) VALUES (?, ?, ?, ?, ?)')
                ->execute([$tid, $name, $price, $desc, now_sql()]);
            ok(['id' => (int) db()->lastInsertId()]);
        }
        if ($op === 'update') {
            require_csrf();
            require_roles(['master', 'tenant_admin']);
            db()->prepare('UPDATE products SET name = ?, price = ?, description = ? WHERE id = ? AND tenant_id = ?')
                ->execute([
                    trim((string) $in['name']),
                    number_format((float) $in['price'], 2, '.', ''),
                    substr((string) ($in['description'] ?? ''), 0, 500),
                    (int) $in['id'],
                    $tid,
                ]);
            ok(['updated' => true]);
        }
        if ($op === 'delete') {
            require_csrf();
            require_roles(['master', 'tenant_admin']);
            db()->prepare('DELETE FROM products WHERE id = ? AND tenant_id = ?')->execute([(int) $in['id'], $tid]);
            ok(['deleted' => true]);
        }
        $st = db()->prepare('SELECT * FROM products WHERE tenant_id = ? OR ? = 0 ORDER BY id DESC');
        $st->execute([$tid, $tid]);
        ok(['products' => $st->fetchAll()]);
        break;

    case 'orders':
        $u = require_user();
        $tid = $u['role'] === 'user' ? (int) $u['tenant_id'] : tenant_scope($u);
        $sql = 'SELECT o.*, p.name AS product_name FROM orders o LEFT JOIN products p ON p.id = o.product_id';
        $args = [];
        if ($u['role'] === 'user') {
            $sql .= ' WHERE o.user_id = ?';
            $args[] = (int) $u['id'];
        } elseif ($tid) {
            $sql .= ' WHERE o.tenant_id = ?';
            $args[] = $tid;
        }
        $sql .= ' ORDER BY o.id DESC LIMIT 100';
        $st = db()->prepare($sql);
        $st->execute($args);
        ok(['orders' => $st->fetchAll()]);
        break;

    case 'settings':
        $u = require_roles(['master', 'tenant_admin']);
        $tid = (int) ($u['tenant_id'] ?? 0);
        if ($_SERVER['REQUEST_METHOD'] === 'POST' || ($in['op'] ?? '') === 'save') {
            require_csrf();
            $mode = in_array(($in['payment_mode'] ?? 'sandbox'), ['sandbox', 'production'], true) ? $in['payment_mode'] : 'sandbox';
            $appId = trim((string) ($in['cf_app_id'] ?? ''));
            $secret = trim((string) ($in['cf_secret'] ?? ''));
            $name = trim((string) ($in['name'] ?? ''));
            $sets = [];
            $args = [];
            if ($name !== '') {
                $sets[] = 'name = ?';
                $args[] = $name;
            }
            $sets[] = 'payment_mode = ?';
            $args[] = $mode;
            if ($appId !== '') {
                $sets[] = 'cf_app_id_encrypted = ?';
                $args[] = aes_encrypt($appId);
            }
            if ($secret !== '') {
                $sets[] = 'cf_secret_encrypted = ?';
                $args[] = aes_encrypt($secret);
            }
            $args[] = $tid ?: (int) ($in['tenant_id'] ?? 0);
            db()->prepare('UPDATE tenants SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($args);
            ok(['saved' => true]);
        }
        $st = db()->prepare('SELECT id, name, admin_username, payment_mode, cf_app_id_encrypted, created_at FROM tenants WHERE id = ?');
        $st->execute([$tid ?: (int) ($u['tenant_id'] ?? 1)]);
        $t = $st->fetch() ?: [];
        if (!empty($t['cf_app_id_encrypted'])) {
            try {
                $plain = aes_decrypt($t['cf_app_id_encrypted']);
                $t['cf_app_id_masked'] = substr($plain, 0, 4) . str_repeat('*', max(0, strlen($plain) - 4));
            } catch (Throwable $e) {
                $t['cf_app_id_masked'] = '(encrypted)';
            }
            unset($t['cf_app_id_encrypted']);
        }
        $t['has_secret'] = false;
        if ($tid) {
            $raw = db()->prepare('SELECT cf_secret_encrypted FROM tenants WHERE id = ?');
            $raw->execute([$tid]);
            $r = $raw->fetch();
            $t['has_secret'] = !empty($r['cf_secret_encrypted']);
        }
        ok(['tenant' => $t]);
        break;

    case 'tenants':
        require_roles(['master']);
        $rows = db()->query('SELECT id, name, admin_username, payment_mode, created_at FROM tenants ORDER BY id DESC')->fetchAll();
        ok(['tenants' => $rows]);
        break;

    case 'tokens':
        $u = require_roles(['master']);
        require_twofa_if_enabled($u);
        $op = $in['op'] ?? $_GET['op'] ?? 'list';
        if ($op === 'create') {
            require_csrf();
            $raw = strtoupper(bin2hex(random_bytes(5)) . '-' . bin2hex(random_bytes(4)));
            $hash = hash('sha256', $raw);
            $hint = substr($raw, 0, 8);
            $hours = max(1, min(168, (int) ($in['hours'] ?? 72)));
            db()->prepare('INSERT INTO admin_tokens (token_hash, token_hint, created_by, used_by, role, expires_at, used_at, created_at) VALUES (?, ?, ?, NULL, ?, ?, NULL, ?)')
                ->execute([$hash, $hint, (int) $u['id'], 'tenant_admin', date('Y-m-d H:i:s', time() + $hours * 3600), now_sql()]);
            ok(['id' => (int) db()->lastInsertId(), 'token' => $raw, 'hint' => $hint, 'expires_in_hours' => $hours]);
        }
        if ($op === 'revoke') {
            require_csrf();
            $id = (int) ($in['id'] ?? 0);
            db()->prepare('DELETE FROM admin_tokens WHERE id = ? AND used_by IS NULL')->execute([$id]);
            ok(['revoked' => true]);
        }
        $rows = db()->query('SELECT id, token_hint, created_by, used_by, role, expires_at, used_at, created_at FROM admin_tokens ORDER BY id DESC LIMIT 80')->fetchAll();
        ok(['tokens' => $rows]);
        break;

    case 'people':
        $u = require_user();
        require_twofa_if_enabled($u);
        $directory = [];
        if ($u['role'] === 'master') {
            $directory = db()->query("SELECT id, username, role, tenant_id, paid, status FROM users WHERE role IN ('master','tenant_admin') ORDER BY role, username")->fetchAll();
        } elseif ($u['role'] === 'tenant_admin') {
            $st = db()->prepare("SELECT id, username, role, tenant_id, paid, status FROM users WHERE (role IN ('master','tenant_admin') OR tenant_id = ?) AND id != ? ORDER BY role, username");
            $st->execute([(int) $u['tenant_id'], (int) $u['id']]);
            $directory = $st->fetchAll();
        } else {
            $st = db()->prepare("SELECT id, username, role, tenant_id, paid, status FROM users WHERE tenant_id = ? AND id != ? ORDER BY username");
            $st->execute([(int) $u['tenant_id'], (int) $u['id']]);
            $directory = $st->fetchAll();
        }
        ok(['people' => $directory]);
        break;

    default:
        fail('Unknown action', 404);
}
