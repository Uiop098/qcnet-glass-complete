<?php
/**
 * Cashfree V3 dual-mode payments.
 * Global: visitors buy a lifetime dashboard (provisions tenant_admin).
 * Tenant: tenants sell products using AES-256 encrypted API keys.
 * DEMO_PAYMENTS=true simulates PAID without hitting Cashfree (local preview).
 */
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';
ensure_schema();
start_app_session();
rate_limit('pay', RATE_MAX_PAY);

$in = json_input();
$action = $_GET['action'] ?? ($in['action'] ?? '');

function cashfree_base(string $mode): string
{
    return $mode === 'production' ? CASHFREE_PROD_URL : CASHFREE_SANDBOX_URL;
}

function tenant_keys(?int $tenantId): array
{
    if (!$tenantId) {
        return ['app_id' => getenv('CF_APP_ID') ?: '', 'secret' => getenv('CF_SECRET') ?: '', 'mode' => 'sandbox'];
    }
    $st = db()->prepare('SELECT cf_app_id_encrypted, cf_secret_encrypted, payment_mode FROM tenants WHERE id = ?');
    $st->execute([$tenantId]);
    $row = $st->fetch();
    if (!$row) {
        fail('Tenant not found', 404);
    }
    $app = '';
    $sec = '';
    try {
        if (!empty($row['cf_app_id_encrypted'])) {
            $app = aes_decrypt($row['cf_app_id_encrypted']);
        }
        if (!empty($row['cf_secret_encrypted'])) {
            $sec = aes_decrypt($row['cf_secret_encrypted']);
        }
    } catch (Throwable $e) {
        fail('Unable to decrypt payment keys', 500);
    }
    return ['app_id' => $app, 'secret' => $sec, 'mode' => $row['payment_mode'] ?: 'sandbox'];
}

function cashfree_create_order(array $keys, array $order): array
{
    if (DEMO_PAYMENTS || $keys['app_id'] === '' || $keys['secret'] === '') {
        return [
            'demo' => true,
            'payment_session_id' => 'demo_sess_' . bin2hex(random_bytes(8)),
            'order_id' => $order['order_id'],
            'payment_url' => null,
        ];
    }
    $payload = json_encode([
        'order_id' => $order['order_id'],
        'order_amount' => (float) $order['amount'],
        'order_currency' => DASHBOARD_CURRENCY,
        'customer_details' => [
            'customer_id' => $order['customer_id'],
            'customer_email' => $order['email'],
            'customer_phone' => $order['phone'] ?? '9999999999',
        ],
        'order_meta' => [
            'return_url' => $order['return_url'],
        ],
    ]);
    $ch = curl_init(cashfree_base($keys['mode']) . '/orders');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'x-api-version: ' . CASHFREE_API_VERSION,
            'x-client-id: ' . $keys['app_id'],
            'x-client-secret: ' . $keys['secret'],
        ],
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_TIMEOUT => 20,
    ]);
    $raw = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $decoded = json_decode((string) $raw, true);
    if ($code >= 400 || !is_array($decoded)) {
        fail('Cashfree error', 502, ['detail' => is_array($decoded) ? $decoded : ['raw' => substr((string) $raw, 0, 300)]]);
    }
    return $decoded;
}

function credit_admin_paid(int $tenantId): void
{
    $admin = db()->prepare("SELECT id FROM users WHERE tenant_id = ? AND role IN ('tenant_admin', 'master') ORDER BY CASE role WHEN 'tenant_admin' THEN 0 ELSE 1 END LIMIT 1");
    $admin->execute([$tenantId]);
    $adm = $admin->fetch();
    if ($adm) {
        db()->prepare('UPDATE users SET paid = paid + 1 WHERE id = ?')->execute([(int) $adm['id']]);
    }
}

function provision_tenant_from_order(array $orderRow, array $meta): array
{
    $pdo = db();
    $username = sanitize_username((string) ($meta['username'] ?? ('tenant' . $orderRow['id'])));
    $email = sanitize_email((string) ($meta['email'] ?? $orderRow['buyer_email']));
    $password = (string) ($meta['password'] ?? bin2hex(random_bytes(6)) . 'Aa1!');
    $dob = (string) ($meta['dob'] ?? '1995-01-01');

    $pdo->beginTransaction();
    $exist = $pdo->prepare('SELECT id, role FROM users WHERE email = ? OR username = ? LIMIT 1');
    $exist->execute([$email, $username]);
    $user = $exist->fetch();

    $pdo->prepare('INSERT INTO tenants (name, admin_username, payment_mode, created_at) VALUES (?, ?, ?, ?)')
        ->execute([$username . ' Workspace', $username, 'sandbox', now_sql()]);
    $tenantId = (int) $pdo->lastInsertId();

    if ($user) {
        $pdo->prepare('UPDATE users SET tenant_id = ?, role = ? WHERE id = ?')
            ->execute([$tenantId, 'tenant_admin', (int) $user['id']]);
        $uid = (int) $user['id'];
    } else {
        $pdo->prepare('INSERT INTO users (tenant_id, role, username, password_hash, email, dob, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$tenantId, 'tenant_admin', $username, password_hash($password, PASSWORD_BCRYPT), $email, $dob, now_sql()]);
        $uid = (int) $pdo->lastInsertId();
    }
    $pdo->prepare('INSERT INTO chat_rooms (tenant_id, room_name, pin_hash, host_password_hash, created_at) VALUES (?, ?, ?, ?, ?)')
        ->execute([$tenantId, $username . '-hq', password_hash('1234', PASSWORD_BCRYPT), password_hash($password, PASSWORD_BCRYPT), now_sql()]);
    $pdo->prepare('UPDATE orders SET status = ?, tenant_id = ?, user_id = ? WHERE id = ?')
        ->execute(['PAID', $tenantId, $uid, (int) $orderRow['id']]);
    $pdo->commit();

    return ['tenant_id' => $tenantId, 'user_id' => $uid, 'username' => $username, 'temp_password' => $user ? null : $password];
}

switch ($action) {
    case 'catalog':
        ok([
            'dashboard_price' => DASHBOARD_PRICE,
            'currency' => DASHBOARD_CURRENCY,
            'demo' => DEMO_PAYMENTS,
        ]);
        break;

    case 'create_dashboard':
        require_csrf();
        $email = sanitize_email((string) ($in['email'] ?? ''));
        $username = sanitize_username((string) ($in['username'] ?? ''));
        $password = (string) ($in['password'] ?? '');
        if (strlen($password) < 8) {
            fail('Password must be at least 8 characters');
        }
        $orderId = 'DASH' . time() . random_int(100, 999);
        $pdo = db();
        $pdo->prepare('INSERT INTO orders (tenant_id, user_id, amount, status, cashfree_session, cashfree_order_id, kind, product_id, buyer_email, created_at) VALUES (NULL, NULL, ?, ?, ?, ?, ?, NULL, ?, ?)')
            ->execute([DASHBOARD_PRICE, 'CREATED', '', $orderId, 'dashboard', $email, now_sql()]);
        $localId = (int) $pdo->lastInsertId();
        $metaFile = DATA_DIR . '/order_meta_' . $localId . '.json';
        file_put_contents($metaFile, json_encode(['username' => $username, 'email' => $email, 'password' => $password, 'dob' => (string) ($in['dob'] ?? '1995-01-01')]));

        $keys = tenant_keys(null);
        $cf = cashfree_create_order($keys, [
            'order_id' => $orderId,
            'amount' => DASHBOARD_PRICE,
            'customer_id' => 'cust_' . $localId,
            'email' => $email,
            'return_url' => (isset($_SERVER['HTTP_HOST']) ? ((empty($_SERVER['HTTPS']) ? 'http://' : 'https://') . $_SERVER['HTTP_HOST']) : '') . '/pay.html?order=' . $localId,
        ]);
        $session = (string) ($cf['payment_session_id'] ?? '');
        $pdo->prepare('UPDATE orders SET cashfree_session = ? WHERE id = ?')->execute([$session, $localId]);
        ok([
            'order_id' => $localId,
            'cashfree_order_id' => $orderId,
            'payment_session_id' => $session,
            'demo' => !empty($cf['demo']),
            'amount' => DASHBOARD_PRICE,
        ]);
        break;

    case 'create_product':
        require_csrf();
        $u = require_user();
        $productId = (int) ($in['product_id'] ?? 0);
        $st = db()->prepare('SELECT * FROM products WHERE id = ?');
        $st->execute([$productId]);
        $p = $st->fetch();
        if (!$p) {
            fail('Product not found', 404);
        }
        $orderId = 'PRD' . time() . random_int(100, 999);
        db()->prepare('INSERT INTO orders (tenant_id, user_id, amount, status, cashfree_session, cashfree_order_id, kind, product_id, buyer_email, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([(int) $p['tenant_id'], (int) $u['id'], $p['price'], 'CREATED', '', $orderId, 'product', $productId, $u['email'], now_sql()]);
        $localId = (int) db()->lastInsertId();
        $keys = tenant_keys((int) $p['tenant_id']);
        $cf = cashfree_create_order($keys, [
            'order_id' => $orderId,
            'amount' => $p['price'],
            'customer_id' => 'u' . $u['id'],
            'email' => $u['email'],
            'return_url' => '/dashboard/dash_user.html',
        ]);
        $session = (string) ($cf['payment_session_id'] ?? '');
        db()->prepare('UPDATE orders SET cashfree_session = ? WHERE id = ?')->execute([$session, $localId]);
        ok([
            'order_id' => $localId,
            'cashfree_order_id' => $orderId,
            'payment_session_id' => $session,
            'demo' => !empty($cf['demo']),
            'amount' => $p['price'],
        ]);
        break;

    case 'confirm':
        require_csrf();
        $localId = (int) ($in['order_id'] ?? 0);
        $st = db()->prepare('SELECT * FROM orders WHERE id = ?');
        $st->execute([$localId]);
        $order = $st->fetch();
        if (!$order) {
            fail('Order not found', 404);
        }
        if ($order['status'] === 'PAID') {
            ok(['already' => true, 'order' => $order]);
        }

        $paid = DEMO_PAYMENTS;
        if (!$paid && $order['cashfree_order_id']) {
            $tid = $order['kind'] === 'dashboard' ? null : (int) $order['tenant_id'];
            $keys = tenant_keys($tid);
            if ($keys['app_id'] !== '') {
                $ch = curl_init(cashfree_base($keys['mode']) . '/orders/' . rawurlencode($order['cashfree_order_id']));
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HTTPHEADER => [
                        'x-api-version: ' . CASHFREE_API_VERSION,
                        'x-client-id: ' . $keys['app_id'],
                        'x-client-secret: ' . $keys['secret'],
                    ],
                    CURLOPT_TIMEOUT => 20,
                ]);
                $raw = curl_exec($ch);
                curl_close($ch);
                $decoded = json_decode((string) $raw, true);
                $paid = is_array($decoded) && (($decoded['order_status'] ?? '') === 'PAID');
            }
        }
        if (!$paid) {
            fail('Payment not confirmed', 402);
        }

        if ($order['kind'] === 'dashboard') {
            $meta = [];
            $metaFile = DATA_DIR . '/order_meta_' . $localId . '.json';
            if (is_file($metaFile)) {
                $meta = json_decode((string) file_get_contents($metaFile), true) ?: [];
            }
            $prov = provision_tenant_from_order($order, $meta);
            start_app_session();
            $_SESSION['uid'] = $prov['user_id'];
            ok(['paid' => true, 'provision' => $prov]);
        }

        db()->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute(['PAID', $localId]);
        if ($order['kind'] === 'product' && !empty($order['tenant_id'])) {
            credit_admin_paid((int) $order['tenant_id']);
        }
        ok(['paid' => true, 'order_id' => $localId]);
        break;

    case 'webhook':
        $raw = file_get_contents('php://input') ?: '';
        $data = json_decode($raw, true);
        $cfOrder = $data['data']['order']['order_id'] ?? ($data['order_id'] ?? '');
        if ($cfOrder === '') {
            fail('Malformed webhook', 400);
        }
        $st = db()->prepare('SELECT * FROM orders WHERE cashfree_order_id = ?');
        $st->execute([$cfOrder]);
        $order = $st->fetch();
        if ($order && ($data['data']['order']['order_status'] ?? $data['order_status'] ?? '') === 'PAID' && $order['status'] !== 'PAID') {
            if ($order['kind'] === 'dashboard') {
                $metaFile = DATA_DIR . '/order_meta_' . $order['id'] . '.json';
                $meta = is_file($metaFile) ? (json_decode((string) file_get_contents($metaFile), true) ?: []) : [];
                provision_tenant_from_order($order, $meta);
            } else {
                db()->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute(['PAID', (int) $order['id']]);
                if (!empty($order['tenant_id'])) {
                    credit_admin_paid((int) $order['tenant_id']);
                }
            }
        }
        ok(['received' => true]);
        break;

    default:
        fail('Unknown action', 404);
}
