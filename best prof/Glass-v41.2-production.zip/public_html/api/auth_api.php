<?php
/**
 * Unified login, registration, session, TOTP SSO, and admin-token signup.
 * One 2FA verification covers dashboard and QuickChat.
 */
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/includes/totp.php';
ensure_schema();
start_app_session();

$in = json_input();
$action = $_GET['action'] ?? ($in['action'] ?? '');

function purge_twofa_pending(): void
{
    try {
        db()->prepare('DELETE FROM twofa_pending WHERE expires_at < ?')->execute([time()]);
    } catch (Throwable $e) {
    }
}

function stamp_login(int $uid): void
{
    db()->prepare('UPDATE users SET last_login_at = ?, last_login_ip = ? WHERE id = ?')
        ->execute([now_sql(), client_ip(), $uid]);
}

function finalize_login(int $uid, bool $twofaOk = true): array
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $uid;
    $_SESSION['twofa_ok'] = $twofaOk;
    $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    stamp_login($uid);
    $user = current_user();
    return $user ?: fail('Session failed', 500);
}

function consume_admin_token(string $raw): array
{
    $raw = strtoupper(trim($raw));
    if ($raw === '') {
        fail('Admin token required');
    }
    $hash = hash('sha256', $raw);
    $st = db()->prepare('SELECT * FROM admin_tokens WHERE token_hash = ? LIMIT 1');
    $st->execute([$hash]);
    $row = $st->fetch();
    if (!$row) {
        fail('Invalid admin token', 400);
    }
    if (!empty($row['used_by'])) {
        fail('Admin token already used', 400);
    }
    if (strtotime((string) $row['expires_at']) < time()) {
        fail('Admin token expired', 410);
    }
    return $row;
}

function provision_admin_workspace(string $username, string $email, string $hash, string $dob, array $tokenRow): int
{
    $pdo = db();
    $pdo->beginTransaction();
    $pdo->prepare('INSERT INTO tenants (name, admin_username, payment_mode, created_at) VALUES (?, ?, ?, ?)')
        ->execute([$username . ' Workspace', $username, 'sandbox', now_sql()]);
    $tenantId = (int) $pdo->lastInsertId();
    $pdo->prepare('INSERT INTO users (tenant_id, role, username, password_hash, email, dob, status, paid, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([$tenantId, 'tenant_admin', $username, $hash, $email, $dob, 'active', 0, now_sql()]);
    $uid = (int) $pdo->lastInsertId();
    $pdo->prepare('INSERT INTO chat_rooms (tenant_id, room_name, pin_hash, host_password_hash, kind, created_at) VALUES (?, ?, ?, ?, ?, ?)')
        ->execute([$tenantId, $username . '-hq', password_hash('1234', PASSWORD_BCRYPT), $hash, 'room', now_sql()]);
    $pdo->prepare('UPDATE admin_tokens SET used_by = ?, used_at = ? WHERE id = ?')
        ->execute([$uid, now_sql(), (int) $tokenRow['id']]);
    $pdo->commit();
    return $uid;
}

purge_twofa_pending();

switch ($action) {
    case 'csrf':
        ok(['csrf' => csrf_token(), 'user' => current_user() ? public_user(current_user()) : null]);
        break;

    case 'register':
        rate_limit('auth', RATE_MAX_AUTH);
        require_csrf();
        $username = sanitize_username((string) ($in['username'] ?? ''));
        $email = sanitize_email((string) ($in['email'] ?? ''));
        $password = (string) ($in['password'] ?? '');
        $dob = (string) ($in['dob'] ?? '');
        $invite = strtoupper(trim((string) ($in['admin_token'] ?? $in['invite'] ?? '')));
        if (strlen($password) < 8) {
            fail('Password must be at least 8 characters');
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
            fail('Date of birth must be YYYY-MM-DD');
        }
        $pdo = db();
        $chk = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1');
        $chk->execute([$username, $email]);
        if ($chk->fetch()) {
            fail('Username or email already registered');
        }
        $hash = password_hash($password, PASSWORD_BCRYPT);
        if ($invite !== '') {
            $tok = consume_admin_token($invite);
            $uid = provision_admin_workspace($username, $email, $hash, $dob, $tok);
            $user = finalize_login($uid, true);
            ok(['user' => public_user($user), 'csrf' => csrf_token(), 'promoted' => 'tenant_admin']);
        }
        $pdo->prepare('INSERT INTO users (tenant_id, role, username, password_hash, email, dob, status, paid, created_at) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute(['user', $username, $hash, $email, $dob, 'active', 0, now_sql()]);
        $user = finalize_login((int) $pdo->lastInsertId(), true);
        ok(['user' => public_user($user), 'csrf' => csrf_token()]);
        break;

    case 'login':
        rate_limit('auth', RATE_MAX_AUTH);
        require_csrf();
        $ident = trim((string) ($in['username'] ?? $in['email'] ?? ''));
        $password = (string) ($in['password'] ?? '');
        if ($ident === '' || $password === '') {
            fail('Username and password required');
        }
        $st = db()->prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
        $st->execute([$ident, strtolower($ident)]);
        $row = $st->fetch();
        if (!$row || !password_verify($password, $row['password_hash'])) {
            fail('Invalid credentials', 401);
        }
        if (($row['status'] ?? 'active') === 'deactivated') {
            fail('This account has been deactivated. Contact your admin.', 403);
        }
        if ((int) ($row['totp_enabled'] ?? 0) === 1 && !empty($row['totp_secret'])) {
            $token = bin2hex(random_bytes(24));
            db()->prepare('INSERT INTO twofa_pending (token, user_id, expires_at) VALUES (?, ?, ?)')
                ->execute([$token, (int) $row['id'], time() + 300]);
            ok([
                'twofa_required' => true,
                'pending_token' => $token,
                'csrf' => csrf_token(),
            ]);
        }
        $user = finalize_login((int) $row['id'], true);
        ok(['user' => public_user($user), 'csrf' => csrf_token()]);
        break;

    case 'verify_2fa':
        rate_limit('auth', RATE_MAX_AUTH);
        require_csrf();
        $pending = preg_replace('/[^a-f0-9]/', '', (string) ($in['pending_token'] ?? ''));
        $code = trim((string) ($in['code'] ?? ''));
        if ($pending === '' || $code === '') {
            fail('Code and pending token required');
        }
        $st = db()->prepare('SELECT * FROM twofa_pending WHERE token = ? LIMIT 1');
        $st->execute([$pending]);
        $pend = $st->fetch();
        if (!$pend || (int) $pend['expires_at'] < time()) {
            if ($pend) {
                db()->prepare('DELETE FROM twofa_pending WHERE token = ?')->execute([$pending]);
            }
            fail('Session expired. Please log in again.', 410);
        }
        $ust = db()->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $ust->execute([(int) $pend['user_id']]);
        $row = $ust->fetch();
        if (!$row) {
            fail('Account missing', 404);
        }
        $secret = '';
        try {
            $secret = $row['totp_secret'] ? aes_decrypt((string) $row['totp_secret']) : '';
        } catch (Throwable $e) {
            fail('Unable to read authenticator secret', 500);
        }
        $usedRecovery = false;
        if (!totp_verify($secret, $code)) {
            $hashes = json_decode((string) ($row['totp_recovery'] ?? '[]'), true) ?: [];
            if (!totp_consume_recovery($hashes, $code)) {
                fail('Incorrect code', 401);
            }
            $usedRecovery = true;
            db()->prepare('UPDATE users SET totp_recovery = ? WHERE id = ?')
                ->execute([json_encode($hashes), (int) $row['id']]);
        }
        db()->prepare('DELETE FROM twofa_pending WHERE token = ?')->execute([$pending]);
        $user = finalize_login((int) $row['id'], true);
        ok(['user' => public_user($user), 'csrf' => csrf_token(), 'recovery_used' => $usedRecovery]);
        break;

    case 'logout':
        require_csrf();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']);
        }
        session_destroy();
        ok(['logged_out' => true]);
        break;

    case 'me':
        $u = current_user();
        ok(['user' => $u ? public_user($u) : null, 'csrf' => csrf_token()]);
        break;

    case 'password':
        rate_limit('auth', RATE_MAX_AUTH);
        require_csrf();
        $u = require_user();
        require_twofa_if_enabled($u);
        $current = (string) ($in['current'] ?? '');
        $next = (string) ($in['next'] ?? '');
        if (strlen($next) < 8) {
            fail('New password must be at least 8 characters');
        }
        $st = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
        $st->execute([(int) $u['id']]);
        $row = $st->fetch();
        if (!$row || !password_verify($current, $row['password_hash'])) {
            fail('Current password is incorrect', 401);
        }
        db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($next, PASSWORD_BCRYPT), (int) $u['id']]);
        ok(['updated' => true]);
        break;

    default:
        fail('Unknown action', 404);
}
