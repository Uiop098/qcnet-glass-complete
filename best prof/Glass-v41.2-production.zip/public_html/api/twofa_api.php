<?php
/**
 * TOTP setup / disable. One verification unlocks dashboard + QuickChat.
 */
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/includes/totp.php';
ensure_schema();
start_app_session();
rate_limit('auth', RATE_MAX_AUTH);

$in = json_input();
$action = $_GET['action'] ?? ($in['action'] ?? '');
$u = require_user();

switch ($action) {
    case 'status':
        ok([
            'enabled' => (int) ($u['totp_enabled'] ?? 0) === 1,
            'verified' => twofa_session_ok(),
        ]);
        break;

    case 'begin':
        require_csrf();
        if ((int) ($u['totp_enabled'] ?? 0) === 1) {
            fail('Two-factor is already enabled');
        }
        $secret = totp_generate_secret();
        $_SESSION['totp_setup_secret'] = $secret;
        ok([
            'secret' => $secret,
            'otpauth' => totp_otpauth_uri($secret, $u['username']),
            'issuer' => 'Glass v41',
        ]);
        break;

    case 'confirm':
        require_csrf();
        $secret = (string) ($_SESSION['totp_setup_secret'] ?? '');
        $code = trim((string) ($in['code'] ?? ''));
        if ($secret === '') {
            fail('Start setup first');
        }
        if (!totp_verify($secret, $code)) {
            fail('Incorrect authenticator code');
        }
        $codes = totp_generate_recovery_codes(8);
        db()->prepare('UPDATE users SET totp_secret = ?, totp_enabled = 1, totp_recovery = ? WHERE id = ?')
            ->execute([aes_encrypt($secret), json_encode(totp_hash_recovery($codes)), (int) $u['id']]);
        unset($_SESSION['totp_setup_secret']);
        $_SESSION['twofa_ok'] = true;
        ok(['enabled' => true, 'recovery_codes' => $codes]);
        break;

    case 'disable':
        require_csrf();
        $password = (string) ($in['password'] ?? '');
        $code = trim((string) ($in['code'] ?? ''));
        $st = db()->prepare('SELECT password_hash, totp_secret, totp_recovery FROM users WHERE id = ?');
        $st->execute([(int) $u['id']]);
        $row = $st->fetch();
        if (!$row || !password_verify($password, $row['password_hash'])) {
            fail('Password incorrect', 401);
        }
        $secret = '';
        try {
            $secret = $row['totp_secret'] ? aes_decrypt((string) $row['totp_secret']) : '';
        } catch (Throwable $e) {
            fail('Unable to read authenticator secret', 500);
        }
        $okCode = $secret !== '' && totp_verify($secret, $code);
        if (!$okCode) {
            $hashes = json_decode((string) ($row['totp_recovery'] ?? '[]'), true) ?: [];
            $okCode = totp_consume_recovery($hashes, $code);
        }
        if (!$okCode) {
            fail('Incorrect authenticator or recovery code', 401);
        }
        db()->prepare('UPDATE users SET totp_secret = NULL, totp_enabled = 0, totp_recovery = NULL WHERE id = ?')
            ->execute([(int) $u['id']]);
        $_SESSION['twofa_ok'] = true;
        ok(['enabled' => false]);
        break;

    default:
        fail('Unknown action', 404);
}
