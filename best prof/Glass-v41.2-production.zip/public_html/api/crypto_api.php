<?php
/**
 * AES-256-GCM helpers for tenant secrets and optional client round-trip tests.
 */
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';
ensure_schema();
start_app_session();
rate_limit('crypto', RATE_MAX_GENERIC);

$action = $_GET['action'] ?? (json_input()['action'] ?? '');

switch ($action) {
    case 'token':
        ok(['csrf' => csrf_token()]);
        break;
    case 'encrypt':
        require_csrf();
        $u = require_roles(['master', 'tenant_admin']);
        $plain = (string) (json_input()['plain'] ?? '');
        if ($plain === '' || strlen($plain) > 2048) {
            fail('Payload required (max 2048 chars)');
        }
        ok(['cipher' => aes_encrypt($plain)]);
        break;
    case 'decrypt':
        require_csrf();
        require_roles(['master']);
        $cipher = (string) (json_input()['cipher'] ?? '');
        try {
            ok(['plain' => aes_decrypt($cipher)]);
        } catch (Throwable $e) {
            fail('Decrypt failed', 400);
        }
        break;
    default:
        fail('Unknown action', 404);
}
