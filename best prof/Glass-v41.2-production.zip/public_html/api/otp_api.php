<?php
/**
 * 3-step OTP password recovery.
 * 1) Email + DOB  2) 6-digit OTP (3 min TTL, 5 min cooldown)  3) Reset + delete row.
 */
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';
ensure_schema();
start_app_session();
rate_limit('otp', RATE_MAX_OTP);

$in = json_input();
$action = $_GET['action'] ?? ($in['action'] ?? '');

function dispatch_otp_mail(string $email, string $otp): bool
{
    $subject = 'Your QuickChat Glass recovery code';
    $body = "Your one-time password is: $otp\nIt expires in 3 minutes.\nIf you did not request this, ignore this email.";
    $headers = 'From: noreply@glass.local' . "\r\n" . 'Content-Type: text/plain; charset=utf-8';
    $sent = @mail($email, $subject, $body, $headers);
    $log = DATA_DIR . '/otp_outbox.log';
    file_put_contents($log, date('c') . " $email $otp sent=" . ($sent ? '1' : '0') . "\n", FILE_APPEND);
    return $sent;
}

switch ($action) {
    case 'request':
        require_csrf();
        $email = sanitize_email((string) ($in['email'] ?? ''));
        $dob = (string) ($in['dob'] ?? '');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
            fail('Date of birth must be YYYY-MM-DD');
        }
        $st = db()->prepare('SELECT id FROM users WHERE email = ? AND dob = ? LIMIT 1');
        $st->execute([$email, $dob]);
        if (!$st->fetch()) {
            fail('No matching account for that email and date of birth', 404);
        }
        $exist = db()->prepare('SELECT cooldown_until FROM otp_recovery WHERE email = ? ORDER BY id DESC LIMIT 1');
        $exist->execute([$email]);
        $prev = $exist->fetch();
        if ($prev && strtotime((string) $prev['cooldown_until']) > time()) {
            fail('Please wait before requesting another code', 429);
        }
        $otp = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $expires = date('Y-m-d H:i:s', time() + OTP_TTL_SECONDS);
        $cool = date('Y-m-d H:i:s', time() + OTP_COOLDOWN_SECONDS);
        db()->prepare('DELETE FROM otp_recovery WHERE email = ?')->execute([$email]);
        db()->prepare('INSERT INTO otp_recovery (email, dob, otp_code, expires_at, cooldown_until) VALUES (?, ?, ?, ?, ?)')
            ->execute([$email, $dob, $otp, $expires, $cool]);
        dispatch_otp_mail($email, $otp);
        $payload = ['dispatched' => true, 'expires_in' => OTP_TTL_SECONDS];
        if (DEMO_PAYMENTS) {
            $payload['demo_otp'] = $otp;
        }
        ok($payload);
        break;

    case 'verify':
        require_csrf();
        $email = sanitize_email((string) ($in['email'] ?? ''));
        $otp = preg_replace('/\D/', '', (string) ($in['otp'] ?? ''));
        $password = (string) ($in['password'] ?? '');
        if (strlen($otp) !== 6) {
            fail('OTP must be 6 digits');
        }
        if (strlen($password) < 8) {
            fail('Password must be at least 8 characters');
        }
        $st = db()->prepare('SELECT * FROM otp_recovery WHERE email = ? AND otp_code = ? LIMIT 1');
        $st->execute([$email, $otp]);
        $row = $st->fetch();
        if (!$row) {
            fail('Invalid OTP', 400);
        }
        if (strtotime((string) $row['expires_at']) < time()) {
            db()->prepare('DELETE FROM otp_recovery WHERE id = ?')->execute([(int) $row['id']]);
            fail('OTP expired', 410);
        }
        db()->prepare('UPDATE users SET password_hash = ? WHERE email = ?')
            ->execute([password_hash($password, PASSWORD_BCRYPT), $email]);
        db()->prepare('DELETE FROM otp_recovery WHERE email = ?')->execute([$email]);
        ok(['reset' => true]);
        break;

    default:
        fail('Unknown action', 404);
}
