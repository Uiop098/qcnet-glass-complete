<?php
/**
 * QuickChat: send/receive, reactions, polls.
 * Opportunistic purge: DELETE expired messages on every request (no CRON).
 * Client may send AES-GCM ciphertext in message_text.
 */
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';
ensure_schema();
start_app_session();
rate_limit('chat', RATE_MAX_CHAT);

$in = json_input();
$action = $_GET['action'] ?? ($in['action'] ?? '');

function purge_expired(): void
{
    try {
        db()->exec("DELETE FROM chat_messages WHERE expires_at < '" . now_sql() . "'");
        if (random_int(1, 40) === 1) {
            db()->exec("DELETE FROM chat_reactions WHERE message_id NOT IN (SELECT id FROM chat_messages)");
        }
    } catch (Throwable $e) {
    }
}

function is_super(?array $u): bool
{
    return $u && in_array($u['role'], ['master', 'tenant_admin'], true);
}

function room_by_id(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM chat_rooms WHERE id = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

function can_access_room(int $roomId, ?array $u): bool
{
    if ($_SESSION['chat_rooms'][$roomId]['joined'] ?? false) {
        return true;
    }
    if (is_super($u)) {
        return true;
    }
    $room = room_by_id($roomId);
    if (!$room || !$u) {
        return false;
    }
    return ($room['kind'] ?? '') === 'dm' && in_array((int) $u['id'], [(int) ($room['peer_a'] ?? 0), (int) ($room['peer_b'] ?? 0)], true);
}

purge_expired();

switch ($action) {
    case 'rooms':
        $u = current_user();
        $sql = "SELECT id, tenant_id, room_name, kind, peer_a, peer_b, created_at FROM chat_rooms WHERE kind = 'room' OR kind IS NULL OR kind = '' ORDER BY id DESC LIMIT 80";
        $rows = db()->query($sql)->fetchAll();
        foreach ($rows as &$r) {
            $r['locked'] = true;
            $r['super_access'] = is_super($u);
        }
        $dms = [];
        $inbox = [];
        if ($u) {
            $dst = db()->prepare("SELECT id, room_name, peer_a, peer_b, created_at FROM chat_rooms WHERE kind = 'dm' AND (peer_a = ? OR peer_b = ?) ORDER BY id DESC");
            $dst->execute([(int) $u['id'], (int) $u['id']]);
            $dms = $dst->fetchAll();
            $rst = db()->prepare('SELECT r.id, r.from_id, r.to_id, r.token_hint, r.status, r.room_id, r.expires_at, r.created_at, u.username AS from_username FROM chat_requests r JOIN users u ON u.id = r.from_id WHERE (r.to_id = ? OR r.from_id = ?) ORDER BY r.id DESC LIMIT 40');
            $rst->execute([(int) $u['id'], (int) $u['id']]);
            $inbox = $rst->fetchAll();
        }
        ok(['rooms' => $rows, 'dms' => $dms, 'requests' => $inbox, 'super' => is_super($u)]);
        break;

    case 'create_room':
        require_csrf();
        $u = require_user();
        $name = trim((string) ($in['room_name'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9._-]{3,32}$/', $name)) {
            fail('Room name: 3-32 chars, letters/numbers/._-');
        }
        $pin = (string) ($in['pin'] ?? '');
        $host = (string) ($in['host_password'] ?? '');
        if (strlen($pin) < 4) {
            fail('PIN must be at least 4 characters');
        }
        if (strlen($host) < 6) {
            fail('Host password must be at least 6 characters');
        }
        $exists = db()->prepare('SELECT id FROM chat_rooms WHERE room_name = ?');
        $exists->execute([$name]);
        if ($exists->fetch()) {
            fail('Room name already taken');
        }
        db()->prepare('INSERT INTO chat_rooms (tenant_id, room_name, pin_hash, host_password_hash, kind, created_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([
                $u['tenant_id'] !== null ? (int) $u['tenant_id'] : null,
                $name,
                password_hash($pin, PASSWORD_BCRYPT),
                password_hash($host, PASSWORD_BCRYPT),
                'room',
                now_sql(),
            ]);
        ok(['id' => (int) db()->lastInsertId()]);
        break;

    case 'join':
        require_csrf();
        $roomId = (int) ($in['room_id'] ?? 0);
        $pin = (string) ($in['pin'] ?? '');
        $room = room_by_id($roomId);
        if (!$room) {
            fail('Room not found', 404);
        }
        $u = current_user();
        $host = false;
        $isDmPeer = $u && ($room['kind'] ?? '') === 'dm' && in_array((int) $u['id'], [(int) ($room['peer_a'] ?? 0), (int) ($room['peer_b'] ?? 0)], true);
        if (!empty($in['host_password']) && password_verify((string) $in['host_password'], $room['host_password_hash'])) {
            $host = true;
        }
        if (!$isDmPeer && !is_super($u) && !$host) {
            if ($room['pin_hash'] !== '' && !password_verify($pin, $room['pin_hash'])) {
                fail('Invalid room PIN', 403);
            }
        }
        start_app_session();
        $_SESSION['chat_rooms'] = $_SESSION['chat_rooms'] ?? [];
        $_SESSION['chat_rooms'][$roomId] = [
            'joined' => true,
            'host' => $host || is_super($u) || $isDmPeer,
            'at' => time(),
        ];
        $nick = $u['username'] ?? trim((string) ($in['nickname'] ?? ''));
        if ($nick === '') {
            fail('Nickname required');
        }
        $_SESSION['chat_nick'] = substr(preg_replace('/[^A-Za-z0-9._-]/', '', $nick) ?: 'guest', 0, 32);
        ok([
            'room' => ['id' => (int) $room['id'], 'name' => $room['room_name']],
            'host' => $host || is_super($u) || $isDmPeer,
            'super' => is_super($u),
            'nick' => $_SESSION['chat_nick'],
        ]);
        break;

    case 'messages':
        $roomId = (int) ($in['room_id'] ?? $_GET['room_id'] ?? 0);
        $after = (int) ($in['after'] ?? $_GET['after'] ?? 0);
        start_app_session();
        $u = current_user();
        if (!can_access_room($roomId, $u)) {
            fail('Join the room first', 403);
        }
        $st = db()->prepare('SELECT id, room_id, sender_username, message_text, media_url, msg_type, extra, expires_at FROM chat_messages WHERE room_id = ? AND id > ? ORDER BY id ASC LIMIT 80');
        $st->execute([$roomId, $after]);
        $msgs = $st->fetchAll();
        $ids = array_column($msgs, 'id');
        $reactions = [];
        if ($ids) {
            $ph = implode(',', array_fill(0, count($ids), '?'));
            $rst = db()->prepare("SELECT message_id, emoji, COUNT(*) c FROM chat_reactions WHERE message_id IN ($ph) GROUP BY message_id, emoji");
            $rst->execute($ids);
            foreach ($rst->fetchAll() as $r) {
                $reactions[(int) $r['message_id']][] = ['emoji' => $r['emoji'], 'count' => (int) $r['c']];
            }
        }
        foreach ($msgs as &$m) {
            $m['reactions'] = $reactions[(int) $m['id']] ?? [];
            if (!empty($m['extra'])) {
                $m['extra'] = json_decode($m['extra'], true);
            }
        }
        ok(['messages' => $msgs, 'server_time' => now_sql()]);
        break;

    case 'send':
        require_csrf();
        $roomId = (int) ($in['room_id'] ?? 0);
        start_app_session();
        $u = current_user();
        if (!can_access_room($roomId, $u)) {
            fail('Join the room first', 403);
        }
        $text = (string) ($in['message_text'] ?? '');
        if (strlen($text) > MAX_MESSAGE_BYTES) {
            fail('Message too large');
        }
        $type = (string) ($in['msg_type'] ?? 'text');
        if (!in_array($type, ['text', 'media', 'poll', 'audio'], true)) {
            $type = 'text';
        }
        if ($text === '' && $type === 'text') {
            fail('Empty message');
        }
        $nick = $_SESSION['chat_nick'] ?? ($u['username'] ?? 'guest');
        $extra = $in['extra'] ?? null;
        $expires = sql_now_plus_hours(CHAT_TTL_HOURS);
        db()->prepare('INSERT INTO chat_messages (room_id, sender_username, message_text, media_url, msg_type, extra, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([
                $roomId,
                $nick,
                $text,
                substr((string) ($in['media_url'] ?? ''), 0, 255),
                $type,
                $extra ? json_encode($extra) : null,
                $expires,
            ]);
        ok(['id' => (int) db()->lastInsertId(), 'expires_at' => $expires]);
        break;

    case 'react':
        require_csrf();
        $msgId = (int) ($in['message_id'] ?? 0);
        $emoji = substr((string) ($in['emoji'] ?? ''), 0, 8);
        if ($emoji === '' || $msgId < 1) {
            fail('message_id and emoji required');
        }
        $u = current_user();
        $nick = $_SESSION['chat_nick'] ?? ($u['username'] ?? 'guest');
        $chk = db()->prepare('SELECT id FROM chat_reactions WHERE message_id = ? AND username = ? AND emoji = ?');
        $chk->execute([$msgId, $nick, $emoji]);
        if ($chk->fetch()) {
            db()->prepare('DELETE FROM chat_reactions WHERE message_id = ? AND username = ? AND emoji = ?')->execute([$msgId, $nick, $emoji]);
            ok(['toggled' => 'off']);
        }
        db()->prepare('INSERT INTO chat_reactions (message_id, username, emoji, created_at) VALUES (?, ?, ?, ?)')
            ->execute([$msgId, $nick, $emoji, now_sql()]);
        ok(['toggled' => 'on']);
        break;

    case 'poll_vote':
        require_csrf();
        $msgId = (int) ($in['message_id'] ?? 0);
        $option = (int) ($in['option'] ?? -1);
        $st = db()->prepare('SELECT extra FROM chat_messages WHERE id = ? AND msg_type = ?');
        $st->execute([$msgId, 'poll']);
        $row = $st->fetch();
        if (!$row) {
            fail('Poll not found', 404);
        }
        $extra = json_decode((string) $row['extra'], true) ?: ['options' => [], 'votes' => []];
        $u = current_user();
        $nick = $_SESSION['chat_nick'] ?? ($u['username'] ?? 'guest');
        $extra['votes'][$nick] = $option;
        db()->prepare('UPDATE chat_messages SET extra = ? WHERE id = ?')->execute([json_encode($extra), $msgId]);
        ok(['votes' => $extra['votes']]);
        break;

    case 'upload':
        require_csrf();
        if (empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
            fail('No file');
        }
        if ($_FILES['file']['size'] > MAX_MEDIA_BYTES) {
            fail('File exceeds 500 KB (inode/bandwidth guard)');
        }
        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['png', 'jpg', 'jpeg', 'gif', 'webp', 'mp3', 'wav', 'ogg', 'webm'], true)) {
            fail('Unsupported file type');
        }
        $name = bin2hex(random_bytes(8)) . '.' . $ext;
        $dest = UPLOAD_DIR . '/' . $name;
        if (!move_uploaded_file($_FILES['file']['tmp_name'], $dest)) {
            fail('Upload failed', 500);
        }
        ok(['url' => '/uploads/' . $name]);
        break;

    case 'dm_open':
        require_csrf();
        $u = require_user();
        require_twofa_if_enabled($u);
        if (!is_super($u)) {
            fail('Only administrators can open direct messages', 403);
        }
        $peerId = (int) ($in['user_id'] ?? 0);
        if ($peerId < 1 || $peerId === (int) $u['id']) {
            fail('Choose another account');
        }
        $peer = db()->prepare('SELECT id, username, role FROM users WHERE id = ?');
        $peer->execute([$peerId]);
        $p = $peer->fetch();
        if (!$p) {
            fail('User not found', 404);
        }
        $a = min((int) $u['id'], $peerId);
        $b = max((int) $u['id'], $peerId);
        $exist = db()->prepare("SELECT * FROM chat_rooms WHERE kind = 'dm' AND peer_a = ? AND peer_b = ? LIMIT 1");
        $exist->execute([$a, $b]);
        $room = $exist->fetch();
        if (!$room) {
            $rname = 'dm-' . $a . '-' . $b;
            db()->prepare('INSERT INTO chat_rooms (tenant_id, room_name, pin_hash, host_password_hash, kind, peer_a, peer_b, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([
                    $u['tenant_id'] !== null ? (int) $u['tenant_id'] : null,
                    $rname,
                    '',
                    password_hash(bin2hex(random_bytes(8)), PASSWORD_BCRYPT),
                    'dm',
                    $a,
                    $b,
                    now_sql(),
                ]);
            $roomId = (int) db()->lastInsertId();
            $room = room_by_id($roomId);
        }
        $_SESSION['chat_rooms'] = $_SESSION['chat_rooms'] ?? [];
        $_SESSION['chat_rooms'][(int) $room['id']] = ['joined' => true, 'host' => true, 'at' => time()];
        $_SESSION['chat_nick'] = $u['username'];
        ok([
            'room' => ['id' => (int) $room['id'], 'name' => $room['room_name'], 'peer' => $p['username']],
            'nick' => $u['username'],
        ]);
        break;

    case 'request_chat':
        require_csrf();
        $u = require_user();
        require_twofa_if_enabled($u);
        $toId = (int) ($in['user_id'] ?? 0);
        if ($toId < 1 || $toId === (int) $u['id']) {
            fail('Choose another account');
        }
        $peer = db()->prepare('SELECT id, username FROM users WHERE id = ?');
        $peer->execute([$toId]);
        if (!$peer->fetch()) {
            fail('User not found', 404);
        }
        $raw = strtoupper(bin2hex(random_bytes(4)) . '-' . bin2hex(random_bytes(3)));
        $hash = hash('sha256', $raw);
        db()->prepare('INSERT INTO chat_requests (from_id, to_id, token_hash, token_hint, status, room_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?, NULL, ?, ?)')
            ->execute([(int) $u['id'], $toId, $hash, substr($raw, 0, 8), 'pending', date('Y-m-d H:i:s', time() + 86400), now_sql()]);
        ok(['id' => (int) db()->lastInsertId(), 'token' => $raw, 'hint' => substr($raw, 0, 8)]);
        break;

    case 'verify_chat':
        require_csrf();
        $u = require_user();
        require_twofa_if_enabled($u);
        $raw = strtoupper(trim((string) ($in['token'] ?? '')));
        if ($raw === '') {
            fail('Chat token required');
        }
        $st = db()->prepare("SELECT * FROM chat_requests WHERE token_hash = ? AND status = 'pending' LIMIT 1");
        $st->execute([hash('sha256', $raw)]);
        $req = $st->fetch();
        if (!$req) {
            fail('Invalid or used chat token', 400);
        }
        if ((int) $req['to_id'] !== (int) $u['id']) {
            fail('This token was issued to a different account', 403);
        }
        if (strtotime((string) $req['expires_at']) < time()) {
            db()->prepare("UPDATE chat_requests SET status = 'expired' WHERE id = ?")->execute([(int) $req['id']]);
            fail('Chat token expired', 410);
        }
        $a = min((int) $req['from_id'], (int) $u['id']);
        $b = max((int) $req['from_id'], (int) $u['id']);
        $exist = db()->prepare("SELECT * FROM chat_rooms WHERE kind = 'dm' AND peer_a = ? AND peer_b = ? LIMIT 1");
        $exist->execute([$a, $b]);
        $room = $exist->fetch();
        if (!$room) {
            $rname = 'peer-' . $a . '-' . $b;
            db()->prepare('INSERT INTO chat_rooms (tenant_id, room_name, pin_hash, host_password_hash, kind, peer_a, peer_b, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([
                    $u['tenant_id'] !== null ? (int) $u['tenant_id'] : null,
                    $rname,
                    '',
                    password_hash(bin2hex(random_bytes(8)), PASSWORD_BCRYPT),
                    'dm',
                    $a,
                    $b,
                    now_sql(),
                ]);
            $room = room_by_id((int) db()->lastInsertId());
        }
        db()->prepare("UPDATE chat_requests SET status = 'accepted', room_id = ? WHERE id = ?")
            ->execute([(int) $room['id'], (int) $req['id']]);
        $_SESSION['chat_rooms'] = $_SESSION['chat_rooms'] ?? [];
        $_SESSION['chat_rooms'][(int) $room['id']] = ['joined' => true, 'host' => true, 'at' => time()];
        $_SESSION['chat_nick'] = $u['username'];
        ok(['room' => ['id' => (int) $room['id'], 'name' => $room['room_name']], 'nick' => $u['username']]);
        break;

    default:
        fail('Unknown action', 404);
}
