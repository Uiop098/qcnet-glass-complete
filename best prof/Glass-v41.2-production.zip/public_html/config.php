<?php
/**
 * Universal Business Dashboard & QuickChat Glass v41
 * PDO connection, environment, and cryptographic constants.
 *
 * InfinityFree: set DB_DRIVER=mysql and fill credentials.
 * Local preview: SQLite under /data (no MySQL required).
 */
declare(strict_types=1);

if (defined('UBD_CONFIG_LOADED')) {
    return;
}
define('UBD_CONFIG_LOADED', true);

date_default_timezone_set('UTC');

define('APP_NAME', 'QuickChat Glass v41');
define('APP_VERSION', '41.2.0');
define('PUBLIC_DIR', __DIR__);
define('ROOT_DIR', dirname(__DIR__));
define('UPLOAD_DIR', PUBLIC_DIR . '/uploads');

$local = PUBLIC_DIR . '/config.local.php';
if (is_file($local)) {
    require $local;
}

$parentData = ROOT_DIR . '/data';
$webData = PUBLIC_DIR . '/data';
if (defined('UBD_DATA_DIR')) {
    define('DATA_DIR', UBD_DATA_DIR);
} elseif (is_dir($parentData) && is_writable($parentData)) {
    define('DATA_DIR', $parentData);
} else {
    define('DATA_DIR', $webData);
}

if (!is_dir(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

/* --- Database --- */
define('DB_DRIVER', getenv('DB_DRIVER') ?: 'sqlite');
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'ubd_v41');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');
define('SQLITE_PATH', DATA_DIR . '/app.db');

/**
 * AES-256 master key (32 bytes). On InfinityFree, set APP_KEY in the environment.
 * Used for tenant Cashfree credentials at rest. Never log this value.
 */
$appKey = getenv('APP_KEY') ?: 'v41-glass-aes256-key-32bytes!!';
if (strlen($appKey) < 32) {
    $appKey = str_pad($appKey, 32, '0');
}
define('APP_KEY', substr($appKey, 0, 32));

define('SESSION_NAME', 'UBDSESSID');
define('SESSION_LIFETIME', 86400);
define('CSRF_TOKEN_NAME', 'csrf_token');

define('OTP_TTL_SECONDS', 180);
define('OTP_COOLDOWN_SECONDS', 300);
define('CHAT_TTL_HOURS', 24);
define('CHAT_POLL_INTERVAL_MS', 4000);
define('MAX_MESSAGE_BYTES', 4096);
define('MAX_MEDIA_BYTES', 512000);

define('RATE_WINDOW_SECONDS', 60);
define('RATE_MAX_AUTH', 20);
define('RATE_MAX_CHAT', 90);
define('RATE_MAX_PAY', 15);
define('RATE_MAX_OTP', 5);
define('RATE_MAX_GENERIC', 60);

define('DASHBOARD_PRICE', '499.00');
define('DASHBOARD_CURRENCY', 'INR');
define('CASHFREE_API_VERSION', '2023-08-01');
define('CASHFREE_SANDBOX_URL', 'https://sandbox.cashfree.com/pg');
define('CASHFREE_PROD_URL', 'https://api.cashfree.com/pg');

define('MASTER_USERNAME', 'master');
define('MASTER_EMAIL', 'master@glass.local');
define('MASTER_PASSWORD', 'Glassv41!Master');
define('MASTER_DOB', '1990-01-01');

if (!defined('DEMO_PAYMENTS')) {
    define('DEMO_PAYMENTS', true);
}
