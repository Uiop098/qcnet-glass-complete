<?php
/**
 * PHP built-in server router for local preview.
 * php -S 0.0.0.0:8080 -t public_html public_html/router.php
 */
declare(strict_types=1);

$uri = urldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
$base = __DIR__;
$path = $base . $uri;

if ($uri !== '/' && is_file($path)) {
    return false;
}
if ($uri === '/' || $uri === '') {
    header('Location: /gateway.html');
    exit;
}
http_response_code(404);
header('Content-Type: text/plain');
echo 'Not found';
