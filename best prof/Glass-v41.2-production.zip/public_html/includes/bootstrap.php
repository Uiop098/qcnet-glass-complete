<?php
/**
 * Shared bootstrap: PDO, sessions, CSRF, rate limits, JSON helpers.
 */
declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';

if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-XSS-Protection: 1; mode=block');
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    if (DB_DRIVER === 'mysql') {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } else {
        $pdo = new PDO('sqlite:' . SQLITE_PATH, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA journal_mode = WAL');
    }
    return $pdo;
}

function is_sqlite(): bool
{
    return DB_DRIVER !== 'mysql';
}

function now_sql(): string
{
    return date('Y-m-d H:i:s');
}

function json_input(): array
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $raw = file_get_contents('php://input') ?: '';
    if ($raw === '') {
        $cached = $_POST ?: [];
        return $cached;
    }
    $decoded = json_decode($raw, true);
    $cached = is_array($decoded) ? $decoded : [];
    return $cached;
}

function json_out(array $payload, int $code = 200): void
{
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fail(string $message, int $code = 400, array $extra = []): void
{
    json_out(array_merge(['ok' => false, 'error' => $message], $extra), $code);
}

function ok(array $data = [], int $code = 200): void
{
    json_out(array_merge(['ok' => true], $data), $code);
}

function client_ip(): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return substr(preg_replace('/[^0-9a-fA-F:.]/', '', $ip) ?: '0.0.0.0', 0, 45);
}

function start_app_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    ]);
    session_start();
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
}

function csrf_token(): string
{
    start_app_session();
    return (string) $_SESSION[CSRF_TOKEN_NAME];
}

function require_csrf(): void
{
    start_app_session();
    $hdr = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    $body = json_input();
    $token = $hdr !== '' ? $hdr : (string) ($body['csrf'] ?? ($_POST['csrf'] ?? ''));
    if ($token === '' || !hash_equals((string) $_SESSION[CSRF_TOKEN_NAME], $token)) {
        fail('Invalid CSRF token', 403);
    }
}

function current_user(): ?array
{
    start_app_session();
    if (empty($_SESSION['uid'])) {
        return null;
    }
    $st = db()->prepare('SELECT id, tenant_id, role, username, email, dob, status, paid, totp_enabled, last_login_at, created_at FROM users WHERE id = ? LIMIT 1');
    $st->execute([(int) $_SESSION['uid']]);
    $row = $st->fetch();
    if (!$row) {
        return null;
    }
    $row['chat_super'] = in_array($row['role'], ['master', 'tenant_admin'], true);
    $row['twofa_verified'] = !empty($_SESSION['twofa_ok']);
    $row['twofa_required'] = ((int) ($row['totp_enabled'] ?? 0) === 1) && empty($_SESSION['twofa_ok']);
    return $row;
}

function require_user(): array
{
    $u = current_user();
    if (!$u) {
        fail('Authentication required', 401);
    }
    if (($u['status'] ?? 'active') === 'deactivated') {
        fail('Account deactivated. Contact your administrator.', 403);
    }
    return $u;
}

function twofa_session_ok(): bool
{
    start_app_session();
    return !empty($_SESSION['twofa_ok']);
}

function require_twofa_if_enabled(array $u): void
{
    if ((int) ($u['totp_enabled'] ?? 0) === 1 && empty($_SESSION['twofa_ok'])) {
        fail('Two-factor verification required', 403, ['twofa_required' => true]);
    }
}

function require_roles(array $roles): array
{
    $u = require_user();
    if (!in_array($u['role'], $roles, true)) {
        fail('Insufficient permissions', 403);
    }
    return $u;
}

function aes_encrypt(string $plain): string
{
    $iv = random_bytes(12);
    $tag = '';
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', APP_KEY, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
    if ($cipher === false) {
        throw new RuntimeException('AES encrypt failed');
    }
    return base64_encode($iv . $tag . $cipher);
}

function aes_decrypt(string $blob): string
{
    $raw = base64_decode($blob, true);
    if ($raw === false || strlen($raw) < 29) {
        throw new RuntimeException('AES decrypt failed');
    }
    $iv = substr($raw, 0, 12);
    $tag = substr($raw, 12, 16);
    $cipher = substr($raw, 28);
    $plain = openssl_decrypt($cipher, 'aes-256-gcm', APP_KEY, OPENSSL_RAW_DATA, $iv, $tag);
    if ($plain === false) {
        throw new RuntimeException('AES decrypt failed');
    }
    return $plain;
}

function rate_limit(string $bucket, int $max): void
{
    $ip = client_ip();
    $window = (int) floor(time() / RATE_WINDOW_SECONDS);
    $key = $bucket . '|' . $ip . '|' . $window;
    $pdo = db();

    try {
        $st = $pdo->prepare('SELECT hits FROM rate_limits WHERE bucket_key = ? LIMIT 1');
        $st->execute([$key]);
        $row = $st->fetch();
        if ($row) {
            if ((int) $row['hits'] >= $max) {
                fail('Rate limit exceeded. Retry shortly.', 429);
            }
            $up = $pdo->prepare('UPDATE rate_limits SET hits = hits + 1 WHERE bucket_key = ?');
            $up->execute([$key]);
        } else {
            $ins = $pdo->prepare('INSERT INTO rate_limits (bucket_key, hits, window_start) VALUES (?, 1, ?)');
            $ins->execute([$key, $window]);
        }
    } catch (Throwable $e) {
        // Table may not exist before setup; skip silently.
    }

    if (random_int(1, 25) === 1) {
        try {
            $cut = (int) floor(time() / RATE_WINDOW_SECONDS) - 3;
            $pdo->prepare('DELETE FROM rate_limits WHERE window_start < ?')->execute([$cut]);
        } catch (Throwable $e) {
        }
    }
}

function sanitize_username(string $name): string
{
    $name = trim($name);
    if (!preg_match('/^[A-Za-z0-9._-]{3,32}$/', $name)) {
        fail('Username must be 3-32 chars: letters, numbers, . _ -');
    }
    return $name;
}

function sanitize_email(string $email): string
{
    $email = strtolower(trim($email));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fail('Invalid email address');
    }
    return $email;
}

function sql_now_plus_hours(int $hours): string
{
    return date('Y-m-d H:i:s', time() + ($hours * 3600));
}

function table_exists(string $name): bool
{
    $pdo = db();
    if (is_sqlite()) {
        $st = $pdo->prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?");
        $st->execute([$name]);
        return (bool) $st->fetch();
    }
    $st = $pdo->prepare('SHOW TABLES LIKE ?');
    $st->execute([$name]);
    return (bool) $st->fetch();
}

function ensure_schema(): void
{
    if (!table_exists('users')) {
        require_once PUBLIC_DIR . '/setup.php';
        run_setup(false);
        return;
    }
    if (!table_exists('admin_tokens') || !column_exists_safe('users', 'totp_enabled')) {
        require_once PUBLIC_DIR . '/setup.php';
        run_setup(false);
    }
}

function column_exists_safe(string $table, string $column): bool
{
    try {
        if (is_sqlite()) {
            $st = db()->query('PRAGMA table_info(' . $table . ')');
            foreach ($st->fetchAll() as $row) {
                if (($row['name'] ?? '') === $column) {
                    return true;
                }
            }
            return false;
        }
        $st = db()->prepare('SHOW COLUMNS FROM `' . str_replace('`', '', $table) . '` LIKE ?');
        $st->execute([$column]);
        return (bool) $st->fetch();
    } catch (Throwable $e) {
        return false;
    }
}

function public_user(array $row): array
{
    return [
        'id' => (int) $row['id'],
        'tenant_id' => $row['tenant_id'] !== null ? (int) $row['tenant_id'] : null,
        'role' => $row['role'],
        'username' => $row['username'],
        'email' => $row['email'] ?? '',
        'dob' => $row['dob'] ?? '',
        'status' => $row['status'] ?? 'active',
        'paid' => (int) ($row['paid'] ?? 0),
        'totp_enabled' => (int) ($row['totp_enabled'] ?? 0),
        'chat_super' => in_array($row['role'], ['master', 'tenant_admin'], true),
        'twofa_verified' => !empty($_SESSION['twofa_ok']),
        'created_at' => $row['created_at'] ?? '',
    ];
}
