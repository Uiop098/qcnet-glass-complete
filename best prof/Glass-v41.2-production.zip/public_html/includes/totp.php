<?php
/**
 * RFC 6238 TOTP in pure PHP (HMAC-SHA1). No Composer.
 * Compatible with Google Authenticator, Authy, 1Password.
 */
declare(strict_types=1);

const TOTP_SECRET_BYTES = 20;
const TOTP_PERIOD = 30;
const TOTP_DIGITS = 6;
const TOTP_WINDOW = 1;

function totp_base32_encode(string $data): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split($data) as $c) {
        $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    }
    $output = '';
    foreach (str_split($bits, 5) as $chunk) {
        $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
        $output .= $alphabet[bindec($chunk)];
    }
    return $output;
}

function totp_base32_decode(string $b32): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Z2-7]/', '', $b32) ?? '');
    $bits = '';
    foreach (str_split($b32) as $c) {
        $pos = strpos($alphabet, $c);
        if ($pos === false) {
            continue;
        }
        $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) === 8) {
            $bytes .= chr(bindec($byte));
        }
    }
    return $bytes;
}

function totp_generate_secret(): string
{
    return totp_base32_encode(random_bytes(TOTP_SECRET_BYTES));
}

function totp_code(string $base32Secret, ?int $timestamp = null): string
{
    $timestamp = $timestamp ?? time();
    $key = totp_base32_decode($base32Secret);
    $counter = intdiv($timestamp, TOTP_PERIOD);
    $counterBytes = pack('N*', 0, $counter);
    $hash = hash_hmac('sha1', $counterBytes, $key, true);
    $offset = ord($hash[strlen($hash) - 1]) & 0x0F;
    $binary = ((ord($hash[$offset]) & 0x7F) << 24)
        | ((ord($hash[$offset + 1]) & 0xFF) << 16)
        | ((ord($hash[$offset + 2]) & 0xFF) << 8)
        | (ord($hash[$offset + 3]) & 0xFF);
    return str_pad((string) ($binary % (10 ** TOTP_DIGITS)), TOTP_DIGITS, '0', STR_PAD_LEFT);
}

function totp_verify(string $base32Secret, string $code, int $window = TOTP_WINDOW): bool
{
    $code = preg_replace('/\s+/', '', $code) ?? '';
    if (!preg_match('/^\d{' . TOTP_DIGITS . '}$/', $code)) {
        return false;
    }
    $now = time();
    for ($i = -$window; $i <= $window; $i++) {
        if (hash_equals(totp_code($base32Secret, $now + ($i * TOTP_PERIOD)), $code)) {
            return true;
        }
    }
    return false;
}

function totp_otpauth_uri(string $base32Secret, string $accountLabel, string $issuer = 'Glass v41'): string
{
    $label = rawurlencode($issuer . ':' . $accountLabel);
    $params = http_build_query([
        'secret' => $base32Secret,
        'issuer' => $issuer,
        'digits' => TOTP_DIGITS,
        'period' => TOTP_PERIOD,
    ], '', '&', PHP_QUERY_RFC3986);
    return "otpauth://totp/{$label}?{$params}";
}

function totp_generate_recovery_codes(int $count = 8): array
{
    $codes = [];
    for ($i = 0; $i < $count; $i++) {
        $codes[] = strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(4)));
    }
    return $codes;
}

function totp_hash_recovery(array $codes): array
{
    return array_map(static fn(string $c): string => password_hash($c, PASSWORD_BCRYPT), $codes);
}

function totp_consume_recovery(array &$hashes, string $code): bool
{
    $code = strtoupper(trim($code));
    foreach ($hashes as $i => $hash) {
        if (is_string($hash) && password_verify($code, $hash)) {
            unset($hashes[$i]);
            $hashes = array_values($hashes);
            return true;
        }
    }
    return false;
}
