(() => {
  const api = (path, body, method) => {
    const opts = {
      method: method || (body ? 'POST' : 'GET'),
      credentials: 'same-origin',
      headers: { Accept: 'application/json' }
    };
    if (body instanceof FormData) {
      opts.body = body;
      if (window.CSRF) body.append('csrf', window.CSRF);
    } else if (body) {
      opts.headers['Content-Type'] = 'application/json';
      if (window.CSRF) body.csrf = window.CSRF;
      opts.headers['X-CSRF-TOKEN'] = window.CSRF || '';
      opts.body = JSON.stringify(body);
    } else if (window.CSRF) {
      opts.headers['X-CSRF-TOKEN'] = window.CSRF;
    }
    return fetch(path, opts).then(async (r) => {
      const data = await r.json().catch(() => ({ ok: false, error: 'Bad response' }));
      if (!r.ok || data.ok === false) {
        throw new Error(data.error || 'Request failed');
      }
      if (data.csrf) window.CSRF = data.csrf;
      return data;
    });
  };

  const toast = (msg) => {
    let el = document.querySelector('.toast');
    if (!el) {
      el = document.createElement('div');
      el.className = 'toast';
      el.setAttribute('role', 'status');
      el.setAttribute('aria-live', 'polite');
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 3200);
  };

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  const boot = async () => {
    try {
      const me = await api('/api/auth_api.php?action=me');
      window.CSRF = me.csrf;
      window.USER = me.user;
      return me;
    } catch (e) {
      return { user: null };
    }
  };

  const requireAuth = async (roles) => {
    const me = await boot();
    if (!me.user) {
      location.href = '/dashboard/dash_login.html';
      throw new Error('auth');
    }
    if (me.user.twofa_required) {
      location.href = '/dashboard/dash_login.html';
      throw new Error('2fa');
    }
    if (roles && !roles.includes(me.user.role)) {
      location.href = me.user.role === 'user' ? '/dashboard/dash_user.html' : '/dashboard/dash_admin.html';
      throw new Error('role');
    }
    return me.user;
  };

  const logout = async () => {
    try { await api('/api/auth_api.php?action=logout', { action: 'logout' }); } catch (e) {}
    location.href = '/dashboard/dash_login.html';
  };

  const bindLogout = () => {
    $$('[data-logout]').forEach((b) => b.addEventListener('click', (e) => {
      e.preventDefault();
      logout();
    }));
  };

  const fillWho = (user) => {
    $$('[data-who]').forEach((el) => { el.textContent = user.username; });
    $$('[data-role]').forEach((el) => { el.textContent = user.role.replace('_', ' '); });
  };

  const table = (el, headers, rows, emptyMsg) => {
    if (!el) return;
    if (!rows.length) {
      el.innerHTML = `<div class="empty"><strong>Nothing here yet</strong>${emptyMsg || 'Records will appear after the first action.'}</div>`;
      return;
    }
    el.innerHTML = `<div class="table-wrap"><table class="data"><thead><tr>${headers.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
  };

  const bindShell = (user) => {
    const drawer = $('#drawer');
    const drawerBack = $('#drawer-back');
    const dock = $('#chat-dock');
    const dockBack = $('#dock-back');
    const openDrawer = (on) => {
      if (!drawer) return;
      drawer.classList.toggle('open', on);
      if (drawerBack) drawerBack.classList.toggle('open', on);
    };
    const openDock = (on) => {
      if (!dock) return;
      dock.classList.toggle('open', on);
      if (dockBack) dockBack.classList.toggle('open', on);
    };
    $$('[data-ham]').forEach((b) => b.addEventListener('click', () => openDrawer(true)));
    $$('[data-close-drawer]').forEach((b) => b.addEventListener('click', () => openDrawer(false)));
    if (drawerBack) drawerBack.addEventListener('click', () => openDrawer(false));
    $$('[data-chat-open]').forEach((b) => b.addEventListener('click', () => { openDrawer(false); openDock(true); if (window.UBD.onChatOpen) window.UBD.onChatOpen(); }));
    $$('[data-close-dock]').forEach((b) => b.addEventListener('click', () => openDock(false)));
    if (dockBack) dockBack.addEventListener('click', () => openDock(false));
    fillWho(user);
    bindLogout();
  };

  window.UBD = { api, toast, $, $$, boot, requireAuth, logout, bindLogout, fillWho, table, bindShell };
})();
