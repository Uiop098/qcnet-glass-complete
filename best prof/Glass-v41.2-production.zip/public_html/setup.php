<?php
/**
 * Auto-creates tables and seeds the Master Admin.
 * Safe to re-run: uses IF NOT EXISTS / existence checks.
 */
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/bootstrap.php';

function run_setup(bool $verbose = true): array
{
    $pdo = db();
    $sqlite = is_sqlite();
    $id = $sqlite
        ? 'INTEGER PRIMARY KEY AUTOINCREMENT'
        : 'INT UNSIGNED AUTO_INCREMENT PRIMARY KEY';
    $ts = $sqlite ? 'TEXT NOT NULL' : 'DATETIME NOT NULL';
    $tsNull = $sqlite ? 'TEXT' : 'DATETIME NULL';
    $dec = $sqlite ? 'TEXT NOT NULL' : 'DECIMAL(12,2) NOT NULL';
    $engine = $sqlite ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    $statements = [];

    $statements[] = "CREATE TABLE IF NOT EXISTS tenants (
        id $id,
        name VARCHAR(80) NOT NULL,
        admin_username VARCHAR(32) NOT NULL,
        cf_app_id_encrypted TEXT,
        cf_secret_encrypted TEXT,
        payment_mode VARCHAR(16) NOT NULL DEFAULT 'sandbox',
        created_at $ts
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS users (
        id $id,
        tenant_id INT UNSIGNED NULL,
        role VARCHAR(24) NOT NULL DEFAULT 'user',
        username VARCHAR(32) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        email VARCHAR(160) NOT NULL UNIQUE,
        dob VARCHAR(10) NOT NULL,
        status VARCHAR(16) NOT NULL DEFAULT 'active',
        paid INT UNSIGNED NOT NULL DEFAULT 0,
        totp_secret TEXT,
        totp_enabled INT UNSIGNED NOT NULL DEFAULT 0,
        totp_recovery TEXT,
        last_login_at $tsNull,
        last_login_ip VARCHAR(45) NOT NULL DEFAULT '',
        created_at $ts
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS products (
        id $id,
        tenant_id INT UNSIGNED NOT NULL,
        name VARCHAR(120) NOT NULL,
        price $dec,
        description VARCHAR(500) NOT NULL DEFAULT '',
        created_at $ts
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS orders (
        id $id,
        tenant_id INT UNSIGNED NULL,
        user_id INT UNSIGNED NULL,
        amount $dec,
        status VARCHAR(24) NOT NULL DEFAULT 'CREATED',
        cashfree_session VARCHAR(191) NOT NULL DEFAULT '',
        cashfree_order_id VARCHAR(80) NOT NULL DEFAULT '',
        kind VARCHAR(24) NOT NULL DEFAULT 'product',
        product_id INT UNSIGNED NULL,
        buyer_email VARCHAR(160) NOT NULL DEFAULT '',
        created_at $ts
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS chat_rooms (
        id $id,
        tenant_id INT UNSIGNED NULL,
        room_name VARCHAR(64) NOT NULL,
        pin_hash VARCHAR(255) NOT NULL DEFAULT '',
        host_password_hash VARCHAR(255) NOT NULL DEFAULT '',
        kind VARCHAR(16) NOT NULL DEFAULT 'room',
        peer_a INT UNSIGNED NULL,
        peer_b INT UNSIGNED NULL,
        created_at $ts
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS chat_messages (
        id $id,
        room_id INT UNSIGNED NOT NULL,
        sender_username VARCHAR(32) NOT NULL,
        message_text TEXT NOT NULL,
        media_url VARCHAR(255) NOT NULL DEFAULT '',
        msg_type VARCHAR(16) NOT NULL DEFAULT 'text',
        extra TEXT,
        expires_at $ts
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS otp_recovery (
        id $id,
        email VARCHAR(160) NOT NULL,
        dob VARCHAR(10) NOT NULL,
        otp_code VARCHAR(6) NOT NULL,
        expires_at $ts,
        cooldown_until $ts
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS rate_limits (
        bucket_key VARCHAR(120) PRIMARY KEY,
        hits INT UNSIGNED NOT NULL DEFAULT 1,
        window_start INT NOT NULL
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS settings (
        k VARCHAR(64) PRIMARY KEY,
        v TEXT NOT NULL
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS chat_reactions (
        id $id,
        message_id INT UNSIGNED NOT NULL,
        username VARCHAR(32) NOT NULL,
        emoji VARCHAR(8) NOT NULL,
        created_at $ts
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS admin_tokens (
        id $id,
        token_hash VARCHAR(64) NOT NULL UNIQUE,
        token_hint VARCHAR(12) NOT NULL,
        created_by INT UNSIGNED NOT NULL,
        used_by INT UNSIGNED NULL,
        role VARCHAR(24) NOT NULL DEFAULT 'tenant_admin',
        expires_at $ts,
        used_at $tsNull,
        created_at $ts
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS twofa_pending (
        token VARCHAR(64) PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        expires_at INT NOT NULL
    )$engine";

    $statements[] = "CREATE TABLE IF NOT EXISTS chat_requests (
        id $id,
        from_id INT UNSIGNED NOT NULL,
        to_id INT UNSIGNED NOT NULL,
        token_hash VARCHAR(64) NOT NULL,
        token_hint VARCHAR(12) NOT NULL,
        status VARCHAR(16) NOT NULL DEFAULT 'pending',
        room_id INT UNSIGNED NULL,
        expires_at $ts,
        created_at $ts
    )$engine";

    foreach ($statements as $sql) {
        $pdo->exec($sql);
    }

    migrate_columns($pdo, $sqlite);

    $indexes = [
        'CREATE INDEX IF NOT EXISTS idx_users_tenant ON users (tenant_id)',
        'CREATE INDEX IF NOT EXISTS idx_products_tenant ON products (tenant_id)',
        'CREATE INDEX IF NOT EXISTS idx_orders_tenant ON orders (tenant_id)',
        'CREATE INDEX IF NOT EXISTS idx_orders_status ON orders (status)',
        'CREATE INDEX IF NOT EXISTS idx_chat_room ON chat_messages (room_id)',
        'CREATE INDEX IF NOT EXISTS idx_chat_exp ON chat_messages (expires_at)',
        'CREATE INDEX IF NOT EXISTS idx_otp_email ON otp_recovery (email)',
        'CREATE INDEX IF NOT EXISTS idx_rooms_name ON chat_rooms (room_name)',
        'CREATE INDEX IF NOT EXISTS idx_admin_tokens_hash ON admin_tokens (token_hash)',
        'CREATE INDEX IF NOT EXISTS idx_chat_req_to ON chat_requests (to_id)',
        'CREATE INDEX IF NOT EXISTS idx_chat_req_from ON chat_requests (from_id)',
        'CREATE INDEX IF NOT EXISTS idx_twofa_exp ON twofa_pending (expires_at)',
    ];
    foreach ($indexes as $sql) {
        try {
            $pdo->exec($sql);
        } catch (Throwable $e) {
            if (!$sqlite) {
                $alt = str_replace('IF NOT EXISTS ', '', $sql);
                try {
                    $pdo->exec($alt);
                } catch (Throwable $e2) {
                }
            }
        }
    }

    $st = $pdo->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
    $st->execute([MASTER_USERNAME]);
    $master = $st->fetch();
    $created = false;

    if (!$master) {
        $pdo->beginTransaction();
        $pdo->prepare('INSERT INTO tenants (name, admin_username, payment_mode, created_at) VALUES (?, ?, ?, ?)')
            ->execute(['Master Workspace', MASTER_USERNAME, 'sandbox', now_sql()]);
        $tenantId = (int) $pdo->lastInsertId();
        $hash = password_hash(MASTER_PASSWORD, PASSWORD_BCRYPT);
        $pdo->prepare('INSERT INTO users (tenant_id, role, username, password_hash, email, dob, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$tenantId, 'master', MASTER_USERNAME, $hash, MASTER_EMAIL, MASTER_DOB, now_sql()]);
        $pdo->prepare('INSERT INTO chat_rooms (tenant_id, room_name, pin_hash, host_password_hash, created_at) VALUES (?, ?, ?, ?, ?)')
            ->execute([$tenantId, 'lobby', password_hash('0000', PASSWORD_BCRYPT), $hash, now_sql()]);
        $pdo->prepare('INSERT INTO products (tenant_id, name, price, description, created_at) VALUES (?, ?, ?, ?, ?)')
            ->execute([$tenantId, 'Starter CRM Seat', '99.00', 'Single-user CRM seat for your workspace', now_sql()]);
        $pdo->commit();
        $created = true;
    }

    $result = [
        'ok' => true,
        'driver' => DB_DRIVER,
        'master_seeded' => $created,
        'master_username' => MASTER_USERNAME,
        'hint' => $created ? 'Default master password is Glassv41!Master — change it after first login.' : 'Schema already present.',
    ];

    if ($verbose && php_sapi_name() !== 'cli' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
        return $result;
    }
    return $result;
}

function column_exists(PDO $pdo, string $table, string $column): bool
{
    if (is_sqlite()) {
        $st = $pdo->query('PRAGMA table_info(' . $table . ')');
        foreach ($st->fetchAll() as $row) {
            if (($row['name'] ?? '') === $column) {
                return true;
            }
        }
        return false;
    }
    $st = $pdo->prepare('SHOW COLUMNS FROM `' . str_replace('`', '', $table) . '` LIKE ?');
    $st->execute([$column]);
    return (bool) $st->fetch();
}

function migrate_columns(PDO $pdo, bool $sqlite): void
{
    $alters = [
        ['users', 'status', $sqlite ? "ALTER TABLE users ADD COLUMN status VARCHAR(16) NOT NULL DEFAULT 'active'" : "ALTER TABLE users ADD COLUMN status VARCHAR(16) NOT NULL DEFAULT 'active'"],
        ['users', 'paid', $sqlite ? 'ALTER TABLE users ADD COLUMN paid INTEGER NOT NULL DEFAULT 0' : 'ALTER TABLE users ADD COLUMN paid INT UNSIGNED NOT NULL DEFAULT 0'],
        ['users', 'totp_secret', 'ALTER TABLE users ADD COLUMN totp_secret TEXT'],
        ['users', 'totp_enabled', $sqlite ? 'ALTER TABLE users ADD COLUMN totp_enabled INTEGER NOT NULL DEFAULT 0' : 'ALTER TABLE users ADD COLUMN totp_enabled INT UNSIGNED NOT NULL DEFAULT 0'],
        ['users', 'totp_recovery', 'ALTER TABLE users ADD COLUMN totp_recovery TEXT'],
        ['users', 'last_login_at', $sqlite ? 'ALTER TABLE users ADD COLUMN last_login_at TEXT' : 'ALTER TABLE users ADD COLUMN last_login_at DATETIME NULL'],
        ['users', 'last_login_ip', "ALTER TABLE users ADD COLUMN last_login_ip VARCHAR(45) NOT NULL DEFAULT ''"],
        ['chat_rooms', 'kind', $sqlite ? "ALTER TABLE chat_rooms ADD COLUMN kind VARCHAR(16) NOT NULL DEFAULT 'room'" : "ALTER TABLE chat_rooms ADD COLUMN kind VARCHAR(16) NOT NULL DEFAULT 'room'"],
        ['chat_rooms', 'peer_a', $sqlite ? 'ALTER TABLE chat_rooms ADD COLUMN peer_a INTEGER' : 'ALTER TABLE chat_rooms ADD COLUMN peer_a INT UNSIGNED NULL'],
        ['chat_rooms', 'peer_b', $sqlite ? 'ALTER TABLE chat_rooms ADD COLUMN peer_b INTEGER' : 'ALTER TABLE chat_rooms ADD COLUMN peer_b INT UNSIGNED NULL'],
    ];
    foreach ($alters as [$table, $col, $sql]) {
        if (column_exists($pdo, $table, $col)) {
            continue;
        }
        try {
            $pdo->exec($sql);
        } catch (Throwable $e) {
        }
    }
}

if (php_sapi_name() === 'cli' && (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__ || (isset($argv[0]) && realpath($argv[0]) === __FILE__))) {
    $out = run_setup(true);
    echo json_encode($out, JSON_PRETTY_PRINT) . PHP_EOL;
    exit;
}

if (php_sapi_name() !== 'cli' && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    $out = run_setup(true);
    if (!empty($_GET['json']) || (isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'))) {
        header('Content-Type: application/json');
        echo json_encode($out);
        exit;
    }
    $msg = htmlspecialchars($out['hint'], ENT_QUOTES);
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Setup</title>
    <style>body{font-family:Inter,sans-serif;background:#12121E;color:#F8FAFC;display:grid;place-items:center;min-height:100vh;margin:0}
    .card{background:rgba(255,255,255,.08);backdrop-filter:blur(24px);padding:32px;border-radius:20px;max-width:480px}
    a{color:#4ADE80}</style></head><body><div class="card"><h1>Setup complete</h1>
    <p>' . $msg . '</p><p>User: <code>master</code></p>
    <p><a href="gateway.html">Open Gateway</a></p></div></body></html>';
    exit;
}
